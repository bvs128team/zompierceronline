using System;
using System.IO;
using System.Text;

namespace ZompiercerLAN
{
    internal enum PacketKind : byte { Hello=1, Welcome=2, State=3, Busy=4, VersionMismatch=5, Heartbeat=6, TrainMotion=7, TrainLayoutChunk=8, TrainLayoutAck=9, WorldState=10, ZombieState=11, ZombieAction=12, ZombieHurt=13, ZombieHurtAck=14, CombatProposal=15, CombatState=16, CombatReload=17,
        // Schema 10 (0.5.0): guest profile persistence on the host.
        IdentityRequest=18, IdentityProof=19, GuestStatus=20, GuestStateChunk=21, GuestStateAck=22, GuestRestoreChunk=23, GuestRestoreAck=24,
        // Schema 11 (0.6.0): host-authoritative shared storages.
        StorageRequest=25, StorageResult=26, StorageViewChunk=27, StorageViewAck=28,
        // Schema 12 (0.6.1): zombie corpses, world doors.
        ZombieCorpse=29, DoorStates=30, DoorToggle=31,
        // Schema 13 (0.7.0): loose items and loot bags of the host's world.
        // Schema 14 (0.8.0): no new kinds; storage request 9 (build) and work kind 5 (refuel).
        // Schema 15 (0.8.1): storage request 10 (place a blueprint), result statuses up to 20.
        WorldItems=32,
        // Schema 16 (0.10.0): marks of either player; storage request 11 (train controls);
        // the train frame carries the cab's state and whether the host lets the guest drive.
        Mark=33,
        // Schema 17 (0.11.0): text chat (LanChatChannel), not bound to a world.
        // Schema 18 (0.12.0): no new kinds; storage request 12 (the guest died), train flag 64 (the host is dead).
        // Schema 19 (1.0.1): a zombie frame also carries its animator's bool parameters, so the
        // guest's copy follows the host's state machine instead of falling back to idle.
        // Schema 20 (1.0.7): zombie batches carry the host clock; car-relative zombie actions.
        // Schema 21 (1.0.8): a player state carries its health; a zombie action its loudness.
        // Schema 22 (1.1.0): a player state carries where it looks up or down and whether it crouches;
        // its shot counter also counts melee swings.
        // Schema 23 (1.1.1): the player state's pose also says whether it aims down the sights.
        // Schema 24 (1.1.5): a workbench's storage view carries its craft queue and progress;
        // storage request 13 cancels one queued craft (the guest uses the game's craft window).
        Chat=34,
        // Schema 25 (1.1.6): a player state carries its health points and chosen look; a guest swing
        // may be a bare fist (item -1); control 6 opens or closes a train door; world items of kind 3
        // are the host's carryable objects (barrels, robot dogs). A zombie's visible effect
        // (a spit, a burst stomach) reaches the guest.
        // Schema 26 (1.1.8): a zombie frame's Flags also carry the firefighter's flamethrower (firing,
        // in which hand) and its burning hands; ZombieEffect 3 is the nurse's thrown healing smoke.
        ZombieEffect=35,
        // Schema 27 (1.1.9): a player state says whether the player lies downed or dead, its
        // flashlights and a reload, and carries its nickname; Revive: the partner is reviving
        // (ReviveHold, while the use key is held) or has revived (ReviveDone) a downed player.
        Revive=36,
        // Schema 28 (1.2.0): the host's quests (QuestStates) reach the guest; storage request 14 asks
        // the host to accept or hand in a quest; a door frame says whether the door is locked and a
        // door toggle may unlock it with the guest's key (DoorUnlock, Revision: the key item).
        // Schema 29 (1.2.1): a carryable object's frame says who holds it and whose robot dog it is;
        // storage request 15 carries objects and drives the guest's own robot dog; storage target 4
        // is a slot of that dog.
        QuestStates=37,
        // Schema 30 (1.2.2): Explosion: a host barrel catches fire or a host explosive goes off
        // (Text: its prefab, X/Y/Z: where); Sleep: a player lies down to sleep, gets up, or the host
        // starts the shared sleep (Revision: hours); work kinds 6-8 fill bottles at, pour bottles into
        // or read the rainwater tank of the host's train.
        Explosion=38, Sleep=39,
        // Schema 31 (1.4.0): no new kinds; storage request 16 throws the guest's grenade, dynamite
        // or C4 in the host's world, storage request 17 paints, wires or letters the host's train
        // (and the train layout carries paint, wires and sign texts).
        // Schema 32 (1.4.2): no new kinds; storage request 18 places the guest's furniture kit on the
        // host's train, storage request 19 takes a part or furniture apart (or a blueprint away);
        // result status 23: the object still holds something.
        // Schema 33 (1.4.3): no new kinds; a zombie's melee hit on the guest is its own ZombieHurt
        // (Action HurtMelee, Text: the zombie's prefab when its hit carries the prefab's effects),
        // the train frame carries the main tank's fuel and the fuel stations near the guest
        // (StationFrame), takable op 6 (StationUse) works a station's lever, pump and fuel gun.
        // Schema 34 (1.4.4): SceneStates: how the host's location objects stand (walls blown up, trap
        // walls, collapsed floors, bridges, drained swamps, world levers and buttons, resources picked
        // clean: SceneFrame by the game's ObjectID); SceneUse: the guest's lever, trap or bridge in the
        // host's world (Revision: ObjectID, Action: what). WorldState carries the host's difficulty.
        SceneStates=40, SceneUse=41,
        // Schema 35 (1.4.5): Leave: the player leaves the game (no waiting 30 s for silence); a quest
        // frame may say the guest has the reward of a quest the host handed in (QuestShared); scene
        // objects 8 (taken apart for resources, by place) and 9 (presence triggers, the guest may set
        // one off); storage quest request 3 claims that reward.
        Leave=42,
        // Schema 39 (2.0.0, up to four players): Players: the host's view of the other guests (their
        // states, each with its slot) for one guest; Welcome tells the guest its slot; Chat, Mark,
        // Revive and Sleep carry the slot of the player they come from (Revive: or go to).
        // Schema 46 (2.3.0): no new kinds; a player's state names what it wears (Outfit).
        // Schema 47 (2.4.0): no new kinds; a player's state names the mods on the weapon in its hands (HandMods).
        // Schema 48 (2.4.2): no new kinds; WorldState names the host's weather (Weather).
        Players=43, SleepAck=44,
        // Schema 49 (2.4.4): FarmStates: the garden beds of the host's train (FarmFrame); work kinds 9-14 (a blow on a
        // fallen tree, a hit on a host barrel, the beds' water, fertilizer, seeds and crops), storage target 3 (a box of a
        // car itself, as the cab's), scene object 10 (how worn an object being taken apart or chopped is).
        FarmStates=45,
        // Schema 51 (2.5.6): bounded application RTT probes/echoes and host roster reports.
        Latency=46,
        // Schema 54 (2.8.0, game 22.0): AnimalState: the host's animals near the guest (AnimalFrame); a hit claim says whether
        // it met a zombie or an animal (HitClaim.Animal); ZombieHurt HurtAnimal: an animal's bite; work kinds 15 and 16
        // (butcher a carcass, catch an animal by hand).
        AnimalState=47
        }
    // A dead zombie's ragdoll: root pose and the world pose of each rigid bone,
    // in the order of the shared prefab's ZombieDamagDetector.rigidElements.
    internal sealed class CorpseFrame
    {
        internal uint Id;
        internal string Prefab;
        internal float X,Y,Z,Yaw;
        internal NetPose[] Bones;
    }
    // A scene door (DoorController) identified by its position; Flags: 1 open, 2 broken, 4 locked (schema 28).
    internal sealed class DoorFrame { internal float X,Y,Z; internal byte Flags; }
    // A location object of the host's scene (schema 34): the game's ObjectID, what it is (SceneBomb ..
    // SceneResource), Flags 1 when it is done (blown up, closed, collapsed, raised, draining, switched on,
    // picked clean), Value the drained time of a swamp (0 otherwise).
    internal sealed class SceneFrame { internal int Id; internal byte Kind,Flags; internal float Value; }
    // A garden bed (FarmTray) of the host's train (schema 49): its car, the host's id of its furniture, Flags 1 watered,
    // 2 fertilized; Water: bottles still to pour, Fertilize: fertilizer left for seeds; its points in the bed's order.
    internal sealed class FarmFrame { internal byte Car; internal int Identity; internal byte Flags,Water,Fertilize; internal FarmPoint[] Points; }
    // A point of a bed: Plant 0 empty, else 1 + its index in ItemsDataBase.FarmPlants; its growth stage, Flags 1 grown,
    // Growth in thousandths, Efficiency in percent (the game's tip).
    internal sealed class FarmPoint { internal byte Plant,Stage,Flags,Efficiency; internal ushort Growth; }
    // The host's difficulty the guest plays by (schema 34): zombie damage, weapon recoil and aim wobble,
    // whether players are shown on the map.
    internal sealed class DifficultySnapshot { internal float ZombieDamage,Recoil,Wobble; internal bool ShowOnMap; }
    // A quest of the host's scene (schema 28): Key is LanQuests.Key of its place in the scene,
    // Flags QuestAccepted/QuestReady/QuestCompleted, Stage its current stage (-1: none).
    internal sealed class QuestFrame { internal uint Key; internal byte Flags; internal sbyte Stage; }
    // A loose item (Kind 0) or loot bag (Kind 1) of the host's world near the guest,
    // or the removal of one (Kind 2). HostId is the host's instance id of the object.
    // Devices (schema 40, 1.4.13): a robot dog's frame (kind 3, the dog's prefab) also says what its device slots
    // hold, slot by slot up to the last one in use: the RobotDevice id the game spawns there, NoDevice: empty.
    internal sealed class WorldItemFrame { internal int HostId,ItemId,Amount; internal byte Kind; internal NetPose Pose; internal byte[] Devices; }
    internal sealed class ZombieFrame
    {
        internal uint Id;
        internal string Prefab;
        internal float X,Y,Z,Yaw,Health,AnimationTime;
        internal int Animation;
        internal uint AnimationFlags; // bool parameters of the zombie's animator, in controller order (schema 19)
        // ZombieStateBits: 0 alive, 1 dead, 2 deactivated, 3 destroyed; an alive zombie's other bits
        // are what it shows (ZombieFlameFiring .. ZombieHandFire1, schema 26).
        internal byte Flags;
    }
    internal sealed class NetPose { internal float X,Y,Z,QX,QY,QZ,QW; }
    internal sealed class CarPose { internal NetPose Root,Body,Front,Back; }
    internal sealed class TrainFrame
    {
        internal uint Sequence;
        internal int Revision;
        internal string Scene;
        internal float Speed,Thrust;
        // 1 engine, 2 brake, 4 reverse, 8 horn, 16 spotlight, 32 the guest may drive (0.10.0),
        // 64 the host's player is dead (0.12.0).
        internal byte Flags;
        // The train's own controls (LanTrainControl order): button states, broken buttons,
        // cab light switches, lever values.
        internal uint Buttons,Broken;
        internal ushort Lights;
        internal float[] Levers=new float[0];
        internal CarPose[] Cars;
        // Schema 33 (1.4.3): the main tank's fuel and capacity (capacity 0: no tank), and the
        // fuel stations near the guest.
        internal float Fuel,FuelMax;
        internal StationFrame[] Stations=new StationFrame[0];
    }
    // A fuel station of the host's scene (schema 33). Key: LanFuelStation.Key of its place,
    // Flags StationActive/StationLever/StationPump/StationPumping, Gun where its fuel gun is
    // (GunAtStation .. GunLoose), GunPose its world pose when a player holds it or it hangs loose.
    // 1.5.0 (schema 41): a hit the guest saw on its own screen: the host's zombie, the place of the limb's
    // LimbDetector in its prefab, the point the round or blade met it and the way it went in (both in that limb's own
    // space), and where the guest saw that point (world). The host checks it against its own zombie.
    // 2.8.0 (schema 54): Animal: Zombie is the host's animal id and Limb the place of the AnimalPartDetector in its prefab.
    internal sealed class HitClaim { internal uint Zombie; internal bool Animal; internal byte Limb; internal float LX,LY,LZ,DX,DY,DZ,WX,WY,WZ; }
    // 2.8.0 (schema 54): an animal of the host's world (game 22.0) near the guest. Id: the host's number of it; Prefab: the
    // name of the prefab its spawner makes. Flags: AnimalStateBits (0 alive, 1 dead, 2 gone: caught, cut up or despawned),
    // AnimalBleeding, AnimalButcher (its carcass can be cut), AnimalCatch (it can be caught by hand). Animation and
    // AnimationTime: the state of its animator's base layer; Speed and Idle: its "speed" and "idleIndex" parameters; Bools:
    // its bool parameters in controller order (at most 8). Voice and Steps: the clip its voice and its steps play (its
    // prefab's clips' index + 1, 0: none), VoiceCount and StepsCount: how many each has started (wraps; a new count plays it
    // once), Loops: AnimalVoiceLoop, AnimalStepsLoop. Left: what its carcass still gives of each of its resources, or null.
    internal sealed class AnimalFrame
    {
        internal uint Id;
        internal string Prefab;
        internal float X,Y,Z,Yaw,AnimationTime,Speed;
        internal int Animation;
        internal sbyte Idle;
        internal byte Flags,Bools,Voice,VoiceCount,Steps,StepsCount,Loops;
        internal byte[] Left;
    }
    internal sealed class StationFrame { internal int Key; internal float Fuel; internal byte Flags,Gun; internal NetPose GunPose; }
    // 2.1.0 (schema 44): an other guest present at the host: its slot and the secure session of whoever sits there.
    internal sealed class PlayerSeat { internal byte Player; internal ulong Session; }
    internal struct LatencySeat { internal byte Slot; internal ulong Session; internal int Milliseconds; }
    internal sealed class Packet
    {
        internal PacketKind Kind;
        internal string GameVersion;
        internal ulong Session;
        internal ulong LatencyNonce;
        internal LatencySeat[] LatencySeats;
        internal uint WorldEpoch;
        internal uint Sequence;
        internal uint SleepAttempt;
        // Players (schema 44): every other guest present (the states in Players are some of them).
        internal PlayerSeat[] Roster;
        internal string Scene;
        internal float X,Y,Z,Yaw,TrainPosition;
        internal int CarIndex=-1;
        internal float LocalX,LocalY,LocalZ,LocalYaw;
        // State: ShotItemId is the item of the last shot; 1.5.0: while Motion says the player eats or drinks (UseEat,
        // UseDrink), the item eaten or drunk (the partner shows it in hand; an older partner only shows shots of it).
        internal int EquippedItemId=-1, ShotItemId=-1;
        internal uint ShotSequence;
        internal TrainFrame Train;
        internal int Revision,ChunkIndex,ChunkCount;
        internal byte[] Chunk;
        internal int Location, RailsId=-1;
        internal ClockSnapshot Clock;
        // WorldState (schema 34): the host's difficulty, or null.
        internal DifficultySnapshot Difficulty;
        // WorldState (schema 48): the name of the host's weather preset, or null.
        internal string Weather;
        // SceneStates (schema 34).
        internal SceneFrame[] SceneObjects;
        // FarmStates (schema 49).
        internal FarmFrame[] Farms;
        internal ZombieFrame[] Zombies;
        // AnimalState (schema 54).
        internal AnimalFrame[] Animals;
        internal float AimX,AimY,AimZ,Damage;
        internal float PowerfulStun;
        // ZombieAction (schema 41, 1.5.0): what the shot's rounds or the swing hit on the guest's screen.
        internal HitClaim[] Hits;
        // ZombieAction: 1–255 for a bow's draw from empty to full. Zero for other weapons.
        internal byte BowDraw;
        // ZombieState (schema 20): the host clock when the batch was taken, for client interpolation.
        internal float HostTime;
        // State (schema 21): the player's health in percent, or NoHealth. ZombieAction: the shot's
        // loudness in percent of the gun's hearing radius (less with a silencer).
        internal byte Health=LanProtocol.NoHealth, Noise=100;
        // State (schema 22): the view's pitch in degrees (up positive); pose flags PoseCrouch, PoseAim (23).
        internal float Pitch;
        internal byte Pose;
        // State (schema 25): health points as the game's own bar shows them (max 0: unknown), and
        // the look the player chose (NPCManager.ModelName, NoSkin: the default).
        internal ushort HealthNow, HealthMax;
        internal byte Skin=LanProtocol.NoSkin;
        // State (schema 27): the nickname the player typed (LanProtocol.ValidName; empty: none).
        internal string Name="";
        // State (schema 36): the sender's clock in milliseconds when it was sent (positions are shown
        // on it), and its dash (the game's dodge on Space): DashCount times 8 plus the direction
        // (DashForward .. clockwise in eighths); a new count is a new dash, 0 none yet.
        internal uint SentAt;
        internal byte Dash;
        // State (schema 37): how the player moves (MotionRun, MotionAir, MotionSwim, MotionCock and
        // what it uses, the use kind times 16) and a count of its throws (wraps; a new count is a throw).
        internal byte Motion, Throws;
        // Schema 39 (2.0.0): a player's slot (0: the host, 1..3: guests), see Players.
        internal byte Player;
        internal Packet[] Players;
        // State (schema 38): a count of the player's presses of the use key in play (wraps; a new count
        // is a reach for a door, a lever, a button or an item on the ground).
        internal byte Interacts;
        // State (schema 46, 2.3.0): the items in the player's equipment slots (helmet, mask, armour, backpack, shoes),
        // at most MaxOutfit; null: none. The partner shows them on its avatar (RemoteOutfitVisual).
        internal ushort[] Outfit;
        // State (schema 47, 2.4.0): the item in each mod slot of the weapon in the player's hands (NoMod: empty), in
        // the order of its EquipmentModsItem.Slots, at most MaxHandMods; null: none. The partner shows them on the
        // weapon in its avatar's hands; the host takes the guest's unit of that weapon with exactly these mods.
        internal ushort[] HandMods;
        internal byte Action;
        internal CombatWeapon[] CombatWeapons;
        internal CombatAmmo[] CombatAmmo;
        internal float Stamina;
        internal int Amount;
        internal CorpseFrame Corpse;
        internal DoorFrame[] Doors;
        internal WorldItemFrame[] Items;
        internal QuestFrame[] Quests;
        internal string Text;
    }
    internal static class LanProtocol
    {
        internal const string ModVersion = "2.8.10";
        private const uint Magic=0x4C504D5A;
        // Schema 53 (2.5.6): Motion bit 7 is cosmetic low-stamina gait; use remains bits 4..6.
        // Schema 54 (2.8.0): animals of the game 22.0 (AnimalState, HitClaim.Animal, HurtAnimal, work kinds 15-16).
        // Schema 55 (2.8.9): bow draw strength for a host-simulated arrow.
        private const byte Version=55;
        internal const byte NoHealth=255;
        internal const byte NoSkin=255, MaxSkin=35;
        // ZombieEffect: Revision is the zombie's id, Action what it did, X/Y/Z where, Aim which way.
        internal const byte EffectShot=1, EffectBurst=2, EffectThrow=3;
        // 2.2.0: a host robot dog's device: its cannon fired, its flamethrower burns (refreshed while it does) or stopped.
        // Revision = the RobotDevice id + 1 (as a dog's frame names it), not a zombie.
        internal const byte EffectDeviceShot=4, EffectFlameOn=5, EffectFlameOff=6;
        // ZombieFrame.Flags: the state, and for an alive firefighter its flamethrower (firing; held in
        // FirePosition 1 rather than 0) and its burning hands (flameParticles 0 and 1).
        internal const byte ZombieStateBits=3, ZombieFlameFiring=4, ZombieFlameHand1=8, ZombieHandFire0=16, ZombieHandFire1=32, MaxZombieFlags=63;
        // WorldItems kind 3 (a carryable object): Amount is its car + 1 (0: in the world, its pose
        // in the world; otherwise in that car's own space) plus TakableActive/Walk/Run times 256.
        internal const int TakableActive=1, TakableWalk=2, TakableRun=4, MaxTakablePrefab=4095;
        // Schema 29: held by the host's player or by the guest; a robot dog the receiving guest owns,
        // or one with an owner at all.
        internal const int TakableHeldByHost=8, TakableHeldByGuest=16, TakableYours=32, TakableClaimed=64, MaxTakableState=127;
        internal const byte PoseCrouch=1, PoseAim=2, PoseDowned=4, PoseDead=8, PoseHelmetLight=16, PoseGunLight=32, PoseReload=64, MaxPose=127;
        // State.Dash (schema 36): the low three bits the direction in eighths of a turn clockwise
        // from the player's facing, the high five a count (1..31, then 1 again) of its dashes.
        internal const int DashDirections=8, MaxDashCount=31;
        internal static bool ValidDash(byte dash) { return (dash>>3)<=MaxDashCount && ((dash>>3)!=0 || (dash&7)==0); }
        // 2.0.0: slots of the players (the host is 0) and how many other players one Players packet shows.
        // 2.1.0: up to eight players (the host and seven guests); a guest hears of up to six others.
        internal const int MaxPlayers=8, MaxOthers=MaxPlayers-2;
        internal static bool ValidPlayer(byte slot) { return slot<MaxPlayers; }
        // State.Motion (schema 37): running, in the air (a jump or a fall), swimming, a throw held
        // back (the throwing phase before the release); bits 4..6 the item being used.
        internal const byte MotionRun=1, MotionAir=2, MotionSwim=4, MotionCock=8, UseShift=4, MotionTired=128;
        internal const byte UseNone=0, UseEat=1, UseDrink=2, UseBandage=3, UseMedicine=4, MaxUse=4;
        internal static byte MotionUse(byte motion) { return (byte)((motion >> UseShift) & 7); }
        internal static bool ValidMotion(byte motion) { return MotionUse(motion)<=MaxUse; }
        internal const byte ReviveHold=1, ReviveDone=2;
        // DoorToggle (schema 28): 0 close, 1 open, DoorUnlock unlock with key item Revision.
        internal const byte DoorUnlock=2, DoorOpenFlag=1, DoorBrokenFlag=2, DoorLockedFlag=4, MaxDoorFlags=7;
        // SceneStates and SceneUse (schema 34). A guest may use a button, set off a trap wall or a
        // collapsing floor, or raise a bridge; the rest only the host's world does.
        internal const int MaxSceneBatch=32;
        internal const byte SceneBomb=1, SceneTrap=2, SceneCollapse=3, SceneActivator=4, SceneDrainer=5, SceneButton=6, SceneResource=7,
            SceneParsed=8, SceneTrigger=9, SceneWear=10, SceneLoot=11, SceneLid=12, SceneFireworks=13,
            SceneSeasonal=14, SceneEvent=15, SceneSeasonProgress=16, MaxSceneKind=16;
        // 2.4.4: SceneWear: how worn an object of the location being taken apart or chopped is, by its load place key:
        // Flags 1: its hit points left (a fallen tree), 0: its durability left (a chair, a wreck).
        // 2.5.0 (schema 50): SceneLoot: a location's loot cabinet behind a door, by its place key: Flags 1 searched
        // (Inventory.wasChecked), 2 empty; what the game's hover writes on it (EMPTY / NOT EMPTY).
        internal const byte MaxLootFlags=3;
        // FarmStates (schema 49): up to 8 beds a packet. The shipped large bed
        // (PlantBoxLargeCraft, furniture 61) has 17 points; a limit of 16 hid all its plants.
        internal const int MaxFarmBatch=8, MaxFarmPoints=17, MaxFarmPlants=64;
        internal const byte MaxFarmStage=16, MaxFarmFlags=3;
        internal static bool ValidFarmFrame(FarmFrame f)
        {
            if(f==null || f.Car>=MaxCars || f.Identity==0 || f.Flags>MaxFarmFlags || f.Points==null || f.Points.Length==0 || f.Points.Length>MaxFarmPoints) return false;
            foreach(var pt in f.Points)
            {
                if(pt==null || pt.Plant>MaxFarmPlants || pt.Stage>MaxFarmStage || pt.Flags>1 || pt.Growth>1000 || pt.Efficiency>250) return false;
                if(pt.Plant==0 && (pt.Stage!=0 || pt.Flags!=0 || pt.Growth!=0 || pt.Efficiency!=0)) return false;
            }
            return true;
        }
        internal static bool ValidSceneFrame(SceneFrame s)
        {
            if(s==null || s.Id==0 || s.Kind<SceneBomb || s.Kind>MaxSceneKind || float.IsNaN(s.Value) || s.Value<0 || s.Value>=100000f) return false;
            if(s.Kind==SceneSeasonProgress) return (s.Id==1 || s.Id==2) && s.Value==(int)s.Value;
            if(s.Flags>(s.Kind==SceneLoot?MaxLootFlags:1)) return false;
            if(s.Kind==SceneEvent) return s.Value==(int)s.Value;
            return s.Kind==SceneDrainer || s.Kind==SceneWear || s.Value==0;
        }
        internal static bool ValidSceneUse(int id,byte kind)
        { return id!=0 && (kind==SceneTrap || kind==SceneCollapse || kind==SceneActivator || kind==SceneButton || kind==SceneTrigger || kind==SceneSeasonal || kind==SceneEvent); }
        internal static bool ValidDifficulty(DifficultySnapshot d)
        {
            if(d==null) return true;
            foreach(float v in new[] {d.ZombieDamage,d.Recoil,d.Wobble}) if(float.IsNaN(v) || v<0 || v>10) return false;
            return true;
        }
        // 2.4.2: a weather preset's name ("Clear Sky", "Cloudy 1"): ASCII letters, digits, spaces, '_', '-', '(' and ')'.
        internal const int MaxWeatherName=32;
        internal static bool ValidWeather(string name)
        {
            if(name==null) return true;
            if(name.Length==0 || name.Length>MaxWeatherName) return false;
            foreach(char c in name)
                if(!((c>='a' && c<='z') || (c>='A' && c<='Z') || (c>='0' && c<='9') || c==' ' || c=='_' || c=='-' || c=='(' || c==')')) return false;
            return true;
        }
        internal const int MaxKeyItem=65535;
        // QuestStates (schema 28).
        internal const byte QuestAccepted=1, QuestReady=2, QuestCompleted=4, QuestShared=8, QuestGifts=16, MaxQuestFlags=31;
        // Explosion and Sleep (schema 30).
        internal const byte ExplosionFire=1, ExplosionBlast=2, SleepWait=1, SleepCancel=2, SleepStart=3;
        internal const int MaxSleepHours=24, MaxExplosiveName=64;
        internal const int MaxQuestBatch=64, MaxQuestStage=63;
        internal const int MaxNameChars=16, MaxNameBytes=64;
        // State (schema 46): at most this many items the player wears.
        internal const int MaxOutfit=8;
        // State (schema 47): at most this many mod slots of the weapon in hand; NoMod: an empty slot.
        internal const int MaxHandMods=6;
        internal const ushort NoMod=ushort.MaxValue;
        internal const float MaxPitch=90f;
        internal const int MaxCorpseBones=24, MaxDoorBatch=64, MaxItemBatch=24;
        // 1.4.13: a robot dog's device slots in its frame (NoDevice: empty); a batch's frames take at most
        // MaxItemBytes (with the longest version and scene names the packet stays within 1200 bytes).
        internal const int MaxDogDevices=16, MaxItemBytes=1000;
        internal const byte NoDevice=255;
        internal static bool DogFrame(WorldItemFrame it) { return it.Kind==3 && it.ItemId==MaxTakablePrefab; }
        internal static int ItemBytes(WorldItemFrame it) { return 41+(DogFrame(it)?1+(it.Devices==null?0:it.Devices.Length):0); }
        internal const int MaxZombieBatch=8, MaxZombieIds=4096, MaxZombieReplicas=256;
        // 1.5.0: hits one shot (its rounds) or one swing (one) may claim; limbs of a zombie prefab; a limb-space coordinate.
        internal const int MaxHitClaims=12, MaxClaimLimbs=64;
        internal const float MaxClaimLocal=1000f;
        internal const int MaxCars=8, ChunkSize=900, MaxLayoutBytes=256*1024;
        internal const int MaxChunks=(MaxLayoutBytes+ChunkSize-1)/ChunkSize;
        internal const int MaxGuestBytes=64*1024, MaxGuestChunks=(MaxGuestBytes+ChunkSize-1)/ChunkSize;
        internal const int WorldIdBytes=16, ProfileTokenBytes=32, MaxStoragePayload=1000;
        internal const int MaxLevers=4;
        // Fuel stations in a train frame (schema 33).
        internal const int MaxStations=2;
        internal const byte StationActive=1, StationLever=2, StationPump=4, StationPumping=8, MaxStationFlags=15;
        internal const byte GunAtStation=0, GunHost=1, GunGuest=2, GunTank=3, GunLoose=4;
        internal static bool GunPosed(byte gun) { return gun==GunHost || gun==GunGuest || gun==GunLoose; }
        // ZombieHurt (schema 33): a zombie's melee hit, with the hit's sounds, blood and shake on the guest.
        internal const byte HurtMelee=5;
        // ZombieHurt (schema 41, 1.5.0): the bodybuilder's blow after its charge (the game's RepulsiveArea): the damage, and
        // the push that throws the player (AimX..AimZ), at most MaxChargePush long.
        internal const byte HurtCharge=6;
        // ZombieHurt (schema 45, 2.2.0): a frog's tongue grabbed the guest: the damage, and where the item it held lands
        // (AimX..AimZ: by the frog), as the game's ItemStealer drops the player's item at its tongue.
        internal const byte HurtSteal=7;
        internal const byte HurtPowerfulMelee=8;
        // ZombieHurt (schema 54, 2.8.0): an animal's bite (the game's IHasHealth.CauseDamage with its effect).
        internal const byte HurtAnimal=9;
        // 2.8.0 (schema 54): animals (AnimalFrame).
        internal const int MaxAnimalBatch=8, MaxAnimalIds=1024, MaxAnimalReplicas=96, MaxAnimalLeft=4, MaxAnimalClips=200;
        internal const byte AnimalStateBits=3, AnimalBleeding=4, AnimalButcher=8, AnimalCatch=16, MaxAnimalFlags=31;
        internal const byte AnimalVoiceLoop=1, AnimalStepsLoop=2, MaxAnimalLoops=3;
        internal const float MaxPowerfulStun=30f;
        internal static bool ValidPowerfulStun(float value) { return !float.IsNaN(value) && value>=0 && value<=MaxPowerfulStun; }
        internal const float MaxChargePush=50f;
        // Chat: Action 0 a message (Sequence = its number), 1 acknowledges every message up to Sequence.
        internal const int MaxChatChars=200, MaxChatBytes=MaxChatChars*3;
        // Marks: 0 removes the sender's mark Revision, 1 enemy, 2 find, 3 point / direction.
        internal const byte MarkClear=0, MarkEnemy=1, MarkFind=2, MarkPoint=3;
        private static readonly Encoding Text=new UTF8Encoding(false,true);
        internal const int MaxBytes=1200;
        internal static byte[] Encode(Packet p) { return Serialize(p,true); }
        // 2.1.0: the encoded size without the datagram limit (the host splits the Players states by it).
        internal static int Size(Packet p) { return Serialize(p,false).Length; }
        private static bool InRoster(PlayerSeat[] roster,byte player,ulong session)
        { foreach(var seat in roster) if(seat!=null && seat.Player==player && seat.Session==session) return true; return false; }
        private static byte[] Serialize(Packet p,bool limited)
        {
            using(var s=new MemoryStream(1200))
            using(var w=new BinaryWriter(s))
            {
                w.Write(Magic); w.Write(Version); w.Write((byte)p.Kind); WriteText(w,p.GameVersion,40); w.Write(p.Session);
                w.Write(p.WorldEpoch);
                switch(p.Kind)
                {
                    case PacketKind.Latency:
                        if(!ValidLatency(p)) throw new InvalidDataException("Latency payload");
                        w.Write(p.Action); w.Write(p.LatencyNonce);
                        if(p.Action==3) {
                            w.Write((byte)p.LatencySeats.Length);
                            foreach(var seat in p.LatencySeats) { w.Write(seat.Slot); w.Write(seat.Session); w.Write((short)seat.Milliseconds); }
                        }
                        break;
                    case PacketKind.ZombieState:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.HostTime);
                        if(p.Zombies==null || p.Zombies.Length>MaxZombieBatch) throw new InvalidDataException("Zombie batch");
                        w.Write((byte)p.Zombies.Length);
                        foreach(var z in p.Zombies) {
                            w.Write(z.Id); WriteText(w,z.Prefab,64); w.Write(z.X);w.Write(z.Y);w.Write(z.Z);w.Write(z.Yaw);
                            w.Write(z.Health);w.Write(z.Flags);w.Write(z.Animation);w.Write(z.AnimationTime);w.Write(z.AnimationFlags);
                        }
                        break;
                    case PacketKind.AnimalState:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.HostTime);
                        if(p.Animals==null || p.Animals.Length>MaxAnimalBatch) throw new InvalidDataException("Animal batch");
                        w.Write((byte)p.Animals.Length);
                        foreach(var a in p.Animals) {
                            if(!ValidAnimal(a)) throw new InvalidDataException("Animal frame");
                            w.Write((ushort)a.Id); WriteText(w,a.Prefab,64); w.Write(a.X);w.Write(a.Y);w.Write(a.Z);w.Write(a.Yaw);
                            w.Write(a.Flags);w.Write(a.Animation);w.Write(a.AnimationTime);w.Write(a.Speed);w.Write(a.Idle);w.Write(a.Bools);
                            w.Write(a.Voice);w.Write(a.VoiceCount);w.Write(a.Steps);w.Write(a.StepsCount);w.Write(a.Loops);
                            int left=a.Left==null?0:a.Left.Length; w.Write((byte)left);
                            for(int i=0;i<left;i++) w.Write(a.Left[i]);
                        }
                        break;
                    case PacketKind.ZombieAction:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.EquippedItemId); w.Write(p.Action);
                        w.Write(p.X);w.Write(p.Y);w.Write(p.Z);w.Write(p.AimX);w.Write(p.AimY);w.Write(p.AimZ); w.Write(p.Revision);
                        // Schema 20: origin and aim in car CarIndex's own space, or in the world (-1).
                        w.Write((sbyte)p.CarIndex); w.Write(p.Noise); w.Write(p.BowDraw);
                        {
                            int claims=p.Hits==null?0:p.Hits.Length;
                            if(claims>MaxHitClaims || p.Action==1 && claims>1 || p.BowDraw!=0 && (p.Action!=0 || claims!=0))
                                throw new InvalidDataException("Hit claims or bow draw");
                            w.Write((byte)claims);
                            for(int i=0;i<claims;i++) {
                                var c=p.Hits[i]; if(c==null) throw new InvalidDataException("Hit claim");
                                w.Write(c.Zombie); w.Write(c.Animal); w.Write(c.Limb); w.Write(c.LX); w.Write(c.LY); w.Write(c.LZ); w.Write(c.DX); w.Write(c.DY); w.Write(c.DZ);
                                w.Write(c.WX); w.Write(c.WY); w.Write(c.WZ);
                            }
                        }
                        break;
                    case PacketKind.CombatReload:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.EquippedItemId); w.Write(p.Revision); break;
                    case PacketKind.CombatProposal:
                    case PacketKind.CombatState:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.Revision); w.Write(p.Action); w.Write(p.Stamina);
                        w.Write(p.ShotSequence); w.Write(p.EquippedItemId);
                        if(!HostCombatInventory.ValidLoadout(p.CombatWeapons,p.CombatAmmo)) throw new InvalidDataException("Combat loadout");
                        w.Write((byte)p.CombatWeapons.Length);
                        foreach(var cw in p.CombatWeapons) { w.Write(cw.ItemId);w.Write(cw.Magazine);w.Write(cw.Durability); }
                        w.Write((byte)p.CombatAmmo.Length);
                        foreach(var ca in p.CombatAmmo) { w.Write(ca.ItemId);w.Write(ca.Amount); } break;
                    case PacketKind.ZombieHurt:
                        if(!ValidHurt(p.Damage,p.Action,p.Text)) throw new InvalidDataException("Zombie hurt");
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.Damage); w.Write(p.Action); WriteText(w,p.Text,MaxExplosiveName);
                        if(p.Action==HurtCharge || p.Action==HurtPowerfulMelee) {
                            if(!ValidPush(p.AimX,p.AimY,p.AimZ)) throw new InvalidDataException("Charge push");
                            w.Write(p.AimX); w.Write(p.AimY); w.Write(p.AimZ);
                            if(p.Action==HurtPowerfulMelee) {
                                if(!ValidPowerfulStun(p.PowerfulStun)) throw new InvalidDataException("Powerful melee stun");
                                w.Write(p.PowerfulStun);
                            }
                        }
                        else if(p.Action==HurtSteal) {
                            if(!ValidPoint(p.AimX,p.AimY,p.AimZ)) throw new InvalidDataException("Grab point");
                            w.Write(p.AimX); w.Write(p.AimY); w.Write(p.AimZ);
                        }
                        break;
                    case PacketKind.ZombieHurtAck:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); break;
                    case PacketKind.WorldState:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.Location); w.Write(p.RailsId); w.Write(p.TrainPosition);
                        w.Write(p.Clock != null);
                        if(p.Clock != null) { w.Write(p.Clock.Year); w.Write(p.Clock.Day); w.Write(p.Clock.Hour); w.Write(p.Clock.HoursPerRealSecond); }
                        if(!ValidDifficulty(p.Difficulty)) throw new InvalidDataException("Difficulty");
                        w.Write(p.Difficulty != null);
                        if(p.Difficulty != null) { w.Write(p.Difficulty.ZombieDamage); w.Write(p.Difficulty.Recoil); w.Write(p.Difficulty.Wobble); w.Write(p.Difficulty.ShowOnMap); }
                        if(!ValidWeather(p.Weather)) throw new InvalidDataException("Weather");
                        WriteText(w,p.Weather??"",MaxWeatherName);
                        break;
                    case PacketKind.State:
                        WriteState(w,p);
                        break;
                    case PacketKind.Welcome:
                        if(!ValidPlayer(p.Player)) throw new InvalidDataException("Player slot");
                        w.Write(p.Player); break;
                    case PacketKind.Players:
                        // 2.0.0: up to MaxOthers other guests, each once, never the host (its own State shows it).
                        // 2.1.0 (schema 44): Roster names every other guest present (slot and session); Players holds the
                        // states of some of them: with six others the states may not fit one datagram, so the host
                        // splits them over packets that each carry the whole roster.
                        if(p.Roster==null || p.Roster.Length>MaxOthers || p.Players==null || p.Players.Length>p.Roster.Length) throw new InvalidDataException("Players");
                        w.Write(p.Sequence); w.Write((byte)p.Roster.Length);
                        for(int i=0;i<p.Roster.Length;i++) {
                            var seat=p.Roster[i];
                            if(seat==null || seat.Player==0 || !ValidPlayer(seat.Player) || seat.Session==0) throw new InvalidDataException("Player slot/session");
                            for(int j=0;j<i;j++) if(p.Roster[j].Player==seat.Player) throw new InvalidDataException("Player slot");
                            w.Write(seat.Player); w.Write(seat.Session);
                        }
                        w.Write((byte)p.Players.Length);
                        for(int i=0;i<p.Players.Length;i++) {
                            var other=p.Players[i];
                            if(other==null || !InRoster(p.Roster,other.Player,other.Session)) throw new InvalidDataException("Player state outside the roster");
                            for(int j=0;j<i;j++) if(p.Players[j].Player==other.Player) throw new InvalidDataException("Player slot");
                            w.Write(other.Player); WriteState(w,other);
                        }
                        break;
                    case PacketKind.TrainMotion:
                        var f=p.Train;
                        w.Write(f.Sequence); w.Write(f.Revision); WriteText(w,f.Scene,96);
                        w.Write(f.Speed); w.Write(f.Thrust); w.Write(f.Flags);
                        w.Write(f.Buttons); w.Write(f.Broken); w.Write(f.Lights);
                        if(f.Levers==null || f.Levers.Length>MaxLevers) throw new InvalidDataException("Train levers");
                        w.Write((byte)f.Levers.Length); foreach(var lever in f.Levers) w.Write(lever);
                        if(f.Cars==null || f.Cars.Length==0 || f.Cars.Length>MaxCars) throw new InvalidDataException("Train car count");
                        w.Write((byte)f.Cars.Length);
                        foreach(var c in f.Cars) { WritePose(w,c.Root); WritePose(w,c.Body); WritePose(w,c.Front); WritePose(w,c.Back); }
                        if(!ValidFuel(f.Fuel,f.FuelMax)) throw new InvalidDataException("Train fuel");
                        w.Write(f.Fuel); w.Write(f.FuelMax);
                        if(f.Stations==null || f.Stations.Length>MaxStations) throw new InvalidDataException("Train stations");
                        w.Write((byte)f.Stations.Length);
                        foreach(var st in f.Stations)
                        {
                            if(!ValidStation(st)) throw new InvalidDataException("Fuel station");
                            w.Write(st.Key); w.Write(st.Fuel); w.Write(st.Flags); w.Write(st.Gun);
                            if(GunPosed(st.Gun)) WritePose(w,st.GunPose);
                        }
                        break;
                    case PacketKind.TrainLayoutChunk:
                        w.Write(p.Revision); w.Write((ushort)p.ChunkCount); w.Write((ushort)p.ChunkIndex);
                        if(p.Chunk==null || p.Chunk.Length>ChunkSize) throw new InvalidDataException("Chunk size");
                        w.Write((ushort)p.Chunk.Length); w.Write(p.Chunk); break;
                    case PacketKind.TrainLayoutAck: w.Write(p.Revision); break;
                    case PacketKind.IdentityRequest:
                    case PacketKind.IdentityProof:
                        int fixedSize=p.Kind==PacketKind.IdentityRequest?WorldIdBytes:ProfileTokenBytes;
                        if(p.Chunk==null || p.Chunk.Length!=fixedSize) throw new InvalidDataException("Identity field size");
                        w.Write(p.Chunk); break;
                    case PacketKind.GuestStatus: w.Write(p.Action); w.Write(p.Revision); break;
                    case PacketKind.GuestStateChunk:
                    case PacketKind.GuestRestoreChunk:
                    case PacketKind.StorageViewChunk:
                        w.Write(p.Revision); w.Write((ushort)p.ChunkCount); w.Write((ushort)p.ChunkIndex);
                        if(p.Chunk==null || p.Chunk.Length>ChunkSize) throw new InvalidDataException("Chunk size");
                        w.Write((ushort)p.Chunk.Length); w.Write(p.Chunk); break;
                    case PacketKind.GuestStateAck:
                    case PacketKind.GuestRestoreAck:
                    case PacketKind.StorageViewAck: w.Write(p.Revision); break;
                    case PacketKind.StorageRequest:
                    case PacketKind.StorageResult:
                        w.Write(p.Sequence); w.Write(p.Action); w.Write(p.Revision);
                        if(p.Kind==PacketKind.StorageResult) w.Write(p.Amount);
                        int payload=p.Chunk==null?0:p.Chunk.Length;
                        if(payload>MaxStoragePayload) throw new InvalidDataException("Storage payload");
                        w.Write((ushort)payload); if(payload>0) w.Write(p.Chunk); break;
                    case PacketKind.ZombieCorpse:
                        var cf=p.Corpse;
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(cf.Id); WriteText(w,cf.Prefab,64);
                        w.Write(cf.X); w.Write(cf.Y); w.Write(cf.Z); w.Write(cf.Yaw);
                        if(cf.Bones==null || cf.Bones.Length>MaxCorpseBones) throw new InvalidDataException("Corpse bones");
                        w.Write((byte)cf.Bones.Length); foreach(var bone in cf.Bones) WritePose(w,bone); break;
                    case PacketKind.DoorStates:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96);
                        if(p.Doors==null || p.Doors.Length>MaxDoorBatch) throw new InvalidDataException("Door batch");
                        w.Write((byte)p.Doors.Length);
                        foreach(var d in p.Doors) { w.Write(d.X); w.Write(d.Y); w.Write(d.Z); w.Write(d.Flags); } break;
                    case PacketKind.DoorToggle:
                        if(!ValidDoorToggle(p.Action,p.Revision)) throw new InvalidDataException("Door toggle");
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.X); w.Write(p.Y); w.Write(p.Z); w.Write(p.Action); w.Write(p.Revision); break;
                    case PacketKind.SceneStates:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96);
                        if(p.SceneObjects==null || p.SceneObjects.Length>MaxSceneBatch) throw new InvalidDataException("Scene batch");
                        w.Write((byte)p.SceneObjects.Length);
                        foreach(var so in p.SceneObjects)
                        {
                            if(!ValidSceneFrame(so)) throw new InvalidDataException("Scene object");
                            w.Write(so.Id); w.Write(so.Kind); w.Write(so.Flags); w.Write(so.Value);
                        }
                        break;
                    case PacketKind.SceneUse:
                        if(!ValidSceneUse(p.Revision,p.Action)) throw new InvalidDataException("Scene use");
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.Revision); w.Write(p.Action); break;
                    case PacketKind.Explosion:
                        if(p.Action<ExplosionFire || p.Action>ExplosionBlast || !ValidExplosive(p.Text)) throw new InvalidDataException("Explosion");
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.Action); WriteText(w,p.Text,MaxExplosiveName); w.Write(p.X); w.Write(p.Y); w.Write(p.Z); break;
                    case PacketKind.Sleep:
                        if(!ValidSleep(p.Action,p.Revision) || !ValidPlayer(p.Player)) throw new InvalidDataException("Sleep");
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.Action); w.Write((byte)p.Revision); w.Write(p.Player); w.Write(p.SleepAttempt); break;
                    case PacketKind.SleepAck:
                        if(p.Sequence==0) throw new InvalidDataException("Sleep acknowledgement");
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); break;
                    case PacketKind.FarmStates:
                        if(p.Sequence==0 || p.Farms==null || p.Farms.Length==0 || p.Farms.Length>MaxFarmBatch) throw new InvalidDataException("Farm batch");
                        w.Write(p.Sequence); w.Write((byte)p.Farms.Length);
                        foreach(var bed in p.Farms)
                        {
                            if(!ValidFarmFrame(bed)) throw new InvalidDataException("Farm frame");
                            w.Write(bed.Car); w.Write(bed.Identity); w.Write(bed.Flags); w.Write(bed.Water); w.Write(bed.Fertilize); w.Write((byte)bed.Points.Length);
                            foreach(var pt in bed.Points) { w.Write(pt.Plant); w.Write(pt.Stage); w.Write(pt.Flags); w.Write(pt.Growth); w.Write(pt.Efficiency); }
                        }
                        break;
                    case PacketKind.QuestStates:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96);
                        if(p.Quests==null || p.Quests.Length>MaxQuestBatch) throw new InvalidDataException("Quest batch");
                        w.Write((byte)p.Quests.Length);
                        for(int i=0;i<p.Quests.Length;i++) {
                            var q=p.Quests[i];
                            if(!ValidQuest(q)) throw new InvalidDataException("Quest frame");
                            for(int j=0;j<i;j++) if(p.Quests[j].Key==q.Key) throw new InvalidDataException("Quest frame");
                            w.Write(q.Key); w.Write(q.Flags); w.Write(q.Stage);
                        }
                        break;
                    case PacketKind.WorldItems:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96);
                        if(p.Items==null || p.Items.Length>MaxItemBatch) throw new InvalidDataException("Item batch");
                        w.Write((byte)p.Items.Length);
                        foreach(var it in p.Items) {
                            w.Write(it.HostId); w.Write(it.ItemId); w.Write(it.Amount); w.Write(it.Kind); WritePose(w,it.Pose);
                            if(!DogFrame(it)) continue;
                            var devices=it.Devices??new byte[0];
                            if(devices.Length>MaxDogDevices) throw new InvalidDataException("Robot dog devices");
                            w.Write((byte)devices.Length); w.Write(devices);
                        }
                        break;
                    case PacketKind.Mark:
                        // A position in the world, or in car CarIndex's own space.
                        if(!ValidPlayer(p.Player)) throw new InvalidDataException("Player slot");
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.Action); w.Write(p.Revision);
                        w.Write((sbyte)p.CarIndex); w.Write(p.X); w.Write(p.Y); w.Write(p.Z); w.Write(p.Player); break;
                    case PacketKind.ZombieEffect:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.Revision); w.Write(p.Action);
                        w.Write(p.X); w.Write(p.Y); w.Write(p.Z); w.Write(p.AimX); w.Write(p.AimY); w.Write(p.AimZ); break;
                    case PacketKind.Revive:
                        if(!ValidPlayer(p.Player)) throw new InvalidDataException("Player slot");
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.Action); w.Write(p.Player); break;
                    case PacketKind.Chat:
                        if(!ValidChat(p.Sequence,p.Action,p.Text)) throw new InvalidDataException("Chat message");
                        var chat=Text.GetBytes(p.Text??"");
                        if(chat.Length>MaxChatBytes) throw new InvalidDataException("Chat message");
                        if(!ValidPlayer(p.Player)) throw new InvalidDataException("Player slot");
                        w.Write(p.Sequence); w.Write(p.Action); w.Write((ushort)chat.Length); w.Write(chat); w.Write(p.Player); break;
                }
                if(limited && s.Length>MaxBytes) throw new InvalidDataException("LAN packet too large");
                return s.ToArray();
            }
        }
        internal static bool ValidLatency(Packet p)
        {
            if(p==null || p.Kind!=PacketKind.Latency || p.LatencyNonce==0 || p.Action<1 || p.Action>3) return false;
            if(p.Action!=3) return p.LatencySeats==null;
            if(p.LatencySeats==null || p.LatencySeats.Length>7) return false;
            int seen=0;
            foreach(var seat in p.LatencySeats) {
                if(seat.Slot<1 || seat.Slot>7 || seat.Session==0 || seat.Milliseconds < -1 || seat.Milliseconds>3000 || (seen & (1<<seat.Slot))!=0) return false;
                seen|=1<<seat.Slot;
            }
            return true;
        }
        internal static bool TryDecode(byte[] data,out Packet packet)
        {
            packet=null;
            if(data==null || data.Length<19 || data.Length>1200) return false;
            try
            {
                using(var s=new MemoryStream(data,false))
                using(var r=new BinaryReader(s))
                {
                    if(r.ReadUInt32()!=Magic || r.ReadByte()!=Version) return false;
                    var kind=(PacketKind)r.ReadByte();
                    if(kind<PacketKind.Hello || kind>PacketKind.AnimalState) return false;
                    var p=new Packet {Kind=kind,GameVersion=ReadText(r,40),Session=r.ReadUInt64(),WorldEpoch=r.ReadUInt32()};
                    switch(kind)
                    {
                        case PacketKind.Latency:
                            p.Action=r.ReadByte(); p.LatencyNonce=r.ReadUInt64();
                            if(p.Action==3) {
                                int latencyCount=r.ReadByte(); if(latencyCount>7) return false;
                                p.LatencySeats=new LatencySeat[latencyCount];
                                for(int i=0;i<latencyCount;i++) p.LatencySeats[i]=new LatencySeat { Slot=r.ReadByte(), Session=r.ReadUInt64(), Milliseconds=r.ReadInt16() };
                            }
                            if(!ValidLatency(p)) return false;
                            break;
                        case PacketKind.ZombieState:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96); p.HostTime=r.ReadSingle();
                            if(float.IsNaN(p.HostTime) || float.IsInfinity(p.HostTime) || p.HostTime<0) return false;
                            int zombies=r.ReadByte(); if(zombies>MaxZombieBatch) return false;
                            p.Zombies=new ZombieFrame[zombies];
                            for(int i=0;i<zombies;i++) {
                                var z=new ZombieFrame {Id=r.ReadUInt32(),Prefab=ReadText(r,64),X=ReadFloat(r),Y=ReadFloat(r),Z=ReadFloat(r),Yaw=ReadFloat(r),Health=ReadFloat(r),Flags=r.ReadByte(),Animation=r.ReadInt32(),AnimationTime=ReadFloat(r),AnimationFlags=r.ReadUInt32()};
                                if(z.Id==0 || z.Id>MaxZombieIds || string.IsNullOrEmpty(z.Prefab) || z.Yaw<0 || z.Yaw>360 || z.Health<0 || z.Flags>MaxZombieFlags || (z.Flags&ZombieStateBits)!=0 && z.Flags>ZombieStateBits || z.AnimationTime<0 || z.AnimationTime>1) return false;
                                for(int j=0;j<i;j++) if(p.Zombies[j].Id==z.Id) return false;
                                p.Zombies[i]=z;
                            }
                            break;
                        case PacketKind.AnimalState:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96); p.HostTime=r.ReadSingle();
                            if(float.IsNaN(p.HostTime) || float.IsInfinity(p.HostTime) || p.HostTime<0) return false;
                            int animals=r.ReadByte(); if(animals>MaxAnimalBatch) return false;
                            p.Animals=new AnimalFrame[animals];
                            for(int i=0;i<animals;i++) {
                                var a=new AnimalFrame {Id=r.ReadUInt16(),Prefab=ReadText(r,64),X=ReadFloat(r),Y=ReadFloat(r),Z=ReadFloat(r),Yaw=ReadFloat(r),
                                    Flags=r.ReadByte(),Animation=r.ReadInt32(),AnimationTime=ReadFloat(r),Speed=ReadFloat(r),Idle=r.ReadSByte(),Bools=r.ReadByte(),
                                    Voice=r.ReadByte(),VoiceCount=r.ReadByte(),Steps=r.ReadByte(),StepsCount=r.ReadByte(),Loops=r.ReadByte()};
                                int left=r.ReadByte(); if(left>MaxAnimalLeft) return false;
                                a.Left=left==0?null:r.ReadBytes(left); if(left!=0 && a.Left.Length!=left) return false;
                                if(!ValidAnimal(a)) return false;
                                for(int j=0;j<i;j++) if(p.Animals[j].Id==a.Id) return false;
                                p.Animals[i]=a;
                            }
                            break;
                        case PacketKind.ZombieAction:
                            p.Sequence=r.ReadUInt32();p.Scene=ReadText(r,96);p.EquippedItemId=r.ReadInt32();p.Action=r.ReadByte();
                            p.X=ReadFloat(r);p.Y=ReadFloat(r);p.Z=ReadFloat(r);p.AimX=ReadFloat(r);p.AimY=ReadFloat(r);p.AimZ=ReadFloat(r);
                            p.Revision=r.ReadInt32(); if(p.Revision<=0) return false;
                            float aim=p.AimX*p.AimX+p.AimY*p.AimY+p.AimZ*p.AimZ;
                            // Schema 25: item -1 is a swing of the bare fists.
                            if(p.EquippedItemId < -1 || p.EquippedItemId>65535 || p.Action>1 || p.EquippedItemId==-1 && p.Action!=1 || aim<.99f || aim>1.01f) return false;
                            p.CarIndex=r.ReadSByte();
                            if(p.CarIndex < -1 || p.CarIndex>=MaxCars || p.CarIndex>=0 && (Math.Abs(p.X)>100 || Math.Abs(p.Y)>100 || Math.Abs(p.Z)>100)) return false;
                            p.Noise=r.ReadByte(); if(p.Noise>100) return false;
                            p.BowDraw=r.ReadByte();
                            {
                                int claims=r.ReadByte(); if(claims>MaxHitClaims || p.Action==1 && claims>1 || p.BowDraw!=0 && (p.Action!=0 || claims!=0)) return false;
                                p.Hits=claims==0?null:new HitClaim[claims];
                                for(int i=0;i<claims;i++) {
                                    uint target=r.ReadUInt32(); byte animal=r.ReadByte(); if(animal>1) return false;
                                    var c=new HitClaim {Zombie=target,Animal=animal==1,Limb=r.ReadByte(),LX=ReadFloat(r),LY=ReadFloat(r),LZ=ReadFloat(r),DX=ReadFloat(r),DY=ReadFloat(r),DZ=ReadFloat(r),
                                        WX=ReadFloat(r),WY=ReadFloat(r),WZ=ReadFloat(r)};
                                    float into=c.DX*c.DX+c.DY*c.DY+c.DZ*c.DZ;
                                    if(c.Zombie==0 || c.Zombie>(c.Animal?(uint)MaxAnimalIds:(uint)MaxZombieIds) || c.Limb>=MaxClaimLimbs || Math.Abs(c.LX)>MaxClaimLocal || Math.Abs(c.LY)>MaxClaimLocal ||
                                        Math.Abs(c.LZ)>MaxClaimLocal || into<.98f || into>1.02f) return false;
                                    for(int j=0;j<i;j++) if(p.Action==1 && p.Hits[j].Zombie==c.Zombie && p.Hits[j].Animal==c.Animal) return false;
                                    p.Hits[i]=c;
                                }
                            }
                            break;
                        case PacketKind.CombatReload:
                            p.Sequence=r.ReadUInt32();p.Scene=ReadText(r,96);p.EquippedItemId=r.ReadInt32();p.Revision=r.ReadInt32();
                            if(p.EquippedItemId<0 || p.EquippedItemId>65535 || p.Revision<=0) return false; break;
                        case PacketKind.CombatProposal:
                        case PacketKind.CombatState:
                            p.Sequence=r.ReadUInt32();p.Scene=ReadText(r,96);p.Revision=r.ReadInt32();p.Action=r.ReadByte();p.Stamina=ReadFloat(r);
                            p.ShotSequence=r.ReadUInt32();p.EquippedItemId=r.ReadInt32();
                            // 1.4.18: up to the host's own bound (HostCombatInventory.MaxMaxStamina): since 1.4.1 the guest's
                            // maximum follows its stamina level (110 at level 2), and a state above 100 was dropped here, so
                            // the guest's combat stalled (no blow, shot or reload confirmed; the ledger kept correcting it).
                            if(p.Revision<0 || p.Action>2 || p.Stamina<0 || p.Stamina>HostCombatInventory.MaxMaxStamina ||
                                p.EquippedItemId < -1 || p.EquippedItemId > 65535 ||
                                kind==PacketKind.CombatProposal && (p.Revision!=0 || p.Action!=0 || p.Stamina!=0 || p.ShotSequence!=0 || p.EquippedItemId!=-1) ||
                                kind==PacketKind.CombatState && ((p.Action==0)!=(p.Revision==0))) return false;
                            int wc=r.ReadByte();if(wc>16) return false;p.CombatWeapons=new CombatWeapon[wc];
                            for(int i=0;i<wc;i++) p.CombatWeapons[i]=new CombatWeapon {ItemId=r.ReadInt32(),Magazine=r.ReadInt32(),Durability=ReadFloat(r)};
                            int ac=r.ReadByte();if(ac>16) return false;p.CombatAmmo=new CombatAmmo[ac];
                            for(int i=0;i<ac;i++) p.CombatAmmo[i]=new CombatAmmo {ItemId=r.ReadInt32(),Amount=r.ReadInt32()};
                            if(!HostCombatInventory.ValidLoadout(p.CombatWeapons,p.CombatAmmo) || kind==PacketKind.CombatState && p.Action!=1 && (wc!=0 || ac!=0)) return false;
                            break;
                        case PacketKind.ZombieHurt:
                            p.Sequence=r.ReadUInt32();p.Scene=ReadText(r,96);p.Damage=ReadFloat(r);p.Action=r.ReadByte();p.Text=ReadText(r,MaxExplosiveName);
                            if(!ValidHurt(p.Damage,p.Action,p.Text)) return false;
                            if(p.Action==HurtCharge || p.Action==HurtPowerfulMelee) { p.AimX=ReadFloat(r);p.AimY=ReadFloat(r);p.AimZ=ReadFloat(r); if(!ValidPush(p.AimX,p.AimY,p.AimZ)) return false;
                                if(p.Action==HurtPowerfulMelee) { p.PowerfulStun=ReadFloat(r); if(!ValidPowerfulStun(p.PowerfulStun)) return false; } }
                            else if(p.Action==HurtSteal) { p.AimX=ReadFloat(r);p.AimY=ReadFloat(r);p.AimZ=ReadFloat(r); if(!ValidPoint(p.AimX,p.AimY,p.AimZ)) return false; }
                            break;
                        case PacketKind.ZombieHurtAck:
                            p.Sequence=r.ReadUInt32();p.Scene=ReadText(r,96); break;
                        case PacketKind.WorldState:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96); p.Location=r.ReadInt32(); p.RailsId=r.ReadInt32(); p.TrainPosition=ReadFloat(r);
                            if(p.WorldEpoch==0 || string.IsNullOrEmpty(p.Scene) || p.Location<0 || p.Location>100000 || p.RailsId < -1 || p.TrainPosition<0) return false;
                            byte hasClock=r.ReadByte(); if(hasClock>1) return false;
                            if(hasClock!=0)
                            {
                                p.Clock=new ClockSnapshot {Year=r.ReadInt32(),Day=r.ReadInt32(),Hour=ReadFloat(r),HoursPerRealSecond=ReadFloat(r)};
                                if(p.Clock.Year<1 || p.Clock.Year>9999 || p.Clock.Day<0 || p.Clock.Day>366 || p.Clock.Hour<0 || p.Clock.Hour>24 || p.Clock.HoursPerRealSecond<0 || p.Clock.HoursPerRealSecond>24) return false;
                            }
                            byte hasDifficulty=r.ReadByte(); if(hasDifficulty>1) return false;
                            if(hasDifficulty!=0)
                            {
                                p.Difficulty=new DifficultySnapshot {ZombieDamage=ReadFloat(r),Recoil=ReadFloat(r),Wobble=ReadFloat(r)};
                                byte map=r.ReadByte(); if(map>1) return false;
                                p.Difficulty.ShowOnMap=map==1;
                                if(!ValidDifficulty(p.Difficulty)) return false;
                            }
                            string weather=ReadText(r,MaxWeatherName); p.Weather=weather.Length==0?null:weather;
                            if(!ValidWeather(p.Weather)) return false;
                            break;
                        case PacketKind.State:
                            if(!ReadState(r,p)) return false;
                            break;
                        case PacketKind.Welcome:
                            p.Player=r.ReadByte(); if(!ValidPlayer(p.Player)) return false;
                            break;
                        case PacketKind.Players:
                            p.Sequence=r.ReadUInt32();
                            int seats=r.ReadByte(); if(seats>MaxOthers) return false;
                            p.Roster=new PlayerSeat[seats];
                            for(int i=0;i<seats;i++) {
                                var seat=new PlayerSeat {Player=r.ReadByte(),Session=r.ReadUInt64()};
                                if(seat.Player==0 || !ValidPlayer(seat.Player) || seat.Session==0) return false;
                                for(int j=0;j<i;j++) if(p.Roster[j].Player==seat.Player) return false;
                                p.Roster[i]=seat;
                            }
                            int others=r.ReadByte(); if(others>seats) return false;
                            p.Players=new Packet[others];
                            for(int i=0;i<others;i++) {
                                var other=new Packet {Kind=PacketKind.State,GameVersion=p.GameVersion,Session=0,WorldEpoch=p.WorldEpoch,Player=r.ReadByte()};
                                foreach(var seat in p.Roster) if(seat.Player==other.Player) other.Session=seat.Session;
                                if(other.Session==0 || !ReadState(r,other)) return false;
                                for(int j=0;j<i;j++) if(p.Players[j].Player==other.Player) return false;
                                p.Players[i]=other;
                            }
                            break;
                        case PacketKind.TrainMotion:
                            var f=new TrainFrame {Sequence=r.ReadUInt32(),Revision=r.ReadInt32(),Scene=ReadText(r,96),Speed=ReadFloat(r),Thrust=ReadFloat(r),Flags=r.ReadByte()};
                            f.Buttons=r.ReadUInt32(); f.Broken=r.ReadUInt32(); f.Lights=r.ReadUInt16();
                            int levers=r.ReadByte(); if(levers>MaxLevers) return false;
                            f.Levers=new float[levers];
                            for(int i=0;i<levers;i++) { f.Levers[i]=ReadFloat(r); if(Math.Abs(f.Levers[i])>1000) return false; }
                            int count=r.ReadByte();
                            if(f.Revision<=0 || string.IsNullOrEmpty(f.Scene) || count==0 || count>MaxCars || Math.Abs(f.Speed)>500 || Math.Abs(f.Thrust)>100 || f.Flags>127) return false;
                            f.Cars=new CarPose[count];
                            for(int i=0;i<count;i++) f.Cars[i]=new CarPose {Root=ReadPose(r),Body=ReadPose(r),Front=ReadPose(r),Back=ReadPose(r)};
                            f.Fuel=ReadFloat(r); f.FuelMax=ReadFloat(r);
                            if(!ValidFuel(f.Fuel,f.FuelMax)) return false;
                            int stations=r.ReadByte(); if(stations>MaxStations) return false;
                            f.Stations=new StationFrame[stations];
                            for(int i=0;i<stations;i++)
                            {
                                var st=new StationFrame {Key=r.ReadInt32(),Fuel=ReadFloat(r),Flags=r.ReadByte(),Gun=r.ReadByte()};
                                if(st.Gun>GunLoose) return false;
                                if(GunPosed(st.Gun)) st.GunPose=ReadPose(r);
                                if(!ValidStation(st)) return false;
                                f.Stations[i]=st;
                            }
                            p.Train=f; break;
                        case PacketKind.TrainLayoutChunk:
                            p.Revision=r.ReadInt32(); p.ChunkCount=r.ReadUInt16(); p.ChunkIndex=r.ReadUInt16();
                            int size=r.ReadUInt16();
                            if(p.Revision<=0 || p.ChunkCount<1 || p.ChunkCount>MaxChunks || p.ChunkIndex>=p.ChunkCount || size<1 || size>ChunkSize) return false;
                            if(p.ChunkIndex<p.ChunkCount-1 && size!=ChunkSize) return false;
                            if((p.ChunkCount-1)*ChunkSize+(p.ChunkIndex==p.ChunkCount-1?size:1)>MaxLayoutBytes) return false;
                            p.Chunk=r.ReadBytes(size); if(p.Chunk.Length!=size) return false;
                            break;
                        case PacketKind.TrainLayoutAck:
                            p.Revision=r.ReadInt32(); if(p.Revision<=0) return false; break;
                        case PacketKind.IdentityRequest:
                        case PacketKind.IdentityProof:
                            int fixedSize=kind==PacketKind.IdentityRequest?WorldIdBytes:ProfileTokenBytes;
                            p.Chunk=r.ReadBytes(fixedSize); if(p.Chunk.Length!=fixedSize) return false;
                            if(kind==PacketKind.IdentityRequest && new Guid(p.Chunk)==Guid.Empty) return false;
                            break;
                        case PacketKind.GuestStatus:
                            p.Action=r.ReadByte(); p.Revision=r.ReadInt32();
                            if(p.Action>1 || (p.Action==0)!=(p.Revision==0) || p.Revision<0) return false; break;
                        case PacketKind.GuestStateChunk:
                        case PacketKind.GuestRestoreChunk:
                        case PacketKind.StorageViewChunk:
                            p.Revision=r.ReadInt32(); p.ChunkCount=r.ReadUInt16(); p.ChunkIndex=r.ReadUInt16();
                            int blobSize=r.ReadUInt16();
                            if(p.Revision<=0 || p.ChunkCount<1 || p.ChunkCount>MaxGuestChunks || p.ChunkIndex>=p.ChunkCount || blobSize<1 || blobSize>ChunkSize) return false;
                            if(p.ChunkIndex<p.ChunkCount-1 && blobSize!=ChunkSize) return false;
                            if((p.ChunkCount-1)*ChunkSize+(p.ChunkIndex==p.ChunkCount-1?blobSize:1)>MaxGuestBytes) return false;
                            p.Chunk=r.ReadBytes(blobSize); if(p.Chunk.Length!=blobSize) return false;
                            break;
                        case PacketKind.GuestStateAck:
                        case PacketKind.GuestRestoreAck:
                        case PacketKind.StorageViewAck:
                            p.Revision=r.ReadInt32(); if(p.Revision<=0) return false; break;
                        case PacketKind.StorageRequest:
                        case PacketKind.StorageResult:
                            p.Sequence=r.ReadUInt32(); p.Action=r.ReadByte(); p.Revision=r.ReadInt32();
                            if(kind==PacketKind.StorageResult) p.Amount=r.ReadInt32();
                            int payloadSize=r.ReadUInt16();
                            if(payloadSize>MaxStoragePayload || p.Sequence==0 || p.Revision<0) return false;
                            p.Chunk=r.ReadBytes(payloadSize); if(p.Chunk.Length!=payloadSize) return false;
                            if(kind==PacketKind.StorageRequest ? !ValidStorageRequest(p.Action,p.Revision,payloadSize) :
                                p.Action>MaxStorageStatus || p.Amount<0 || p.Amount>1000000) return false;
                            break;
                        case PacketKind.ZombieCorpse:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96);
                            var corpse=new CorpseFrame {Id=r.ReadUInt32(),Prefab=ReadText(r,64),X=ReadFloat(r),Y=ReadFloat(r),Z=ReadFloat(r),Yaw=ReadFloat(r)};
                            int bones=r.ReadByte();
                            if(corpse.Id==0 || corpse.Id>MaxZombieIds || string.IsNullOrEmpty(corpse.Prefab) || corpse.Yaw<0 || corpse.Yaw>360 || bones>MaxCorpseBones) return false;
                            corpse.Bones=new NetPose[bones];
                            for(int i=0;i<bones;i++) corpse.Bones[i]=ReadPose(r);
                            p.Corpse=corpse; break;
                        case PacketKind.DoorStates:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96);
                            int doors=r.ReadByte(); if(doors>MaxDoorBatch) return false;
                            p.Doors=new DoorFrame[doors];
                            for(int i=0;i<doors;i++) {
                                p.Doors[i]=new DoorFrame {X=ReadFloat(r),Y=ReadFloat(r),Z=ReadFloat(r),Flags=r.ReadByte()};
                                if(p.Doors[i].Flags>MaxDoorFlags) return false;
                            }
                            break;
                        case PacketKind.DoorToggle:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96); p.X=ReadFloat(r); p.Y=ReadFloat(r); p.Z=ReadFloat(r); p.Action=r.ReadByte(); p.Revision=r.ReadInt32();
                            if(!ValidDoorToggle(p.Action,p.Revision)) return false; break;
                        case PacketKind.SceneStates:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96);
                            int sceneCount=r.ReadByte(); if(sceneCount>MaxSceneBatch) return false;
                            p.SceneObjects=new SceneFrame[sceneCount];
                            for(int i=0;i<sceneCount;i++)
                            {
                                var so=new SceneFrame {Id=r.ReadInt32(),Kind=r.ReadByte(),Flags=r.ReadByte(),Value=ReadFloat(r)};
                                if(!ValidSceneFrame(so)) return false;
                                p.SceneObjects[i]=so;
                            }
                            break;
                        case PacketKind.SceneUse:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96); p.Revision=r.ReadInt32(); p.Action=r.ReadByte();
                            if(!ValidSceneUse(p.Revision,p.Action)) return false; break;
                        case PacketKind.Explosion:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96); p.Action=r.ReadByte(); p.Text=ReadText(r,MaxExplosiveName);
                            p.X=ReadFloat(r); p.Y=ReadFloat(r); p.Z=ReadFloat(r);
                            if(p.Action<ExplosionFire || p.Action>ExplosionBlast || !ValidExplosive(p.Text)) return false;
                            break;
                        case PacketKind.Sleep:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96); p.Action=r.ReadByte(); p.Revision=r.ReadByte(); p.Player=r.ReadByte(); p.SleepAttempt=r.ReadUInt32();
                            if(!ValidSleep(p.Action,p.Revision) || !ValidPlayer(p.Player)) return false;
                            break;
                        case PacketKind.SleepAck:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96);
                            if(p.Sequence==0) return false;
                            break;
                        case PacketKind.FarmStates:
                            p.Sequence=r.ReadUInt32();
                            int farms=r.ReadByte(); if(p.Sequence==0 || farms==0 || farms>MaxFarmBatch) return false;
                            p.Farms=new FarmFrame[farms];
                            for(int i=0;i<farms;i++)
                            {
                                var bed=new FarmFrame {Car=r.ReadByte(),Identity=r.ReadInt32(),Flags=r.ReadByte(),Water=r.ReadByte(),Fertilize=r.ReadByte()};
                                int points=r.ReadByte(); if(points==0 || points>MaxFarmPoints) return false;
                                bed.Points=new FarmPoint[points];
                                for(int j=0;j<points;j++) bed.Points[j]=new FarmPoint {Plant=r.ReadByte(),Stage=r.ReadByte(),Flags=r.ReadByte(),Growth=r.ReadUInt16(),Efficiency=r.ReadByte()};
                                if(!ValidFarmFrame(bed)) return false;
                                p.Farms[i]=bed;
                            }
                            break;
                        case PacketKind.QuestStates:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96);
                            int quests=r.ReadByte(); if(quests>MaxQuestBatch) return false;
                            p.Quests=new QuestFrame[quests];
                            for(int i=0;i<quests;i++) {
                                var q=new QuestFrame {Key=r.ReadUInt32(),Flags=r.ReadByte(),Stage=r.ReadSByte()};
                                if(!ValidQuest(q)) return false;
                                for(int j=0;j<i;j++) if(p.Quests[j].Key==q.Key) return false;
                                p.Quests[i]=q;
                            }
                            break;
                        case PacketKind.WorldItems:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96);
                            int items=r.ReadByte(); if(items>MaxItemBatch) return false;
                            p.Items=new WorldItemFrame[items];
                            for(int i=0;i<items;i++) {
                                var it=new WorldItemFrame {HostId=r.ReadInt32(),ItemId=r.ReadInt32(),Amount=r.ReadInt32(),Kind=r.ReadByte(),Pose=ReadPose(r)};
                                if(DogFrame(it)) {
                                    int devices=r.ReadByte(); if(devices>MaxDogDevices) return false;
                                    it.Devices=r.ReadBytes(devices); if(it.Devices.Length!=devices) return false;
                                }
                                if(it.HostId==0 || it.Kind>3 || it.Kind==0 && (it.ItemId<0 || it.ItemId>65535 || it.Amount<1 || it.Amount>1000000) ||
                                    (it.Kind==1 || it.Kind==2) && (it.ItemId!=-1 || it.Amount!=0)) return false;
                                if(it.Kind==3 && (it.ItemId<0 || it.ItemId>MaxTakablePrefab || it.Amount<0 || (it.Amount&255)>MaxCars || it.Amount>>8>MaxTakableState ||
                                    (it.Amount&255)!=0 && (Math.Abs(it.Pose.X)>256 || Math.Abs(it.Pose.Y)>256 || Math.Abs(it.Pose.Z)>256))) return false;
                                p.Items[i]=it;
                            }
                            break;
                        case PacketKind.Mark:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96); p.Action=r.ReadByte(); p.Revision=r.ReadInt32();
                            p.CarIndex=r.ReadSByte(); p.X=ReadFloat(r); p.Y=ReadFloat(r); p.Z=ReadFloat(r); p.Player=r.ReadByte();
                            if(p.Action>MarkPoint || p.Revision<1 || p.Revision>65535 || p.CarIndex < -1 || p.CarIndex>=MaxCars || !ValidPlayer(p.Player)) return false;
                            if(p.CarIndex>=0 && (Math.Abs(p.X)>256 || Math.Abs(p.Y)>256 || Math.Abs(p.Z)>256)) return false;
                            break;
                        case PacketKind.ZombieEffect:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96); p.Revision=r.ReadInt32(); p.Action=r.ReadByte();
                            p.X=ReadFloat(r); p.Y=ReadFloat(r); p.Z=ReadFloat(r); p.AimX=ReadFloat(r); p.AimY=ReadFloat(r); p.AimZ=ReadFloat(r);
                            float facing=p.AimX*p.AimX+p.AimY*p.AimY+p.AimZ*p.AimZ;
                            if(p.Revision<1 || p.Revision>MaxZombieIds || p.Action<EffectShot || p.Action>EffectFlameOff || facing<.99f || facing>1.01f) return false;
                            if(p.Action>=EffectDeviceShot && (p.Revision>NoDevice || !ValidPoint(p.X,p.Y,p.Z))) return false;
                            break;
                        case PacketKind.Revive:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96); p.Action=r.ReadByte(); p.Player=r.ReadByte();
                            if(p.Action<ReviveHold || p.Action>ReviveDone || !ValidPlayer(p.Player)) return false;
                            break;
                        case PacketKind.Chat:
                            p.Sequence=r.ReadUInt32(); p.Action=r.ReadByte();
                            int chatBytes=r.ReadUInt16(); if(chatBytes>MaxChatBytes) return false;
                            var chat=r.ReadBytes(chatBytes); if(chat.Length!=chatBytes) return false;
                            p.Text=Text.GetString(chat); p.Player=r.ReadByte();
                            if(!ValidChat(p.Sequence,p.Action,p.Text) || !ValidPlayer(p.Player)) return false;
                            break;
                    }
                    if(WorldBound(kind) && (p.WorldEpoch==0 || p.Sequence==0 || string.IsNullOrEmpty(p.Scene))) return false;
                    if(s.Position!=s.Length) return false;
                    packet=p; return true;
                }
            }
            catch(Exception) { return false; }
        }
        // Messages about one world epoch and scene, numbered by their sender.
        internal static bool WorldBound(PacketKind kind)
        { return kind>=PacketKind.ZombieState && kind<=PacketKind.CombatReload || kind>=PacketKind.ZombieCorpse && kind<=PacketKind.Mark || kind==PacketKind.ZombieEffect || kind==PacketKind.Revive || kind==PacketKind.QuestStates || kind==PacketKind.Explosion || kind==PacketKind.Sleep || kind==PacketKind.SceneStates || kind==PacketKind.SceneUse || kind==PacketKind.AnimalState; }
        // An explosive's prefab name: letters, digits, '_', '-' and spaces.
        internal static bool ValidExplosive(string name)
        {
            if(string.IsNullOrEmpty(name) || name.Length>MaxExplosiveName) return false;
            foreach(char c in name) if(!(c>='a' && c<='z' || c>='A' && c<='Z' || c>='0' && c<='9' || c=='_' || c=='-' || c==' ')) return false;
            return true;
        }
        // A zombie hurt (schema 33): damage kinds 1..4, or a melee hit (HurtMelee) that alone may name
        // the zombie's prefab (no control characters).
        // 2.8.0 (schema 54): an animal frame the wire can carry: a known id and a prefab name, a place and facing, known flags
        // (a gone animal shows nothing else), an animation moment, a sane speed, clip indexes in range, a few resources left.
        internal static bool ValidAnimal(AnimalFrame a)
        {
            if(a==null || a.Id==0 || a.Id>MaxAnimalIds || string.IsNullOrEmpty(a.Prefab) || Text.GetByteCount(a.Prefab)>64) return false;
            foreach(char c in a.Prefab) if(c<0x20 || c==0x7F) return false;
            if(!ValidPoint(a.X,a.Y,a.Z) || float.IsNaN(a.Yaw) || a.Yaw<0 || a.Yaw>360) return false;
            int state=a.Flags&AnimalStateBits;
            if(a.Flags>MaxAnimalFlags || state==3 || state==2 && a.Flags!=2) return false;
            if(float.IsNaN(a.AnimationTime) || a.AnimationTime<0 || a.AnimationTime>1 || float.IsNaN(a.Speed) || Math.Abs(a.Speed)>100) return false;
            if(a.Voice>MaxAnimalClips || a.Steps>MaxAnimalClips || a.Loops>MaxAnimalLoops) return false;
            return a.Left==null || a.Left.Length<=MaxAnimalLeft;
        }
        // A world point the wire can carry (as ReadFloat takes it).
        internal static bool ValidPoint(float x,float y,float z)
        {
            foreach(float v in new[]{x,y,z}) if(float.IsNaN(v) || float.IsInfinity(v) || Math.Abs(v)>=100000f) return false;
            return true;
        }
        internal static bool ValidPush(float x,float y,float z)
        {
            if(float.IsNaN(x) || float.IsNaN(y) || float.IsNaN(z) || float.IsInfinity(x) || float.IsInfinity(y) || float.IsInfinity(z)) return false;
            return x*x+y*y+z*z<=MaxChargePush*MaxChargePush;
        }
        internal static bool ValidHurt(float damage,byte action,string prefab)
        {
            if(!(damage>0 && damage<=1000) || action<1 || action>HurtAnimal) return false;
            if(string.IsNullOrEmpty(prefab)) return true;
            if(action!=HurtMelee && action!=HurtPowerfulMelee || Text.GetByteCount(prefab)>MaxExplosiveName) return false;
            foreach(char c in prefab) if(c<0x20 || c==0x7F) return false;
            return true;
        }
        // The main tank (schema 33): no tank (both 0), or a level within a capacity.
        internal static bool ValidFuel(float fuel,float max)
        {
            if(float.IsNaN(fuel) || float.IsNaN(max) || max<0 || max>=100000f || fuel<0) return false;
            return max==0 ? fuel==0 : fuel<=max+1f;
        }
        internal static bool ValidStation(StationFrame s)
        {
            if(s==null || s.Key==0 || float.IsNaN(s.Fuel) || s.Fuel<0 || s.Fuel>=100000f || s.Flags>MaxStationFlags || s.Gun>GunLoose) return false;
            if(!GunPosed(s.Gun)) return s.GunPose==null;
            var g=s.GunPose;
            if(g==null) return false;
            foreach(float v in new[] {g.X,g.Y,g.Z,g.QX,g.QY,g.QZ,g.QW}) if(float.IsNaN(v) || float.IsInfinity(v) || Math.Abs(v)>=100000f) return false;
            float n=g.QX*g.QX+g.QY*g.QY+g.QZ*g.QZ+g.QW*g.QW;
            return n>=0.9f && n<=1.1f;
        }
        // Lying down and starting carry the hours; getting up carries none.
        internal static bool ValidSleep(byte action,int hours)
        { return action==SleepCancel ? hours==0 : (action==SleepWait || action==SleepStart) && hours>=1 && hours<=MaxSleepHours; }
        // A door toggle: close or open (no key), or unlock with a key item (schema 28).
        internal static bool ValidDoorToggle(byte action,int key)
        { return action<=1 ? key==0 : action==DoorUnlock && key>=0 && key<=MaxKeyItem; }
        // A quest frame: known flags, completed or ready only once accepted, a stage only once accepted.
        internal static bool ValidQuest(QuestFrame q)
        {
            if(q==null || q.Key==0 || q.Flags>MaxQuestFlags || q.Stage<-1 || q.Stage>MaxQuestStage) return false;
            if((q.Flags&QuestShared)!=0 && (q.Flags&QuestCompleted)==0) return false; // a reward only for a quest handed in
            if((q.Flags&QuestGifts)!=0 && (q.Flags&QuestAccepted)==0) return false;
            return (q.Flags&QuestAccepted)!=0 || q.Flags==0 && q.Stage==-1;
        }
        // The wire form of a chat packet: a message is 1..MaxChatChars UTF-16 units without
        // C0/C1 control characters (strict UTF-8 already excludes lone surrogates); an
        // acknowledgement has no text. Display always cleans again (LanChatChannel.Clean).
        // A nickname as typed (1.1.9): up to MaxNameChars characters, no control characters, no
        // markup brackets, no leading or trailing spaces; empty means none.
        internal static bool ValidName(string name)
        {
            if(name==null || name.Length>MaxNameChars || name!=name.Trim()) return false;
            foreach(char c in name) if(c<0x20 || c>=0x7F && c<=0x9F || c=='<' || c=='>' || char.IsSurrogate(c) || c=='\uFFFD') return false;
            return true;
        }
        // What the player typed, made valid (characters ValidName refuses are dropped).
        internal static string CleanName(string typed)
        {
            var b=new StringBuilder();
            foreach(char c in typed??"") if(!(c<0x20 || c>=0x7F && c<=0x9F || c=='<' || c=='>' || char.IsSurrogate(c) || c=='\uFFFD')) b.Append(c);
            var name=b.ToString().Trim();
            if(name.Length>MaxNameChars) name=name.Substring(0,MaxNameChars).Trim();
            return name;
        }
        internal static bool ValidChat(uint sequence,byte action,string text)
        {
            if(sequence==0 || action>1 || text==null) return false;
            if(action==1) return text.Length==0;
            if(text.Length==0 || text.Length>MaxChatChars) return false;
            foreach(char c in text) if(c<0x20 || c>=0x7F && c<=0x9F) return false;
            return true;
        }
        // Storage operations (LanStorage): 1 open (target, no handle), 2 take and 3 put
        // (handle and payload), 4 close (handle, no payload).
        // 0.7.0: 5 pick up a loose item, 6 drop an item, 7 work on the world, 8 craft at a host
        // workbench (no handle, payload). 0.8.0: 9 build on the host's train (no handle, payload).
        // 0.8.1: 10 place a blueprint on the host's train (no handle, payload).
        // 0.10.0: 11 use a control of the host's train (no handle, payload).
        // 0.12.0: 12 the guest died: everything it owns goes into a bag where it fell (no handle, payload).
        // 1.1.5: 13 cancel one queued craft of the open workbench (handle, payload).
        // 1.2.0: 14 accept or hand in a quest of the host's scene (no handle, payload).
        // 1.2.1: 15 carry a host object, or drive the guest's own robot dog (no handle, payload).
        internal const byte StorageOpen=1, StorageTake=2, StoragePut=3, StorageClose=4, StoragePickup=5, StorageDrop=6, StorageWork=7, StorageCraft=8, StorageBuild=9, StoragePlace=10, StorageControl=11, StorageDeath=12, StorageCraftCancel=13, StorageQuest=14, StorageTakable=15, StorageThrow=16, StorageDecor=17, StorageFurniture=18, StorageDismantle=19, MaxStorageStatus=23;
        internal static bool ValidStorageRequest(byte op,int handle,int payload)
        {
            switch(op)
            {
                case StorageOpen: case StoragePickup: case StorageDrop: case StorageWork: case StorageCraft: case StorageBuild: case StoragePlace: case StorageControl: case StorageDeath: case StorageQuest: case StorageTakable: case StorageThrow: case StorageDecor: case StorageFurniture: case StorageDismantle: return handle==0 && payload>0;
                case StorageTake: case StoragePut: case StorageCraftCancel: return handle>0 && payload>0;
                case StorageClose: return handle>0 && payload==0;
                default: return false;
            }
        }
        private static float ReadFloat(BinaryReader r)
        {
            float v=r.ReadSingle();
            if(float.IsNaN(v)||float.IsInfinity(v)||Math.Abs(v)>=100000f) throw new InvalidDataException("Invalid coordinate");
            return v;
        }
        // A player's state (State, and each frame of Players).
        private static void WriteState(BinaryWriter w,Packet p)
        {
            w.Write(p.Sequence); WriteText(w,p.Scene,96);
            w.Write(p.X); w.Write(p.Y); w.Write(p.Z); w.Write(p.Yaw); w.Write(p.TrainPosition);
            w.Write((sbyte)p.CarIndex); w.Write(p.LocalX); w.Write(p.LocalY); w.Write(p.LocalZ); w.Write(p.LocalYaw);
            w.Write(p.EquippedItemId); w.Write(p.ShotSequence); w.Write(p.ShotItemId); w.Write(p.Health);
            w.Write(p.Pitch); w.Write(p.Pose);
            w.Write(p.HealthNow); w.Write(p.HealthMax); w.Write(p.Skin);
            if(!ValidName(p.Name??"")) throw new InvalidDataException("Player name");
            WriteText(w,p.Name??"",MaxNameBytes);
            if(!ValidDash(p.Dash)) throw new InvalidDataException("Dash");
            if(!ValidMotion(p.Motion)) throw new InvalidDataException("Motion");
            w.Write(p.SentAt); w.Write(p.Dash); w.Write(p.Motion); w.Write(p.Throws); w.Write(p.Interacts);
            var outfit=p.Outfit??new ushort[0];
            if(outfit.Length>MaxOutfit) throw new InvalidDataException("Outfit");
            w.Write((byte)outfit.Length); foreach(var item in outfit) w.Write(item);
            var mods=p.HandMods??new ushort[0];
            if(mods.Length>MaxHandMods) throw new InvalidDataException("Hand mods");
            w.Write((byte)mods.Length); foreach(var mod in mods) w.Write(mod);
        }
        private static bool ReadState(BinaryReader r,Packet p)
        {
            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96);
            p.X=ReadFloat(r); p.Y=ReadFloat(r); p.Z=ReadFloat(r); p.Yaw=ReadFloat(r); p.TrainPosition=ReadFloat(r);
            if(string.IsNullOrEmpty(p.Scene) || p.Yaw < 0 || p.Yaw > 360 || p.TrainPosition < 0) return false;
            p.CarIndex=r.ReadSByte();
            if(p.CarIndex < -1 || p.CarIndex>=MaxCars) return false;
            p.LocalX=ReadFloat(r); p.LocalY=ReadFloat(r); p.LocalZ=ReadFloat(r); p.LocalYaw=ReadFloat(r);
            if(Math.Abs(p.LocalX)>100 || Math.Abs(p.LocalY)>100 || Math.Abs(p.LocalZ)>100) return false;
            if(p.LocalYaw < 0 || p.LocalYaw > 360) return false;
            p.EquippedItemId=r.ReadInt32(); p.ShotSequence=r.ReadUInt32(); p.ShotItemId=r.ReadInt32();
            if(p.EquippedItemId < -1 || p.EquippedItemId > 65535 || p.ShotItemId < -1 || p.ShotItemId > 65535) return false;
            p.Health=r.ReadByte(); if(p.Health>100 && p.Health!=NoHealth) return false;
            p.Pitch=ReadFloat(r); p.Pose=r.ReadByte();
            if(p.Pitch < -MaxPitch || p.Pitch > MaxPitch || p.Pose>MaxPose) return false;
            p.HealthNow=r.ReadUInt16(); p.HealthMax=r.ReadUInt16(); p.Skin=r.ReadByte();
            if(p.HealthNow>p.HealthMax || p.Skin>MaxSkin && p.Skin!=NoSkin) return false;
            p.Name=ReadText(r,MaxNameBytes); if(!ValidName(p.Name)) return false;
            p.SentAt=r.ReadUInt32(); p.Dash=r.ReadByte(); if(!ValidDash(p.Dash)) return false;
            p.Motion=r.ReadByte(); p.Throws=r.ReadByte(); if(!ValidMotion(p.Motion)) return false;
            p.Interacts=r.ReadByte();
            int worn=r.ReadByte(); if(worn>MaxOutfit) return false;
            p.Outfit=new ushort[worn]; for(int i=0;i<worn;i++) p.Outfit[i]=r.ReadUInt16();
            int mods=r.ReadByte(); if(mods>MaxHandMods) return false;
            p.HandMods=new ushort[mods]; for(int i=0;i<mods;i++) p.HandMods[i]=r.ReadUInt16();
            return true;
        }
        private static void WritePose(BinaryWriter w,NetPose p) { w.Write(p.X);w.Write(p.Y);w.Write(p.Z);w.Write(p.QX);w.Write(p.QY);w.Write(p.QZ);w.Write(p.QW); }
        private static NetPose ReadPose(BinaryReader r)
        {
            var p=new NetPose {X=ReadFloat(r),Y=ReadFloat(r),Z=ReadFloat(r),QX=ReadFloat(r),QY=ReadFloat(r),QZ=ReadFloat(r),QW=ReadFloat(r)};
            float n=p.QX*p.QX+p.QY*p.QY+p.QZ*p.QZ+p.QW*p.QW;
            if(n<0.9f || n>1.1f) throw new InvalidDataException("Invalid rotation");
            return p;
        }
        private static void WriteText(BinaryWriter w,string value,int maximum)
        {
            var b=Text.GetBytes(value??""); if(b.Length>maximum) throw new ArgumentException("LAN text field too long");
            w.Write((byte)b.Length); w.Write(b);
        }
        private static string ReadText(BinaryReader r,int maximum)
        {
            int length=r.ReadByte(); if(length>maximum) throw new InvalidDataException("LAN text field too long");
            var b=r.ReadBytes(length); if(b.Length!=length) throw new EndOfStreamException(); return Text.GetString(b);
        }
    }
}
