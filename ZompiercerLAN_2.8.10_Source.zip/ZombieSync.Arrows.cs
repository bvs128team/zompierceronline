using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;
using UnityEngine;
using Object = UnityEngine.Object;

namespace ZompiercerLAN
{
    internal sealed partial class ZombieSync
    {
        private const float MinArrowSpeed = 8f;
        private readonly HashSet<BulletScript> _hostArrows = new HashSet<BulletScript>();

        private static byte DrawCode(float speed, float maxSpeed)
        {
            if (!HostCombatInventory.Finite(speed) || !HostCombatInventory.Finite(maxSpeed) || maxSpeed <= 0)
                return 1;
            return (byte)(1 + Math.Round(Math.Max(0, Math.Min(1, speed / maxSpeed)) * 254));
        }

        private static float ArrowSpeed(byte draw, float maxSpeed, int strength)
        {
            float drawSpeed = Math.Max(MinArrowSpeed, maxSpeed * (draw - 1) / 254f);
            return drawSpeed * (1f + .015f * strength);
        }

        private void FireGuestArrow(Remote guest, Bow bow, WeaponData weapon, Vector3 origin, Vector3 aim, byte draw)
        {
            float maxSpeed = bow.ArrowSpeedMax;
            if (!HostCombatInventory.Finite(maxSpeed) || maxSpeed <= 0f) return;
            var ledger = guest.Combat.Ledger?.Invoke();
            int strength = ledger == null ? 1 : ledger.StrengthLevel;
            var body = Object.Instantiate(bow.arrowPrefab, origin, Quaternion.LookRotation(aim));
            var arrow = body.GetComponent<BulletScript>();
            if (arrow == null) { Object.Destroy(body.gameObject); return; }
            arrow.bulletDamage = Mathf.Clamp(arrow.bulletDamage * (1f + .05f * (strength - 1)) *
                (1f + Mathf.Clamp(bow.DamageMultiplier, 0f, 10f)), 0f, 400f);
            arrow.StealthDamageMultiplier = Mathf.Clamp(weapon.stealthModifier, 0f, 10f);
            body.AddRelativeForce(Vector3.forward * ArrowSpeed(draw, maxSpeed, strength), ForceMode.VelocityChange);
            _hostArrows.RemoveWhere(round => round == null);
            _hostArrows.Add(arrow);
            GuestRound(arrow, guest);
        }

        private void ClearGuestArrows()
        {
            foreach (var arrow in _hostArrows)
            {
                if (arrow == null) continue;
                arrow.enabled = false;
                Object.Destroy(arrow.gameObject);
            }
            _hostArrows.Clear();
        }

        // Use the distance the rigidbody can actually travel this step, even on a full draw.
        // The native minimum still applies at low speeds.
        private static void ArrowStep(BulletScript arrow, ref Ray ray, ref float distance)
        {
            var body = arrow.GetComponent<Rigidbody>();
            if (body == null) return;
            var velocity = body.velocity;
            float speed = velocity.magnitude;
            if (speed <= 1f) return;
            ray.direction = velocity / speed;
            distance = Mathf.Max(distance, speed * Time.fixedDeltaTime);
        }

        private static IEnumerable<CodeInstruction> ReplaceBulletContactRay(IEnumerable<CodeInstruction> instructions)
        {
            var native = AccessTools.Method(typeof(Physics), nameof(Physics.Raycast),
                new[] { typeof(Ray), typeof(RaycastHit).MakeByRefType(), typeof(float), typeof(int) });
            var replacement = AccessTools.Method(typeof(ZombieSync), nameof(BulletContactRay));
            var result = new List<CodeInstruction>();
            int replaced = 0;
            foreach (var instruction in instructions)
            {
                if (instruction.opcode == OpCodes.Call && Equals(instruction.operand, native))
                {
                    var loadArrow = new CodeInstruction(OpCodes.Ldarg_0);
                    loadArrow.labels.AddRange(instruction.labels);
                    instruction.labels.Clear();
                    result.Add(loadArrow);
                    instruction.operand = replacement;
                    replaced++;
                }
                result.Add(instruction);
            }
            if (replaced != 1) throw new InvalidOperationException("Unsupported BulletScript.BulletContact raycast");
            return result;
        }

        private static bool BulletContactRay(Ray ray, out RaycastHit hit, float distance, int mask, BulletScript round)
        {
            var sync = Active;
            if (round.arrow && sync != null && sync._hostArrows.Contains(round))
                ArrowStep(round, ref ray, ref distance);
            return Physics.Raycast(ray, out hit, distance, mask);
        }

        // The native contact handles damage, material effects and recoverable arrows.
        // A solid without a recognized material tag still stops a guest's arrow.
        private static void AfterBulletContact(BulletScript __instance, RaycastHit ___hit)
        {
            var sync = Active;
            if (!__instance.arrow || sync == null || ___hit.collider == null || ___hit.collider.isTrigger ||
                !sync._hostArrows.Remove(__instance)) return;
            _guestRounds.Remove(__instance.GetInstanceID());
            __instance.enabled = false;
            Object.Destroy(__instance.gameObject);
        }

        private static bool GuestArrowSurface(Ray ray, float distance, int mask, out RaycastHit hit)
        {
            bool found = Physics.Raycast(ray, out hit, distance, mask);
            float nearest = found ? hit.distance : distance;
            const int replicaLayers = (1 << 2) | (1 << TrainLayout.SupportLayer);
            int extra = replicaLayers & ~mask;
            if (extra == 0) return found;
            foreach (var copy in Physics.RaycastAll(ray, nearest, extra, QueryTriggerInteraction.Ignore))
            {
                if (found && copy.distance >= nearest) continue;
                var collider = copy.collider;
                if (collider == null) continue;
                if (!TrainLayout.IsGroundSupport(collider) && collider.GetComponentInParent<LanWorldReplica>() == null &&
                    !TrainLayout.TryIdentifyItem(collider, out _, out _)) continue;
                hit = copy;
                nearest = copy.distance;
                found = true;
            }
            return found;
        }

        private void GuestArrowContact(BulletScript arrow)
        {
            if (_host || !_playerReady)
            {
                arrow.enabled = false;
                Object.Destroy(arrow.gameObject);
                return;
            }
            var body = arrow.GetComponent<Rigidbody>();
            if (body != null) body.detectCollisions = false; // Only the host can affect the world.
            var ray = new Ray(arrow.transform.position, arrow.transform.forward);
            float distance = arrow.bulletRayDistance;
            ArrowStep(arrow, ref ray, ref distance);
            bool hitSurface = GuestArrowSurface(ray, distance, arrow.targetRaycastMask.value, out var surface);
            if (hitSurface) distance = surface.distance;
            bool hitCreature = RoundHits(ray.origin, ray.direction, distance, out var creature, out var bone, out var along);
            if (!hitSurface && !hitCreature) return;

            arrow.enabled = false;
            Object.Destroy(arrow.gameObject);
            try
            {
                if (hitCreature)
                    BulletBlood(ray.GetPoint(along), ray.direction, bone, creature.Root.transform.position);
                else if (arrow.arrowBrake != null)
                    Object.Instantiate(arrow.arrowBrake, surface.point, arrow.transform.rotation);
            }
            catch (Exception ex)
            {
                if (_arrowEffectFailed) return;
                _arrowEffectFailed = true;
                _report("Arrow impact effect failed: " + ex.GetType().Name + ": " + ex.Message);
            }
        }
        private bool _arrowEffectFailed;
    }
}
