# Build / Сборка

Install the .NET SDK (10 for the LAN security checks). Run PowerShell from this Source folder:

```powershell
./build.ps1 -GameDir "<installed game folder>"
```

Установите .NET SDK (10 для проверок безопасности LAN). Выполните команду выше в PowerShell из папки Source, указав путь к игре.

Output / Результат: bin/Release/net472. Build script does not install or overwrite game files. Скрипт не устанавливает сборку и не меняет файлы игры.
Game assemblies are referenced from your installation and are not redistributed. Игровые библиотеки берутся из установленной игры и не распространяются.
Runtime third-party licenses are in vendor/licenses and vendor/BouncyCastle. Existing copyright and license notices are retained. No new license is assigned to code that has no license notice.
Лицензии сторонних библиотек находятся в vendor/licenses и vendor/BouncyCastle. Существующие уведомления об авторстве сохранены. Для кода без лицензии новая лицензия не назначалась.

Version 2.8.10 supports direct LAN and a custom internet relay. The source has empty built-in relay defaults. The installed game is needed for compilation.

2.8.8 prevents a delayed death request from emptying the inventory restored from an earlier save. The selected save must contain the guest profile.

В версии 2.8.8 запоздалый запрос о гибели больше не очищает инвентарь, восстановленный из раннего сохранения. В выбранном сохранении должен быть профиль гостя.

2.8.9 fixes guest bow arrows passing through objects. The host simulates the arrow using the bow’s draw and the guest sees it stop at impact. This release includes the 2.8.8 death and reload fix.

В версии 2.8.9 исправлен пролёт стрел гостя сквозь объекты. Хост моделирует полёт стрелы с учётом натяжения лука, а гость видит попадание. Исправление потери вещей после гибели из версии 2.8.8 включено.

2.8.10 adds compatibility with Zompiercer 22.2, Steam build 26851073. The guest bow and death reload fixes from 2.8.9 are included.

Версия 2.8.10 совместима с Zompiercer 22.2, сборка Steam 26851073. Исправления стрельбы из лука и загрузки после гибели из версии 2.8.9 включены.
