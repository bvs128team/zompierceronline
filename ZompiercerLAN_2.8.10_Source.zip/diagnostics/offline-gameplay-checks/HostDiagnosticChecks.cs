using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Threading;

internal static class HostDiagnosticChecks
{
    internal static void Run(Assembly mod)
    {
        const BindingFlags flags = BindingFlags.Instance | BindingFlags.NonPublic;
        Type type = mod.GetType("ZompiercerLAN.LanCheckpointWriter", true);
        MethodInfo enqueue = type.GetMethod("Enqueue", flags), shutdown = type.GetMethod("Shutdown", flags), status = type.GetMethod("Status", flags);
        var entered = new ManualResetEvent(false);
        var release = new ManualResetEvent(false);
        var writes = new Dictionary<string, string>();
        Action<string, string> sink = (path, text) =>
        {
            if (path == "blocked") { entered.Set(); release.WaitOne(); }
            lock (writes) writes[path] = text;
        };
        object writer = Activator.CreateInstance(type, flags, null, new object[] { sink }, null);
        Func<string, string, bool> put = (path, text) => (bool)enqueue.Invoke(writer, new object[] { path, text });
        try
        {
            Require(put("blocked", "first") && entered.WaitOne(3000), "Writer did not start");
            Require(put("latest", "old") && put("latest", "new"), "Latest coalescing failed");
            for (int i = 0; i < 159; i++) Require(put("numbered-" + i, "evidence-" + i), "Bound rejected too early");
            Require(!put("overflow", "rejected"), "Queue is not bounded");
            Require(put("latest", "newest"), "Full queue must still accept replacement");
            Require(!put("latest", new string('x', 8 * 1024 * 1024 + 1)), "Payload memory bound missing");
            var watch = Stopwatch.StartNew();
            Require(!(bool)shutdown.Invoke(writer, new object[] { 0 }), "Blocked disk incorrectly drained");
            Require(watch.ElapsedMilliseconds < 1000, "Nonblocking shutdown waited for disk");
            Require(!put("after-stop", "rejected"), "Stopped writer accepted more work");
            release.Set();
            bool done = false;
            for (int i = 0; i < 30 && !done; i++) done = (bool)shutdown.Invoke(writer, new object[] { 100 });
            Require(done, "Writer failed to drain");
            lock (writes)
            {
                Require(writes.Count == 161 && writes["latest"] == "newest", "Coalescing lost numbered evidence or latest state");
                for (int i = 0; i < 159; i++) Require(writes["numbered-" + i] == "evidence-" + i, "Numbered evidence corrupted");
            }
            string summary = (string)status.Invoke(writer, null);
            Require(summary.Contains("coalesced=2") && summary.Contains("rejected=3") && summary.Contains("pending=0"), "Writer metrics incorrect: " + summary);
        }
        finally { release.Set(); shutdown.Invoke(writer, new object[] { 100 }); }

        Action<string, string> failure = (path, text) => { throw new System.IO.IOException("test disk failure"); };
        object broken = Activator.CreateInstance(type, flags, null, new object[] { failure }, null);
        enqueue.Invoke(broken, new object[] { "failure", "evidence" });
        bool finished = false;
        for (int i = 0; i < 30 && !finished; i++) finished = (bool)shutdown.Invoke(broken, new object[] { 100 });
        Require(finished && ((string)status.Invoke(broken, null)).Contains("failed=1"), "Disk failure was not contained/reported");
        Console.WriteLine("PASS: bounded asynchronous checkpoint queue, latest coalescing, numbered evidence, memory cap, nonblocking stop and disk failure reporting (managed only)");
    }

    private static void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
}
