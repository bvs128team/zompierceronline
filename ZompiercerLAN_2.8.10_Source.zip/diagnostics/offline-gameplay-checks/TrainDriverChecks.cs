using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

internal static class TrainDriverChecks
{
    internal static void Run(Assembly game, Assembly mod)
    {
        const BindingFlags flags = BindingFlags.NonPublic | BindingFlags.Static;
        var controls = mod.GetType("ZompiercerLAN.LanTrainControl", true);
        var transform = controls.GetMethod("ReplaceDriverPresence", flags);
        var update = game.GetType("Zompiercer.Train.TrainController", true).GetMethod("Update", BindingFlags.NonPublic | BindingFlags.Instance);
        var original = PatchProcessor.GetOriginalInstructions(update, (ILGenerator)null);
        var field = game.GetType("ZombieFighterController", true).GetField("OnTrainCar");
        Require(original.Count(i => i.opcode == OpCodes.Ldfld && Equals(i.operand, field)) == 1, "Native train presence probe changed");
        var patched = ((IEnumerable<CodeInstruction>)transform.Invoke(null, new object[] { original })).ToList();
        Require(patched.Count == original.Count, "Train presence transform changes instruction count");
        Require(!patched.Any(i => i.opcode == OpCodes.Ldfld && Equals(i.operand, field)), "Train still checks only the host passenger");
        var replacement = patched.Single(i => i.operand is MethodInfo m && m.Name == "DriverCar");
        var helper = (MethodInfo)replacement.operand;
        Require(helper.ReturnType == field.FieldType && helper.GetParameters().Single().ParameterType == field.DeclaringType, "Presence replacement changes stack types");
        Require(patched.Any(i => i.operand is MethodInfo m && m.Name == "EmergencyBraking"), "Emergency braking was removed");
        foreach (int count in new[] { 0, 2 })
        {
            var changed = new List<CodeInstruction>();
            for (int i = 0; i < count; i++) changed.Add(new CodeInstruction(OpCodes.Ldfld, field));
            bool rejected = false;
            try { transform.Invoke(null, new object[] { changed }); }
            catch (TargetInvocationException ex) { rejected = ex.InnerException is InvalidOperationException; }
            Require(rejected, "Unsupported driver presence IL accepted");
        }
        var body = PatchProcessor.GetOriginalInstructions(helper, (ILGenerator)null);
        foreach (string name in new[] { "HostAllows", "HostGuestCar" })
            Require(body.Any(i => i.operand is FieldInfo f && f.Name == name), "Guest presence bypasses " + name);
        Require(body.Any(i => i.operand is MethodInfo m && m.Name == "get_Active" && m.DeclaringType.Name == "LanSaveIsolation"), "Guest copy can override native driver authority");
        var look = PatchProcessor.GetOriginalInstructions(controls.GetMethod("TickNativeLook", flags), (ILGenerator)null);
        Require(look.Any(i => i.operand is MethodInfo m && m.Name == "InteractionRay" && m.DeclaringType.Name == "TrainInteractionRays"), "Cab fallback uses different geometry filtering from native interaction");
        Console.WriteLine("PASS: actual native unattended-train probe accepts authorized guests, retains emergency brake and rejects changed IL");
    }
    private static void Require(bool value, string message) { if (!value) throw new InvalidOperationException(message); }
}
