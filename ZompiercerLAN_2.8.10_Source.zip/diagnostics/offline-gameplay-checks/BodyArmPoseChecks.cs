using System;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using ZompiercerLAN;

// Executes the production scalar arm solver with the shipped RigW/RigSkuf segment lengths.
// No Transform, animator, game object, scene, or Unity process is created.
internal static class BodyArmPoseChecks
{
    private const BindingFlags All = BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
    private static RemoteArmSolver.Point P(float x, float y, float z) { return new RemoteArmSolver.Point(x, y, z); }

    internal static void Run(Assembly game, Assembly mod)
    {
        var motion = mod.GetType("ZompiercerLAN.RemoteAvatarMotion", true);
        var late = PatchProcessor.GetOriginalInstructions(motion.GetMethod("LateUpdate", All), (ILGenerator)null).ToList();
        int use = Call(late, "Using"), flinch = Call(late, "Flinching"), swim = Call(late, "Swimming"), roll = Call(late, "Roll");
        Require(use > flinch && use > swim && use > roll, "Mouth target is solved before final head/body motion");
        var reach = PatchProcessor.GetOriginalInstructions(motion.GetMethod("Reach", All), (ILGenerator)null).ToList();
        Require(Call(reach, "Solve") >= 0, "Runtime arm reach bypasses the tested body solver");
        var prepare = PatchProcessor.GetOriginalInstructions(motion.GetMethod("PrepareTurns", All), (ILGenerator)null).ToList();
        var reachInput = PatchProcessor.GetOriginalInstructions(motion.GetMethod("ReachInput", All), (ILGenerator)null).ToList();
        Require(prepare.Count(i => (i.operand as MethodBase)?.Name == "InverseTransformDirection") >= 3 &&
            reachInput.Count(i => (i.operand as MethodBase)?.Name == "TransformDirection") == 3,
            "Torso body axes are not calibrated relative to the NPC chest bone");
        foreach (var field in new[] { "_torsoRightLocal", "_torsoUpLocal", "_torsoForwardLocal" })
            Require(prepare.Any(i => i.opcode == OpCodes.Stfld && (i.operand as FieldInfo)?.Name == field) &&
                reachInput.Any(i => i.opcode == OpCodes.Ldfld && (i.operand as FieldInfo)?.Name == field),
                "Torso frame calibration is not used for " + field);
        // RigW: .26802 m shoulder span, upper .30253, twist chain .234.
        // RigSkuf: .40096 m span, upper .31836, twist chain .23832.
        // Derived from the local TRS hierarchy in diagnostics/grip-npc-full.jsonl.
        CheckTorso(false, .30253f, .234f, .26802f, .01335f, -.02501f, .43235f);
        CheckTorso(true, .31836f, .23832f, .40096f, -.07282f, -.05013f, .56608f);
        CheckReachBoundary();
        CheckMouth(.30253f, .234f);
        CheckTransition(.30253f, .234f);
        CheckOpposingPole();
        Console.WriteLine("PASS: body-aware scalar arm geometry for free reaches and mouth ordering (held items: hold-pose-checks)");
    }

    private static void CheckTorso(bool left, float upper, float lower, float width,
        float shoulderY, float shoulderZ, float torsoHeight)
    {
        float sign = left ? -1f : 1f;
        var shoulder = P(sign * width * .5f, shoulderY, shoulderZ);
        // Adversarial animator bend: elbow and wrist point inward and behind the chest.
        var elbow = P(sign * (width * .5f - .09f), -.12f, -.24f);
        var wrist = P(sign * .04f, -.19f, -.20f);
        elbow = AtDistance(shoulder, elbow, upper);
        wrist = AtDistance(elbow, wrist, lower);
        var input = Input(left, width, torsoHeight, shoulder, elbow, wrist, P(0f, -.14f, -.17f), 1f);
        var result = RemoteArmSolver.Solve(input);
        Require(result.Valid, "Cross-torso case did not solve");
        Require(result.Elbow.X * sign > width * .25f, "Elbow still bends across torso");
        Require(ClearArm(input, result), "Upper arm or forearm crosses actual-rig torso proxy");
        Require(Near(Distance(shoulder, result.Elbow), upper, .002f) &&
            Near(Distance(result.Elbow, result.Wrist), lower, .002f), "Solved arm changed its bone lengths");
    }

    private static void CheckReachBoundary()
    {
        // A long downward reach across the chest used to pass the torso even though its wrist
        // had been pushed forward. This case approaches the RigW arm's maximum extension.
        float width = .26802f;
        var shoulder = P(width * .5f, .01335f, -.02501f);
        var elbow = AtDistance(shoulder, P(.05f, -.16f, -.23f), .30253f);
        var wrist = AtDistance(elbow, P(.03f, -.36f, -.17f), .234f);
        foreach (float x in new[] { -.15f, -.10f, 0f, .08f })
            foreach (float y in new[] { -.40f, -.20f, .12f })
                foreach (float z in new[] { -.15f, 0f, .10f })
                {
                    var input = Input(false, width, .43235f, shoulder, elbow, wrist, P(x, y, z), 1f);
                    var solved = RemoteArmSolver.Solve(input);
                    Require(solved.Valid && ClearArm(input, solved),
                        "Long cross-body reach still enters the torso at " + x + "," + y + "," + z);
                }
    }

    private static void CheckMouth(float upper, float lower)
    {
        var shoulder = P(.13401f, .01335f, -.02501f);
        var elbow = AtDistance(shoulder, P(.40f, -.12f, .12f), upper);
        var wrist = AtDistance(elbow, P(.16f, .12f, .23f), lower);
        // Mouth is above torso and must remain at the measured food/bottle contact.
        var target = P(.03f, .23f, .18f);
        var solved = RemoteArmSolver.Solve(Input(false, .26802f, .43235f, shoulder, elbow, wrist, target, 1f));
        Require(solved.Valid && Distance(solved.Wrist, target) < .002f,
            "Food contact was displaced from the mouth");
        Require(solved.Elbow.X > .1f, "Eating elbow crosses the body");
    }

    private static void CheckTransition(float upper, float lower)
    {
        var shoulder = P(.13401f, .01335f, -.02501f);
        var elbow = AtDistance(shoulder, P(.43f, -.18f, .07f), upper);
        var wrist = AtDistance(elbow, P(.38f, -.22f, .26f), lower);
        var target = P(.06f, -.12f, .20f);
        var start = RemoteArmSolver.Solve(Input(false, .26802f, .43235f, shoulder, elbow, wrist, target, 0f));
        var tiny = RemoteArmSolver.Solve(Input(false, .26802f, .43235f, shoulder, elbow, wrist, target, .0011f));
        var low = RemoteArmSolver.Solve(Input(false, .26802f, .43235f, shoulder, elbow, wrist, target, .01f));
        var halfway = RemoteArmSolver.Solve(Input(false, .26802f, .43235f, shoulder, elbow, wrist, target, .5f));
        var full = RemoteArmSolver.Solve(Input(false, .26802f, .43235f, shoulder, elbow, wrist, target, 1f));
        Require(!start.Valid && tiny.Valid && low.Valid && halfway.Valid && full.Valid, "Arm transition does not respect zero weight");
        Require(Distance(tiny.Elbow, elbow) < .005f && Distance(low.Elbow, elbow) < .02f,
            "Elbow snaps when reach starts");
        Require(Distance(halfway.Wrist, wrist) < Distance(full.Wrist, wrist), "Arm transition skips its intermediate pose");
    }

    private static void CheckOpposingPole()
    {
        var shoulder = P(.13401f, .01335f, -.02501f);
        // The source elbow bends inward; the goal is almost directly forward. The final pole
        // must reach the outward side exactly, including the nearly antipodal bend case.
        var elbow = AtDistance(shoulder, P(-.12f, -.01f, .05f), .30253f);
        var wrist = AtDistance(elbow, P(-.08f, -.02f, .28f), .234f);
        var result = RemoteArmSolver.Solve(Input(false, .26802f, .43235f, shoulder,
            elbow, wrist, P(.13401f, .01335f, .28f), 1f));
        Require(result.Valid && result.Elbow.X > shoulder.X + .02f,
            "Full-weight bend pole did not reach its outward endpoint");
    }

    private static bool ClearArm(RemoteArmSolver.Input input, RemoteArmSolver.Result result)
    {
        var joints = new[] { input.Shoulder, result.Elbow, result.Wrist };
        float top = input.Shoulder.Y + input.ShoulderWidth * .55f;
        for (int segment = 0; segment < 2; segment++)
            for (int step = 1; step <= 10; step++)
            {
                var point = Mix(joints[segment], joints[segment + 1], step / 10f);
                if (point.Y < -input.TorsoHeight || point.Y > top) continue;
                if (Math.Abs(point.X) < input.ShoulderWidth * .40f &&
                    point.Z > -input.ShoulderWidth * .28f && point.Z < input.ShoulderWidth * .42f) return false;
            }
        return true;
    }
    private static RemoteArmSolver.Input Input(bool left, float width, float height, RemoteArmSolver.Point shoulder,
        RemoteArmSolver.Point elbow, RemoteArmSolver.Point wrist, RemoteArmSolver.Point target, float weight)
    {
        return new RemoteArmSolver.Input { Left = left, ShoulderWidth = width, TorsoHeight = height, Shoulder = shoulder,
            Elbow = elbow, Wrist = wrist, Target = target, Chest = P(0f, 0f, 0f),
            Right = P(1f, 0f, 0f), Forward = P(0f, 0f, 1f), Up = P(0f, 1f, 0f), Weight = weight };
    }
    private static RemoteArmSolver.Point AtDistance(RemoteArmSolver.Point a, RemoteArmSolver.Point b, float length)
    { var delta = b - a; return a + delta * (length / delta.Length); }
    private static RemoteArmSolver.Point Mix(RemoteArmSolver.Point a, RemoteArmSolver.Point b, float t)
    { return a + (b - a) * t; }
    private static float Distance(RemoteArmSolver.Point a, RemoteArmSolver.Point b) { return (a - b).Length; }
    private static bool Near(float a, float b, float tolerance) { return Math.Abs(a - b) < tolerance; }
    private static int Call(System.Collections.Generic.List<CodeInstruction> body, string name)
    { return body.FindIndex(i => (i.opcode == OpCodes.Call || i.opcode == OpCodes.Callvirt) && (i.operand as MethodBase)?.Name == name); }
    private static void Require(bool condition, string message)
    { if (!condition) throw new InvalidOperationException(message); }
}
