using System;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;

// 2.6.1: Zompiercer.Singleton<T>.Global creates a bare manager when the real one is gone (on the way to the main
// menu); the menu's real InputController then destroys itself. The mod must read the registered instance only.
internal static class SingletonAccessChecks
{
    internal static void Run(Assembly game, Assembly mod)
    {
        var singleton = game.GetType("Zompiercer.Singleton`1", true);
        Require(singleton.GetField("_instance", BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public) != null,
            "Singleton<T>._instance missing: LanGame would read every manager as absent");
        // Read on a closed type: Harmony cannot read the open generic getter.
        var getter = singleton.MakeGenericType(game.GetType("Zompiercer.Inputs.InputController", true))
            .GetProperty("Global", BindingFlags.Static | BindingFlags.Public)?.GetGetMethod();
        Require(getter != null && Program.ReadInstructions(getter).Any(i => (i.opcode == OpCodes.Call || i.opcode == OpCodes.Callvirt) && i.operand is MethodInfo m && m.Name == "AddComponent"),
            "Singleton<T>.Global no longer creates a stand-in (recheck whether LanGame is still needed)");
        var lanGame = mod.GetType("ZompiercerLAN.LanGame", true);
        foreach (var name in new[] { "Input", "Gui", "Stats", "Detector", "GuiCore" })
            Require(lanGame.GetProperty(name, BindingFlags.Static | BindingFlags.NonPublic) != null, "LanGame." + name + " missing");

        int methods = 0;
        const BindingFlags all = BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.DeclaredOnly;
        foreach (var type in mod.GetTypes())
            foreach (var method in type.GetMethods(all).Cast<MethodBase>().Concat(type.GetConstructors(all)))
            {
                if (method.GetMethodBody() == null || method.ContainsGenericParameters) continue;
                methods++;
                foreach (var i in Program.ReadInstructions(method))
                {
                    // 2.6.3: GlobalManager.GameStarted is set only by a new game; a loaded world (most hosts) never has it.
                    if (i.opcode == OpCodes.Ldfld && i.operand is FieldInfo started && started.Name == "GameStarted" && started.DeclaringType != null && started.DeclaringType.Name == "GlobalManager")
                        throw new Exception("GameStarted read in " + type.FullName + "." + method.Name + ": false in every loaded world");
                    if ((i.opcode == OpCodes.Call || i.opcode == OpCodes.Callvirt) && i.operand is MethodInfo called && called.Name == "get_Global" &&
                        called.DeclaringType != null && called.DeclaringType.IsGenericType &&
                        called.DeclaringType.GetGenericTypeDefinition().FullName == "Zompiercer.Singleton`1")
                        throw new Exception("Self-creating " + called.DeclaringType.GetGenericArguments()[0].Name + ".Global in " +
                            type.FullName + "." + method.Name + ": use LanGame");
                }
            }
        Console.WriteLine("PASS: no self-creating Singleton<T>.Global and no GameStarted read in " + methods + " mod methods; LanGame reads Singleton<T>._instance");
    }

    private static void Require(bool ok, string message) { if (!ok) throw new Exception(message); }
}
