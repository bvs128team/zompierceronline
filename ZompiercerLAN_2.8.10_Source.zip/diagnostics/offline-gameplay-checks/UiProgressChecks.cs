using System;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

internal static class UiProgressChecks
{
    internal static void Run(Assembly game, Assembly mod)
    {
        const BindingFlags statics = BindingFlags.NonPublic | BindingFlags.Static;
        var progress = mod.GetType("ZompiercerLAN.LanWorkProgress", true);
        var fraction = progress.GetMethod("Fraction", statics);
        Func<float, float, float> evaluate = (current, maximum) => (float)fraction.Invoke(null, new object[] { current, maximum });
        foreach (var values in new[] { new[] { 25f, 100f, .25f }, new[] { -1f, 100f, 0f }, new[] { 101f, 100f, 1f },
            new[] { 1f, 0f, 0f }, new[] { float.NaN, 100f, 0f }, new[] { 1f, float.PositiveInfinity, 0f } })
            Require(Math.Abs(evaluate(values[0], values[1]) - values[2]) < .0001f, "Invalid work HUD fraction");
        var manager = game.GetType("GlobalManager", true);
        foreach (var field in new[] { "buildProgressInfoDisplayer", "buildProgressInfoBar", "buildProgressInfoText" })
        {
            Require(manager.GetField(field) != null, "Native work HUD field missing: " + field);
            var body = PatchProcessor.GetOriginalInstructions(progress.GetMethod("Show", statics), (ILGenerator)null);
            Require(body.Any(i => i.operand is FieldInfo f && f.Name == field), "Work HUD never updates " + field);
        }
        var late = mod.GetType("ZompiercerLAN.LanPlugin", true).GetMethod("LateUpdate", BindingFlags.Instance | BindingFlags.NonPublic);
        Require(PatchProcessor.GetOriginalInstructions(late, (ILGenerator)null).Any(i => i.operand is MethodInfo m &&
            m.DeclaringType.Name == "LanTrainBuild" && m.Name == "DrawProgress"), "Train work HUD is not drawn after native Update");
        var draw = mod.GetType("ZompiercerLAN.LanTrainBuild", true).GetMethod("DrawProgress", statics);
        var calls = PatchProcessor.GetOriginalInstructions(draw, (ILGenerator)null);
        Require(calls.Any(i => i.operand is MethodInfo m && m.DeclaringType == progress && m.Name == "Show"), "Train work HUD is not populated");
        Require(calls.Any(i => i.operand is MethodInfo m && m.Name == "TryIdentifyBuild"), "Train work HUD ignores host build state");
        Console.WriteLine("PASS: native work bar uses host progress after Update; percentage bounds and invalid values checked without Unity execution");
    }
    private static void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
}
