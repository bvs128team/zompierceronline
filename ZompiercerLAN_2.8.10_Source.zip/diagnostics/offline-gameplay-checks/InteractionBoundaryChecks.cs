using System;
using System.Collections.Generic;
using System.Reflection;

// Doubles only at the Unity query boundary. The filtering implementation is the
// linked production source; actual game method compatibility is checked separately.
namespace UnityEngine
{
    public sealed class Collider { }
    public struct Ray { }
    public struct RaycastHit { public Collider collider; public float distance; }
    public enum QueryTriggerInteraction { UseGlobal }
    public static class Physics
    {
        internal static RaycastHit First;
        internal static RaycastHit[] Results = new RaycastHit[0];
        internal static int QueryCount;
        public static bool Raycast(Ray ray, out RaycastHit hit, float distance, int mask)
        { hit = First; return hit.collider != null; }
        public static int RaycastNonAlloc(Ray ray, RaycastHit[] hits, float distance, int mask, QueryTriggerInteraction query)
        { QueryCount++; Array.Copy(Results, hits, Math.Min(Results.Length, hits.Length)); return Math.Min(Results.Length, hits.Length); }
    }
}
internal sealed class SelectionManager { }
internal sealed class ZombieFighterRays { }
namespace ZompiercerLAN
{
    internal static class TrainLayout
    {
        internal static readonly HashSet<UnityEngine.Collider> Managed = new HashSet<UnityEngine.Collider>();
        internal static bool IsGroundSupport(UnityEngine.Collider collider) { return Managed.Contains(collider); }
        internal static bool Planning;
        internal static bool SurfacePlanning() { return Planning; }
    }
}
internal static class InteractionBoundaryChecks
{
    private static readonly MethodInfo Filter = typeof(ZompiercerLAN.TrainInteractionRays)
        .GetMethod("InteractionRay", BindingFlags.Static | BindingFlags.NonPublic);
    private static void Require(bool condition, string message)
    { if (!condition) throw new InvalidOperationException(message); }
    private static UnityEngine.RaycastHit Hit(UnityEngine.Collider collider, float distance)
    { return new UnityEngine.RaycastHit { collider = collider, distance = distance }; }
    private static bool Query(out UnityEngine.RaycastHit hit)
    {
        var arguments = new object[] { new UnityEngine.Ray(), default(UnityEngine.RaycastHit), 10f, -1 };
        bool found = (bool)Filter.Invoke(null, arguments); hit = (UnityEngine.RaycastHit)arguments[1]; return found;
    }
    internal static void Run()
    {
        var floor = new UnityEngine.Collider(); var furniture = new UnityEngine.Collider(); var loot = new UnityEngine.Collider();
        UnityEngine.RaycastHit hit;
        // Solo worlds and ordinary obstacles must keep exactly their original result.
        UnityEngine.Physics.First = Hit(floor, 1);
        Require(Query(out hit) && hit.collider == floor && UnityEngine.Physics.QueryCount == 0, "Solo ray changed");
        ZompiercerLAN.TrainLayout.Managed.Add(floor);
        ZompiercerLAN.TrainLayout.Managed.Add(furniture);
        UnityEngine.Physics.Results = new[] { Hit(loot, 4), Hit(furniture, 2), Hit(floor, 1) };
        Require(Query(out hit) && hit.collider == loot && hit.distance == 4, "Host furniture became selectable");
        UnityEngine.Physics.Results = new[] { Hit(floor, 1), Hit(furniture, 2) };
        Require(!Query(out hit) && hit.collider == null, "A ray containing only host construction exposed an interaction");
        // 1.4.16: placing a part on a surface aims at the host's construction (a picture on a host wall).
        ZompiercerLAN.TrainLayout.Planning = true;
        UnityEngine.Physics.First = Hit(furniture, 2);
        Require(Query(out hit) && hit.collider == furniture, "Surface placement did not meet the host's construction");
        ZompiercerLAN.TrainLayout.Planning = false;
        UnityEngine.Physics.First = Hit(floor, 1);
        UnityEngine.Physics.Results = new UnityEngine.RaycastHit[128];
        UnityEngine.Physics.Results[0] = Hit(loot, 4);
        Require(!Query(out hit) && hit.collider == null, "Saturated geometry query exposed an interaction");
        UnityEngine.Physics.First = Hit(loot, .5f);
        int queries = UnityEngine.Physics.QueryCount;
        Require(Query(out hit) && hit.collider == loot && UnityEngine.Physics.QueryCount == queries, "Unmanaged foreground obstacle changed");
        ZompiercerLAN.TrainLayout.Managed.Clear();
        UnityEngine.Physics.First = Hit(floor, 1);
        Require(Query(out hit) && hit.collider == floor, "Cleanup did not restore the original selection result");
        UnityEngine.Physics.First = default(UnityEngine.RaycastHit);
        Require(!Query(out hit) && hit.collider == null, "Empty ray produced an interaction");
        Console.WriteLine("PASS: production interaction filter / solo / host furniture / nearest hit / surface placement / overflow / cleanup");
    }
}
