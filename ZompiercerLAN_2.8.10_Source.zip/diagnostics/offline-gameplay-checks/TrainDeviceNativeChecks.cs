using System;
using System.Linq;
using System.Reflection;
using HarmonyLib;

// Reads shipped methods and mod IL; never executes Unity/gameplay methods.
internal static class TrainDeviceNativeChecks
{
    private const BindingFlags Any = BindingFlags.Static | BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
    private static void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
    private static System.Collections.Generic.List<CodeInstruction> Read(MethodBase method) { Require(method != null, "Device method missing"); return PatchProcessor.GetOriginalInstructions(method); }
    private static bool Calls(CodeInstruction i, string type, string name) { var m = i.operand as MethodBase; return m != null && m.DeclaringType.Name == type && m.Name == name; }
    internal static void Run(Assembly game, Assembly mod)
    {
        foreach (var contract in new[] {
            "Fireplace:Active,SecondsLeft,CurrentBurning,ActiveObjects,ActiveParticleSystems,FireplaceAudioSource",
            "AudioPlayer:audioSource,SelectedAudioIndex,MusicList,ConnectedInventory,gramophoneNeedle,gramophoneReader,turntableGramophoneRecord,gramophoneRecordOnMechanism,StartPlayAngle,EndPlayAngle,rotationSpeed,Cooldown,CooldownTimer",
            "Zompiercer.LightSwitcher:active,moveblePart,rotationOn,rotationOff",
            "Zompiercer.Train.Lamp:active,lights,meshRenderer,meshRenderers,MaterialOn,MaterialOff",
            "LogicInput:State", "LogicOutput:State", "RainwaterTank:VolumeCurrent,VolumeMax,trainPart" })
        {
            var split = contract.Split(':'); var type = game.GetType(split[0], true);
            foreach (var field in split[1].Split(',')) Require(type.GetField(field, Any) != null, "Native device field changed: " + contract + " / " + field);
        }
        var fire = game.GetType("Fireplace", true);
        Require(Read(fire.GetMethod("SetActivate", Any)).Any(i => Calls(i, "Fireplace", "ConsumeFuel")), "Fire activation no longer consumes host fuel");
        var audio = game.GetType("AudioPlayer", true);
        foreach (var name in new[] { "SetMusic", "PlayCurrent", "Pause", "Stop", "CheckMusic" }) Require(audio.GetMethod(name, Any) != null, "Native audio action changed: " + name);
        Require(Read(audio.GetMethod("Update", Any)).Any(i => Calls(i, "AudioPlayer", "PlayNext")), "Native track progression changed");
        var layout = mod.GetType("ZompiercerLAN.TrainLayout", true);
        var create = Read(layout.GetMethod("CreateReplica", Any));
        Require(create.FindIndex(i => Calls(i, "LanTrainDevices", "CaptureVisual")) >= 0 && create.FindIndex(i => Calls(i, "LanTrainDevices", "CaptureVisual")) < create.FindIndex(i => Calls(i, "Object", "DestroyImmediate")), "Device refs must be captured before gameplay scripts are stripped");
        var geometry = mod.GetType("ZompiercerLAN.TrainLayout+Entry", true);
        Require(!Read(geometry.GetMethod("SameGeometry", Any)).Any(i => i.operand is FieldInfo f && f.Name == "Decor"), "Dynamic devices cause geometry rebuilds");
        var visual = mod.GetType("ZompiercerLAN.LanTrainDeviceVisual", true);
        foreach (var name in new[] { "Apply", "Update" })
            Require(!Read(visual.GetMethod(name, Any)).Any(i => Calls(i, "Fireplace", "SetActivate") || Calls(i, "Fireplace", "ConsumeFuel") || Calls(i, "AudioPlayer", "SetMusic") || Calls(i, "LogicInput", "SetState") || Calls(i, "LogicOutput", "SetState")), "Guest visuals execute native device gameplay");
        var devices = mod.GetType("ZompiercerLAN.LanTrainDevices", true);
        var host = Read(devices.GetMethod("Host", Any));
        Require(host.Any(i => Calls(i, "LanTrainDecor", "Find")) && host.Any(i => Calls(i, "LanTrainDecor", "Distance")) && host.Any(i => Calls(i, "LanTrainDevices", "RecordIds")), "Host device identity/reach/record ownership checks missing");
        var storage = mod.GetType("ZompiercerLAN.LanStorageGame", true);
        Require(Read(storage.GetMethod("InventoryUpdatePrefix", Any)).Any(i => Calls(i, "LanTrainDevices", "Tick")) && Read(storage.GetMethod("DrawNotice", Any)).Any(i => Calls(i, "LanTrainDevices", "Draw")), "Guest device controls are not wired");
        var water = mod.GetType("ZompiercerLAN.LanWorldWork", true);
        Require(water.GetMethod("Watered", Any).GetParameters().Length == 5 && Read(water.GetMethod("HostWater", Any)).Any(i => Calls(i, "Object", "GetInstanceID")), "Water does not bind replies and host lookup to exact tank identity");
        // 2.8.5: lamps without their own on/off materials (wall light, external lamp, light base) only change their glow;
        // the guest set an empty material on them and they were drawn magenta.
        var lamp = Read(game.GetType("Zompiercer.Train.Lamp", true).GetMethod("ApplyToMeshRenderer", Any));
        Require(lamp.Any(i => i.operand as string == "_EmissionColor") && lamp.Any(i => Calls(i, "Renderer", "get_material")), "Native lamp glow fallback changed");
        var show = Read(visual.GetMethod("ShowLamp", Any));
        Require(show.Any(i => Calls(i, "Renderer", "get_material")) && show.Any(i => Calls(i, "Material", "SetColor")), "Guest lamps lost the native glow fallback");
        Require(!Read(visual.GetMethod("Apply", Any)).Any(i => Calls(i, "Renderer", "set_sharedMaterial")) && Read(visual.GetMethod("Apply", Any)).Any(i => Calls(i, "LanTrainDeviceVisual", "ShowLamp")), "Guest lamps set materials outside ShowLamp");
        Require(Read(visual.GetMethod("Restore", Any)).Count(i => Calls(i, "Object", "Destroy")) >= 2, "Guest lamp materials are not released");
        Console.WriteLine("PASS: native train device contracts, replica capture order, visual-only playback, host ownership, water identity and lamp glow");
    }
}
