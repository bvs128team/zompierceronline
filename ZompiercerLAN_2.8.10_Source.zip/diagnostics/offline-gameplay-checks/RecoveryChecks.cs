using System;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

internal static class RecoveryChecks
{
    internal static void Run(Assembly game, Assembly mod)
    {
        const BindingFlags all = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
        Func<Type, string, System.Collections.Generic.List<CodeInstruction>> body = (t, n) =>
            PatchProcessor.GetOriginalInstructions(t.GetMethod(n, all), (ILGenerator)null);
        var animator = body(game.GetType("WeaponAnimator", true), "Update");
        Require(animator.Any(i => i.operand is FieldInfo f && f.Name == "currentHealth") &&
            animator.Any(i => i.opcode == OpCodes.Stfld && i.operand is FieldInfo f && f.Name == "HideWeapon"),
            "Native low-health hand hiding changed");
        var weapons = game.GetType("ZombieFighterFireArmWeapon", true);
        Require(body(weapons, "SetWeapon").Any(i => i.operand is FieldInfo f && f.Name == "SelectedWeaponID"),
            "Native same-ID weapon gate changed");
        var selection = weapons.GetNestedTypes(all).Single(t => t.Name.StartsWith("<SetWeaponIE>"));
        Require(body(selection, "MoveNext").Any(i => i.operand is MethodInfo m && m.Name == "GameObjectSetActive"),
            "Native equipment activation moved");
        Require(body(weapons, "TryToActivateFists").Any(i => Equals(i.operand, "Hands")), "Native fists ID changed");
        var inventory = game.GetType("Zompiercer.Inventory.InventoryController", true);
        Require(body(inventory, "UpdateActiveItem").Any(i => i.operand is MethodInfo m && m.Name == "SelectBeltIcon"),
            "Native belt refresh changed");
        var downed = mod.GetType("ZompiercerLAN.LanDowned", true);
        Require(body(downed, "Revive").Any(i => i.operand is MethodInfo m && m.Name == "RestoreEquipment") &&
            body(mod.GetType("ZompiercerLAN.LanGuestDeath", true), "Respawn").Any(i => i.operand is MethodInfo m && m.Name == "RestoreEquipment"),
            "Recovery never restores equipment");
        var gui = game.GetType("Zompiercer.GUI.GUIManager", true);
        foreach (var pair in new[] { new[] { "HungerChanged", "_currentHunger" }, new[] { "ThirstChanged", "_currentThirst" },
            new[] { "StunAfterFlightChanged", "_stunAfterFlight" } })
        {
            var instructions = body(gui, pair[0]);
            Require(instructions.Count(i => i.opcode == OpCodes.Stfld) == 1 &&
                instructions.Any(i => i.opcode == OpCodes.Stfld && i.operand is FieldInfo f && f.Name == pair[1]),
                "GUI cache setter changed: " + pair[0]);
        }
        foreach (var name in new[] { "hungerAndThirstScreenTimer", "hungerAndThirstScreenPeak", "hungerAndThirstScreenImage", "maxTransparency" })
            Require(gui.GetField(name, all) != null, "Native needs screen field missing: " + name);
        Require(body(gui, "Update").Any(i => i.operand is FieldInfo f && f.Name == "maxTransparency"),
            "Native needs tint endpoint changed");
        Console.WriteLine("PASS: native low-health hand hiding, same-ID gate, belt/fists activation and GUI needs-cache contracts (no Unity execution)");
    }
    private static void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
}
