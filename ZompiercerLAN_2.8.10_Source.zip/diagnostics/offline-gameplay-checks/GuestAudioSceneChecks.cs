using System;
using System.Linq;
using System.Reflection;
using Mono.Cecil;
using Mono.Cecil.Cil;

// Metadata and IL checks only. This reads the installed game and built mod DLL;
// it never starts Unity or executes any native gameplay method.
internal static class GuestAudioSceneChecks
{
    private static void Require(bool condition, string message)
    { if (!condition) throw new InvalidOperationException(message); }

    private static TypeDefinition Type(AssemblyDefinition assembly, string name)
    {
        var type = assembly.MainModule.Types.FirstOrDefault(t => t.FullName == name);
        Require(type != null, "Missing type: " + name);
        return type;
    }
    private static MethodDefinition Method(TypeDefinition type, string name)
    {
        var method = type.Methods.FirstOrDefault(m => m.Name == name && m.HasBody);
        Require(method != null, "Missing method: " + type.FullName + "." + name);
        return method;
    }
    private static bool Calls(MethodDefinition method, string name)
    {
        return method.Body.Instructions.Any(i => i.Operand is MethodReference &&
            ((MethodReference)i.Operand).FullName.Contains(name));
    }
    private static bool Reads(MethodDefinition method, string field)
    {
        return method.Body.Instructions.Any(i => i.OpCode == OpCodes.Ldfld &&
            i.Operand is FieldReference && ((FieldReference)i.Operand).Name == field);
    }
    private static bool Stores(MethodDefinition method, string field)
    {
        return method.Body.Instructions.Any(i => i.OpCode == OpCodes.Stfld &&
            i.Operand is FieldReference && ((FieldReference)i.Operand).Name == field);
    }

    internal static void Run(Assembly gameAssembly, Assembly modAssembly)
    {
        using (var game = AssemblyDefinition.ReadAssembly(gameAssembly.Location))
        using (var mod = AssemblyDefinition.ReadAssembly(modAssembly.Location))
        {
            var inventory = Method(Type(game, "Zompiercer.Inventory.InventoryController"), "Update");
            var close = Method(Type(game, "Zompiercer.Inventory.InventoryWindow"), "Close");
            Require(Reads(inventory, "doors") && Calls(inventory, "Door::SwitchOpen"), "Native chest open no longer switches standalone Door");
            Require(Calls(close, "Door::SetOpen"), "Native chest close no longer closes standalone Door");

            var fireworks = Method(Type(game, "OpenDetectorFireworkSystem"), "Update");
            Require(Reads(fireworks, "Open") && Stores(fireworks, "trapTouched") &&
                Calls(fireworks, "ZombieSpawn::Activator") && Calls(fireworks, "ZombieAIController::ShotNoiseCheck") &&
                Calls(fireworks, "UnityEngine.Object::Destroy"), "Native fireworks trigger or lifecycle changed");
            var scene = Type(mod, "ZompiercerLAN.LanSceneStates");
            Require(Calls(Method(scene, "HostGuestViewChanged"), "SetLid"), "Accepted storage view does not drive the lid");
            Require(Calls(Method(Type(mod, "ZompiercerLAN.LanStorageHostWorld"), "SetGuestView"), "HostGuestViewChanged"),
                "Storage view no longer notifies lid tracker");
            Require(!Calls(Method(Type(mod, "ZompiercerLAN.LanStorageHostWorld"), "Resolve"), "HostGuestViewChanged"),
                "Recipe resolution can trigger the scene lid");
            Require(!Calls(Method(scene, "ApplyFireworks"), "ZombieSpawn::Activator") &&
                !Calls(Method(scene, "ApplyFireworks"), "ZombieAIController::ShotNoiseCheck"),
                "Guest fireworks effect invokes host AI/spawner logic");

            var bench = Method(Type(game, "Workbench"), "Update");
            var cancel = Method(Type(game, "Workbench"), "StopCurrentCraftProcess");
            Require(Calls(bench, "Workbench::RemoveFromQueue") && Calls(bench, "UnityEngine.AudioSource::PlayOneShot") &&
                Calls(bench, "UnityEngine.AudioSource::Play") && Calls(bench, "UnityEngine.AudioSource::Stop"),
                "Native craft completion or loop audio changed");
            Require(Calls(cancel, "Workbench::RemoveFromQueue"), "Native cancellation path changed");
            var storage = Type(mod, "ZompiercerLAN.LanStorageGame");
            Require(Calls(Method(storage, "CraftUpdatePostfix"), "QueueUnits") &&
                Calls(Method(storage, "ShowCraftState"), "PlayDone"), "Host completion counter is not used for guest sound");
            Require(Calls(Method(Type(mod, "ZompiercerLAN.LanWorldWork"), "PlaySuppressedHitEffects"), "Gun::AudioPlay"),
                "Suppressed melee hits lack native local clips");
            Console.WriteLine("PASS: native chest/firework lifecycle, host-only effect, craft completion and loop, validated local hit audio (IL only)");
        }
    }
}
