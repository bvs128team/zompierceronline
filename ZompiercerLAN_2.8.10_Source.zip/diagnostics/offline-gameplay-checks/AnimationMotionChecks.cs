using System;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

// Offline contract check for the display-only remote pose (2.7.0: RemoteHoldPose). No Unity object is created; the
// geometry itself runs in diagnostics/hold-pose-checks on the offline renders' inputs.
internal static class AnimationMotionChecks
{
    private const BindingFlags Instance = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

    internal static void Run(Assembly mod)
    {
        var motion = mod.GetType("ZompiercerLAN.RemoteAvatarMotion", true);
        var equipment = mod.GetType("ZompiercerLAN.RemoteEquipmentVisual", true);
        var pose = mod.GetType("ZompiercerLAN.RemoteHoldPose", true);
        Require(equipment.GetProperty("HasHeldItem", Instance)?.PropertyType == typeof(bool) &&
                equipment.GetProperty("PrimaryLeft", Instance)?.PropertyType == typeof(bool) &&
                equipment.GetProperty("Kind", Instance)?.PropertyType == pose.GetNestedType("Kind", BindingFlags.NonPublic),
            "Remote item visibility, bow primacy or stance kind contract is missing");
        var weapon = equipment.GetMethod("TryGetWeapon", Instance);
        Require(weapon != null && weapon.ReturnType == typeof(bool) && weapon.GetParameters().Length == 1 &&
                weapon.GetParameters()[0].ParameterType.GetElementType() == pose.GetNestedType("Weapon", BindingFlags.NonPublic),
            "Held native weapon geometry for the stances is missing");
        var finger = equipment.GetMethod("TryGetGripFinger", Instance);
        var fingerParameters = finger == null ? null : finger.GetParameters();
        Require(finger != null && finger.ReturnType == typeof(bool) && fingerParameters.Length == 3 &&
                fingerParameters[0].ParameterType == typeof(string) &&
                fingerParameters[1].ParameterType.FullName == "UnityEngine.Quaternion&" &&
                fingerParameters[2].ParameterType.FullName == "UnityEngine.Quaternion&",
            "Native per-item finger curl contract is missing");

        var late = Read(motion, "LateUpdate");
        int roll = CallIndex(late, "Roll"), holding = CallIndex(late, "Holding"), striking = CallIndex(late, "Striking");
        int reaching = CallIndex(late, "Reaching"), use = CallIndex(late, "Using"), fingers = CallIndex(late, "Fingers");
        Require(roll >= 0 && holding > roll && striking > holding && reaching > holding && use > reaching && fingers > use,
            "Held stance is not posed after the body and before strikes, the use key, eating and the fingers");
        var hold = Read(motion, "Holding");
        foreach (var stance in new[] { "LongGun", "Handgun", "Bow", "TwoHand", "OneHand", "Protract", "Slide", "TryGetWeapon", "ArmTo" })
            Require(CallIndex(hold, stance) >= 0, "Held stance path lacks " + stance);
        Require(CallIndex(Read(motion, "ArmTo"), "Solve") >= 0, "Arms bypass the tested hinge solver");
        Require(CallIndex(Read(motion, "BindLocalRotation"), "get_bindposes") >= 0 &&
                CallIndex(Read(motion, "Fingers"), "TryGetGripFinger") >= 0 && CallIndex(Read(motion, "Fist"), "TryFist") >= 0,
            "Finger curl is no longer transferred relative to mesh bind poses");
        var apply = Read(motion, "Apply");
        Require(CallIndex(apply, "get_Kind") >= 0 && CallIndex(apply, "SetActive") >= 0,
            "The armed NPC is not limited to long guns");
        Console.WriteLine("PASS: held stances after the body, before strikes and use; hinge-solved arms; native and fist finger grips");
    }

    private static System.Collections.Generic.List<CodeInstruction> Read(Type type, string name)
    {
        var method = type.GetMethod(name, Instance | BindingFlags.Static);
        Require(method != null, "Missing motion method " + name);
        return PatchProcessor.GetOriginalInstructions(method, (ILGenerator)null);
    }

    private static int CallIndex(System.Collections.Generic.List<CodeInstruction> code, string name)
    { return code.FindIndex(i => IsCall(i, name)); }

    private static bool IsCall(CodeInstruction instruction, string name)
    {
        if (instruction.opcode != OpCodes.Call && instruction.opcode != OpCodes.Callvirt) return false;
        var method = instruction.operand as MethodBase;
        return method != null && method.Name == name;
    }

    private static void Require(bool condition, string message)
    { if (!condition) throw new InvalidOperationException(message); }
}
