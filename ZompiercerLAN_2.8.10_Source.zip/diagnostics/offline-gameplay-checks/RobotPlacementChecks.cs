using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

// Compatibility and production-IL guards only; these do not simulate Unity physics.
internal static class RobotPlacementChecks
{
    private const BindingFlags Methods = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance;
    private static void Require(bool condition, string message)
    { if (!condition) throw new InvalidOperationException(message); }
    private static List<CodeInstruction> Body(Type type, string name)
    { return PatchProcessor.GetOriginalInstructions(type.GetMethod(name, Methods), (ILGenerator)null); }
    private static bool Calls(IEnumerable<CodeInstruction> body, string type, string method)
    { return body.Any(i => i.operand is MethodBase m && m.DeclaringType.Name == type && m.Name == method); }
    internal static void Run(Assembly game, Assembly mod)
    {
        var rays = game.GetType("ZombieFighterRays", true);
        var scene = game.GetType("GlobalSceneManager", true);
        var takable = game.GetType("TakableItem", true);
        var production = mod.GetType("ZompiercerLAN.LanTakables", true);
        Require(rays.GetMethod("ReloadActionOnStarted", Methods) != null && rays.GetMethod("Update", Methods) != null,
            "Robot placement input hooks changed");
        var load = scene.GetMethod("LoadLevel", Methods);
        Require(load != null && load.ReturnType == typeof(void), "Robot travel hook changed");
        Require(takable.GetMethod("SetTaked", Methods, null, new[] { typeof(bool) }, null) != null,
            "Robot native carry cleanup changed");
        foreach (var body in new[] { Body(takable, "SetTaked"), Body(game.GetType("RobotDogAiController", true), "TurnCollidersOn") })
            Require(!body.Any(i => i.operand is MethodBase m && m.DeclaringType.Name == "Transform") &&
                !body.Any(i => i.opcode == OpCodes.Stfld && i.operand is FieldInfo f && f.Name == "OnTrainCar"),
                "Native carry cleanup now changes placement or train ownership");
        var nativeDrop = rays.GetNestedTypes(BindingFlags.Public | BindingFlags.NonPublic)
            .Single(t => t.Name.StartsWith("<DropRobotRoutine>", StringComparison.Ordinal));
        Require(Calls(Body(nativeDrop, "MoveNext"), "TakableItem", "SetTaked") &&
            Body(nativeDrop, "MoveNext").Any(i => i.opcode == OpCodes.Stfld && i.operand is FieldInfo f && f.Name == "takableItemTaked"),
            "Native robot release no longer uses the same hand cleanup contract");
        Require(Calls(Body(production, "RobotAim"), "Physics", "RaycastAll"),
            "Robot aim lost its independent physical-surface query");
        Require(Calls(Body(production, "Release"), "LanTakables", "CheckedDogPlacement"),
            "Host no longer validates robot support");
        Require(Calls(Body(production, "CheckedDogPlacement"), "Physics", "RaycastAll") &&
            Calls(Body(production, "CheckedDogPlacement"), "LanTakables", "PlacementSurface"),
            "Host support query or normal validation missing");
        var placement = Body(production, "RobotReloadPrefix");
        Require(Calls(placement, "LanTakables", "SendRelease") && !Calls(placement, "Object", "Destroy"),
            "Guest placement no longer waits for host result");
        var travel = Body(production, "RobotTravelPrefix");
        Require(Calls(travel, "LanTakables", "TravelSurface") && Calls(travel, "LanTakables", "ParkForTravel"),
            "Carried robot travel preparation missing");
        var park = Body(production, "ParkForTravel");
        Require(Calls(park, "LanTakables", "PlaceDog") && Calls(park, "TakableItem", "SetTaked"),
            "Robot travel does not restore native placed state");
        Require(!Calls(park, "Object", "Instantiate") && !Calls(park, "Object", "Destroy"),
            "Robot travel replaces the original object and risks losing devices or duplicating it");
        Require(Calls(Body(production, "PlaceDog"), "Transform", "SetParent") &&
            Body(production, "PlaceDog").Any(i => i.opcode == OpCodes.Stfld && i.operand is FieldInfo f && f.Name == "OnTrainCar"),
            "Robot travel no longer joins persistent train ownership");
        Console.WriteLine("PASS: robot input/travel signatures, host support validation, acknowledged placement and identity-preserving train parenting (IL guards)");
    }
}
