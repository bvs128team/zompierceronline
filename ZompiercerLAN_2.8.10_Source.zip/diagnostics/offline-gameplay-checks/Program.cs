using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

// This executable reads game IL and runs only the mod's instruction transforms.
// It never launches Unity, constructs a game object, loads a world or opens a socket.
internal static class Program
{
    private static string _root;
    private static string _modDirectory;
    private static void Require(bool condition, string message)
    { if (!condition) throw new InvalidOperationException(message); }
    private static int Main(string[] args)
    {
        try
        {
            _root = Path.GetFullPath(args.Length == 0 ? "." : args[0]);
            // 2.2.0: by default the 2.x line's build (it checked the frozen two-player line's DLL before).
            string modPath = args.Length > 1 ? Path.GetFullPath(args[1]) :
                Path.Combine(_root, "ZompiercerLAN4P/bin/Release/net472/ZompiercerLAN.dll");
            _modDirectory = Path.GetDirectoryName(modPath);
            AppDomain.CurrentDomain.AssemblyResolve += Resolve;
            var game = Assembly.LoadFrom(Path.Combine(_root, "Zompiercer_Data/Managed/Assembly-CSharp.dll"));
            var mod = Assembly.LoadFrom(modPath);
            CheckWorldCatalog(mod);
            Require((int)mod.GetType("ZompiercerLAN.TrainLayout", true)
                .GetField("SupportLayer", BindingFlags.Static | BindingFlags.NonPublic).GetRawConstantValue() == 10,
                "Construction uses a layer ignored by the installed character");
            CheckTransform(game, mod, "SelectionManager", "FixedUpdate", "TrainInteractionRays", "ReplaceRays", 2);
            CheckTransform(game, mod, "ZombieFighterRays", "Update", "TrainInteractionRays", "ReplaceRays", 1);
            CheckTransform(game, mod, "ZombieFighterController", "Update", "TrainGroundProbes", "ReplaceGroundRays", 2);
            CheckTransform(game, mod, "ZombieFighterController", "Jump", "TrainGroundProbes", "ReplaceGroundRays", 1);
            CheckWorkbench(game, mod);
            CheckFuelStation(game);
            CheckLocationAndDifficulty(game);
            CheckCoopFactorsAndFirearms(game, mod);
            CheckWeather(game, mod);
            CheckSleepingBagModSlotsAndRounds(game, mod);
            CheckWorkAndFarm(game, mod);
            FarmWorkChecks.Run(game, mod);
            RecoveryChecks.Run(game, mod);
            AnimationMotionChecks.Run(mod);
            NativeGripChecks.Run(game, mod);
            ConsumableAnimationChecks.Run(game, mod);
            MotionStyleChecks.Run(game, mod);
            StarterLootNativeChecks.Run(game, mod);
            GuestRejoinChecks.Run(game, mod);
            BodyArmPoseChecks.Run(game, mod);
            HostDiagnosticChecks.Run(mod);
            TrainBenchAndHudChecks.Run(game, mod);
            TrainDeviceNativeChecks.Run(game, mod);
            GuestAudioSceneChecks.Run(game, mod);
            CheckModPartsAndBarrelSwing(game, mod);
            CheckGuestSoundsAndLoot(game, mod);
            CheckAvatarLooks(game, mod);
            UiProgressChecks.Run(game, mod);
            TrainDriverChecks.Run(game, mod);
            CheckBowAndHolders(game, mod);
            CheckLeaveAndRewards(game);
            CheckDash(game);
            CheckMotion(game);
            CheckRobotWindowAndHand(game);
            RobotPlacementChecks.Run(game, mod);
            CheckBeaverHooks(game, mod);
            SingletonAccessChecks.Run(game, mod);
            // Existing local prefab allow-list must survive epoch changes; retaining
            // assets must not be confused with retaining old live zombies or packets.
            var zombie = mod.GetType("ZompiercerLAN.ZombieSync", true);
            var reset = Read(zombie.GetMethod("ResetWorld", BindingFlags.Instance | BindingFlags.NonPublic));
            Require(!CallsClearForField(reset, "_prefabs"), "World reset discards trusted prefab catalogue");
            foreach (var field in new[] { "_replicas", "_hostIds", "_catalog", "_failedPrefabs" })
                Require(CallsClearForField(reset, field), "World reset retains stale zombie state: " + field);
            Require(CallsClearForField(reset, "Hurts"), "World reset retains stale per-guest hurt state");
            var tick = Read(zombie.GetMethod("Tick", BindingFlags.Instance | BindingFlags.NonPublic));
            int send = tick.FindIndex(i => IsCall(i, "SendBatch"));
            int release = tick.FindIndex(i => IsCall(i, "ReleaseTargets"));
            Require(send >= 0 && release > send, "Zombie replication is blocked by the combat readiness branch");
            var freeze = Read(zombie.GetMethod("Freeze", BindingFlags.Instance | BindingFlags.NonPublic));
            Require(freeze.Any(i => i.opcode == OpCodes.Stfld && ((FieldInfo)i.operand).Name == "_playerReady"),
                "Freeze fails to revoke client combat readiness");
            Console.WriteLine("PASS: catalogue survives travel; world state is cleared; visuals precede combat gate; freeze revokes combat");
            InteractionBoundaryChecks.Run();
            Console.WriteLine("PASS: offline gameplay compatibility checks (no Unity execution)");
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine("FAIL: " + ex);
            var loading = ex as ReflectionTypeLoadException;
            if (loading != null) foreach (var failure in loading.LoaderExceptions) Console.Error.WriteLine(failure.Message);
            return 1;
        }
    }
    private static void CheckWorldCatalog(Assembly mod)
    {
        const BindingFlags flags = BindingFlags.Static | BindingFlags.NonPublic;
        var catalog = mod.GetType("ZompiercerLAN.LanWorldCatalog", true);
        var ready = catalog.GetProperty("Ready", flags);
        var failure = catalog.GetProperty("Failure", flags);
        catalog.GetMethod("Initialize", flags).Invoke(null, new object[] { Path.Combine(_root, "Zompiercer_Data") });
        var timeout = System.Diagnostics.Stopwatch.StartNew();
        while (!(bool)ready.GetValue(null))
        {
            string reason = (string)failure.GetValue(null);
            Require(reason == null, "LAN world catalogue rejected installed game: " + reason);
            Require(timeout.Elapsed < TimeSpan.FromMinutes(2), "LAN world catalogue timed out");
            System.Threading.Thread.Sleep(25);
        }
        Console.WriteLine("PASS: production LAN world catalogue accepts installed game assets");
    }
    private static Assembly Resolve(object sender, ResolveEventArgs args)
    {
        string name = new AssemblyName(args.Name).Name + ".dll";
        string modDependency = Path.Combine(_modDirectory, name);
        if (File.Exists(modDependency)) return Assembly.LoadFrom(modDependency);
        foreach (string directory in new[] { "Zompiercer_Data/Managed", "BepInEx/core", "ZompiercerLAN4P/bin/Release/net472" })
        {
            string path = Path.Combine(_root, directory, name);
            if (File.Exists(path)) return Assembly.LoadFrom(path);
        }
        return null;
    }
    private static List<CodeInstruction> Read(MethodBase method)
    { return PatchProcessor.GetOriginalInstructions(method, (ILGenerator)null); }
    internal static List<CodeInstruction> ReadInstructions(MethodBase method) { return Read(method); }
    private static void CheckWorkbench(Assembly game, Assembly mod)
    {
        var bench = game.GetType("Workbench", true);
        var original = bench.GetMethod("Update", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
        var storage = mod.GetType("ZompiercerLAN.LanStorageGame", true);
        var patch = storage.GetMethod("ReplaceWorkbenchWindow", BindingFlags.Static | BindingFlags.NonPublic);
        var field = bench.GetField("WindowOpened", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
        var body = Read(original);
        Require(body.Count(i => i.opcode == OpCodes.Ldfld && Equals(i.operand, field)) == 1, "Unexpected manual-work window gate");
        var hooked = storage.GetProperty("ManualWorkHooked", BindingFlags.Static | BindingFlags.NonPublic);
        var result = ((IEnumerable<CodeInstruction>)patch.Invoke(null, new object[] { body })).ToList();
        Require((bool)hooked.GetValue(null), "Actual Workbench.Update IL not hooked");
        Require(result.Count == body.Count, "Manual-work replacement changed the method length");
        Require(!result.Any(i => i.opcode == OpCodes.Ldfld && Equals(i.operand, field)), "Manual-work gate was not replaced");
        var replacements = result.Where(i => IsCall(i, "WorkbenchWindowOpen")).ToList();
        Require(replacements.Count == 1, "Manual-work replacement count");
        var helper = (MethodInfo)replacements[0].operand;
        Require(helper.ReturnType == typeof(bool) && helper.GetParameters().Length == 1 && helper.GetParameters()[0].ParameterType == bench, "Manual-work replacement changes stack shape");
        // 1.1.3: a changed method is left exactly as it is (no exception, so the shared
        // storage hooks stay installed) and the guest's manual work stays refused.
        foreach (int gates in new[] { 0, 2 })
        {
            var unsupported = new List<CodeInstruction>();
            for (int i = 0; i < gates; i++) unsupported.Add(new CodeInstruction(OpCodes.Ldfld, field));
            unsupported.Add(new CodeInstruction(OpCodes.Ret));
            var kept = ((IEnumerable<CodeInstruction>)patch.Invoke(null, new object[] { unsupported })).ToList();
            Require(!(bool)hooked.GetValue(null), "Changed manual-work IL was accepted");
            Require(kept.Count == gates + 1 && kept.Count(i => i.opcode == OpCodes.Ldfld && Equals(i.operand, field)) == gates &&
                !kept.Any(i => IsCall(i, "WorkbenchWindowOpen")), "Changed manual-work IL was modified");
        }
        Console.WriteLine("PASS: actual Workbench.Update IL manual gate, stack shape, changed gates left untouched and refused (no Unity execution)");
    }
    private static bool IsCall(CodeInstruction instruction, string name)
    { return instruction.operand is MethodInfo method && method.Name == name; }
    // 1.4.3: the game fields and methods LanFuelStation reaches (a wrong name or type would switch it off).
    private static void CheckFuelStation(Assembly game)
    {
        var fields = new[]
        {
            "FuelStationController.refuelingGunPoint:Transform", "FuelStationController.button:HardwareButton",
            "FuelStationController.fuelStationGun:FuelStationGunController", "FuelStationController.fuelAmount:Single",
            "FuelStationController.refuelingSpeed:Single", "FuelStationController.fuelAmountText:Text",
            "FuelStationController.gasStationActivated:Boolean", "FuelStationController.fuelPumpEngine:AudioSource",
            "FuelStationSwitchboard.fuelStation:FuelStationController", "FuelStationSwitchboard.lever:HardwareButton",
            "FuelStationGunController.connectedTrainFuelTank:TrainFuelTank", "TrainFuelTank.refuelingGunPoint:Transform",
            "ZombieFighterRays.fuelStationDetected:FuelStationController", "ZombieFighterRays.trainFuelTankDetected:TrainFuelTank",
        };
        foreach (var entry in fields)
        {
            var parts = entry.Split(':'); var names = parts[0].Split('.');
            var field = game.GetType(names[0], true).GetField(names[1], BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            Require(field != null && field.FieldType.Name == parts[1], "Fuel station field missing or changed: " + entry);
        }
        Require(game.GetType("FuelStationController", true).GetMethod("Update", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, null, Type.EmptyTypes, null) != null, "FuelStationController.Update");
        var rays = game.GetType("ZombieFighterRays", true);
        Require(rays.GetMethod("TakeTakeableItem", new[] { game.GetType("TakableItem", true) }) != null, "ZombieFighterRays.TakeTakeableItem");
        Require(rays.GetMethod("DropItem", Type.EmptyTypes) != null, "ZombieFighterRays.DropItem");
        Console.WriteLine("PASS: fuel station fields and methods match the installed game");
    }
    // 1.4.4: what LanSceneStates and LanDifficulty reach in the game.
    private static void CheckLocationAndDifficulty(Assembly game)
    {
        const BindingFlags any = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        foreach (var entry in new[] { "DestroyableByBomb.Destroyed:Boolean", "TrapWall.Activated:Boolean", "StructuralDestructionAndRepair.trapActivated:Boolean",
            "StructuralDestructionAndRepair.destructible:Boolean", "ObjectActivator.Activated:Boolean", "WaterDrainer.Drain:Boolean", "WaterDrainer.CurrentDuration:Single",
            "DifficultyManager.ZombieHP:Single", "DifficultyManager.ZombieDamage:Single", "DifficultyManager.WeaponRecoil:Single",
            "DifficultyManager.WeaponAimWobble:Single", "DifficultyManager.ShowPlayerOnMap:Boolean" })
        {
            var parts = entry.Split(':'); var names = parts[0].Split('.');
            var field = game.GetType(names[0], true).GetField(names[1], any);
            Require(field != null && field.FieldType.Name == parts[1], "Game field missing or changed: " + entry);
        }
        var all = game.GetType("Zompiercer.SaveLoad.SaveLoadCore", true).GetField("AllObjectID", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
        Require(all != null && typeof(System.Collections.IList).IsAssignableFrom(all.FieldType), "SaveLoadCore.AllObjectID");
        Require(game.GetType("ObjectID", true).GetField("ID", any) != null, "ObjectID.ID");
        Require(game.GetType("TrapWall", true).GetMethod("Activate", Type.EmptyTypes) != null, "TrapWall.Activate");
        Require(game.GetType("StructuralDestructionAndRepair", true).GetMethod("Set", new[] { typeof(bool) }) != null, "StructuralDestructionAndRepair.Set");
        Require(game.GetType("ObjectActivator", true).GetMethod("Interact", Type.EmptyTypes) != null, "ObjectActivator.Interact");
        foreach (var name in new[] { "DestroyableByBomb", "TrapWall", "StructuralDestructionAndRepair", "ObjectActivator", "WaterDrainer", "CollectedResource" })
            Require(game.GetType(name, true).GetMethod("Load", new[] { typeof(object[]) }) != null, name + ".Load");
        var difficulty = game.GetType("DifficultyManager", true);
        Require(difficulty.GetMethod("Save", any, null, Type.EmptyTypes, null) != null && difficulty.GetMethod("Load", any, null, new[] { typeof(object[]) }, null) != null, "DifficultyManager save");
        // The loot hook patches a private method: its parameter name must match, and the method must
        // be too long for Mono to inline into GenerateLoot (its limit is 20 bytes of IL).
        var amount = game.GetType("ObjectLootController", true).GetMethod("ApplyAmountMultiplier", any, null, new[] { typeof(float) }, null);
        Require(amount != null && amount.GetParameters()[0].Name == "itemAmount" && amount.GetMethodBody().GetILAsByteArray().Length > 20, "ObjectLootController.ApplyAmountMultiplier");
        Console.WriteLine("PASS: location object and difficulty fields and methods match the installed game (loot hook not inlinable: " +
            amount.GetMethodBody().GetILAsByteArray().Length + " bytes of IL)");
    }
    // 2.4.1: the co-op factors from one guest up to seven, and what LanExtraWeapons reaches in the game.
    private static void CheckCoopFactorsAndFirearms(Assembly game, Assembly mod)
    {
        const BindingFlags any = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        const BindingFlags statics = BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
        var forGuests = mod.GetType("ZompiercerLAN.LanDifficulty", true).GetMethod("ForGuests", statics);
        Func<float, float, int, float> factor = (one, most, guests) => (float)forGuests.Invoke(null, new object[] { one, most, guests });
        var health = new[] { 1.3f, 1.45f, 1.6f, 1.75f, 1.9f, 2.05f, 2.2f };
        var loot = new[] { 1.5f, 1.6667f, 1.8333f, 2f, 2.1667f, 2.3333f, 2.5f };
        for (int guests = 1; guests <= 7; guests++)
        {
            Require(Math.Abs(factor(1.3f, 2.2f, guests) - health[guests - 1]) < .001f, "Zombie health for " + (guests + 1) + " players");
            Require(Math.Abs(factor(1.5f, 2.5f, guests) - loot[guests - 1]) < .001f, "Loot for " + (guests + 1) + " players");
        }
        Require(factor(1.3f, 2.2f, 0) == 1.3f && factor(1.3f, 2.2f, 50) == 2.2f, "Co-op factor guest bounds");
        Require(factor(1f, 2.2f, 7) == 1f && factor(.5f, 3f, 7) == 1f && factor(float.NaN, 3f, 7) == 1f, "A one-guest factor of 1 turns it off");
        Require(factor(1.6f, 1.2f, 7) == 1.6f && factor(1.3f, 9f, 7) == 3f && factor(1.3f, float.NaN, 7) == 1.3f, "Co-op factor maximum bounds");
        var extra = mod.GetType("ZompiercerLAN.LanExtraWeapons", true);
        Require((int)extra.GetField("MinPlayers", statics).GetRawConstantValue() == 4, "Two firearms from 4 players");
        var firearms = (int[])extra.GetField("Firearms", statics).GetValue(null);
        Require(firearms.OrderBy(i => i).SequenceEqual(new[] { 4, 5, 6, 17, 18, 19, 195, 196, 248, 249 }), "Firearm item ids");
        foreach (var entry in new[] { "Zompiercer.Inventory.InventoryInserter.insertTo:Inventory", "Zompiercer.Inventory.InventoryInserter.forTrain:Boolean",
            "Zompiercer.Inventory.InventoryItem.inInventory:Inventory", "Zompiercer.Inventory.InventoryItem.itemID:Int32", "Zompiercer.Inventory.InventoryItem.amount:Int32",
            "Zompiercer.Inventory.ItemsDataBase.itemPrefab:InventoryItem[]", "Zompiercer.SaveLoad.SaveLoadCore.LoadingNow:Boolean" })
        {
            var parts = entry.Split(':'); int dot = parts[0].LastIndexOf('.');
            var field = game.GetType(parts[0].Substring(0, dot), true).GetField(parts[0].Substring(dot + 1), any);
            Require(field != null && field.FieldType.Name == parts[1], "Game field missing or changed: " + entry);
        }
        var item = game.GetType("Zompiercer.Inventory.InventoryItem", true);
        Require(item.GetMethod("Save", Type.EmptyTypes)?.ReturnType == typeof(object[]) && item.GetMethod("Load", new[] { typeof(object[]) }) != null, "InventoryItem.Save/Load");
        // The copy's inserter acts as the original's: a second after Start, into insertTo, or the train's box (forTrain).
        var inserter = game.GetType("Zompiercer.Inventory.InventoryInserter", true);
        Require(inserter.GetMethod("Start", any, null, Type.EmptyTypes, null) != null, "InventoryInserter.Start");
        var delayed = inserter.GetNestedTypes(BindingFlags.NonPublic).FirstOrDefault(t => t.Name.StartsWith("<DelayedStart>"));
        var steps = delayed == null ? null : Read(delayed.GetMethod("MoveNext", any));
        Require(steps != null && steps.Any(i => i.operand is FieldInfo f && f.Name == "insertTo") && steps.Any(i => i.operand is FieldInfo f && f.Name == "forTrain") &&
            steps.Any(i => i.operand is MethodInfo m && m.Name == "Add" && m.DeclaringType.Name == "Inventory"), "InventoryInserter.DelayedStart");
        Console.WriteLine("PASS: co-op factors 2-8 players (zombie health x1.3..x2.2, loot x1.5..x2.5); firearm copies reach the installed game");
    }
    // 2.4.3: what the guest's sleeping bag (LanSleep.LookAtSleepingBag), the mod slots read from a prefab (LanModSlots)
    // and the guest's rounds stopping in a zombie copy (ZombieSync.BeforeBulletContact) take from the game.
    private static void CheckSleepingBagModSlotsAndRounds(Assembly game, Assembly mod)
    {
        const BindingFlags any = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        // The game's look-at code: a sleeping bag wants a building (CharInHouse), no zombie within its safe distance, and
        // lies down with sleepConditions 5 (a bed: 2).
        var sleeper = game.GetType("SleepController", true);
        var bag = sleeper.GetField("sleepbag"); var safe = sleeper.GetField("safeZombieDistance");
        Require(bag != null && bag.FieldType == typeof(bool) && safe != null && safe.FieldType == typeof(float), "SleepController sleeping bag fields");
        var inHouse = game.GetType("GlobalManager", true).GetField("CharInHouse");
        Require(inHouse != null && inHouse.FieldType == typeof(bool), "GlobalManager.CharInHouse");
        var conditions = game.GetType("GlobalSleepController", true).GetField("sleepConditions", any);
        var look = Read(game.GetType("InteractingObjectsController", true).GetMethod("Update", any, null, Type.EmptyTypes, null));
        Require(look.Any(i => Equals(i.operand, bag)) && look.Any(i => Equals(i.operand, safe)) && look.Any(i => Equals(i.operand, inHouse)), "The game's sleeping bag look-at changed");
        var stores = Enumerable.Range(1, look.Count - 1).Where(i => look[i].opcode == OpCodes.Stfld && Equals(look[i].operand, conditions)).Select(i => look[i - 1]).ToList();
        Require(stores.Any(i => i.opcode == OpCodes.Ldc_I4_5) && stores.Any(i => i.opcode == OpCodes.Ldc_I4_2), "The game's bed and sleeping bag rest changed");
        // EquipmentModsItem gathers its slots only when it wakes (a prefab's own list stays as stored), and saves them in
        // that order.
        var mods = game.GetType("EquipmentModsItem", true); var slotType = game.GetType("EquipmentModSlotItem", true);
        var slots = mods.GetField("Slots", any);
        var awake = Read(mods.GetMethod("Awake", any, null, Type.EmptyTypes, null));
        int gather = awake.FindIndex(i => i.operand is MethodInfo m && m.Name == "GetComponentsInChildren" && m.GetParameters().Length == 0 && m.IsGenericMethod && m.GetGenericArguments()[0] == slotType);
        Require(gather >= 0 && awake.Skip(gather).Any(i => i.opcode == OpCodes.Stfld && Equals(i.operand, slots)), "EquipmentModsItem.Awake no longer gathers its active slots");
        Require(Read(mods.GetMethod("Save", any, null, Type.EmptyTypes, null)).Any(i => Equals(i.operand, slots)), "EquipmentModsItem.Save no longer follows Slots");
        // In the mod, only the weapon in the player's own hands (spawned, awake) is read through Slots.
        var readers = new List<string>();
        foreach (var type in mod.GetTypes())
            foreach (var method in type.GetMethods(any | BindingFlags.Static | BindingFlags.DeclaredOnly))
            {
                if (method.IsAbstract || method.ContainsGenericParameters || method.GetMethodBody() == null) continue;
                List<CodeInstruction> body;
                try { body = Read(method); } catch (Exception) { continue; }
                if (body.Any(i => Equals(i.operand, slots))) readers.Add(type.Name + "." + method.Name);
            }
        Require(readers.Count == 1 && readers[0] == "RemoteEquipment.CaptureLocalHandMods", "A prefab's Slots read by the mod: " + string.Join(", ", readers));
        var of = mod.GetType("ZompiercerLAN.LanModSlots", true).GetMethod("Of", BindingFlags.Static | BindingFlags.NonPublic);
        Require(of != null && of.ReturnType == slotType.MakeArrayType(), "LanModSlots.Of");
        // The game's round: its ray each step (BulletRayCast: from the round, ahead), then BulletContact; the blood a
        // round leaves in a zombie.
        var bullet = game.GetType("BulletScript", true);
        var fixedUpdate = Read(bullet.GetMethod("FixedUpdate", any, null, Type.EmptyTypes, null));
        int cast = fixedUpdate.FindIndex(i => IsCall(i, "BulletRayCast")), contact = fixedUpdate.FindIndex(i => IsCall(i, "BulletContact"));
        Require(cast >= 0 && contact > cast, "BulletScript.FixedUpdate no longer casts, then meets");
        var ray = Read(bullet.GetMethod("BulletRayCast", any, null, Type.EmptyTypes, null));
        Require(ray.Any(i => IsCall(i, "get_position")) && ray.Any(i => IsCall(i, "get_forward")), "BulletScript.BulletRayCast is no longer the round's position and forward");
        Require(bullet.GetField("bulletRayDistance")?.FieldType == typeof(float) && bullet.GetField("arrow")?.FieldType == typeof(bool) && bullet.GetField("targetRaycastMask") != null, "BulletScript fields");
        var contactBody = Read(bullet.GetMethod("BulletContact", any, null, Type.EmptyTypes, null));
        foreach (var name in new[] { "bulletHitCloudBlood", "bloodHole", "bloodOnWallsPrefab", "bloodOnWallsCheckRange" })
            Require(contactBody.Any(i => i.operand is FieldInfo f && f.Name == name), "BulletScript.BulletContact no longer uses GlobalEffects." + name);
        Require(contactBody.Any(i => IsCall(i, "SpawnBloodDecal")) && contactBody.Any(i => i.operand is FieldInfo f && f.Name == "bloodOnWallsRaycastLayerMask"), "BulletScript.BulletContact blood decal / wall blood");
        Require(mod.GetType("ZompiercerLAN.ZombieSync", true).GetMethod("BeforeBulletContact", BindingFlags.Static | BindingFlags.NonPublic) != null, "ZombieSync.BeforeBulletContact");
        Console.WriteLine("PASS: sleeping bag rules, mod slots gathered on waking (only the weapon in hand read through Slots), the round's ray and blood match what 2.4.3 relies on");
    }
    // 2.4.4: what the guest's work on trees, barrels and chairs, its tool swings and the garden beds reach in the game.
    private static void CheckWorkAndFarm(Assembly game, Assembly mod)
    {
        const BindingFlags any = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        Func<string, Type> type = name => game.GetTypes().Single(t => t.Name == name);
        Func<Type, string, Type, bool> field = (t, name, fieldType) => t.GetField(name, any)?.FieldType == fieldType;
        Func<Type, string, string, bool> named = (t, name, typeName) => t.GetField(name, any)?.FieldType.FullName == typeName;
        // A fallen tree: HitPoints (its ResourceContent drops the logs) hit by the game's melee blow.
        var points = type("HitPoints"); var resource = type("ResourceContent"); var gun = game.GetType("Gun", true);
        Require(field(points, "CurrentHP", typeof(float)) && field(points, "MaxHP", typeof(float)) && points.GetMethod("CauseDamage", any) != null, "HitPoints members");
        Require(field(resource, "durability", typeof(float)) && field(resource, "durabilityMax", typeof(float)) && resource.GetMethod("ObjectParsed", any) != null, "ResourceContent members");
        Require(Read(gun.GetMethod("MeleeHitTarget", any)).Any(i => IsCall(i, "CauseDamage")), "Gun.MeleeHitTarget no longer damages HitPoints");
        Require(Read(gun.GetMethod("MeleeDisassemblyTarget", any)).Any(i => i.operand is FieldInfo f && f.Name == "durability"), "Gun.MeleeDisassemblyTarget no longer wears durability");
        // Tool swings: building (Repairs) and taking apart (MeleeRightMouseButton) start the game's swing flags.
        var assembly = gun.GetField("meleeAssembly", any); var disassembly = gun.GetField("meleeDisassembly", any);
        Require(assembly?.FieldType == typeof(bool) && disassembly?.FieldType == typeof(bool), "Gun swing flags");
        Require(Read(gun.GetMethod("Repairs", any)).Any(i => i.opcode == OpCodes.Stfld && Equals(i.operand, assembly)), "Gun.Repairs no longer starts the building swing");
        Require(Read(gun.GetMethod("MeleeRightMouseButton", any)).Any(i => i.opcode == OpCodes.Stfld && Equals(i.operand, disassembly)), "Gun.MeleeRightMouseButton no longer starts the take-apart swing");
        // The garden beds.
        var tray = type("FarmTray"); var plant = type("FarmPlant"); var point = type("FarmTrayPlantPoint");
        Require(field(tray, "_hasWater", typeof(bool)) && field(tray, "_hasFertilize", typeof(bool)) && field(tray, "_amountForFertilizeRemained", typeof(int)) &&
            field(tray, "waterBottleForWet", typeof(int)) && named(tray, "soilMeshes", "UnityEngine.MeshRenderer[]") && named(tray, "dryMaterial", "UnityEngine.Material") &&
            named(tray, "wetMaterial", "UnityEngine.Material") && named(tray, "fertilizedMaterial", "UnityEngine.Material") && field(tray, "FramTrayPlantPoints", point.MakeArrayType()), "FarmTray fields");
        foreach (var name in new[] { "get_IsNeedWater", "get_IsNeedFertilize", "get_IsCanPlant", "get_WaterBottleForWetRemained", "GetNeedFertilized", "AddWater", "AddFertilizer" })
            Require(tray.GetMethod(name, BindingFlags.Instance | BindingFlags.Public) != null, "FarmTray." + name);
        Require(named(plant, "stagesGrowth", "UnityEngine.GameObject[]") && field(plant, "_currentGrowingTimeMax", typeof(float)) && named(plant, "PlantModelsParent", "UnityEngine.Transform") &&
            field(plant, "MinScale", typeof(float)) && field(plant, "MaxScale", typeof(float)) && field(plant, "GrowingTimeMax", typeof(float)) && field(plant, "GrowingFactor", typeof(float)) &&
            field(plant, "HarvestItemName", typeof(string)) && field(plant, "HarvestItemID", typeof(int)) && field(plant, "HarvestAmount", typeof(int)) &&
            plant.GetProperty("IsGrown") != null && plant.GetProperty("CurrentStageGrowth") != null, "FarmPlant members");
        Require(field(point, "PlantedHere", plant) && point.GetMethod("Plant", new[] { plant }) != null && point.GetMethod("Remove", Type.EmptyTypes) != null, "FarmTrayPlantPoint members");
        var items = type("ItemsDataBase"); var item = type("InventoryItem");
        Require(field(items, "FarmPlants", typeof(List<>).MakeGenericType(plant)) && items.GetMethod("FindItemIdByName") != null && items.GetMethod("GetItemNameByID") != null, "ItemsDataBase farm members");
        Require(field(item, "SeedForPlantName", typeof(string)) && item.GetMethod("GetPlantByHarvestName", Type.EmptyTypes)?.ReturnType == plant, "InventoryItem seed members");
        // The game's own bed keys: dirty water (61) leaves an empty bottle (10), fertilizer is item 297, seeds are item type 18.
        var interacting = type("InteractingObjectsController");
        var check = Read(interacting.GetMethod("CheckTray", any | BindingFlags.Static));
        Require(check.Any(i => i.opcode == OpCodes.Ldc_I4_S && Convert.ToInt32(i.operand) == 61) && check.Any(i => i.opcode == OpCodes.Ldc_I4 && Convert.ToInt32(i.operand) == 297) &&
            check.Any(i => i.opcode == OpCodes.Ldc_I4_S && Convert.ToInt32(i.operand) == 10) && check.Any(i => IsCall(i, "AddWater")) && check.Any(i => IsCall(i, "AddFertilizer")), "InteractingObjectsController.CheckTray changed");
        var seeds = Read(interacting.GetMethod("CheckSeedsInHand", any | BindingFlags.Static));
        Require(seeds.Any(i => i.opcode == OpCodes.Ldc_I4_S && Convert.ToInt32(i.operand) == 18) && seeds.Any(i => IsCall(i, "GetPlantByHarvestName")) && seeds.Any(i => IsCall(i, "Plant")), "InteractingObjectsController.CheckSeedsInHand changed");
        var harvest = Read(interacting.GetMethod("Harvesting", any | BindingFlags.Static));
        Require(harvest.Any(i => i.operand is FieldInfo f && f.Name == "HarvestItemID") && harvest.Any(i => i.operand is FieldInfo f && f.Name == "HarvestAmount") && harvest.Any(i => IsCall(i, "Remove")), "InteractingObjectsController.Harvesting changed");
        // The mod's side of it.
        var farm = mod.GetType("ZompiercerLAN.LanFarm", true);
        Require(farm.GetMethod("GuestPrefix", BindingFlags.Static | BindingFlags.NonPublic) != null && farm.GetMethod("HostWork", BindingFlags.Static | BindingFlags.NonPublic) != null, "LanFarm hooks");
        Require((int)farm.GetField("Fertilizer", BindingFlags.Static | BindingFlags.NonPublic).GetRawConstantValue() == 297, "LanFarm fertilizer item");
        Console.WriteLine("PASS: fallen trees, take-apart wear, tool swings and the garden beds (fields, methods, items 61/10/297, seeds of type 18) match what 2.4.4 relies on");
    }
    // 2.4.5: a mod item's mod part is set only when it wakes (a prefab's field is empty), the game's fit check that
    // LanModSlots.Fits repeats, and the take-apart swing that LanWorldWork.SwingPrefix starts at a host barrel's copy.
    private static void CheckModPartsAndBarrelSwing(Assembly game, Assembly mod)
    {
        const BindingFlags any = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        Func<string, Type> type = name => game.GetTypes().Single(t => t.Name == name);
        var item = type("InventoryItem"); var part = type("EquipmentModItem"); var slot = type("EquipmentModSlotItem");
        var field = item.GetField("equipmentMod", any);
        Require(field != null && field.FieldType == part, "InventoryItem.equipmentMod");
        var awake = Read(item.GetMethod("Awake", any, null, Type.EmptyTypes, null));
        int get = awake.FindIndex(i => i.operand is MethodInfo m && m.Name == "GetComponent" && m.IsGenericMethod && m.GetGenericArguments()[0] == part);
        Require(get >= 0 && awake[get + 1].opcode == OpCodes.Stfld && Equals(awake[get + 1].operand, field), "InventoryItem.Awake no longer takes its mod part");
        // IsSuitableToFitHere: muzzle type 3 fits slot types 7 and 9; then slot type, mount type (0 any), scope tier.
        var suit = Read(slot.GetMethod("IsSuitableToFitHere", any));
        Func<string, bool> uses = name => suit.Any(i => i.operand is FieldInfo f && f.Name == name);
        Require(uses("MuzzleModType") && uses("Slot") && uses("Type") && uses("MountType") && uses("ScopeTier") && uses("MaxAllowedScopeTier") && uses("equipmentMod"), "IsSuitableToFitHere fields");
        var numbers = suit.Where(i => i.opcode == OpCodes.Ldc_I4_3 || i.opcode == OpCodes.Ldc_I4_7 || i.opcode == OpCodes.Ldc_I4_S).Select(i => i.opcode == OpCodes.Ldc_I4_3 ? 3 : i.opcode == OpCodes.Ldc_I4_7 ? 7 : Convert.ToInt32(i.operand)).ToList();
        Require(numbers.SequenceEqual(new[] { 3, 7, 9 }), "IsSuitableToFitHere muzzle rule changed: " + string.Join(",", numbers));
        var slots = mod.GetType("ZompiercerLAN.LanModSlots", true);
        Require(slots.GetMethod("ModOf", BindingFlags.Static | BindingFlags.NonPublic)?.ReturnType == part && slots.GetMethod("Fits", BindingFlags.Static | BindingFlags.NonPublic) != null, "LanModSlots.ModOf/Fits");
        // The mod reads no prefab's equipmentMod field outside ModOf.
        var readers = new List<string>();
        foreach (var t in mod.GetTypes())
            foreach (var m in t.GetMethods(any | BindingFlags.Static | BindingFlags.DeclaredOnly))
            {
                if (m.IsAbstract || m.ContainsGenericParameters || m.GetMethodBody() == null) continue;
                List<CodeInstruction> body;
                try { body = Read(m); } catch (Exception) { continue; }
                if (body.Any(i => Equals(i.operand, field)) || body.Any(i => IsCall(i, "IsSuitableToFitHere"))) readers.Add(t.Name + "." + m.Name);
            }
        Require(readers.Count == 1 && readers[0] == "LanModSlots.ModOf", "equipmentMod or IsSuitableToFitHere used by the mod: " + string.Join(", ", readers));
        // The take-apart swing: GunShot starts it on the aim button (gamepad: disassemble) with a melee weapon, only at an
        // object SelectionManager knows; Gun.OnHit lands it in MeleeDisassemblyTarget.
        var shot = Read(type("ZombieFighterFireArmWeapon").GetMethod("GunShot", any, null, Type.EmptyTypes, null));
        int aim = shot.FindIndex(i => i.operand is FieldInfo f && f.Name == "isAimPressed");
        int apart = shot.FindIndex(i => i.operand is FieldInfo f && f.Name == "isDisassemblePressed");
        int hovered = shot.FindIndex(i => i.operand is FieldInfo f && f.Name == "HoveredResourceContent");
        int swing = shot.FindLastIndex(i => IsCall(i, "MeleeRightMouseButton"));
        Require(aim >= 0 && apart > aim && hovered > apart && swing > hovered, "GunShot no longer starts the take-apart swing as LanWorldWork.SwingPrefix does");
        var gun = game.GetType("Gun", true);
        var hit = Read(gun.GetMethod("OnHit", any, null, Type.EmptyTypes, null));
        int flag = hit.FindIndex(i => i.operand is FieldInfo f && f.Name == "meleeDisassembly");
        Require(flag >= 0 && hit.Skip(flag).Any(i => IsCall(i, "MeleeDisassemblyTarget")), "Gun.OnHit no longer lands the take-apart swing");
        var prefix = mod.GetType("ZompiercerLAN.LanWorldWork", true).GetMethod("SwingPrefix", BindingFlags.Static | BindingFlags.NonPublic);
        Require(prefix != null, "LanWorldWork.SwingPrefix");
        // Every condition GunShot checks before its aim branch (paint mode, open inventory or equipment, eating, running,
        // swimming, knocked back, bouncing, control) and inside it before what is hovered (keys, constructor, wire mode),
        // SwingPrefix checks too.
        int state = shot.FindIndex(i => IsCall(i, "get_CurrentState"));
        int target = shot.FindIndex(aim, i => i.operand is FieldInfo f && f.Name == "HoveredTrainPartInfRange");
        Require(state > 0 && target > aim, "GunShot layout around the aim branch changed");
        Func<CodeInstruction, string> condition = i =>
            i.operand is FieldInfo f && (f.FieldType == typeof(bool) || f.FieldType.Name == "GameObject") ? f.Name :
            i.operand is MethodInfo m && m.ReturnType == typeof(bool) && !m.IsSpecialName && m.DeclaringType != typeof(object) ? m.Name : null;
        var needed = shot.Take(state).Concat(shot.Skip(aim).Take(target - aim)).Select(condition).Where(n => n != null).Distinct().ToList();
        var mine = new HashSet<string>(Read(prefix).Select(condition).Where(n => n != null));
        var missing = needed.Where(n => !mine.Contains(n)).ToList();
        Require(needed.Count >= 12 && missing.Count == 0, "SwingPrefix misses GunShot's conditions: " + string.Join(", ", missing) + " (of " + string.Join(", ", needed) + ")");
        Console.WriteLine("PASS: mod parts read as InventoryItem.Awake takes them (the prefab field unused), the fit rule, and the take-apart swing match what 2.4.5 relies on (" + needed.Count + " swing conditions)");
    }
    // 2.5.0: what a bow never in hand, the new-game introduction, the loot cabinets' hover, the take-apart blow's sounds and
    // the zombie sounds of the guests rely on in the game.
    private static void CheckGuestSoundsAndLoot(Assembly game, Assembly mod)
    {
        const BindingFlags any = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        const BindingFlags all = any | BindingFlags.Static;
        Func<string, Type> type = name => game.GetTypes().Single(t => t.FullName == name);
        Func<Type, string, MethodInfo> method = (t, name) => t.GetMethods(all | BindingFlags.DeclaredOnly).First(m => m.Name == name);
        Func<MethodBase, string, bool> says = (m, text) => Read(m).Any(i => i.opcode == OpCodes.Ldstr && (string)i.operand == text);
        Func<MethodBase, string, bool> reads = (m, field) => Read(m).Any(i => i.operand is FieldInfo f && f.Name == field);
        Func<MethodBase, string, bool> calls = (m, name) => Read(m).Any(i => IsCall(i, name));
        Func<Func<CodeInstruction, bool>, List<string>> readers = match =>
        {
            var list = new List<string>();
            foreach (var t in mod.GetTypes())
                foreach (var m in t.GetMethods(all | BindingFlags.DeclaredOnly))
                {
                    if (m.IsAbstract || m.ContainsGenericParameters || m.GetMethodBody() == null) continue;
                    List<CodeInstruction> body;
                    try { body = Read(m); } catch (Exception) { continue; }
                    if (body.Any(match)) list.Add(t.Name + "." + m.Name);
                }
            return list;
        };
        // A bow: Gun.Awake takes the Bow beside it; the mod reads Gun.bow only in LanCombatSync.BowOf.
        var gun = type("Gun");
        var bowField = gun.GetField("bow", any);
        var awake = Read(gun.GetMethod("Awake", any, null, Type.EmptyTypes, null));
        int bowAt = awake.FindIndex(i => i.opcode == OpCodes.Stfld && Equals(i.operand, bowField));
        Require(bowField != null && bowAt > 0 && awake[bowAt - 1].operand is MethodInfo take && take.Name == "GetComponent" && take.IsGenericMethod &&
            take.GetGenericArguments()[0].Name == "Bow", "Gun.Awake no longer takes its Bow");
        var bowReaders = readers(i => i.opcode == OpCodes.Ldfld && Equals(i.operand, bowField));
        Require(bowReaders.Count == 1 && bowReaders[0] == "LanCombatSync.BowOf", "Gun.bow read outside LanCombatSync.BowOf: " + string.Join(", ", bowReaders));
        // The introduction a new game shows; the mod closes it as soon as its text is up.
        var scenes = type("GlobalSceneManager");
        var gui = type("Zompiercer.GUI.GUIManager");
        Require(gui.GetField("introductionText") != null && gui.GetField("playAfterIntroductionButton") != null, "GUIManager introduction fields");
        Require(reads(method(scenes, "IntroductionText"), "introductionText") && reads(method(scenes, "PlayAfterIntroductionButton"), "introductionText") &&
            reads(method(scenes, "PlayAfterIntroductionButton"), "playAfterIntroductionButton"), "The new-game introduction changed");
        Require(readers(i => i.operand is FieldInfo f && f.Name == "introductionText").Count > 0, "The mod no longer looks at the introduction");
        // The hover of a loot cabinet behind a door: searched, empty or not.
        var hover = type("InteractingObjectsController").GetMethod("Update", any, null, Type.EmptyTypes, null);
        foreach (var text in new[] { "ObjectForLoot", "Empty", "NotEmpty" }) Require(says(hover, text), "The hover no longer says " + text);
        foreach (var field in new[] { "wasChecked", "robotDevice", "inventoryBuildingElement", "doors", "inventoryExternalOpened", "craftWindowOpened", "colorRed", "colorGreen" })
            Require(reads(hover, field), "The hover no longer reads " + field);
        // The take-apart blow's sound and dust.
        var blow = gun.GetMethod("MeleeDisassemblyTarget", any, null, Type.EmptyTypes, null);
        foreach (var text in new[] { "WallMetal", "ObjectMetal", "WallWood", "ObjectWood" }) Require(says(blow, text), "The take-apart blow no longer tells " + text);
        foreach (var field in new[] { "disassemblyMetalSound", "disassemblyWoodSound", "meleeMetalHit", "meleeWoodHit", "bulletHitDust", "diggingSandHit", "diggingSoilHit", "cutGrassEffect", "RequiredTool", "raycastHit" })
            Require(reads(blow, field), "The take-apart blow no longer uses " + field);
        foreach (var name in new[] { "GetDiggingSand", "GetDiggingSoil", "GetPlantCut", "AudioPlay" }) Require(calls(blow, name), "The take-apart blow no longer calls " + name);
        var localHit = mod.GetType("ZompiercerLAN.LanWorldWork", true).GetMethod("PlaySuppressedHitEffects", BindingFlags.Static | BindingFlags.NonPublic);
        Require(localHit != null && calls(localHit, "AudioPlay") && calls(localHit, "DoRaycast"),
            "Suppressed guest work no longer plays its validated native hit effects");
        // The zombie's sounds: its clips, its steps, its roar clock and where each roar is made.
        var fx = type("ZombieEffects");
        foreach (var field in new[] { "zombieFootSteps", "zombieWalkRoar", "zombieTriggerRoar", "zombieAttackRoar", "zombieHitPainRoar", "zombieMediumDeathRoar" })
            Require(fx.GetField(field) != null && fx.GetField(field).IsPublic, "ZombieEffects." + field);
        var steps = method(type("Footsteps"), "Update");
        Require(reads(steps, "VerticalPosThreshold") && reads(steps, "footTransform") && calls(steps, "ZombieFootSteps"), "Footsteps.Update no longer steps as the copy does");
        var ai = type("ZombieAIController");
        var roar = ai.GetNestedTypes(BindingFlags.NonPublic).Single(n => n.Name.StartsWith("<zombieRoar>", StringComparison.Ordinal)).GetMethod("MoveNext", any);
        var roarBody = Read(roar);
        Func<int, bool> pushes = value => roarBody.Any(i => i.opcode == OpCodes.Ldc_I4_S && Convert.ToInt32(i.operand) == value || i.opcode == OpCodes.Ldc_I4 && Convert.ToInt32(i.operand) == value);
        Require(calls(roar, "ZombieRoarSound") && pushes(60) && pushes(120), "The zombie's roar clock changed (60-120 s)");
        Require(calls(method(ai, "TriggrRoar"), "ZombieTriggerRoar") && calls(method(ai, "ZombieAttackRays"), "ZombieAttackRoarSound"), "The noticing or attack roar moved");
        var detector = type("ZombieDamagDetector");
        Require(calls(method(detector, "Dead"), "ZombieMediumDeathRoarSound") && calls(method(detector, "DetectionDamage"), "ZombieComboHitPainSound"), "The pain or death roar moved");
        var animation = type("ZombieAnimation");
        foreach (var flag in new[] { "Chase", "attackHunter1", "attackHunter2", "attackDoor1", "attackDoor2" })
            Require(animation.GetMethods(all | BindingFlags.DeclaredOnly).Any(m => m.GetMethodBody() != null && says(m, flag)), "The zombie animator has no " + flag);
        Require(mod.GetType("ZompiercerLAN.ZombieVoice", true) != null, "ZombieVoice");
        Console.WriteLine("PASS: a bow's own Bow (Gun.bow read only by LanCombatSync.BowOf), the new-game introduction, the loot cabinets' hover, the take-apart blow's sounds and the zombie sounds match what 2.5.0 relies on");
    }
    // 2.5.1: the looks offered for the avatars are models of this game, without the farmer woman whose long hair fell
    // below the head (Farmer_01); a look saved before turns into her replacement, and only offered looks are shown.
    private static void CheckAvatarLooks(Assembly game, Assembly mod)
    {
        const BindingFlags all = BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
        var names = game.GetTypes().Single(t => t.FullName == "NPCManager+ModelName");
        var picker = mod.GetType("ZompiercerLAN.LanSkinPicker", true);
        var allowed = (string[])picker.GetField("Allowed", all).GetValue(null);
        Require(allowed.Length == 4 && allowed.All(id => Enum.IsDefined(names, id)), "A look is not a model of this game");
        Require(!allowed.Contains("RegularWomanNPC_Farmer_01") && allowed.Contains("RegularWomanNPC_Farmer_03"), "The farmer woman with long hair is offered again");
        var parse = picker.GetMethod("Parse", all);
        var isAllowed = picker.GetMethod("IsAllowed", all);
        byte farmer3 = (byte)(int)Enum.Parse(names, "RegularWomanNPC_Farmer_03"), farmer1 = (byte)(int)Enum.Parse(names, "RegularWomanNPC_Farmer_01");
        Require((byte)parse.Invoke(null, new object[] { "RegularWomanNPC_Farmer_01" }) == farmer3, "A saved Farmer_01 look does not become Farmer_03");
        Require(!(bool)isAllowed.Invoke(null, new object[] { farmer1 }) && (bool)isAllowed.Invoke(null, new object[] { farmer3 }), "LanSkinPicker.IsAllowed");
        var create = mod.GetType("ZompiercerLAN.LanPlugin", true).GetMethod("CreateAvatar", BindingFlags.Instance | BindingFlags.NonPublic);
        Require(Read(create).Any(i => IsCall(i, "IsAllowed")), "Another player's look is shown without LanSkinPicker.IsAllowed");
        foreach (var t in mod.GetTypes())
            foreach (var m in t.GetMethods(all | BindingFlags.Instance | BindingFlags.DeclaredOnly))
            {
                if (m.IsAbstract || m.ContainsGenericParameters || m.GetMethodBody() == null || m.Name == "Parse") continue;
                List<CodeInstruction> body;
                try { body = Read(m); } catch (Exception) { continue; }
                Require(!body.Any(i => i.opcode == OpCodes.Ldstr && (string)i.operand == "RegularWomanNPC_Farmer_01"), "Farmer_01 still used in " + t.Name + "." + m.Name);
            }
        Console.WriteLine("PASS: the avatar looks are models of this game without Farmer_01; a saved Farmer_01 becomes Farmer_03; only offered looks are shown");
    }
    // 2.5.2: the game's bow is weaponType 3 with its own shot (Bow.TryShot, never Gun.Shot); a takable holder is plain data
    // the guest's copies of the barrel mounts keep, and the game hangs a carried object in the hovered one.
    private static void CheckBowAndHolders(Assembly game, Assembly mod)
    {
        const BindingFlags any = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        const BindingFlags all = any | BindingFlags.Static;
        Func<string, Type> type = name => game.GetTypes().Single(t => t.FullName == name);
        Func<string, string, MethodInfo> method = (t, name) => type(t).GetMethods(all | BindingFlags.DeclaredOnly).Single(m => m.Name == name);
        var reloadEnd = Read(method("Gun", "OnReloadEnd"));
        Require(Enumerable.Range(0, reloadEnd.Count - 1).Any(i => reloadEnd[i].operand is FieldInfo f && f.Name == "weaponType" && reloadEnd[i + 1].opcode == OpCodes.Ldc_I4_3),
            "The bow's weaponType 3 is gone from Gun.OnReloadEnd");
        var tryShot = Read(method("Bow", "TryShot"));
        Require(!tryShot.Any(i => IsCall(i, "Shot")) && tryShot.Any(i => i.operand is FieldInfo f && f.Name == "magazine"), "Bow.TryShot changed (its own shot, spending the magazine)");
        var ranged = Read(mod.GetType("ZompiercerLAN.LanCombatSync", true).GetMethod("Ranged", all));
        Require(ranged.Any(i => IsCall(i, "BowOf")), "LanCombatSync.Ranged no longer counts a bow");
        Require(mod.GetType("ZompiercerLAN.RemoteEquipment", true).GetMethod("AfterBowShot", all) != null, "RemoteEquipment.AfterBowShot");
        var sync = mod.GetType("ZompiercerLAN.ZombieSync", true);
        var contact = Read(method("BulletScript", "BulletContact"));
        int nativeRay = contact.FindIndex(i => i.operand is MethodInfo m && m.DeclaringType.FullName == "UnityEngine.Physics" &&
            m.Name == "Raycast" && m.GetParameters()[0].ParameterType.FullName == "UnityEngine.Ray");
        Require(nativeRay >= 0, "Native arrow contact ray is missing");
        var nativeRayMethod = (MethodInfo)contact[nativeRay].operand;
        var transform = sync.GetMethod("ReplaceBulletContactRay", all);
        var patched = ((IEnumerable<CodeInstruction>)transform.Invoke(null, new object[] { contact })).ToList();
        var replacement = (MethodInfo)patched[nativeRay + 1].operand;
        Require(patched.Count == contact.Count + 1 && patched[nativeRay].opcode == OpCodes.Ldarg_0 &&
            replacement.Name == "BulletContactRay" && replacement.GetParameters().Select(p => p.ParameterType)
                .SequenceEqual(nativeRayMethod.GetParameters().Select(p => p.ParameterType).Concat(new[] { type("BulletScript") })),
            "Bow flight did not replace only the native contact ray with its projectile instance");
        var action = Read(sync.GetMethod("ReceiveAction", all));
        Require(action.FindIndex(i => IsCall(i, "Spend")) >= 0 &&
            action.FindIndex(i => IsCall(i, "FireGuestArrow")) > action.FindIndex(i => IsCall(i, "Spend")),
            "Host arrow can bypass combat accounting");
        Require(Read(sync.GetMethod("BeforeBulletContact", all)).Any(i => IsCall(i, "GuestArrowContact")) &&
            Read(sync.GetMethod("AfterBowShot", all)).Any(i => IsCall(i, "CaptureAction")), "Guest arrow is disconnected from the native bow or contact hook");
        var draw = sync.GetMethod("DrawCode", all);
        var speed = sync.GetMethod("ArrowSpeed", all);
        Require((byte)draw.Invoke(null, new object[] { 0f, 60f }) == 1 &&
            (byte)draw.Invoke(null, new object[] { 30f, 60f }) == 128 &&
            (byte)draw.Invoke(null, new object[] { 100f, 60f }) == 255 &&
            Math.Abs((float)speed.Invoke(null, new object[] { (byte)1, 60f, 1 }) - 8f * 1.015f) < .001f &&
            Math.Abs((float)speed.Invoke(null, new object[] { (byte)255, 60f, 10 }) - 69f) < .001f,
            "Bow draw no longer follows the native minimum, maximum and strength multiplier");
        Console.WriteLine("PASS: native bow launch, host combat accounting, and installed BulletContact ray stack");
        var holder = type("TakableHolder");
        foreach (var message in new[] { "Awake", "Start", "OnEnable", "OnDisable", "Update", "FixedUpdate", "LateUpdate", "OnDestroy" })
            Require(holder.GetMethod(message, all | BindingFlags.DeclaredOnly) == null, "TakableHolder now runs " + message + " (its copies would run it)");
        var check = method("InteractingObjectsController", "CheckTakableHolder");
        var body = Read(check);
        Require(check.ReturnType == typeof(bool) && body.Any(i => i.operand is FieldInfo f && f.Name == "HoveredTakableHolder") &&
            body.Any(i => IsCall(i, "DropInTakableHolderCo")), "InteractingObjectsController.CheckTakableHolder changed");
        Require(Read(method("SelectionManager", "FixedUpdate")).Any(i => i.operand is MethodInfo m && m.Name == "GetComponentInParent" &&
            m.IsGenericMethod && m.GetGenericArguments()[0].Name == "TakableHolder"), "SelectionManager no longer finds a holder from its collider");
        var layout = mod.GetType("ZompiercerLAN.TrainLayout", true);
        Require(Read(layout.GetMethod("CreateReplica", all)).Any(i => IsCall(i, "RestoreHolders")), "The copies lose their holders again");
        Require(mod.GetType("ZompiercerLAN.LanTakables", true).GetMethod("HolderPrefix", all) != null, "LanTakables.HolderPrefix");
        Console.WriteLine("PASS: the bow (weaponType 3, Bow.TryShot) counts as ranged and is shown; the barrel mounts' holders stay on the guest's copies as plain data");
        // 2.5.5: the game puts a built part's colliders on layer 13 (TrainPart.SetAsBuilt); the copies' holders go there too.
        var built = Read(type("Zompiercer.Train.TrainPart").GetMethod("SetAsBuilt", all | BindingFlags.DeclaredOnly));
        Require(Enumerable.Range(0, built.Count - 1).Any(i => built[i].opcode == OpCodes.Ldc_I4_S && Convert.ToInt32(built[i].operand) == 13 && IsCall(built[i + 1], "SetLayers")),
            "TrainPart.SetAsBuilt no longer puts a built part's colliders on layer 13");
        Require((int)layout.GetField("BuiltPartLayer", all).GetRawConstantValue() == 13 && Read(layout.GetMethod("RestoreHolders", all)).Any(i => IsCall(i, "set_layer")),
            "The copies' holders are not on the built layer");
        // 2.7.0: handguns have their own stance (RemoteHoldPose.Handgun, both hands), never the long gun's.
        var motion = mod.GetType("ZompiercerLAN.RemoteAvatarMotion", true);
        var kindOf = mod.GetType("ZompiercerLAN.RemoteHoldPose", true).GetMethod("KindOf", all);
        Require(Read(motion.GetMethod("Holding", all)).Any(i => i.operand is MethodInfo m && m.Name == "Handgun" && m.DeclaringType.Name == "RemoteHoldPose") &&
            new[] { "Glock", "M1911", "Volter", "Revolver" }.All(id => kindOf.Invoke(null, new object[] { id }).ToString() == "Handgun"),
            "Handguns are held in the rifle's stance again");
        Console.WriteLine("PASS: the holders of the guest's copies on the built layer 13; handguns out in both hands (2.5.5, 2.7.0)");
        // 2.5.3: the zombies at a guest in every batch, before the others' turns.
        var send = Read(mod.GetType("ZompiercerLAN.ZombieSync", true).GetMethod("SendBatch", all));
        Require(send.Count(i => IsCall(i, "AddFrame")) >= 2 && send.Any(i => IsCall(i, "Contains")), "The zombies at the guest no longer go in every batch");
        Console.WriteLine("PASS: the zombies at a guest go in every batch (2.5.3)");
    }
    // 2.4.2: what LanWeather reaches in the game (the weather timer it holds, the presets it reads and turns to),
    // and the zombie tick no longer reaching for a host's own Combat.
    private static void CheckWeather(Assembly game, Assembly mod)
    {
        const BindingFlags any = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        var weather = game.GetType("WeatherManager", true);
        var update = weather.GetMethod("Update", any, null, Type.EmptyTypes, null);
        Require(update != null && Read(update).Any(i => i.operand is MethodInfo m && m.Name == "SetRandomWeather"), "WeatherManager.Update picks the random weather");
        var preset = game.GetType("EnviroWeatherPreset", true);
        Require(weather.GetField("Global", BindingFlags.Static | BindingFlags.Public)?.FieldType == weather, "WeatherManager.Global");
        Require(weather.GetField("CurrentWeatherName", any)?.FieldType == typeof(string), "WeatherManager.CurrentWeatherName");
        Require(weather.GetMethod("FindWeatherPresetWithName", new[] { typeof(string) })?.ReturnType == preset, "WeatherManager.FindWeatherPresetWithName");
        Require(weather.GetMethod("SetWeather", new[] { typeof(string) }) != null && weather.GetMethod("SetWeatherInstant", new[] { typeof(string) }) != null, "WeatherManager.SetWeather/SetWeatherInstant");
        var sky = game.GetType("EnviroSkyMgr", true);
        Require(sky.GetProperty("instance", BindingFlags.Static | BindingFlags.Public) != null && sky.GetMethod("GetCurrentWeatherPreset", Type.EmptyTypes)?.ReturnType == preset, "EnviroSkyMgr current preset");
        Require(preset.GetField("Name")?.FieldType == typeof(string), "EnviroWeatherPreset.Name");
        var valid = mod.GetType("ZompiercerLAN.LanProtocol", true).GetMethod("ValidWeather", BindingFlags.Static | BindingFlags.NonPublic);
        foreach (var name in new[] { "Clear Sky", "Cloudy 1", "Heavy Rain", "Storm (night)" }) Require((bool)valid.Invoke(null, new object[] { name }), "Weather name refused: " + name);
        var tick = mod.GetType("ZompiercerLAN.ZombieSync", true).GetMethod("Tick", BindingFlags.Instance | BindingFlags.NonPublic);
        var body = Read(tick);
        int combat = body.FindIndex(i => i.operand is FieldInfo f && f.Name == "Combat" && f.DeclaringType.Name == "ZombieSync");
        // Only "not the host" leads there: one branch, right after reading _host (2.2.0-2.4.1 had a second, from _ready).
        var into = combat > 0 ? body[combat - 1].labels : new List<Label>();
        var sources = Enumerable.Range(0, body.Count).Where(i => body[i].operand is Label l && into.Contains(l)).ToList();
        Require(sources.Count == 1 && sources[0] > 0 && body[sources[0] - 1].operand is FieldInfo h && h.Name == "_host", "ZombieSync.Tick reaches its own Combat only on the guest");
        Console.WriteLine("PASS: weather manager, Enviro presets and the host's zombie tick match what 2.4.2 relies on");
    }
    // 1.4.5: leaving for the main menu, taken-apart objects, presence triggers, the boss's second bag
    // and shared quest rewards.
    private static void CheckLeaveAndRewards(Assembly game)
    {
        const BindingFlags any = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        foreach (var entry in new[] { "CharPresenceTrigger.ActivationLimiter:Boolean", "CharPresenceTrigger.OnEnter:UnityEvent" })
        {
            var parts = entry.Split(':'); var names = parts[0].Split('.');
            var field = game.GetType(names[0], true).GetField(names[1], any);
            Require(field != null && field.FieldType.Name == parts[1], "Game field missing or changed: " + entry);
        }
        Require(game.GetType("Zompiercer.GUI.GUIManager", true).GetMethod("ExitGameToMainMenuYesButton", Type.EmptyTypes) != null, "GUIManager.ExitGameToMainMenuYesButton");
        Require(game.GetType("ResourceContent", true).GetMethod("ObjectParsed", Type.EmptyTypes) != null, "ResourceContent.ObjectParsed");
        Require(game.GetType("CharPresenceTrigger", true).GetMethods(any).Any(m => m.Name == "OnTriggerEnter" && m.GetParameters().Length == 1 &&
            m.GetParameters()[0].ParameterType.Name == "Collider" && m.GetParameters()[0].Name == "collider"), "CharPresenceTrigger.OnTriggerEnter");
        Require(game.GetType("Zompiercer.Train.TrainController", true).GetMethod("EmergencyBraking", Type.EmptyTypes) != null, "TrainController.EmergencyBraking");
        var setDead = game.GetType("ZombieAIController", true).GetMethod("SetDead", new[] { typeof(bool) });
        Require(setDead != null && setDead.GetParameters()[0].Name == "value", "ZombieAIController.SetDead");
        Require(game.GetType("Quest", true).GetMethod("Complete", Type.EmptyTypes) != null, "Quest.Complete");
        Console.WriteLine("PASS: leave, taken-apart objects, presence triggers, boss bag and quest reward hooks match the installed game");
    }
    // 1.4.6: the player's dash (the dodge on Space) is seen from ZombieFighterController's bounce flags.
    private static void CheckDash(Assembly game)
    {
        const BindingFlags any = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        var fighter = game.GetType("ZombieFighterController", true);
        foreach (var name in new[] { "bounceF", "bounceFR", "bounceR", "bounceBR", "bounceB", "bounceBL", "bounceL", "bounceFL" })
        {
            var field = fighter.GetField(name, any);
            Require(field != null && field.FieldType == typeof(bool), "ZombieFighterController." + name);
        }
        var bouncing = fighter.GetMethod("IsBouncing", Type.EmptyTypes);
        Require(bouncing != null && bouncing.ReturnType == typeof(bool), "ZombieFighterController.IsBouncing");
        Console.WriteLine("PASS: the dash flags the partner's roll is taken from match the installed game");
    }
    // 1.4.7: how the partner moves is read from these fields of the player, its gun and its inventory.
    private static void CheckMotion(Assembly game)
    {
        const BindingFlags any = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        var fighter = game.GetType("ZombieFighterController", true);
        foreach (var entry in new[] { "runing:Boolean", "swimming:Boolean", "controller:CharacterController" })
        {
            var parts = entry.Split(':');
            var field = fighter.GetField(parts[0], any);
            Require(field != null && field.FieldType.Name == parts[1], "ZombieFighterController." + parts[0]);
        }
        var jumped = fighter.GetField("TimeOfJumpOrDash", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
        Require(jumped != null && jumped.FieldType == typeof(float), "ZombieFighterController.TimeOfJumpOrDash");
        var phase = game.GetType("Gun", true).GetField("ThrowingPhase", any);
        Require(phase != null && phase.FieldType == typeof(int), "Gun.ThrowingPhase");
        var inventory = game.GetType("Zompiercer.Inventory.InventoryController", true);
        foreach (var entry in new[] { "consumeSomething:Boolean", "reservedItem:InventoryItem", "CurrentlyDrainingFromRainwaterTank:RainwaterTank" })
        {
            var parts = entry.Split(':');
            var field = inventory.GetField(parts[0], any);
            Require(field != null && field.FieldType.Name == parts[1], "InventoryController." + parts[0]);
        }
        var item = game.GetType("Zompiercer.Inventory.InventoryItem", true);
        Require(item.GetField("itemType", any) != null && item.GetField("itemID", any) != null, "InventoryItem.itemType/itemID");
        Console.WriteLine("PASS: run, jump, swim, throw and consumable fields the partner's motion is taken from match the installed game");
    }
    // 1.4.21: the backpack's close time the guest's robot window waits out, and the game's refresh of the hand
    // after the guest's death empties its belt.
    private static void CheckRobotWindowAndHand(Assembly game)
    {
        const BindingFlags any = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        var inventory = game.GetType("Zompiercer.Inventory.InventoryController", true);
        var closed = inventory.GetField("_timeBackPackClosed", any);
        Require(closed != null && closed.FieldType == typeof(float), "InventoryController._timeBackPackClosed");
        var update = inventory.GetMethod("UpdateActiveItem", BindingFlags.Instance | BindingFlags.Public, null, Type.EmptyTypes, null);
        Require(update != null && update.ReturnType == typeof(void), "InventoryController.UpdateActiveItem()");
        var open = game.GetType("Zompiercer.GUI.GUIManager", true).GetMethod("OpenCloseRoboDogWindow", BindingFlags.Instance | BindingFlags.Public, null, Type.EmptyTypes, null);
        Require(open != null, "GUIManager.OpenCloseRoboDogWindow()");
        Console.WriteLine("PASS: robot window backpack timer and the hand refresh after death match the installed game");
        // 1.5.0: the bodybuilder's blow reads the area's private repulse state, force and side offset.
        var area = game.GetType("RepulsiveArea", true);
        foreach (var entry in new[] { "Repulse:Boolean", "Force:Single", "MinSideOffset:Single", "Damage:Single", "HitPlayer:Boolean" })
        {
            var parts = entry.Split(':');
            var field = area.GetField(parts[0], any);
            Require(field != null && field.FieldType.Name == parts[1], "RepulsiveArea." + parts[0]);
        }
        Console.WriteLine("PASS: the bodybuilder's repulsive area fields match the installed game");
    }
    private static void CheckBeaverHooks(Assembly game, Assembly mod)
    {
        const BindingFlags instance = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        const BindingFlags statics = BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
        var database = game.GetType("Zompiercer.Inventory.ItemsDataBase", true);
        var item = game.GetType("Zompiercer.Inventory.InventoryItem", true);
        var data = game.GetType("Zompiercer.Inventory.ItemsDataBase+ItemData", true);
        var awake = database.GetMethod("Awake", instance | BindingFlags.DeclaredOnly, null, Type.EmptyTypes, null);
        Require(awake != null && awake.ReturnType == typeof(void), "Figurine database Awake hook changed");
        Require(database.GetField("Global", statics)?.FieldType == database, "Figurine database Global changed");
        Require(database.GetField("itemPrefab", instance)?.FieldType == item.MakeArrayType(), "Figurine prefab table changed");
        Require(database.GetField("items", instance)?.FieldType == typeof(List<>).MakeGenericType(data), "Figurine item-data table changed");
        foreach (var field in new[] { "name", "description", "weght", "icon" })
            Require(data.GetField(field, instance) != null, "Figurine item data changed: " + field);
        foreach (var field in new[] { "itemID", "type", "itemType", "Name", "HideInMenu", "amount" })
            Require(item.GetField(field, instance) != null, "Figurine prefab field changed: " + field);
        Require(item.GetMethod("Save", instance, null, Type.EmptyTypes, null)?.ReturnType == typeof(object[]) &&
            item.GetMethod("Load", instance, null, new[] { typeof(object[]) }, null)?.ReturnType == typeof(void),
            "Native figurine item save shape changed");
        var binary = game.GetType("BinarySaver", true);
        var save = binary.GetMethod("Save", statics | instance, null, new[] { typeof(object), typeof(string) }, null);
        var load = binary.GetMethod("Load", statics | instance, null, new[] { typeof(string) }, null);
        Require(save?.ReturnType == typeof(void) && load?.ReturnType == typeof(object),
            "Figurine BinarySaver Save/Load hook changed");
        var beaver = mod.GetType("ZompiercerLAN.LanBeaverItem", true);
        Require((int)beaver.GetField("ItemId", statics).GetRawConstantValue() == 4095 &&
            (int)beaver.GetField("FallbackId", statics).GetRawConstantValue() == 149,
            "Figurine custom/fallback IDs changed");
        Require(beaver.GetMethod("DatabaseAwakePostfix", statics) != null &&
            mod.GetType("ZompiercerLAN.LanBeaverSave", true).GetMethod("SavePrefix", statics) != null &&
            mod.GetType("ZompiercerLAN.LanBeaverSave", true).GetMethod("LoadPostfix", statics) != null,
            "Figurine patch methods missing");
        Console.WriteLine("PASS: figurine database, item and native-save hook signatures match the installed game");
    }
    private static bool CallsClearForField(List<CodeInstruction> body, string name)
    {
        for (int i = 0; i + 1 < body.Count; i++)
            if (body[i].operand is FieldInfo field && field.Name == name && IsCall(body[i + 1], "Clear")) return true;
        return false;
    }
    private static void CheckTransform(Assembly game, Assembly mod, string type, string method, string patchType, string patchMethod, int expected)
    {
        var original = game.GetType(type, true).GetMethod(method, BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
        var patch = mod.GetType("ZompiercerLAN." + patchType, true).GetMethod(patchMethod, BindingFlags.Static | BindingFlags.NonPublic);
        var instructions = Read(original);
        var nativeCalls = instructions.Select(i => i.operand as MethodInfo).Where(m => m != null &&
            m.DeclaringType.Name == "Physics" && (m.Name == "Raycast" || m.Name == "RaycastNonAlloc")).ToArray();
        Require(nativeCalls.Length == expected, "Unexpected game raycast count: " + type + "." + method);
        var rewritten = ((IEnumerable<CodeInstruction>)patch.Invoke(null, new object[] { instructions, original })).ToList();
        Require(rewritten.Count(i => i.operand is MethodInfo m && m.DeclaringType.Name == patchType) == expected,
            "Production transform misses a game raycast: " + type + "." + method);
        var replacements = rewritten.Select(i => i.operand as MethodInfo).Where(m => m != null && m.DeclaringType.Name == patchType).ToArray();
        for (int i = 0; i < nativeCalls.Length; i++)
        {
            var parameters = nativeCalls[i].GetParameters().Select(p => p.ParameterType);
            if (patchType == "TrainGroundProbes") parameters = parameters.Concat(new[] { original.DeclaringType });
            Require(replacements[i].ReturnType == nativeCalls[i].ReturnType &&
                replacements[i].GetParameters().Select(p => p.ParameterType).SequenceEqual(parameters),
                "Changed raycast stack signature: " + nativeCalls[i]);
        }
        // An incompatible game must be rejected rather than silently dropping protection.
        bool rejected = false;
        try { ((IEnumerable<CodeInstruction>)patch.Invoke(null, new object[] { new List<CodeInstruction>(), original })).ToList(); }
        catch (TargetInvocationException ex) { rejected = ex.InnerException is InvalidOperationException; }
        catch (InvalidOperationException) { rejected = true; }
        Require(rejected, "Unsupported game IL was accepted");
        Console.WriteLine("PASS: actual game IL " + type + "." + method + ", replacements=" + expected + ", incompatible IL rejected");
    }
}
