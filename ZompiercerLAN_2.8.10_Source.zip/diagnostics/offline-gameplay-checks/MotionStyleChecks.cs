using System;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

internal static class MotionStyleChecks
{
    private const BindingFlags All = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
    internal static void Run(Assembly game, Assembly mod)
    {
        var style = mod.GetType("ZompiercerLAN.RemoteMotionStyle", true);
        var tired = style.GetMethod("Tired", All);
        Func<bool, float, float, bool> test = (before, now, max) => (bool)tired.Invoke(null, new object[] { before, now, max });
        Require(test(false, 25, 100) && !test(false, 26, 100) && test(true, 34, 100) && !test(true, 35, 100), "Fatigue hysteresis is unstable");
        Require(test(false, 50, 200) && !test(false, 60, 200), "Fatigue ignores effective max stamina");
        foreach (float bad in new[] { float.NaN, float.PositiveInfinity, float.NegativeInfinity, -1f })
            Require(!test(true, bad, 100) && !test(true, 0, bad), "Invalid stamina sustains fatigue");
        Require(!test(true, 0, 0) && !test(true, 101, 100), "Unknown or recovered stamina sustains fatigue");
        var sample = style.GetMethod("Sample", All);
        foreach (bool drink in new[] { false, true })
        {
            float previous = 0;
            float maximumStep = 0;
            bool sawContact = false, sawRest = false, sawChew = false, tippedAway = false;
            int atMouth = 0;
            for (int i = 0; i < 12000; i++)
            {
                var value = sample.Invoke(null, new object[] { i * .001f, drink });
                float contact = Number(value, "Contact"), chew = Number(value, "Chew"), tilt = Number(value, "Tilt"), head = Number(value, "Head");
                Require(Finite(contact) && contact >= 0 && contact <= 1 && Finite(chew) && chew >= 0 && chew <= 1 &&
                    Finite(tilt) && tilt >= 0 && tilt <= 1.0251f && Finite(head) && Math.Abs(head) <= 11, "Consumption curve out of range");
                maximumStep = Math.Max(maximumStep, Math.Abs(contact - previous)); previous = contact;
                sawContact |= contact > .99f; sawRest |= i > 500 && contact < .01f; sawChew |= chew > .9f;
                // 2.8.1: a bottle tips only at the lips (2.7.0 tipped it on the way, level beside the cheek halfway up).
                tippedAway |= drink && tilt > .05f && contact < .95f;
                if (contact > .99f) atMouth++;
            }
            Require(sawContact && sawRest && maximumStep < .005f && (drink ? !sawChew : sawChew), "Consumption lacks smooth lift, rest or chewing");
            // 2.8.1: food and drink at the mouth for most of each cycle (2.7.0: a bite touched it 0.22 s of 2.4 s).
            Require(!tippedAway && atMouth > 12000 * (drink ? .5f : .4f), "Consumption tips away from the lips or rarely reaches them");
            foreach (float bad in new[] { -1f, float.NaN, float.PositiveInfinity })
                Require(Number(sample.Invoke(null, new object[] { bad, drink }), "Contact") == 0, "Invalid age animates consumption");
        }
        var bar = game.GetType("ZombieFighterIndicatorsBar", true);
        var current = bar.GetField("currentStamina", All);
        var maximum = bar.GetProperty("MaxStamina", All)?.GetGetMethod(true);
        Require(current?.FieldType == typeof(float) && maximum?.ReturnType == typeof(float), "Installed stamina fields changed");
        var equipment = mod.GetType("ZompiercerLAN.RemoteEquipment", true);
        var observe = Read(equipment, "ObserveMotion");
        Require(observe.Any(i => i.opcode == OpCodes.Ldfld && Equals(i.operand, current)) &&
            observe.Any(i => Equals(i.operand, maximum)) && Calls(observe, "Tired") &&
            !observe.Any(i => i.opcode == OpCodes.Stfld && Equals(i.operand, current)), "Cosmetic capture bypasses effective stamina or mutates it");
        var plugin = mod.GetType("ZompiercerLAN.LanPlugin", true);
        Require(Calls(Read(plugin, "ShowRemotePlayer"), "MotionUse"), "Fatigue bit leaks into the item use kind");
        var motion = mod.GetType("ZompiercerLAN.RemoteAvatarMotion", true);
        Require(Calls(Read(motion, "Using"), "Sample") && Calls(Read(motion, "Using"), "ArmTo"), "Runtime consumes no staged curve or arm solver");
        var stride = Read(motion, "Stride");
        Require(stride.Any(i => (i.operand as FieldInfo)?.Name == "_tired") && Calls(stride, "get_IsClimbing") &&
            stride.Any(i => (i.operand as FieldInfo)?.Name == "_rollAt") &&
            !stride.Any(i => (i.operand as MethodBase)?.Name == "set_position"), "Tired gait changes root movement or lacks interruption");
        Console.WriteLine("PASS: staged food/drink curves, fatigue hysteresis, native stamina capture and cosmetic gait (no Unity execution)");
    }
    private static System.Collections.Generic.List<CodeInstruction> Read(Type type, string method)
    { return PatchProcessor.GetOriginalInstructions(type.GetMethod(method, All), (ILGenerator)null).ToList(); }
    private static bool Calls(System.Collections.Generic.List<CodeInstruction> code, string name)
    { return code.Any(i => (i.operand as MethodBase)?.Name == name); }
    private static float Number(object value, string name) { return (float)value.GetType().GetField(name, All).GetValue(value); }
    private static bool Finite(float x) { return !float.IsNaN(x) && !float.IsInfinity(x); }
    private static void Require(bool good, string message) { if (!good) throw new InvalidOperationException(message); }
}
