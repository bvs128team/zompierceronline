using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

// Verify the real partial-Add failure boundary without constructing Unity objects.
internal static class StarterLootNativeChecks
{
    private const BindingFlags All = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance;
    internal static void Run(Assembly game, Assembly mod)
    {
        var inventory = game.GetType("Zompiercer.Inventory.Inventory", true);
        var item = game.GetType("Zompiercer.Inventory.InventoryItem", true);
        var add = Read(inventory.GetMethod("Add", All, null, new[] { item, typeof(bool) }, null));
        int append = add.FindIndex(i => (i.operand as MethodBase)?.Name == "Add" &&
            (i.operand as MethodBase).DeclaringType.IsGenericType &&
            (i.operand as MethodBase).DeclaringType.GetGenericTypeDefinition() == typeof(List<>));
        int refresh = Call(add, "Regenerate");
        int owner = add.FindIndex(i => i.opcode == OpCodes.Stfld && (i.operand as FieldInfo)?.Name == "inInventory");
        Require(append >= 0 && refresh > append && owner > refresh, "Native Add failure boundary changed; review cleanup");
        Require(inventory.GetMethod("RecalculateWeight", All, null, Type.EmptyTypes, null)?.ReturnType == typeof(void), "Native weight refresh changed");
        var loot = mod.GetType("ZompiercerLAN.LanStarterLoot", true);
        var detach = Read(loot.GetMethod("DetachFailedCopy", All));
        Require(Call(detach, "RemoveAll") >= 0 && Call(detach, "RecalculateWeight") > Call(detach, "RemoveAll") &&
            Call(detach, "Remove") < 0, "Failed Add cleanup retains an ownerless entry or invokes unsafe UI callbacks");
        var predicate = detach.Select(i => i.operand as MethodInfo).FirstOrDefault(m => m != null && m.Name.Contains("b__"));
        Require(predicate != null && (Call(Read(predicate), "ReferenceEquals") >= 0 ||
            Read(predicate).Any(i => i.opcode == OpCodes.Ceq) && !Read(predicate).Any(i => i.operand is MethodBase)),
            "Cleanup may remove other inventory items instead of the failed copy");
        var tick = Read(loot.GetMethod("Tick", All));
        Require(tick.Count(i => (i.operand as MethodBase)?.Name == "DetachFailedCopy") == 2 &&
            Call(tick, "DetachFailedCopy") < Call(tick, "Destroy"), "Cleanup no longer detaches both known destination and assigned owner before destruction");
        Require(Call(tick, "Eligible") >= 0 && Call(tick, "Commit") < Call(tick, "SetParent"),
            "Starter kit is published before admission/once receipt");
        // 2.8.2: the receipt follows the game's own fields (21 in 21.4, 22 in 22.0), the game reads them without it, and
        // the mod never refuses the game's save.
        var core = game.GetType("Zompiercer.SaveLoad.SaveLoadCore", true);
        var receipt = mod.GetType("ZompiercerLAN.LanStarterLootReceipt", true);
        int minimum = (int)receipt.GetField("NativeMinimum", All).GetRawConstantValue();
        var world = Read(core.GetMethod("SaveWorldToData", All, null, Type.EmptyTypes, null));
        int array = world.FindIndex(i => i.opcode == OpCodes.Newarr && (i.operand as Type)?.FullName == "System.Object");
        Require(array > 0 && world[array - 1].opcode == OpCodes.Ldc_I4_S && Convert.ToInt32(world[array - 1].operand) >= minimum,
            "The game's world snapshot has fewer fields than the receipt expects");
        var saved = Read(loot.GetMethod("Saved", All));
        Require(Call(saved, "Save") >= 0 && Call(saved, "SetValue") < 0, "Native save cannot retain the receipt or refuses the game's save");
        var loading = loot.GetMethod("Loading", All);
        Require(loading.GetParameters().Length == 1 && loading.GetParameters()[0].ParameterType == typeof(object[]).MakeByRefType() &&
            Read(loading).Count(i => (i.operand as MethodBase)?.Name == "Load") == 2 && Read(loading).Any(i => i.opcode == OpCodes.Stind_Ref),
            "The game would read the receipt as a field of its own");
        // 2.8.3: the kit's scene is the game's first location as the world catalogue (made from the level files) has it;
        // 2.5.6-2.8.2 named the second one and the kit never came.
        string scene = (string)receipt.GetField("Scene", All).GetRawConstantValue();
        var catalog = mod.GetType("ZompiercerLAN.LanWorldCatalog", true);
        string first = null;
        foreach (var entry in (Array)catalog.GetField("Entries", All).GetValue(null))
            if ((int)entry.GetType().GetField("Location", All).GetValue(entry) == 1)
                first = (string)entry.GetType().GetField("Scene", All).GetValue(entry);
        Require(first != null && scene == first, "Starter kit scene " + scene + " is not the first location " + first);
        Console.WriteLine("PASS: starter loot native partial-Add cleanup, exact-reference removal, weight refresh, commit/save ordering, receipt after the game's " + minimum + "+ fields and out of its load, kit on the first location " + first + " (no Unity execution)");
    }
    private static List<CodeInstruction> Read(MethodBase method)
    { Require(method != null, "Required starter loot method missing"); return PatchProcessor.GetOriginalInstructions(method, (ILGenerator)null).ToList(); }
    private static int Call(List<CodeInstruction> code, string name) { return code.FindIndex(i => (i.operand as MethodBase)?.Name == name); }
    private static void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
}
