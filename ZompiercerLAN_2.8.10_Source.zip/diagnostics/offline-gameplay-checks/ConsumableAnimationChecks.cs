using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

// Checks the shipped consumption contract and the visual call order from compiled IL only.
// No Unity object, game scene, save or network process is constructed.
internal static class ConsumableAnimationChecks
{
    private const BindingFlags Instance = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
    private const BindingFlags Static = BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;

    internal static void Run(Assembly game, Assembly mod)
    {
        var inventory = game.GetType("Zompiercer.Inventory.InventoryController", true);
        var item = game.GetType("Zompiercer.Inventory.InventoryItem", true);
        var consuming = inventory.GetField("consumeSomething", Instance);
        var reserved = inventory.GetField("reservedItem", Instance);
        var itemType = item.GetField("itemType", Instance);
        var itemId = item.GetField("itemID", Instance);
        Require(consuming?.FieldType == typeof(bool) && reserved?.FieldType == item &&
                itemType != null && itemType.FieldType.IsEnum && itemId?.FieldType == typeof(int),
            "Installed game consumption fields changed");

        // The game establishes the reserved item before announcing consumption and clears both
        // when it completes or is cancelled. The mod samples this pair to name the shown item.
        var start = Read(inventory.GetMethod("TryUseFoodOrWater", Instance));
        Require(FirstStore(start, reserved) >= 0 && FirstStore(start, consuming) > FirstStore(start, reserved) &&
                Reads(start, itemType) && LoadsInt(start, 15),
            "Native food start no longer provides a typed reserved item or energy drink");
        var stop = Read(inventory.GetMethod("StopConsumption", Instance));
        Require(FirstStore(stop, consuming) >= 0 && FirstStore(stop, reserved) > FirstStore(stop, consuming),
            "Native cancellation no longer clears consumption and reserved item");

        var local = mod.GetType("ZompiercerLAN.RemoteEquipment", true);
        var useOf = Read(local.GetMethod("UseOf", Static));
        Require(Reads(useOf, consuming) && Reads(useOf, reserved) && Reads(useOf, itemType) && Reads(useOf, itemId) &&
                FirstCall(useOf, "IsDrinkType") >= 0,
            "Local use no longer recognizes the game's typed energy drink");
        var isDrink = local.GetMethod("IsDrinkType", Static);
        Require(isDrink != null && (bool)isDrink.Invoke(null, new object[] { 11 }) &&
                (bool)isDrink.Invoke(null, new object[] { 15 }) &&
                !(bool)isDrink.Invoke(null, new object[] { 10 }) &&
                !(bool)isDrink.Invoke(null, new object[] { 13 }),
            "Drink classification does not match water, energy drink, food and medicine types");
        var observe = Read(local.GetMethod("ObserveMotion", Static));
        Require(FirstCall(observe, "UseOf") >= 0 && Reads(observe, reserved),
            "Local use no longer names the item it uses");
        var visual = mod.GetType("ZompiercerLAN.RemoteEquipmentVisual", true);
        var build = Read(visual.GetMethod("BuildFood", Instance));
        Require(Reads(build, itemType) && FirstCall(build, "Bounds") > FirstCall(build, "CopyGeometry") &&
                FirstCall(build, "CopyGeometry") > FirstCall(build, "ExcludedLowerLods") &&
                FirstCall(build, "IsDrinkType") >= 0 && FirstCall(build, "TryMeasure") > FirstCall(build, "Bounds"),
            "Consumable model validation or measured geometry is missing");
        Require(visual.GetMethod("TryGetUseItem", Instance)?.ReturnType == typeof(bool) &&
                visual.GetMethod("PlaceUse", Instance) != null &&
                FirstCall(Read(visual.GetMethod("ShowUse", Instance)), "BuildFood") >= 0,
            "Consumable bounds, placement or lifecycle API is missing");
        var show = Read(visual.GetMethod("ShowUse", Instance));
        var nextBuild = visual.GetField("_nextFoodAt", Instance);
        Require(show.Count(i => i.opcode == OpCodes.Stfld && Equals(i.operand, nextBuild)) == 1 &&
                FirstCall(show, "Destroy") >= 0 && Reads(show, visual.GetField("_foodUse", Instance)),
            "Stop/switch may bypass build throttling or keep a stale use visual");
        CheckMeasuredScale(mod);

        var motion = mod.GetType("ZompiercerLAN.RemoteAvatarMotion", true);
        var usingBody = Read(motion.GetMethod("Using", Instance));
        foreach (var call in new[] { "TryGetUseItem", "Drink", "Eat", "Medkit", "BandageArm", "BandageWrap", "ArmTo", "PlaceUse" })
            Require(FirstCall(usingBody, call) >= 0, "Use pose lacks " + call);
        var late = Read(motion.GetMethod("LateUpdate", Instance));
        Require(FirstCall(late, "Using") > FirstCall(late, "Roll") && FirstCall(late, "Fingers") > FirstCall(late, "Using"),
            "Mouth contact or finger placement order changed");
        Console.WriteLine("PASS: native typed consumption, every use names its item, measured scale, hand placement and cancellation (no Unity execution)");
    }

    private static void CheckMeasuredScale(Assembly mod)
    {
        var geometry = mod.GetType("ZompiercerLAN.RemoteConsumablePose", true);
        var measure = geometry.GetMethod("TryMeasure", Static);
        Require(measure != null, "Runtime consumable measurement is missing");
        Require(Near(Measure(measure, -.036f, 0f, -.036f, .036f, .242f, .036f), 1f) &&
                Near(Measure(measure, -.127f, 0f, -.166f, .127f, .093f, .166f), .3f / .332f) &&
                Near(Measure(measure, -.059f, 0f, -.058f, .058f, .142f, .110f), 1f),
            "Shipped bottle, broad food or bandage scale is wrong");
        foreach (var bad in new[] {
            new[] { float.NaN, 0f, 0f, 1f, 1f, 1f },
            new[] { 1f, 0f, 0f, 0f, 1f, 1f },
            new[] { 0f, 0f, 0f, .001f, .001f, .001f },
            new[] { 0f, 0f, 0f, 11f, 1f, 1f }
        })
        {
            var args = new object[] { bad[0], bad[1], bad[2], bad[3], bad[4], bad[5], null };
            Require(!(bool)measure.Invoke(null, args), "Invalid geometry was accepted for a palm attachment");
        }
    }

    private static float Measure(MethodInfo method, float minX, float minY, float minZ, float maxX, float maxY, float maxZ)
    {
        var args = new object[] { minX, minY, minZ, maxX, maxY, maxZ, null };
        Require((bool)method.Invoke(null, args), "Expected shipped consumable geometry was rejected");
        return (float)args[6];
    }
    private static bool Near(float actual, float expected)
    { return Math.Abs(actual - expected) < .0001f; }

    private static List<CodeInstruction> Read(MethodBase method)
    {
        Require(method != null, "Expected game or mod method is missing");
        return PatchProcessor.GetOriginalInstructions(method, (ILGenerator)null).ToList();
    }
    private static bool Reads(IEnumerable<CodeInstruction> code, FieldInfo field)
    { return code.Any(i => (i.opcode == OpCodes.Ldfld || i.opcode == OpCodes.Ldsfld) && Equals(i.operand, field)); }
    private static int FirstStore(List<CodeInstruction> code, FieldInfo field)
    { return code.FindIndex(i => i.opcode == OpCodes.Stfld && Equals(i.operand, field)); }
    private static int FirstCall(List<CodeInstruction> code, string name)
    { return code.FindIndex(i => (i.opcode == OpCodes.Call || i.opcode == OpCodes.Callvirt) &&
        (i.operand as MethodBase)?.Name == name); }
    private static bool LoadsInt(IEnumerable<CodeInstruction> code, int value)
    { return code.Any(i => i.opcode == OpCodes.Ldc_I4 && i.operand is int n && n == value ||
        i.opcode == OpCodes.Ldc_I4_S && Convert.ToInt32(i.operand) == value); }
    private static void Require(bool condition, string message)
    { if (!condition) throw new InvalidOperationException(message); }
}
