using System;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

// Reads compiled metadata and runs only pure ID classification. No Unity object is created.
internal static class NativeGripChecks
{
    private const BindingFlags Static = BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
    private const BindingFlags Instance = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

    internal static void Run(Assembly game, Assembly mod)
    {
        var grip = mod.GetType("ZompiercerLAN.RemoteNativeGrip", true);
        var pose = grip.GetNestedType("Pose", BindingFlags.Public | BindingFlags.NonPublic);
        var frame = grip.GetNestedType("PalmFrame", BindingFlags.Public | BindingFlags.NonPublic);
        Require(pose != null && frame != null, "Native grip pose/frame types are missing");
        Require(pose.GetField("PrimaryFrame", Instance)?.FieldType == frame &&
                pose.GetField("SupportFrame", Instance)?.FieldType == frame &&
                pose.GetField("PrimaryFrameValid", Instance)?.FieldType == typeof(bool) &&
                pose.GetField("SupportValid", Instance)?.FieldType == typeof(bool),
            "Native anatomical or support pose contract is missing");
        Require(pose.GetMethod("Release", Instance) != null && grip.GetMethod("Clear", Static) != null,
            "Native geometry/cache disposal contract is missing");
        var capture = grip.GetMethod("CaptureTargetFrame", Static);
        var fit = grip.GetMethod("FitPalm", Static);
        Require(capture != null && capture.ReturnType == typeof(bool) &&
                capture.GetParameters().Length == 2 && capture.GetParameters()[1].ParameterType == frame.MakeByRefType() &&
                fit != null && fit.ReturnType == typeof(bool) && fit.GetParameters().Length == 5 &&
                fit.GetParameters()[0].ParameterType == frame && fit.GetParameters()[1].ParameterType == frame &&
                fit.GetParameters()[2].ParameterType == typeof(float) &&
                fit.GetParameters()[3].ParameterType.FullName == "UnityEngine.Vector3&" &&
                fit.GetParameters()[4].ParameterType.FullName == "UnityEngine.Quaternion&",
            "Native-to-NPC scaled palm fit is missing");

        // The 35 held items in the installed 2.5.6 asset catalogue.
        var ids = new[] {
            "Volter", "Sawed-off shotgun", "M1911", "Remington", "Glock", "AKM", "Grenade Mk2",
            "Baseball Bat", "Hammer Scrap", "Hammer", "Baseball Bat Nails", "Adjustable Wrench Scrap",
            "Knife Scrap", "Bow Rough", "Flashlight Scrap", "C4", "Shovel Scrap", "Adjustable Wrench",
            "Dynamite", "Dynamite Bundle", "Baseball Bat Lucille", "Hammer Quality",
            "Adjustable Wrench Quality", "Knife Combat", "Knife Tactical", "Shovel Metal", "Flashlight",
            "Axe Scrap", "Axe Old Fire", "Axe Quality", "Bow Reinforced", "Hunting Rifle", "Revolver",
            "ShotgunM4", "OldRifle"
        };
        var mesh = grip.GetMethod("MainMesh", Static);
        var kindOf = mod.GetType("ZompiercerLAN.RemoteHoldPose", true).GetMethod("KindOf", Static);
        Require(mesh != null && kindOf != null && ids.Length == 35 && ids.Distinct().Count() == 35,
            "Native held-item catalogue is incomplete");
        foreach (var id in ids)
        {
            var args = new object[] { id, false };
            Require(!string.IsNullOrEmpty((string)mesh.Invoke(null, args)), "Native mesh missing: " + id);
            Require((bool)args[1] == id.StartsWith("Bow ", StringComparison.Ordinal),
                "Only bows may use the left primary palm: " + id);
        }
        // 2.7.0: the partner's stance by item: six long guns, four handguns, two bows, two shovels, the rest in one hand.
        var kinds = ids.GroupBy(id => kindOf.Invoke(null, new object[] { id }).ToString()).ToDictionary(g => g.Key, g => g.Count());
        Require(kinds.Count == 5 && kinds["Long"] == 6 && kinds["Handgun"] == 4 && kinds["Bow"] == 2 && kinds["TwoHand"] == 2 &&
                kinds["OneHand"] == 21 && kindOf.Invoke(null, new object[] { "" }).ToString() == "None",
            "Held-item stance catalogue changed");
        foreach (var id in new[] { "Bow Rough", "Bow Reinforced" })
            Require(kindOf.Invoke(null, new object[] { id }).ToString() == "Bow", "Bow stance lost: " + id);

        var gun = game.GetType("Gun", true);
        var weapon = game.GetType("WeaponAnimation", true);
        var slot = game.GetType("EquipmentModSlot", true);
        Require(gun.GetField("equipmentMods", Instance)?.FieldType == game.GetType("EquipmentMods", true) &&
                gun.GetField("bulletSpawnPoint", Instance)?.FieldType.FullName == "UnityEngine.Transform" &&
                weapon.GetField("Length", Instance)?.FieldType == typeof(float) &&
                slot.GetField("SpawnedModel", Instance)?.FieldType.FullName == "UnityEngine.Transform",
            "Installed native weapon metadata changed");
        var extract = grip.GetMethod("Extract", Static);
        var instructions = PatchProcessor.GetOriginalInstructions(extract, (ILGenerator)null);
        Require(instructions.Any(i => (i.opcode == OpCodes.Call || i.opcode == OpCodes.Callvirt) &&
                (i.operand as MethodBase)?.Name == "SampleAnimation") &&
                instructions.Any(i => (i.opcode == OpCodes.Call || i.opcode == OpCodes.Callvirt) &&
                (i.operand as MethodBase)?.Name == "Anchors") &&
                instructions.Any(i => (i.opcode == OpCodes.Call || i.opcode == OpCodes.Callvirt) &&
                (i.operand as MethodBase)?.Name == "KindOf"),
            "Native idle pose, stance kind or measured anchors are missing");
        Console.WriteLine("PASS: 35 native held IDs in 5 stances; bow primacy; scaled anatomical fit and measured anchors (no Unity execution)");
    }

    private static void Require(bool condition, string message)
    { if (!condition) throw new InvalidOperationException(message); }
}
