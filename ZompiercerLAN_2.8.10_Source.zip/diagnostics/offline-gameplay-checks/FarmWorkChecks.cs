using System;
using System.Linq;
using System.Reflection;
using Mono.Cecil;
using Mono.Cecil.Cil;

// Verify the native calls behind farm and world work against the installed game binary.
// Metadata and IL only: no Unity scene, save or network session is started.
internal static class FarmWorkChecks
{
    private static void Require(bool condition, string message)
    { if (!condition) throw new InvalidOperationException(message); }

    private static TypeDefinition Type(AssemblyDefinition assembly, string name)
    {
        var type = assembly.MainModule.Types.FirstOrDefault(t => t.FullName == name);
        Require(type != null, "Missing game or mod type: " + name);
        return type;
    }

    private static MethodDefinition Method(TypeDefinition type, string name)
    {
        var method = type.Methods.FirstOrDefault(m => m.Name == name && m.HasBody);
        Require(method != null, "Missing method: " + type.FullName + "." + name);
        return method;
    }

    private static bool Calls(MethodDefinition method, string target)
    {
        return method.Body.Instructions.Any(i =>
        {
            var member = i.Operand as MethodReference;
            return member != null && member.FullName.Contains(target);
        });
    }

    private static bool Reads(MethodDefinition method, string field)
    {
        return method.Body.Instructions.Any(i => i.OpCode == OpCodes.Ldfld &&
            i.Operand is FieldReference && ((FieldReference)i.Operand).Name == field);
    }

    private static bool Stores(MethodDefinition method, string field)
    {
        return method.Body.Instructions.Any(i => i.OpCode == OpCodes.Stfld &&
            i.Operand is FieldReference && ((FieldReference)i.Operand).Name == field);
    }

    private static bool ReadsStatic(MethodDefinition method, string field)
    {
        return method.Body.Instructions.Any(i => i.OpCode == OpCodes.Ldsfld &&
            i.Operand is FieldReference && ((FieldReference)i.Operand).Name == field);
    }

    private static bool Pushes(MethodDefinition method, int value)
    {
        return method.Body.Instructions.Any(i =>
            (i.OpCode == OpCodes.Ldc_I4 || i.OpCode == OpCodes.Ldc_I4_S) &&
            Convert.ToInt32(i.Operand) == value);
    }

    internal static void Run(Assembly game, Assembly mod)
    {
        using (var native = AssemblyDefinition.ReadAssembly(game.Location))
        using (var patched = AssemblyDefinition.ReadAssembly(mod.Location))
        {
            var furniture = Method(Type(native, "Furniture"), "Awake");
            var trayType = Type(native, "Zompiercer.Farm.FarmTray");
            var tray = Method(trayType, "Awake");
            Require(Calls(furniture, "GetComponent<Zompiercer.Farm.FarmTray>") &&
                Calls(tray, "GetComponent<Furniture>"), "FarmTray no longer shares its Furniture object");
            // The companion asset check parses these serialized fields in order;
            // fail if a game update changes that layout rather than misreading a count.
            var serialized = trayType.Fields.Where(f => !f.IsStatic && (f.IsPublic ||
                f.CustomAttributes.Any(a => a.AttributeType.FullName == "UnityEngine.SerializeField"))).Select(f => f.Name).Take(8).ToArray();
            Require(serialized.SequenceEqual(new[] { "transparentMaterial", "dryMaterial", "wetMaterial", "fertilizedMaterial",
                "soilMeshes", "timeToDrySoil", "waterBottleForWet", "FramTrayPlantPoints" }), "Native farm asset serialization layout changed");

            var gun = Type(native, "Gun");
            var resourceStart = Method(Type(native, "ResourceContent"), "Start");
            Require(Calls(Method(gun, "DoRaycast"), "GetComponentInParent<ResourceContent>") &&
                Reads(resourceStart, "durabilityMax") && Stores(resourceStart, "durability"),
                "ResourceContent target or load-place lifecycle changed");
            var nativeBlow = Method(gun, "MeleeDisassemblyTarget");
            Require(Reads(nativeBlow, "toolKnife") && Calls(nativeBlow, "CollectedResource::GettingResource"),
                "Native flower cutting no longer uses the knife flag and collected resource");
            var itemAwake = Method(Type(native, "Zompiercer.Inventory.InventoryItem"), "Awake");
            Require(Stores(itemAwake, "toolKnife") && Pushes(itemAwake, 56) &&
                Pushes(itemAwake, 187) && Pushes(itemAwake, 188),
                "Native knife item-ID classification changed");

            var work = Type(patched, "ZompiercerLAN.LanWorldWork");
            var host = Method(work, "HostWork");
            var search = Method(work, "NearestResource");
            var hostKnife = Method(work, "HostKnife");
            Require(Calls(host, "NearestResource") && Calls(host, "HostKnife") &&
                Calls(host, "HostGun") &&
                Pushes(hostKnife, 56) && Pushes(hostKnife, 187) && Pushes(hostKnife, 188),
                "Host work lost the bounded resource fallback or knife check");
            Require(Calls(search, "FindObjectsOfType<ResourceContent>") &&
                ReadsStatic(search, "LoadPlaces") && Calls(search, "ContainsKey") &&
                Calls(search, "LanWorldItems::Present") &&
                Calls(Method(work, "AtLoadPlace"), "LanWorldItems::Present"),
                "Resource lookup no longer limits culled scene objects to initialized resources");

            var farm = Type(patched, "ZompiercerLAN.LanFarm");
            Require(Calls(Method(farm, "Tick"), "LanFarm::Current") &&
                Calls(Method(farm, "Current"), "LanFarm::Frame"),
                "Garden-bed snapshot path changed");
            Require(Pushes(Method(farm, "Frame"), 17) && Pushes(Method(farm, "LayoutOf"), 17),
                "Host snapshot or guest layout still drops the shipped 17-point large bed");
        }
        Console.WriteLine("PASS: farm and world-work paths match installed game IL; started-resource lookup and native knife IDs retained");
    }
}
