using System;
using System.Collections;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

// Inspects shipped game and mod IL without starting Unity or a world.
internal static class TrainBenchAndHudChecks
{
    private const BindingFlags Any = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;

    internal static void Run(Assembly game, Assembly mod)
    {
        var selection = game.GetType("SelectionManager", true);
        var buttonHover = selection.GetField("HoveredHardwareButton", Any);
        var leverHover = selection.GetField("HoveredLever", Any);
        Require(buttonHover != null && buttonHover.FieldType.Name == "HardwareButton", "Native button hover changed");
        Require(leverHover != null && leverHover.FieldType.Name == "Lever", "Native lever hover changed");
        var interaction = game.GetType("InteractingObjectsController", true);
        var nativeButton = Read(interaction.GetMethod("CheckHardwareButton", Any));
        Require(nativeButton.Any(i => Equals(i.operand, buttonHover)) &&
            nativeButton.Any(i => IsCall(i, "HardwareButton", "Switch")) &&
            nativeButton.Any(i => IsCall(i, "SimpleInfoDisplayer", "SetText")) &&
            nativeButton.Any(i => IsCall(i, "HardwareButton", "LeverButtonRepair")),
            "Native button prompt, press or repair path changed");
        Require(Read(interaction.GetMethod("Update", Any)).Any(i => IsCall(i, "InteractingObjectsController", "CheckHardwareButton")),
            "Native Update no longer owns button hover");

        var controls = mod.GetType("ZompiercerLAN.LanTrainControl", true);
        var fallback = Read(controls.GetMethod("TickNativeLook", Any));
        int hover = fallback.FindIndex(i => Equals(i.operand, buttonHover));
        int prompt = fallback.FindIndex(i => IsCall(i, "SimpleInfoDisplayer", "SetText"));
        Require(hover >= 0 && prompt > hover && fallback.Any(i => Equals(i.operand, leverHover)),
            "Cab fallback writes over native hover or no longer guards native lever hover");
        Require(fallback.Any(i => IsCall(i, "TrainInteractionRays", "InteractionRay")),
            "Cab fallback lost its filtered native interaction ray");

        var layout = mod.GetType("ZompiercerLAN.TrainLayout", true);
        var native = mod.GetType("ZompiercerLAN.TrainLayout+Native", true);
        var entry = mod.GetType("ZompiercerLAN.TrainLayout+Entry", true);
        Require((byte)layout.GetField("Version", Any).GetRawConstantValue() == 8 &&
            entry.GetField("Embedded", Any) != null &&
            Read(layout.GetMethod("MakeEntry", Any)).Any(i => IsCall(i, "TrainLayout", "EmbeddedWorkbenchNative")) &&
            Read(layout.GetMethod("Write", Any)).Any(i => i.operand is FieldInfo f && f.Name == "Embedded") &&
            Read(layout.GetMethod("Decode", Any)).Any(i => i.operand is FieldInfo f && f.Name == "Embedded") &&
            Read(layout.GetMethod("ValidatePrefab", Any)).Any(i => IsCall(i, "TrainLayout", "EmbeddedFurniture")) &&
            Read(entry.GetMethod("SameGeometry", Any)).Any(i => i.operand is FieldInfo f && f.Name == "Embedded"),
            "Layout v8 does not carry and validate the exact built-in bench marker");
        var builtIn = Activator.CreateInstance(entry, true);
        var placeable = Activator.CreateInstance(entry, true);
        Set(builtIn, "Embedded", true);
        Require(!(bool)entry.GetMethod("SameGeometry", Any).Invoke(builtIn, new[] { placeable }),
            "Placeable prefab zero can consume the embedded native bench");
        foreach (var field in new[] { "EmbeddedWorkbench", "OriginalParent", "OriginalLocalPosition", "OriginalLocalRotation" })
            Require(native.GetField(field, Any) != null, "Embedded bench pose backup missing: " + field);
        var snapshot = Read(layout.GetMethod("SnapshotNative", Any));
        var apply = Read(native.GetMethod("ApplyHostPose", Any));
        var restore = Read(native.GetMethod("RestorePose", Any));
        var commit = Read(layout.GetMethod("Commit", Any));
        Require(snapshot.Any(i => IsCall(i, "TrainLayout", "EmbeddedWorkbenchNative")) &&
            Read(layout.GetMethod("FindNative", Any)).Any(i => i.operand is FieldInfo f && f.Name == "EmbeddedWorkbench"),
            "Prefab-zero furniture is matched without the unique native bench identity");
        Require(apply.Any(i => IsCall(i, "Transform", "TransformPoint")) &&
            apply.Any(i => IsCall(i, "Transform", "set_position")) &&
            apply.Any(i => IsCall(i, "Transform", "set_rotation")),
            "Embedded bench does not receive the host car pose");
        Require(restore.Any(i => IsCall(i, "Transform", "set_localPosition")) &&
            restore.Any(i => IsCall(i, "Transform", "set_localRotation")) &&
            Read(native.GetMethod("SetVisible", Any)).Any(i => IsCall(i, "Native", "RestorePose")) &&
            Read(native.GetMethod("Restore", Any)).Any(i => IsCall(i, "Native", "RestorePose")),
            "Bench pose is not restored on hide and cleanup");
        Require(commit.FindIndex(i => IsCall(i, "Native", "ApplyHostPose")) <
            commit.FindIndex(i => IsCall(i, "Native", "SetVisible")),
            "Bench pose is applied after colliders become visible");

        var feedback = layout.GetMethod("ApplyBuildFeedback", Any);
        Require(feedback != null && feedback.ReturnType == typeof(bool) &&
            Read(feedback).Any(i => i.operand is FieldInfo f && f.Name == "Feedback") &&
            commit.Any(i => IsCall(i, "TrainLayout", "CarryBuildFeedback")) &&
            Read(layout.GetMethod("CarryBuildFeedback", Any)).Any(i => i.operand is FieldInfo f && f.Name == "AfterRevision"),
            "Accepted hit progress is not guarded against older in-flight layouts");
        CheckRevisionOverlay(mod, layout);
        var sync = mod.GetType("ZompiercerLAN.TrainSync", true);
        Require(sync.GetProperty("HostRevision", Any) != null &&
            Read(sync.GetMethod("TickClient", Any)).Any(i => IsCall(i, "TrainLayout", "Apply")),
            "Host or incoming layout revision is unavailable to build feedback");
        var invalidate = Read(sync.GetMethod("InvalidateLayout", Any));
        var hostTick = Read(sync.GetMethod("TickHost", Any));
        Require(invalidate.Any(i => i.opcode == OpCodes.Ldc_R4 && Math.Abs((float)i.operand - .15f) < .0001f) &&
            invalidate.Any(i => i.operand is FieldInfo f && f.Name == "_refreshDue") &&
            hostTick.Any(i => i.operand is FieldInfo f && f.Name == "_lastCapture") &&
            hostTick.Any(i => i.operand is FieldInfo f && f.Name == "_refreshDue"),
            "Structural layout refresh no longer waits for native completion or keeps a bounded deadline");
        Console.WriteLine("PASS: embedded bench host pose/restoration, native cab HUD ownership, bounded build feedback and delayed layout refresh match installed game IL");
    }

    private static void CheckRevisionOverlay(Assembly mod, Type layout)
    {
        var runtimeType = mod.GetType("ZompiercerLAN.TrainLayout+Runtime", true);
        var entryType = mod.GetType("ZompiercerLAN.TrainLayout+Entry", true);
        var feedbackType = mod.GetType("ZompiercerLAN.TrainLayout+BuildFeedback", true);
        var runtime = Activator.CreateInstance(runtimeType, true);
        var feedback = Activator.CreateInstance(feedbackType, true);
        Set(feedback, "Car", 0); Set(feedback, "Prefab", 0); Set(feedback, "Progress", 600);
        Set(feedback, "Blueprint", true); Set(feedback, "AfterRevision", 7);
        long key = ((long)1 << 32) | 42u;
        var held = (IDictionary)runtimeType.GetField("Feedback", Any).GetValue(runtime);
        held.Add(key, feedback);
        var entry = Activator.CreateInstance(entryType, true);
        Set(entry, "Car", (ushort)0); Set(entry, "Prefab", 0); Set(entry, "Progress", 300);
        Set(entry, "Blueprint", true);
        var entriesType = typeof(System.Collections.Generic.Dictionary<,>).MakeGenericType(typeof(long), entryType);
        var entries = (IDictionary)Activator.CreateInstance(entriesType);
        entries.Add(key, entry);
        var carry = layout.GetMethod("CarryBuildFeedback", Any);
        carry.Invoke(null, new object[] { runtime, entries, 7 });
        Require((int)entryType.GetField("Progress", Any).GetValue(entry) == 600 && held.Count == 1,
            "Older in-flight layout rolled back accepted build progress");
        Set(entry, "Progress", 100);
        carry.Invoke(null, new object[] { runtime, entries, 8 });
        Require((int)entryType.GetField("Progress", Any).GetValue(entry) == 100 && held.Count == 0,
            "Newer host layout cannot lower progress after dismantle");
    }

    private static void Set(object instance, string name, object value)
    {
        instance.GetType().GetField(name, Any).SetValue(instance, value);
    }

    private static System.Collections.Generic.List<CodeInstruction> Read(MethodBase method)
    {
        Require(method != null, "Expected game or mod method missing");
        return PatchProcessor.GetOriginalInstructions(method, (ILGenerator)null);
    }
    private static bool IsCall(CodeInstruction instruction, string type, string name)
    {
        return instruction.operand is MethodInfo method && method.DeclaringType.Name == type && method.Name == name;
    }
    private static void Require(bool value, string message)
    {
        if (!value) throw new InvalidOperationException(message);
    }
}
