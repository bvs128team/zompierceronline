using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

// 2.8.4: a guest's later session in the same run of the game. The rules themselves are in the security checks
// (IsolationRulesChecks); here the release DLL is read: Activate goes through them with the player's saves kept from the
// first session, and the pre-session backup is skipped while the saves are isolated.
internal static class GuestRejoinChecks
{
    private const BindingFlags All = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static | BindingFlags.Instance;
    internal static void Run(Assembly game, Assembly mod)
    {
        var isolation = mod.GetType("ZompiercerLAN.LanSaveIsolation", true);
        var activate = Read(isolation.GetMethod("Activate", All));
        int refusal = Calls(activate, "LanIsolationRules", "Refusal");
        Require(refusal >= 0, "Activate does not use the save-folder rules");
        Require(activate.Take(refusal).Any(i => (i.operand as FieldInfo)?.Name == "_originalPath") &&
            activate.Take(refusal).Any(i => (i.operand as FieldInfo)?.Name == "controlledChar"),
            "A later session must keep the player's own saves and refuse a loaded world");
        Require(!activate.Any(i => i.opcode == OpCodes.Ldstr && ((string)i.operand).Contains("until restart")),
            "The old restart-only latch is still there");
        var plugin = mod.GetType("ZompiercerLAN.LanPlugin", true);
        var join = Read(plugin.GetMethod("StartJoining", All));
        int backup = Calls(join, "LanInventoryGuard", "BackupSavesBeforeSession");
        Require(backup > 0 && join.Take(backup).Reverse().Take(4).Any(i => (i.operand as MethodBase)?.Name == "get_Active" &&
            (i.operand as MethodBase).DeclaringType.Name == "LanSaveIsolation"), "A later session backs up the previous session folder");
        var hosting = Read(plugin.GetMethod("StartHosting", All));
        Require(hosting.Take(6).Any(i => (i.operand as MethodBase)?.Name == "get_Active"), "Hosting after a guest session still needs a restart");
        Console.WriteLine("PASS: guest rejoin: Activate through the save-folder rules with the player's saves from the first session, no backup of a session folder, hosting still after a restart");
    }
    private static List<CodeInstruction> Read(MethodBase method)
    { Require(method != null, "Required isolation method missing"); return PatchProcessor.GetOriginalInstructions(method, (ILGenerator)null).ToList(); }
    private static int Calls(List<CodeInstruction> code, string type, string name)
    { return code.FindIndex(i => (i.operand as MethodBase)?.Name == name && (i.operand as MethodBase).DeclaringType.Name == type); }
    private static void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
}
