using System;
using System.Collections.Generic;
using UnityEngine;
using Random = UnityEngine.Random;

namespace ZompiercerLAN
{
    // 2.5.0, guest: a zombie copy's voice and steps. The copy has no scripts (ZombieSync.CreateVisual) and the game makes
    // every zombie sound in code, through ZombieEffects: Footsteps.Update (a foot coming down), the zombieRoar coroutine (a
    // roar every 60-120 s), TriggrRoar (once, when it notices a player), ZombieAttackRays (each attack) and
    // ZombieDamagDetector (pain, death). Guests heard no zombie at all. The same clips of the prefab's ZombieEffects play on
    // the copy here, from the host's frames: steps as a foot of the animated copy comes down, the roars on the same clock,
    // the noticing roar when its Chase turns on, an attack roar when an attack turns on, pain when its health drops, the
    // death roar when it dies before the guest's eyes.
    internal sealed class ZombieVoice
    {
        private static readonly int ChaseFlag = Animator.StringToHash("Chase");
        private static readonly int[] AttackFlags =
        {
            Animator.StringToHash("attackHunter1"), Animator.StringToHash("attackHunter2"),
            Animator.StringToHash("attackDoor1"), Animator.StringToHash("attackDoor2")
        };
        // The game: no steps for 2 s after it appears (Footsteps.noiseTime); a roar every 60-120 s (zombieRoar).
        private const float StepsAfter = 2f, PainEvery = .35f, AttackEvery = .8f, NoticeEvery = 15f;
        private const int RoarMin = 60, RoarMax = 120;
        private readonly AudioSource _audio;
        private readonly AudioClip[] _steps, _roars, _attacks, _pains, _deaths;
        private readonly AudioClip _notice;
        private readonly bool _silent;
        private readonly Transform _frame;
        private readonly Transform[] _feet;
        private readonly bool[] _grounded;
        private readonly float _threshold, _born;
        private float _roarAt, _noticeAt = -100f, _attackAt = -100f, _painAt = -100f, _health = -1f;

        private ZombieVoice(AudioSource audio, ZombieEffects fx, bool silent, Transform frame, Transform[] feet, float threshold)
        {
            _audio = audio; _silent = silent; _frame = frame; _feet = feet; _grounded = new bool[feet.Length]; _threshold = threshold;
            _steps = fx.zombieFootSteps; _roars = fx.zombieWalkRoar; _attacks = fx.zombieAttackRoar; _pains = fx.zombieHitPainRoar;
            _deaths = fx.zombieMediumDeathRoar; _notice = fx.zombieTriggerRoar;
            _born = Time.time; _roarAt = _born + Random.Range(RoarMin, RoarMax);
        }

        // The copy's sound source, set as the prefab's own (ZombieEffects takes the AudioSource beside it), and its feet.
        internal static ZombieVoice Create(ZombieAIController prefab, GameObject root, Dictionary<Transform, Transform> map)
        {
            var fx = prefab.zombieEffects != null ? prefab.zombieEffects : prefab.GetComponentInChildren<ZombieEffects>(true);
            if (fx == null) return null;
            Transform holder;
            if (!map.TryGetValue(fx.transform, out holder) || holder == null) holder = root.transform;
            var audio = holder.gameObject.AddComponent<AudioSource>();
            audio.playOnAwake = false; audio.loop = false; audio.spatialBlend = 1f;
            var source = fx.GetComponent<AudioSource>();
            if (source != null)
            {
                audio.outputAudioMixerGroup = source.outputAudioMixerGroup; audio.volume = source.volume; audio.spatialBlend = source.spatialBlend;
                audio.minDistance = source.minDistance; audio.maxDistance = source.maxDistance; audio.rolloffMode = source.rolloffMode;
                audio.dopplerLevel = source.dopplerLevel; audio.spread = source.spread; audio.priority = source.priority; audio.pitch = source.pitch;
                if (source.rolloffMode == AudioRolloffMode.Custom)
                    audio.SetCustomCurve(AudioSourceCurveType.CustomRolloff, source.GetCustomCurve(AudioSourceCurveType.CustomRolloff));
            }
            var steps = prefab.GetComponentInChildren<Footsteps>(true);
            Transform frame = null;
            var feet = new List<Transform>();
            if (steps != null && steps.Foots != null && map.TryGetValue(steps.transform, out frame))
                foreach (var foot in steps.Foots)
                {
                    Transform copy;
                    if (foot != null && foot.footTransform != null && map.TryGetValue(foot.footTransform, out copy)) feet.Add(copy);
                }
            return new ZombieVoice(audio, fx, prefab.zombieSilent, feet.Count == 0 ? null : frame, feet.ToArray(), steps == null ? 0f : steps.VerticalPosThreshold);
        }

        // Every frame of a living copy: its roar on the game's clock, and a step as a foot comes down below the
        // threshold in the frame of the prefab's Footsteps (as Footsteps.Update).
        internal void Tick()
        {
            if (_audio == null) return;
            float now = Time.time;
            if (now >= _roarAt) { _roarAt = now + Random.Range(RoarMin, RoarMax); if (!_silent) Play(_roars); }
            if (_frame == null || now - _born < StepsAfter) return;
            for (int i = 0; i < _feet.Length; i++)
            {
                var foot = _feet[i];
                if (foot == null) continue;
                float y = _frame.InverseTransformPoint(foot.position).y;
                if (_grounded[i]) { if (y > _threshold) _grounded[i] = false; }
                else if (y < _threshold) { _grounded[i] = true; Play(_steps); }
            }
        }

        // The animator's bool parameters the host sent (bit i: the controller's i-th bool) that have just turned on.
        internal void Flags(int[] hashes, uint before, uint after)
        {
            if (_audio == null || hashes == null) return;
            float now = Time.time;
            for (int i = 0; i < hashes.Length && i < 32; i++)
            {
                uint bit = 1u << i;
                if ((after & bit) == 0 || (before & bit) != 0) continue;
                if (hashes[i] == ChaseFlag)
                {
                    if (!_silent && now - _noticeAt >= NoticeEvery) { _noticeAt = now; PlayClip(_notice); }
                }
                else if (Array.IndexOf(AttackFlags, hashes[i]) >= 0 && now - _attackAt >= AttackEvery) { _attackAt = now; Play(_attacks); }
            }
        }

        // The host's health of the zombie in each frame: pain when it drops (not on regeneration).
        internal void Health(float health)
        {
            float now = Time.time;
            if (_health >= 0f && health > 0f && health < _health - .01f && now - _painAt >= PainEvery) { _painAt = now; Play(_pains); }
            _health = health;
        }

        // It died while the guest saw it alive: the death roar cuts whatever it was saying (ZombieMediumDeathRoarSound).
        internal void Die()
        {
            if (_audio == null) return;
            if (_audio.isPlaying) _audio.Stop();
            Play(_deaths);
        }

        private void Play(AudioClip[] clips)
        {
            if (clips == null || clips.Length == 0) return;
            PlayClip(clips[Random.Range(0, clips.Length)]);
        }
        private void PlayClip(AudioClip clip)
        {
            if (clip == null || _audio == null || !_audio.isActiveAndEnabled) return;
            var sounds = GlobalSoundEffects.global;
            _audio.PlayOneShot(clip, sounds == null ? 1f : Mathf.Clamp01(sounds.EffectsVolume));
        }
    }
}
