using System;

namespace ZompiercerLAN
{
    // One committed layout per secure/world session. The host stops resending it
    // after ACK; a replacement local train must be able to rebuild that revision.
    internal sealed class LanTrainRecovery
    {
        private byte[] _layout;
        private int _revision;
        private string _scene;

        internal void Remember(string scene, int revision, byte[] layout)
        {
            if (string.IsNullOrEmpty(scene) || revision <= 0 || layout == null ||
                layout.Length == 0 || layout.Length > LanProtocol.MaxLayoutBytes)
                throw new ArgumentException("Invalid committed train layout");
            _scene = scene; _revision = revision; _layout = (byte[])layout.Clone();
        }

        internal byte[] Recover(string scene, int revision)
        {
            return _layout != null && scene == _scene && revision == _revision ? (byte[])_layout.Clone() : null;
        }

        internal void Clear() { _layout = null; _scene = null; _revision = 0; }
    }
}
