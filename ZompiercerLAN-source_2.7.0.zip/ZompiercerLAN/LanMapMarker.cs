using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;

namespace ZompiercerLAN
{
    // The partner on the tablet's map (1.2.2): a copy of the game's own player marker, tinted, placed
    // with the tablet's own world-to-map mapping, shown when the game shows the player there
    // (DifficultyManager.ShowPlayerOnMap) and the partner is in this world. Main thread only.
    internal static class LanMapMarker
    {
        private static readonly Color Tint = new Color(1f, .55f, .1f, 1f);
        private static Harmony _harmony;
        private static Action<string> _log;
        private static bool _logged;
        private static MethodInfo _posOnMap;
        private static RectTransform _source;
        // 2.0.0: one marker per other player.
        private static readonly List<RectTransform> _markers = new List<RectTransform>();
        internal static string Failure { get; private set; }
        // Set by the plugin every frame: where the partner stands in this world (null: not here).
        internal static Func<IList<Vector3>> Partners;

        internal static void Initialize(Action<string> log)
        {
            _log = log;
            if (_harmony != null || Failure != null) return;
            _harmony = new Harmony("local.zompiercer.lan.map");
            try
            {
                _posOnMap = AccessTools.Method(typeof(Zompiercer.GUI.TabletPC), "GetPosOnMap");
                if (_posOnMap == null) throw new MissingMethodException("TabletPC.GetPosOnMap");
                _harmony.Patch(AccessTools.Method(typeof(Zompiercer.GUI.TabletPC), "Update"), postfix: new HarmonyMethod(typeof(LanMapMarker), nameof(UpdatePostfix)));
                _harmony.Patch(AccessTools.Method(typeof(Zompiercer.GUI.TabletPC), "LateUpdate"), postfix: new HarmonyMethod(typeof(LanMapMarker), nameof(LateUpdatePostfix)));
            }
            catch (Exception ex)
            {
                Failure = ex.GetType().Name + ": " + ex.Message;
                _harmony.UnpatchSelf();
                log("Map marker hook unavailable: " + Failure);
            }
        }
        internal static void Shutdown()
        {
            _harmony?.UnpatchSelf(); _harmony = null; Partners = null;
            foreach (var marker in _markers) if (marker != null) UnityEngine.Object.Destroy(marker.gameObject);
            _markers.Clear(); _source = null;
        }

        private static void UpdatePostfix(Zompiercer.GUI.TabletPC __instance)
        {
            try
            {
                var source = __instance.MapMarkerPlayer;
                if (source == null) return;
                var all = Partners == null ? null : Partners();
                bool show = all != null && DifficultyManager.Global != null && DifficultyManager.Global.ShowPlayerOnMap;
                int count = show ? all.Count : 0;
                if (_source != source)
                {
                    foreach (var marker in _markers) if (marker != null) UnityEngine.Object.Destroy(marker.gameObject);
                    _markers.Clear(); _source = source;
                }
                while (_markers.Count < count)
                {
                    var copy = UnityEngine.Object.Instantiate(source.gameObject, source.parent, false);
                    copy.name = "LAN partner marker";
                    foreach (var graphic in copy.GetComponentsInChildren<Graphic>(true)) graphic.color = Tint;
                    _markers.Add(copy.GetComponent<RectTransform>());
                }
                for (int i = 0; i < _markers.Count; i++)
                {
                    if (_markers[i] == null) continue;
                    bool on = i < count;
                    if (on) _markers[i].localPosition = (Vector3)_posOnMap.Invoke(__instance, new object[] { all[i] });
                    _markers[i].gameObject.SetActive(on);
                }
            }
            catch (Exception ex)
            {
                if (!_logged) { _logged = true; _log?.Invoke("Partner map marker failed: " + ex.GetType().Name + ": " + ex.Message); }
            }
        }
        private static void LateUpdatePostfix()
        {
            if (_source != null) foreach (var marker in _markers) if (marker != null) marker.localScale = _source.localScale;
        }
    }
}
