using System;
using System.Collections;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
using Zompiercer.Train;
using Object = UnityEngine.Object;

namespace ZompiercerLAN
{
    // Location progress together (1.4.4). Walls and gates blown up with C4 (DestroyableByBomb), trap
    // walls, collapsing floors, bridges (ObjectActivator), drained swamps (WaterDrainer), the world's own
    // levers and buttons, and resources picked clean live in the host's world: only the host's explosions
    // break a wall, and the guest's copy of the location kept its own state. The host sends how they
    // stand, by the game's own ObjectID (SceneFrame), changed ones first and the rest in turn, and the
    // guest's copy takes it as the game loads a save. The guest's lever or button in the host's world,
    // and a trap or bridge it sets off, is a request the host does as its own (SceneUse). Train doors,
    // scene doors, quests and fuel stations have their own sync. 1.4.5: what the host took apart for
    // resources (ResourceContent: boxes, wrecks, fallen trees; the game destroys them and saves nothing,
    // so they are known by their place) goes away for the guest too, and a presence trigger
    // (CharPresenceTrigger: trap walls, the train's emergency brake) the guest walks into goes off on the
    // host as well. Main thread only.
    internal sealed partial class LanSceneStates
    {
        private const float IndexEvery = 10f, ScanEvery = 2f, SendEvery = .25f, ResourceRadius = 150f, UseEvery = .3f, LootRadius = 40f;
        private const float ButtonReach = 4.5f, TrapReach = 25f, CollapseReach = 20f, ActivatorReach = 8f, TriggerReach = 30f;
        private const int PerBatch = 16;
        private static Harmony _harmony;
        private static Action<string> _staticLog;
        private static bool _logged;
        internal static string Failure { get; private set; }
        private static IList _allObjectIds;
        private static AccessTools.FieldRef<DestroyableByBomb, bool> _bombDone;
        private static AccessTools.FieldRef<TrapWall, bool> _trapDone;
        private static AccessTools.FieldRef<StructuralDestructionAndRepair, bool> _collapseDone, _collapsible;
        private static AccessTools.FieldRef<ObjectActivator, bool> _raised;
        private static AccessTools.FieldRef<WaterDrainer, bool> _draining;
        private static AccessTools.FieldRef<WaterDrainer, float> _drained;
        private static AccessTools.FieldRef<CharPresenceTrigger, bool> _entered;
        private static AccessTools.FieldRef<CharPresenceTrigger, UnityEngine.Events.UnityEvent> _onEnter;
        // Host (1.4.5): what was taken apart in this scene, by place key, and where.
        private static readonly Dictionary<int, Vector3> Parsed = new Dictionary<int, Vector3>();
        private static string _parsedScene;
        // Guest: the copy the hooks report to, and whether the host's state is being applied.
        private static LanSceneStates _guestCurrent;
        private static bool _applying;
        private static int _pressFrame = -1;
        private static bool _hoverFailed;
        // Host scene lids are held open while any accepted guest view uses them. The native
        // inventory window handles the host's own view. Each link removes only its own slot.
        private static readonly Dictionary<Zompiercer.Inventory.Inventory, HashSet<int>> LidViewers = new Dictionary<Zompiercer.Inventory.Inventory, HashSet<int>>();
        private static string _lidScene;
        private static uint _lidEpoch;
        private sealed class FireworkPulse { internal Vector3 At; internal float Elapsed; internal OpenDetectorFireworkSystem Source; }
        private static readonly Dictionary<int, FireworkPulse> Fireworks = new Dictionary<int, FireworkPulse>();

        private sealed class Entry { internal int Id; internal byte Kind; internal Component Target; internal Vector3 At; }
        private readonly bool _host;
        private readonly Action<Packet> _send;
        private readonly Action<string> _log;
        private readonly Dictionary<int, Entry> _byId = new Dictionary<int, Entry>();
        private readonly Dictionary<Component, Entry> _byTarget = new Dictionary<Component, Entry>();
        private readonly List<Entry> _objects = new List<Entry>(), _resources = new List<Entry>(), _relevant = new List<Entry>();
        // 2.5.0: the host's loot cabinets of the location (SceneLoot), and on the guest what the host said of them, by place key.
        private readonly List<Entry> _loot = new List<Entry>();
        private readonly Dictionary<int, byte> _lootFlags = new Dictionary<int, byte>();
        private readonly List<Entry> _lids = new List<Entry>();
        private readonly Dictionary<int, Zompiercer.Inventory.Inventory> _lidsByPlace = new Dictionary<int, Zompiercer.Inventory.Inventory>();
        private readonly Dictionary<int, OpenDetectorFireworkSystem> _detectors = new Dictionary<int, OpenDetectorFireworkSystem>();
        private readonly HashSet<int> _fireworksSeen = new HashSet<int>();
        private readonly Dictionary<int, float> _fireworksPlaying = new Dictionary<int, float>();
        // What each guest last got, by kind and id (2.4.4: a taken-apart object and its wear share a place key).
        private readonly Dictionary<long, int> _sent = new Dictionary<long, int>();
        private static long SentKey(byte kind, int id) { return (long)kind << 32 | (uint)id; }
        private readonly Dictionary<int, float> _usedAt = new Dictionary<int, float>();
        // Guest (1.4.5): its copies of what can be taken apart, by place key (2.4.4: where they stood when the location loaded).
        private readonly Dictionary<int, ResourceContent> _parts = new Dictionary<int, ResourceContent>();
        private string _scene;
        private uint _epoch, _sequence, _received;
        private bool _ready;
        private float _indexAt = -100f, _scanAt, _sendAt;
        private int _cursor;

        internal LanSceneStates(bool host, Action<Packet> send, Action<string> log) { _host = host; _send = send; _log = log; }

        internal static void Initialize(Action<string> log)
        {
            _staticLog = log;
            if (_harmony != null || Failure != null) return;
            _harmony = new Harmony("local.zompiercer.lan.scene-states");
            try
            {
                var field = AccessTools.Field(typeof(Zompiercer.SaveLoad.SaveLoadCore), "AllObjectID");
                _allObjectIds = field == null ? null : field.GetValue(null) as IList;
                if (_allObjectIds == null) throw new MissingFieldException("SaveLoadCore.AllObjectID");
                InitializeSharedWorld();
                _bombDone = AccessTools.FieldRefAccess<DestroyableByBomb, bool>("Destroyed");
                _trapDone = AccessTools.FieldRefAccess<TrapWall, bool>("Activated");
                _collapseDone = AccessTools.FieldRefAccess<StructuralDestructionAndRepair, bool>("trapActivated");
                _collapsible = AccessTools.FieldRefAccess<StructuralDestructionAndRepair, bool>("destructible");
                _raised = AccessTools.FieldRefAccess<ObjectActivator, bool>("Activated");
                _draining = AccessTools.FieldRefAccess<WaterDrainer, bool>("Drain");
                _drained = AccessTools.FieldRefAccess<WaterDrainer, float>("CurrentDuration");
                _entered = AccessTools.FieldRefAccess<CharPresenceTrigger, bool>("ActivationLimiter");
                _onEnter = AccessTools.FieldRefAccess<CharPresenceTrigger, UnityEngine.Events.UnityEvent>("OnEnter");
                _harmony.Patch(AccessTools.Method(typeof(TrapWall), "Activate"), prefix: new HarmonyMethod(typeof(LanSceneStates), nameof(TrapPrefix)));
                _harmony.Patch(AccessTools.Method(typeof(StructuralDestructionAndRepair), "Set"), prefix: new HarmonyMethod(typeof(LanSceneStates), nameof(CollapsePrefix)));
                _harmony.Patch(AccessTools.Method(typeof(ObjectActivator), "Interact"), prefix: new HarmonyMethod(typeof(LanSceneStates), nameof(RaisePrefix)));
                _harmony.Patch(AccessTools.Method(typeof(CharPresenceTrigger), "OnTriggerEnter"), prefix: new HarmonyMethod(typeof(LanSceneStates), nameof(PresencePrefix)));
                _harmony.Patch(AccessTools.Method(typeof(ResourceContent), "ObjectParsed"), prefix: new HarmonyMethod(typeof(LanSceneStates), nameof(ParsedPrefix)));
                _harmony.Patch(AccessTools.Method(typeof(Door), "SetOpen"), prefix: new HarmonyMethod(typeof(LanSceneStates), nameof(LidClosePrefix)));
                _harmony.Patch(AccessTools.Method(typeof(OpenDetectorFireworkSystem), "Update"), prefix: new HarmonyMethod(typeof(LanSceneStates), nameof(FireworkUpdatePrefix)),
                    postfix: new HarmonyMethod(typeof(LanSceneStates), nameof(FireworkUpdatePostfix)));
            }
            catch (Exception ex)
            {
                // Without these the guest's copy of a location keeps its own walls and levers, as before 1.4.4.
                Failure = ex.GetType().Name + ": " + ex.Message;
                _harmony.UnpatchSelf(); ShutdownSharedWorld();
                log("Location object hooks unavailable: " + Failure);
                return;
            }
            // 2.5.0: optional: without it the guest's hover only lacks EMPTY / NOT EMPTY on loot cabinets.
            try { _harmony.Patch(AccessTools.Method(typeof(InteractingObjectsController), "Update"), postfix: new HarmonyMethod(typeof(LanSceneStates), nameof(HoverPostfix))); }
            catch (Exception ex) { log("Loot cabinet hover hook unavailable: " + ex.GetType().Name + ": " + ex.Message); }
        }
        internal static void Shutdown() { _guestCurrent?.ClearSharedGuest(); ShutdownSharedWorld(); _harmony?.UnpatchSelf(); _harmony = null; _guestCurrent = null; LidViewers.Clear(); Fireworks.Clear(); _lidScene = null; _lidEpoch = 0; }
        internal void Clear() { ClearSharedGuest(); if (_guestCurrent == this) _guestCurrent = null; }

        private static void Once(string text) { if (_logged) return; _logged = true; _staticLog?.Invoke(text); }

        private static InteractingObjects LidObject(Zompiercer.Inventory.Inventory inventory)
        {
            if (inventory == null || !inventory.IsLootInventory || inventory.IsBackpack) return null;
            var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrain;
            if (Foreign(inventory, train)) return null;
            var io = inventory.GetComponent<InteractingObjects>();
            if (io == null) io = inventory.interactingObjects;
            return io != null && io.doors != null && io.doors.Length > 0 ? io : null;
        }

        // Called only by LanStorageHost after a real, checked StorageOpen or when that
        // view closes. Resolve also serves recipe validation and must have no lid effects.
        internal static void HostGuestViewChanged(int slot, Zompiercer.Inventory.Inventory previous, Zompiercer.Inventory.Inventory current)
        {
            if (LanSaveIsolation.Active || ReferenceEquals(previous, current)) return;
            if (previous != null)
            {
                HashSet<int> viewers;
                if (LidViewers.TryGetValue(previous, out viewers))
                {
                    viewers.Remove(slot);
                    if (viewers.Count == 0)
                    {
                        LidViewers.Remove(previous);
                        // The host's native window owns the lid while it is still open.
                        if (previous.connectedInventoryWindow == null) SetLid(previous, false);
                    }
                }
            }
            if (LidObject(current) == null) return;
            HashSet<int> watching;
            if (!LidViewers.TryGetValue(current, out watching)) LidViewers.Add(current, watching = new HashSet<int>());
            if (watching.Add(slot)) SetLid(current, true);
        }

        private static void SetLid(Zompiercer.Inventory.Inventory inventory, bool open)
        {
            var io = LidObject(inventory);
            if (io == null) return;
            foreach (var door in io.doors)
                if (door != null && door.Open != open) door.SetOpen(open);
        }

        // InventoryWindow.Close and the host's own E can request close while a guest is
        // still looking in the same chest. Preserve the shared physical lid until all
        // accepted viewers leave it.
        private static bool LidClosePrefix(Door __instance, bool NewState)
        {
            if (NewState || LanSaveIsolation.Active || __instance == null) return true;
            foreach (var pair in LidViewers)
            {
                if (pair.Key == null || pair.Value.Count == 0) continue;
                var io = LidObject(pair.Key);
                if (io == null) continue;
                foreach (var door in io.doors) if (door == __instance) return false;
            }
            return true;
        }

        // The native detector's Update does the one permitted host-side activation. On
        // guests it is suppressed before the lid can open, so no copied ZombieSpawn or
        // ZombieAIController is ever invoked. The host remembers the pulse after the
        // native object destroys itself at ten seconds.
        private static bool FireworkUpdatePrefix(OpenDetectorFireworkSystem __instance)
        {
            return !LanSaveIsolation.Active;
        }
        private static void FireworkUpdatePostfix(OpenDetectorFireworkSystem __instance)
        {
            if (LanSaveIsolation.Active || __instance == null || !__instance.trapTouched || __instance.door == null) return;
            int key = PlaceKey(__instance.door);
            FireworkPulse pulse;
            if (!Fireworks.TryGetValue(key, out pulse)) Fireworks[key] = pulse = new FireworkPulse { At = __instance.door.transform.position };
            pulse.Source = __instance;
            pulse.Elapsed = Mathf.Max(0f, __instance.fireworksTimer);
        }

        // ---- The scene's location objects, by the game's ObjectID ----

        private void Rebuild(float now)
        {
            _indexAt = now + IndexEvery;
            _byId.Clear(); _byTarget.Clear(); _objects.Clear(); _resources.Clear(); _lids.Clear(); _lidsByPlace.Clear(); _detectors.Clear();
            var twice = new HashSet<int>();
            var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrain;
            foreach (var item in _allObjectIds)
            {
                var oid = item as ObjectID;
                if (oid == null || oid.ID == 0) continue;
                byte kind; Component target;
                if (!KindOf(oid.gameObject, out kind, out target) || Foreign(target, train)) continue;
                if (_byId.ContainsKey(oid.ID)) { twice.Add(oid.ID); continue; }
                var entry = new Entry { Id = oid.ID, Kind = kind, Target = target };
                _byId.Add(oid.ID, entry);
            }
            foreach (int id in twice) _byId.Remove(id); // an id two objects share names neither
            foreach (var entry in _byId.Values)
            {
                _byTarget[entry.Target] = entry;
                (entry.Kind == LanProtocol.SceneResource ? _resources : _objects).Add(entry);
            }
            // Standalone Door on each loot inventory, including the military trunk.
            // Resolve duplicate place keys to neither chest, as with SceneLoot.
            var lidPlaces = new Dictionary<int, int>();
            foreach (var io in Object.FindObjectsOfType<InteractingObjects>())
            {
                var inventory = io == null ? null : io.GetComponent<Zompiercer.Inventory.Inventory>();
                if (LidObject(inventory) == null || Foreign(inventory, train)) continue;
                int key = PlaceKey(inventory), index;
                if (lidPlaces.TryGetValue(key, out index)) { if (index >= 0) _lids[index] = null; lidPlaces[key] = -1; continue; }
                lidPlaces[key] = _lids.Count;
                _lids.Add(new Entry { Id = key, Kind = LanProtocol.SceneLid, Target = inventory, At = inventory.transform.position });
            }
            _lids.RemoveAll(e => e == null);
            if (!_host)
            {
                foreach (var lid in _lids) _lidsByPlace[lid.Id] = (Zompiercer.Inventory.Inventory)lid.Target;
                foreach (var detector in Object.FindObjectsOfType<OpenDetectorFireworkSystem>(true))
                {
                    if (detector == null || detector.door == null || Foreign(detector, train)) continue;
                    detector.enabled = false;
                    int key = PlaceKey(detector.door);
                    if (!_detectors.ContainsKey(key)) _detectors.Add(key, detector);
                    else _detectors[key] = null; // ambiguous scene reference: show neither
                }
            }
            if (_host)
            {
                // 2.5.0: the location's loot cabinets (two at one place: neither).
                _loot.Clear();
                var keys = new Dictionary<int, int>();
                foreach (var io in Object.FindObjectsOfType<InteractingObjects>())
                {
                    var inventory = LootOf(io);
                    if (inventory == null || Foreign(inventory, train)) continue;
                    int key = PlaceKey(inventory), at;
                    if (keys.TryGetValue(key, out at)) { if (at >= 0) _loot[at] = null; keys[key] = -1; continue; }
                    keys[key] = _loot.Count;
                    _loot.Add(new Entry { Id = key, Kind = LanProtocol.SceneLoot, Target = inventory });
                }
                _loot.RemoveAll(e => e == null);
                return;
            }
            _parts.Clear();
            var places = new HashSet<int>();
            foreach (var part in Object.FindObjectsOfType<ResourceContent>(true))
            {
                if (part == null || Foreign(part, train)) continue;
                int key = LoadKey(part);
                if (!places.Add(key)) _parts.Remove(key); // two at one place: neither
                else _parts[key] = part;
            }
        }
        // FNV-1a of the object's name and place (5 cm): the same on both sides for a scene object.
        internal static int PlaceKey(Component c) { return PlaceKey(c.gameObject.name, c.transform.position); }
        // 2.4.4: an object to take apart by where it stood when its location loaded (LanWorldWork), the same on every side
        // after it was knocked about. 1.4.5-2.4.3 keyed it by where it stood then: a chair the host took apart after it
        // moved on one side stayed on the other.
        internal static int LoadKey(ResourceContent part) { return PlaceKey(part.gameObject.name, LanWorldWork.LoadPlace(part)); }
        private static int PlaceKey(string name, Vector3 p)
        {
            int clone = name.IndexOf("(Clone)", StringComparison.Ordinal);
            if (clone >= 0) name = name.Substring(0, clone);
            uint hash = 2166136261;
            foreach (char ch in name.Trim() + "|" + Mathf.RoundToInt(p.x * 20f) + "|" + Mathf.RoundToInt(p.y * 20f) + "|" + Mathf.RoundToInt(p.z * 20f))
            { hash ^= ch; hash *= 16777619; }
            int key = unchecked((int)hash);
            return key == 0 ? 1 : key;
        }
        private static bool KindOf(GameObject go, out byte kind, out Component target)
        {
            kind = 0;
            if ((target = go.GetComponent<DestroyableByBomb>()) != null) kind = LanProtocol.SceneBomb;
            else if ((target = go.GetComponent<TrapWall>()) != null) kind = LanProtocol.SceneTrap;
            else if ((target = go.GetComponent<StructuralDestructionAndRepair>()) != null) kind = LanProtocol.SceneCollapse;
            else if ((target = go.GetComponent<ObjectActivator>()) != null) kind = LanProtocol.SceneActivator;
            else if ((target = go.GetComponent<WaterDrainer>()) != null) kind = LanProtocol.SceneDrainer;
            else if ((target = go.GetComponent<CollectedResource>()) != null) kind = LanProtocol.SceneResource;
            else if ((target = go.GetComponent<CharPresenceTrigger>()) != null) kind = LanProtocol.SceneTrigger;
            else
            {
                var button = go.GetComponent<HardwareButton>();
                if (button != null && !LanFuelStation.IsStationButton(button)) { target = button; kind = LanProtocol.SceneButton; }
            }
            return kind != 0;
        }
        // The train, its builds and copies, players and robot dogs are not the location's.
        private static bool Foreign(Component c, FluffyUnderware.Curvy.Examples.TrainManager train)
        {
            return c.GetComponentInParent<TrainCar>() != null || c.GetComponentInParent<LanTrainReplica>() != null || c.GetComponentInParent<TrainPart>() != null ||
                c.GetComponentInParent<Furniture>() != null || c.GetComponentInParent<ZombieFighterController>() != null || c.GetComponentInParent<RobotDogAiController>() != null ||
                train != null && c.transform.IsChildOf(train.transform);
        }
        private Entry Find(int id, byte kind)
        {
            Entry entry;
            if ((!_byId.TryGetValue(id, out entry) || entry.Target == null) && Time.unscaledTime - (_indexAt - IndexEvery) > 3f) { Rebuild(Time.unscaledTime); _byId.TryGetValue(id, out entry); }
            return entry != null && entry.Target != null && entry.Kind == kind ? entry : null;
        }

        // Flags 1 when done; a swamp's drained time in `value`.
        private static byte State(Entry e, out float value)
        {
            value = 0f;
            switch (e.Kind)
            {
                case LanProtocol.SceneBomb: return (byte)(_bombDone((DestroyableByBomb)e.Target) ? 1 : 0);
                case LanProtocol.SceneTrap: return (byte)(_trapDone((TrapWall)e.Target) ? 1 : 0);
                case LanProtocol.SceneCollapse: return (byte)(_collapseDone((StructuralDestructionAndRepair)e.Target) ? 1 : 0);
                case LanProtocol.SceneActivator: return (byte)(_raised((ObjectActivator)e.Target) ? 1 : 0);
                case LanProtocol.SceneDrainer:
                    var drainer = (WaterDrainer)e.Target;
                    value = Mathf.Clamp(_drained(drainer), 0f, 99999f);
                    return (byte)(_draining(drainer) ? 1 : 0);
                case LanProtocol.SceneButton: return (byte)(((HardwareButton)e.Target).State ? 1 : 0);
                case LanProtocol.SceneTrigger: return (byte)(_entered((CharPresenceTrigger)e.Target) ? 1 : 0);
                case LanProtocol.SceneParsed: return 1;
                case LanProtocol.SceneLoot:
                {
                    var inventory = (Zompiercer.Inventory.Inventory)e.Target;
                    return (byte)((inventory.wasChecked ? 1 : 0) | (inventory.content.Count == 0 ? 2 : 0));
                }
                case LanProtocol.SceneLid:
                {
                    var io = LidObject((Zompiercer.Inventory.Inventory)e.Target);
                    if (io == null) return 0;
                    foreach (var door in io.doors) if (door != null && door.Open) return 1;
                    return 0;
                }
                case LanProtocol.SceneFireworks:
                {
                    FireworkPulse pulse;
                    return (byte)(Fireworks.TryGetValue(e.Id, out pulse) && pulse.Source != null && pulse.Elapsed < 10f ? 1 : 0);
                }
                case LanProtocol.SceneWear:
                {
                    // 2.4.4: hit points left (a fallen tree) or durability left (a chair, a wreck).
                    var part = (ResourceContent)e.Target;
                    var points = LanWorldWork.HitPointsOf(part);
                    value = Mathf.Clamp(points != null ? points.CurrentHP : part.durability, 0f, 99999f);
                    return (byte)(points != null ? 1 : 0);
                }
                default:
                    // Picked clean: the game hides a resource once nothing is left (another reason to be
                    // switched off is not the guest's business).
                    return (byte)(((CollectedResource)e.Target).resourceQuantity <= 0 ? 1 : 0);
            }
        }
        // What the guest last got: the flags and the drained time to the second.
        private static int Stamp(byte flags, float value) { return flags | Mathf.RoundToInt(value) << 1; }

        // ---- Host ----

        internal void Tick(string scene, uint epoch, bool ready, Vector3? guest)
        {
            if (scene != _scene || epoch != _epoch)
            {
                _scene = scene; _epoch = epoch; _sequence = 0; _received = 0; _cursor = 0;
                _byId.Clear(); _byTarget.Clear(); _objects.Clear(); _resources.Clear(); _relevant.Clear(); _sent.Clear(); _usedAt.Clear(); _parts.Clear();
                _loot.Clear(); _lootFlags.Clear(); _lids.Clear(); _lidsByPlace.Clear(); _detectors.Clear(); _fireworksSeen.Clear(); _fireworksPlaying.Clear();
                _indexAt = -100f; _scanAt = 0f; ClearSharedGuest();
            }
            if (_host && (scene != _lidScene || epoch != _lidEpoch))
            {
                _lidScene = scene; _lidEpoch = epoch;
                LidViewers.Clear(); Fireworks.Clear();
            }
            _ready = ready && epoch != 0 && !string.IsNullOrEmpty(scene) && Failure == null;
            if (!_host && _ready) _guestCurrent = this;
            else if (_guestCurrent == this) _guestCurrent = null;
            if (!_ready) return;
            float now = Time.unscaledTime;
            if (now >= _indexAt) Rebuild(now);
            if (!_host) UpdateFireworkVisuals(now);
            if (!_host || guest == null) return;
            try
            {
                SendSharedWorld(now);
                if (now >= _scanAt)
                {
                    // Every object of the location, and the resources picked clean near the guest.
                    _scanAt = now + ScanEvery;
                    _relevant.Clear();
                    foreach (var e in _objects) if (e.Target != null) _relevant.Add(e);
                    float far = ResourceRadius * ResourceRadius;
                    foreach (var e in _resources)
                    {
                        float ignored;
                        if (e.Target != null && State(e, out ignored) == 1 && (e.Target.transform.position - guest.Value).sqrMagnitude <= far) _relevant.Add(e);
                    }
                    if (_parsedScene == _scene)
                        foreach (var pair in Parsed)
                            if ((pair.Value - guest.Value).sqrMagnitude <= far) _relevant.Add(new Entry { Id = pair.Key, Kind = LanProtocol.SceneParsed, At = pair.Value });
                    // 2.5.0: the loot cabinets near the guest: searched or not, empty or not.
                    float near = LootRadius * LootRadius;
                    foreach (var e in _loot) if (e.Target != null && (e.Target.transform.position - guest.Value).sqrMagnitude <= near) _relevant.Add(e);
                    foreach (var e in _lids) if (e.Target != null && (e.At - guest.Value).sqrMagnitude <= near) _relevant.Add(e);
                    foreach (var pair in Fireworks)
                        if ((pair.Value.At - guest.Value).sqrMagnitude <= near)
                            _relevant.Add(new Entry { Id = pair.Key, Kind = LanProtocol.SceneFireworks, At = pair.Value.At });
                    // 2.4.4: objects being taken apart or chopped near the guest, so its copy shows the progress (the game's
                    // hover: a chair's durability bar, a tree's hit points); carryable ones (barrels) go with their own copy.
                    var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrain;
                    foreach (var part in Object.FindObjectsOfType<ResourceContent>(true))
                    {
                        if (part == null || Foreign(part, train) || part.GetComponentInParent<TakableItem>() != null) continue;
                        var points = LanWorldWork.HitPointsOf(part);
                        bool worn = points != null ? points.CurrentHP < points.MaxHP : part.durability < part.durabilityMax;
                        if (worn && (part.transform.position - guest.Value).sqrMagnitude <= far)
                            _relevant.Add(new Entry { Id = LoadKey(part), Kind = LanProtocol.SceneWear, Target = part, At = part.transform.position });
                    }
                }
                if (now < _sendAt || _relevant.Count == 0) return;
                _sendAt = now + SendEvery;
                var batch = new List<SceneFrame>();
                var included = new HashSet<int>();
                foreach (var e in _relevant)
                {
                    if (batch.Count >= LanProtocol.MaxSceneBatch) break;
                    if (e.Target == null && e.Kind != LanProtocol.SceneParsed && e.Kind != LanProtocol.SceneFireworks) continue;
                    float value; byte flags = State(e, out value);
                    int last;
                    if (_sent.TryGetValue(SentKey(e.Kind, e.Id), out last) && last == Stamp(flags, value)) continue;
                    batch.Add(new SceneFrame { Id = e.Id, Kind = e.Kind, Flags = flags, Value = value }); included.Add(e.Id);
                }
                for (int visited = 0; visited < _relevant.Count && batch.Count < PerBatch; visited++)
                {
                    if (_cursor >= _relevant.Count) _cursor = 0;
                    var e = _relevant[_cursor++];
                    if (e.Target == null && e.Kind != LanProtocol.SceneParsed && e.Kind != LanProtocol.SceneFireworks || included.Contains(e.Id)) continue;
                    float value; byte flags = State(e, out value);
                    batch.Add(new SceneFrame { Id = e.Id, Kind = e.Kind, Flags = flags, Value = value }); included.Add(e.Id);
                }
                if (batch.Count == 0) return;
                foreach (var frame in batch) _sent[SentKey(frame.Kind, frame.Id)] = Stamp(frame.Flags, frame.Value);
                _send(new Packet { Kind = PacketKind.SceneStates, WorldEpoch = _epoch, Scene = _scene, Sequence = ++_sequence, SceneObjects = batch.ToArray() });
            }
            catch (Exception ex) { Once("Location objects not sent: " + ex.GetType().Name + ": " + ex.Message); }
        }

        internal void Receive(Packet p, Vector3? guest)
        {
            if (!_ready || p.WorldEpoch != _epoch || p.Scene != _scene) return;
            try
            {
                if (_host) { if (p.Kind == PacketKind.SceneUse && guest != null) HostUse(p.Revision, p.Action, guest.Value); return; }
                if (p.Kind != PacketKind.SceneStates || (_received != 0 && unchecked((int)(p.Sequence - _received)) <= 0)) return;
                _received = p.Sequence;
                foreach (var frame in p.SceneObjects)
                {
                    if (ApplySharedWorld(frame)) continue;
                    if (frame.Kind == LanProtocol.SceneParsed) { TakeApart(frame.Id); continue; }
                    if (frame.Kind == LanProtocol.SceneWear) { Wear(frame); continue; }
                    if (frame.Kind == LanProtocol.SceneLoot) { if (_lootFlags.Count < 4096 || _lootFlags.ContainsKey(frame.Id)) _lootFlags[frame.Id] = frame.Flags; continue; }
                    if (frame.Kind == LanProtocol.SceneLid) { ApplyLid(frame); continue; }
                    if (frame.Kind == LanProtocol.SceneFireworks) { ApplyFireworks(frame); continue; }
                    var e = Find(frame.Id, frame.Kind);
                    if (e != null) Apply(e, frame);
                }
            }
            catch (Exception ex) { Once("Location objects not applied: " + ex.GetType().Name + ": " + ex.Message); }
        }

        // A lever, trap or bridge the guest used, done as the host's own player would.
        private void HostUse(int id, byte kind, Vector3 guest)
        {
            if (!LanProtocol.ValidSceneUse(id, kind)) return;
            if (kind == LanProtocol.SceneSeasonal || kind == LanProtocol.SceneEvent) { HostSharedUse(id, kind, guest); return; }
            var e = Find(id, kind);
            if (e == null) { _log?.Invoke("The guest's location object " + id + " is not in this world"); return; }
            float reach = kind == LanProtocol.SceneButton ? ButtonReach : kind == LanProtocol.SceneTrap ? TrapReach : kind == LanProtocol.SceneCollapse ? CollapseReach :
                kind == LanProtocol.SceneTrigger ? TriggerReach : ActivatorReach;
            if ((e.Target.transform.position - guest).sqrMagnitude > reach * reach) { _log?.Invoke("The guest's location object " + id + " is too far from the guest"); return; }
            switch (kind)
            {
                case LanProtocol.SceneButton:
                    var button = (HardwareButton)e.Target;
                    if (button.defective) return;
                    button.Switch();
                    break;
                case LanProtocol.SceneTrap:
                    ((TrapWall)e.Target).Activate();
                    break;
                case LanProtocol.SceneCollapse:
                    var floor = (StructuralDestructionAndRepair)e.Target;
                    if (!_collapsible(floor) || _collapseDone(floor)) return;
                    floor.Set(true);
                    break;
                case LanProtocol.SceneTrigger:
                    // As CharPresenceTrigger.OnTriggerEnter does for the host's own player.
                    var trigger = (CharPresenceTrigger)e.Target;
                    if (_entered(trigger)) return;
                    _entered(trigger) = true;
                    _onEnter(trigger)?.Invoke();
                    var controller = GlobalManager.global == null ? null : GlobalManager.global.controlledTrainController;
                    if (controller != null) controller.EmergencyBraking();
                    _log?.Invoke("The guest set off a trigger of the location");
                    break;
                default:
                    ((ObjectActivator)e.Target).Interact();
                    break;
            }
            _sent.Remove(SentKey(kind, id)); // answer with the new state at once
            if (!_relevant.Contains(e)) _relevant.Add(e);
            _sendAt = 0f;
        }

        // ---- Guest ----

        // The host's state on the guest's copy, as the game's own load sets it.
        private static void Apply(Entry e, SceneFrame frame)
        {
            float local; byte flags = State(e, out local);
            bool done = frame.Flags == 1;
            _applying = true;
            try
            {
                switch (e.Kind)
                {
                    case LanProtocol.SceneBomb:
                        if (done && flags == 0) ((DestroyableByBomb)e.Target).Load(new object[] { true }); // nothing builds a blown wall back
                        break;
                    case LanProtocol.SceneTrap:
                        if (done && flags == 0) ((TrapWall)e.Target).Load(new object[] { true }); // the game never opens one again
                        break;
                    case LanProtocol.SceneCollapse:
                        if (done && flags == 0) ((StructuralDestructionAndRepair)e.Target).Load(new object[] { true });
                        break;
                    case LanProtocol.SceneActivator:
                        if (done && flags == 0) ((ObjectActivator)e.Target).Load(new object[] { true });
                        break;
                    case LanProtocol.SceneDrainer:
                        if (done != (flags == 1) || Mathf.Abs(local - frame.Value) > 1f) ((WaterDrainer)e.Target).Load(new object[] { done, frame.Value });
                        break;
                    case LanProtocol.SceneButton:
                        var button = (HardwareButton)e.Target;
                        if (button.State != done) button.Set(done); // its lamp, sound and what it drives, as on the host
                        break;
                    case LanProtocol.SceneTrigger:
                        if (done && flags == 0) ((CharPresenceTrigger)e.Target).Load(new object[] { true }); // spent, as after a load
                        break;
                    default:
                        if (done && flags == 0) ((CollectedResource)e.Target).Load(new object[] { 0 });
                        break;
                }
            }
            finally { _applying = false; }
        }

        // Guest: the host took this apart: so does the guest's copy (what fell out is the host's world item).
        private void ApplyLid(SceneFrame frame)
        {
            Zompiercer.Inventory.Inventory inventory;
            if (!_lidsByPlace.TryGetValue(frame.Id, out inventory) || inventory == null) return;
            var io = LidObject(inventory);
            if (io == null) return;
            bool open = frame.Flags == 1;
            // Native detector Update is patched off on guests before SetOpen can
            // trigger its zombie/spawner side effects. Door itself owns lid motion
            // and opening/closing audio.
            foreach (var door in io.doors) if (door != null && door.Open != open) door.SetOpen(open);
        }

        private void ApplyFireworks(SceneFrame frame)
        {
            if (frame.Flags == 0)
            {
                if (_fireworksPlaying.Remove(frame.Id)) StopFireworks(frame.Id, true);
                return;
            }
            OpenDetectorFireworkSystem detector;
            if (!_detectors.TryGetValue(frame.Id, out detector) || detector == null) return;
            if (!_fireworksSeen.Add(frame.Id)) return;
            // Only the presentation children are activated. Their scripts and
            // colliders are disabled first; the detector itself never executes.
            if (detector.fireworks != null)
                foreach (var effect in detector.fireworks)
                {
                    if (effect == null) continue;
                    foreach (var script in effect.GetComponentsInChildren<MonoBehaviour>(true)) if (script != null) script.enabled = false;
                    foreach (var collider in effect.GetComponentsInChildren<Collider>(true)) if (collider != null) collider.enabled = false;
                    effect.SetActive(true);
                    foreach (var source in effect.GetComponentsInChildren<AudioSource>(true))
                        if (source != null && source.clip != null && !source.isPlaying) source.Play();
                }
            if (detector.fireworksParticle != null)
                foreach (var particle in detector.fireworksParticle) if (particle != null) particle.Play();
            _fireworksPlaying[frame.Id] = Time.unscaledTime;
        }

        private void StopFireworks(int id, bool hide)
        {
            OpenDetectorFireworkSystem detector;
            if (!_detectors.TryGetValue(id, out detector) || detector == null) return;
            if (detector.fireworksParticle != null)
                foreach (var particle in detector.fireworksParticle) if (particle != null) particle.Stop(true);
            if (hide && detector.fireworks != null)
                foreach (var effect in detector.fireworks) if (effect != null) effect.SetActive(false);
        }

        private void UpdateFireworkVisuals(float now)
        {
            if (_fireworksPlaying.Count == 0) return;
            var finished = new List<int>();
            foreach (var pair in _fireworksPlaying)
            {
                float elapsed = now - pair.Value;
                if (elapsed >= 8f) StopFireworks(pair.Key, false);
                if (elapsed >= 10f) { StopFireworks(pair.Key, true); finished.Add(pair.Key); }
            }
            foreach (var id in finished) _fireworksPlaying.Remove(id);
        }

        // Guest: the host took this apart: so does the guest's copy (what fell out is the host's world item).
        private void TakeApart(int key)
        {
            ResourceContent part;
            if (!_parts.TryGetValue(key, out part)) return;
            _parts.Remove(key);
            if (part != null) Object.Destroy(part.gameObject);
        }

        // Guest (2.4.4): the host's wear on the guest's copy, so the game's own hover shows how far it got.
        // 2.5.0: a loot cabinet of the location as the game's hover takes one (InteractingObjectsController.Update): an
        // InteractingObjects named ObjectForLoot with a door, on no furniture, with a storage that is neither a robot's
        // device nor a building element.
        private static Zompiercer.Inventory.Inventory LootOf(InteractingObjects io)
        {
            if (io == null || io.name != "ObjectForLoot" || io.doors == null || io.doors.Length == 0 || io.GetComponent<Furniture>() != null) return null;
            var inventory = io.GetComponent<Zompiercer.Inventory.Inventory>();
            return inventory == null || inventory.robotDevice || inventory.inventoryBuildingElement ? null : inventory;
        }
        // 2.5.0, guest: the game's hover writes EMPTY / NOT EMPTY on a searched cabinet from its own copy, which the guest never
        // searches (its use key opens the host's cabinet) and whose content is not the host's. The host's word goes there
        // instead, as the game writes it (same keys and colours), right after the game's own hover.
        private static void HoverPostfix(InteractingObjectsController __instance)
        {
            var owner = _guestCurrent;
            if (owner == null || !LanSaveIsolation.Active || __instance == null || __instance.simpleInfoDisplayer == null) return;
            try
            {
                var input = LanGame.Input;
                var inventories = Zompiercer.Inventory.InventoryController.global;
                var hovered = SelectionManager.Global == null ? null : SelectionManager.Global.HoveredObject;
                if (hovered == null || input == null || (int)input.CurrentState != 1 || inventories == null || inventories.inventoryExternalOpened || inventories.craftWindowOpened) return;
                var io = hovered.GetComponent<InteractingObjects>();
                var inventory = LootOf(io);
                if (inventory == null || io.doors[0] == null || io.doors[0].Open || io.GetComponentInParent<TrainPart>() != null) return;
                byte flags;
                if (!owner._lootFlags.TryGetValue(PlaceKey(inventory), out flags) || (flags & 1) == 0) return;
                bool empty = (flags & 2) != 0;
                var sounds = GlobalSoundEffects.global;
                var info = __instance.simpleInfoDisplayer;
                if (sounds != null) info.color = empty ? sounds.colorRed : sounds.colorGreen;
                info.SetText(Zompiercer.GUI.LocalizationCore.GetTextByKey(empty ? "Empty" : "NotEmpty").ToUpper());
            }
            catch (Exception ex)
            {
                if (_hoverFailed) return;
                _hoverFailed = true; _staticLog?.Invoke("Loot cabinet hover failed: " + ex.GetType().Name + ": " + ex.Message);
            }
        }

        private void Wear(SceneFrame frame)
        {
            ResourceContent part;
            if (!_parts.TryGetValue(frame.Id, out part) || part == null) return;
            if (frame.Flags == 1)
            {
                var points = LanWorldWork.HitPointsOf(part);
                if (points != null) points.CurrentHP = Mathf.Min(points.MaxHP, frame.Value); // never through CauseDamage: no fall here
            }
            else part.durability = Mathf.Min(part.durabilityMax, frame.Value);
        }

        private bool Use(Entry e)
        {
            float now = Time.unscaledTime, last;
            // A held button is pressed and let go quickly; traps and bridges may be set off frame after frame.
            if (e.Kind != LanProtocol.SceneButton && _usedAt.TryGetValue(e.Id, out last) && now - last < UseEvery) return true;
            _usedAt[e.Id] = now;
            _send(new Packet { Kind = PacketKind.SceneUse, WorldEpoch = _epoch, Scene = _scene, Sequence = ++_sequence, Revision = e.Id, Action = e.Kind });
            return true;
        }
        private static bool GuestEntry(Component target, byte kind, out LanSceneStates owner, out Entry entry)
        {
            entry = null; owner = _guestCurrent;
            if (owner == null || _applying || target == null || !LanSaveIsolation.Active) return false;
            return owner._byTarget.TryGetValue(target, out entry) && entry.Kind == kind;
        }

        // A lever or button of the location: the host switches its own (the guest's copy follows).
        internal static bool GuestSwitch(HardwareButton button)
        {
            LanSceneStates owner; Entry e;
            if (Failure != null || !GuestEntry(button, LanProtocol.SceneButton, out owner, out e)) return false;
            if (_pressFrame == Time.frameCount) return true;
            _pressFrame = Time.frameCount;
            if (button.defective) return true; // the game does nothing either
            return owner.Use(e);
        }
        // A trap wall, a collapsing floor or a bridge set off by the guest: at once in its copy, and the
        // host sets off its own.
        private static void TrapPrefix(TrapWall __instance)
        {
            try { LanSceneStates owner; Entry e; if (GuestEntry(__instance, LanProtocol.SceneTrap, out owner, out e) && !_trapDone(__instance)) owner.Use(e); }
            catch (Exception ex) { Once("Trap wall hook failed: " + ex.GetType().Name + ": " + ex.Message); }
        }
        private static void CollapsePrefix(StructuralDestructionAndRepair __instance, bool value)
        {
            try { LanSceneStates owner; Entry e; if (value && GuestEntry(__instance, LanProtocol.SceneCollapse, out owner, out e) && !_collapseDone(__instance)) owner.Use(e); }
            catch (Exception ex) { Once("Collapsing floor hook failed: " + ex.GetType().Name + ": " + ex.Message); }
        }
        private static void PresencePrefix(CharPresenceTrigger __instance, Collider collider)
        {
            try
            {
                LanSceneStates owner; Entry e;
                var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
                if (player == null || collider == null || collider.GetComponentInParent<ZombieFighterController>() != player) return;
                if (GuestEntry(__instance, LanProtocol.SceneTrigger, out owner, out e) && !_entered(__instance)) owner.Use(e);
            }
            catch (Exception ex) { Once("Presence trigger hook failed: " + ex.GetType().Name + ": " + ex.Message); }
        }
        // Host: something of the scene is taken apart (the game destroys it right after).
        private static void ParsedPrefix(ResourceContent __instance)
        {
            try
            {
                if (__instance == null || LanSaveIsolation.Active) return;
                var scenes = GlobalSceneManager.global;
                string scene = scenes == null ? null : scenes.CurrentSceneName;
                if (scene == null) return;
                if (scene != _parsedScene) { Parsed.Clear(); _parsedScene = scene; }
                if (Parsed.Count < 4096) Parsed[LoadKey(__instance)] = __instance.transform.position;
            }
            catch (Exception ex) { Once("Taken-apart object not noted: " + ex.GetType().Name + ": " + ex.Message); }
        }

        private static void RaisePrefix(ObjectActivator __instance)
        {
            try { LanSceneStates owner; Entry e; if (GuestEntry(__instance, LanProtocol.SceneActivator, out owner, out e) && !_raised(__instance)) owner.Use(e); }
            catch (Exception ex) { Once("Bridge hook failed: " + ex.GetType().Name + ": " + ex.Message); }
        }
    }
}
