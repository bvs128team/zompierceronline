using System;

namespace ZompiercerLAN
{
    // Stored in the SAME native snapshot as loose items. A sidecar written after
    // the native save cannot atomically remember whether those items existed.
    internal sealed class LanStarterLootReceipt
    {
        internal const int NativeFields = 21;
        internal const string Magic = "ZompiercerLAN.StarterLoot";
        internal const string Scene = "Terrain1";
        internal const int Backpack = 7, Bat = 27, Knife = 56;
        private int _state = 2; // 0 eligible, 1 granted, 2 unknown/blocked
        internal bool Granted { get { return _state == 1; } }
        internal void NewWorld() { _state = 0; }
        internal void Block() { _state = 2; }
        internal bool Eligible(bool host, bool isolated, int admittedGuests, string scene, bool loading)
        { return _state == 0 && host && !isolated && admittedGuests >= 1 && admittedGuests <= 7 && scene == Scene && !loading; }
        internal bool Commit()
        { if (_state != 0) return false; _state = 1; return true; }
        internal void Load(object[] data)
        {
            _state = 2;
            if (data == null) return;
            // Legacy native saves predate this feature and contain no extra kit.
            if (data.Length == NativeFields) { _state = 0; return; }
            if (data.Length != NativeFields + 1) return;
            var receipt = data[NativeFields] as object[];
            if (receipt == null || receipt.Length != 3 || !Magic.Equals(receipt[0]) ||
                !(receipt[1] is int) || (int)receipt[1] != 1 || !(receipt[2] is int)) return;
            int state = (int)receipt[2];
            if (state >= 0 && state <= 2) _state = state;
        }
        internal object[] Save(object[] data)
        {
            // Do not overwrite an extension belonging to another mod/version.
            if (data == null || data.Length != NativeFields)
                throw new InvalidOperationException("Unexpected native starter-loot snapshot shape");
            var copy = new object[NativeFields + 1];
            Array.Copy(data, copy, NativeFields);
            copy[NativeFields] = new object[] { Magic, 1, _state };
            return copy;
        }
    }
}
