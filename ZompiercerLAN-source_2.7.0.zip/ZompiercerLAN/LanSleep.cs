using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
using Zompiercer.Inventory;

namespace ZompiercerLAN
{
    // Sleeping together (1.2.2). The game's sleep runs the world clock fast for the hours chosen in
    // its bed window. With a partner in this world, the one who lies down waits under a dark screen
    // ("waiting for the partner", Space or E to get up) and the partner hears of it; once both lie,
    // the host starts the sleep for the fewer of the two chosen hours and both sleep it out with the
    // game's own sleep (the guest's clock follows the host's). Alone, the game sleeps as ever.
    // 2.0.0: with every other player in this world: the host starts it once all of them lie, for the
    // fewest hours any of them chose; each lying down or getting up is told to all. Main thread only.
    internal static class LanSleep
    {
        private static Harmony _harmony;
        private static Action<string> _log;
        internal static string Failure { get; private set; }
        // Set by the plugin every frame: the other players in this world (alive; slots), whether this side
        // hosts, how to tell them (action, hours: a guest tells its host, the host tells every guest).
        internal static Func<IList<int>> PlayersHere;
        internal static bool Hosting;
        internal static Action<byte, int, uint> Send;
        // Host (1.3.0 guest checks): a guest (slot) sleeps now, for this many hours.
        internal static Action<int, int> GuestSleeps;
        // Host (2.0.0): the guests lying down now, and the hours each chose.
        private static readonly Dictionary<int, int> _lying = new Dictionary<int, int>();
        private static readonly Dictionary<int, uint> _attempts = new Dictionary<int, uint>();
        private static readonly LanSleepIntent _intent = new LanSleepIntent();
        internal static uint AttemptFor(int slot) { uint attempt; return _attempts.TryGetValue(slot, out attempt) ? attempt : 0; }

        private static GlobalSleepController _controller;
        private static bool _bypass, _waiting;
        private static int _hours;
        private static float _waitingSince, _health;
        private static GUIStyle _style;
        internal static bool Waiting { get { return _waiting; } }

        internal static void Initialize(Action<string> log)
        {
            _log = log;
            if (_harmony != null || Failure != null) return;
            _harmony = new Harmony("local.zompiercer.lan.sleep");
            try
            {
                _harmony.Patch(AccessTools.Method(typeof(GlobalSleepController), "GoToSleepButton"), prefix: new HarmonyMethod(typeof(LanSleep), nameof(SleepPrefix)));
            }
            catch (Exception ex)
            {
                Failure = ex.GetType().Name + ": " + ex.Message;
                _harmony.UnpatchSelf();
                log("Sleep hook unavailable: " + Failure);
            }
        }
        internal static void Shutdown() { Reset(); _harmony?.UnpatchSelf(); _harmony = null; PlayersHere = null; Send = null; GuestSleeps = null; }

        private static bool Others() { var here = PlayersHere == null ? null : PlayersHere(); return here != null && here.Count != 0; }

        // The game's "go to sleep" button: alone it sleeps; with a partner here it lies down and waits.
        private static bool SleepPrefix(GlobalSleepController __instance)
        {
            if (_bypass || PlayersHere == null || Send == null) return true;
            if (!Others())
            {
                // Alone (the host is down or away): the game's sleep; the host still hears of it (1.3.0 checks).
                if (!Hosting) Send(LanProtocol.SleepWait, Mathf.Clamp(Mathf.RoundToInt(__instance.timeToSleep), 1, LanProtocol.MaxSleepHours), _intent.Begin());
                return true;
            }
            try
            {
                _controller = __instance;
                _intent.Begin();
                _hours = Mathf.Clamp(Mathf.RoundToInt(__instance.timeToSleep), 1, LanProtocol.MaxSleepHours);
                // Claim cleanup before changing tint/input: even partial setup must unwind.
                _waiting = true;
                var gui = LanGame.Gui;
                if (gui != null && gui.sleepActivatorBase != null) gui.sleepActivatorBase.SetActive(false);
                if (GlobalTintController.Global != null) GlobalTintController.Global.SetGlobalTint(true);
                var player = GlobalManager.global.controlledChar;
                if (player != null) { player.controlEnabled = false; _health = player.zombieFighterIndicatorsBar == null ? 0f : player.zombieFighterIndicatorsBar.currentHealth; }
                _waiting = true; _waitingSince = Time.unscaledTime;
                Send(LanProtocol.SleepWait, _hours, _intent.Attempt);
                _log?.Invoke("Lying down to sleep " + _hours + " h; waiting for the others");
                if (Hosting) TryShared();
            }
            catch (Exception ex) { _log?.Invoke("Shared sleep failed, sleeping alone: " + ex.Message); StandUp(true); return true; }
            return false;
        }

        // Another player's Sleep packet (2.0.0: from: its slot; a host gets its guests' own).
        internal static void Receive(byte action, int hours, int from, uint attempt)
        {
            string who = LanSkinPicker.Label(from);
            if (action == LanProtocol.SleepWait)
            {
                bool was = false;
                if (Hosting)
                {
                    GuestSleeps?.Invoke(from, hours); // 1.3.0: the guest's sleep may grow from now on
                    was = _lying.ContainsKey(from);
                    _lying[from] = hours;
                    _attempts[from] = attempt;
                    if (_waiting) { TryShared(); return; }
                }
                if (!was && !_waiting) LanNotify.Alert(who + LanText.T(" лёг спать: лягте все, чтобы промотать время"));
            }
            else if (action == LanProtocol.SleepCancel)
            {
                if (Hosting) { _lying.Remove(from); _attempts.Remove(from); }
                if (!_waiting) LanNotify.Message(who + LanText.T(" встал"));
            }
            else if (action == LanProtocol.SleepStart && !Hosting && _waiting && _intent.TryStart(attempt)) Sleep(hours);
        }

        // Host: everyone here lies: the fewest chosen hours, for all.
        private static void TryShared()
        {
            if (!Hosting || !_waiting) return;
            var here = PlayersHere == null ? null : PlayersHere();
            if (here == null) return;
            int hours = _hours;
            foreach (int slot in here)
            {
                int theirs;
                if (!_lying.TryGetValue(slot, out theirs)) return; // someone here is still up
                hours = Math.Min(hours, theirs);
            }
            hours = Math.Max(1, hours);
            Send?.Invoke(LanProtocol.SleepStart, hours, _intent.Attempt);
            foreach (int slot in here) GuestSleeps?.Invoke(slot, hours);
            Sleep(hours);
        }

        // The game's own sleep for `hours`.
        private static void Sleep(int hours)
        {
            var controller = _controller != null ? _controller : GlobalSleepController.global;
            _lying.Clear(); _attempts.Clear(); _intent.Cancel();
            if (controller == null) { _log?.Invoke("Shared sleep: no sleep controller here"); StandUp(false); return; }
            try
            {
                controller.timeToSleep = hours;
                _bypass = true;
                try { controller.GoToSleepButton(); } finally { _bypass = false; }
                _waiting = false; _controller = null;
                _log?.Invoke("Shared sleep for " + hours + " h");
            }
            catch (Exception ex) { _log?.Invoke("Shared sleep not started: " + ex.Message); StandUp(false); }
        }

        // Guest: a copy of a host bed in sight; the game's own bed hint and key open the bed window.
        internal static bool LookAtBed(Zompiercer.Inputs.InputController input)
        {
            var info = InventoryController.global == null ? null : InventoryController.global.simpleInfoDisplayer;
            var gui = LanGame.Gui;
            var sleep = GlobalSleepController.global;
            if (info == null || gui == null || sleep == null || gui.sleepActivatorBase == null || gui.sleepActivatorBase.activeSelf || _waiting) return true;
            var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrainController;
            if (train != null && train.Velocity != 0f)
            {
                info.color = GlobalSoundEffects.global.colorRed;
                info.SetText(Zompiercer.GUI.LocalizationCore.GetTextByKey("SleepInMovingTrainWarning").ToUpper());
                return true;
            }
            info.color = GlobalSoundEffects.global.colorGreen;
            info.SetIconText("GoToSleep", (Zompiercer.Inputs.Actions)29, (Zompiercer.Inputs.Actions)0, true);
            bool lie = input.isKbMouseDevice ? input.isLeverUpDown : input.gp_isAltUseDown;
            if (!lie) return true;
            input.isLeverUpDown = false; input.gp_isAltUseDown = false;
            gui.GlobalInventoryCloser();
            sleep.BackFromBed();
            sleep.sleepConditions = 2; // a bed, as the game's own beds
            return true;
        }

        // Guest (2.4.3): a host sleeping bag under the crosshair. It is a loose item (SleepingBagLoot), and only its
        // script-free copy is here, so the game offered no sleep on it. As the game's own: only inside (a building or
        // a car: CharInHouse) and with no live zombie within the bag's safe distance; the lever key lies down in it,
        // with half a bed's rest (sleepConditions 5). False when the item is no sleeping bag.
        internal static bool LookAtSleepingBag(int itemId, Zompiercer.Inputs.InputController input)
        {
            var database = ItemsDataBase.Global;
            var prefab = database == null || database.itemPrefab == null || itemId < 0 || itemId >= database.itemPrefab.Length ? null : database.itemPrefab[itemId];
            var bag = prefab == null ? null : prefab.GetComponent<SleepController>();
            if (bag == null || !bag.sleepbag) return false;
            var info = InventoryController.global == null ? null : InventoryController.global.simpleInfoDisplayer;
            var gui = LanGame.Gui;
            var sleep = GlobalSleepController.global;
            var manager = GlobalManager.global;
            var player = manager == null ? null : manager.controlledChar;
            if (info == null || gui == null || sleep == null || player == null || input == null || gui.sleepActivatorBase == null || gui.sleepActivatorBase.activeSelf || _waiting) return true;
            if (!manager.CharInHouse)
            {
                info.color = GlobalSoundEffects.global.colorRed;
                info.SetText(Zompiercer.GUI.LocalizationCore.GetTextByKey("SleepOnlyInBuildings").ToUpper());
                return true;
            }
            if (ZombieSync.LiveZombieNear(player.transform.position, bag.safeZombieDistance))
            {
                info.color = GlobalSoundEffects.global.colorRed;
                info.SetText(Zompiercer.GUI.LocalizationCore.GetTextByKey("ZombieTooClose").ToUpper());
                return true;
            }
            info.color = GlobalSoundEffects.global.colorGreen;
            info.SetIconText("GoToSleep", (Zompiercer.Inputs.Actions)29, (Zompiercer.Inputs.Actions)0, true);
            bool lie = input.isKbMouseDevice ? input.isLeverUpDown : input.gp_isAltUseDown;
            if (!lie) return true;
            input.isLeverUpDown = false; input.gp_isAltUseDown = false;
            gui.GlobalInventoryCloser();
            sleep.BackFromBed();
            sleep.sleepConditions = 5; // a sleeping bag, as the game's own
            _log?.Invoke("Lying down in the host's sleeping bag");
            return true;
        }

        // Gets up from waiting (`tell`: the partner hears of it).
        private static void StandUp(bool tell)
        {
            _intent.Cancel();
            if (!_waiting) return;
            _waiting = false;
            _controller = null;
            // A broken tint/UI component must not prevent restoring player controls.
            try { if (GlobalTintController.Global != null) GlobalTintController.Global.SetGlobalTint(false); }
            catch (Exception ex) { _log?.Invoke("Clearing sleep tint failed: " + ex.Message); }
            try
            {
                var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
                if (player != null) player.controlEnabled = true;
            }
            catch (Exception ex) { _log?.Invoke("Restoring sleep controls failed: " + ex.Message); }
            try
            {
                var gui = LanGame.Gui;
                if (gui != null) { gui.CursorLock(); gui.UpdateStateInput(); }
            }
            catch (Exception ex) { _log?.Invoke("Getting up failed: " + ex.Message); }
            if (tell) Send?.Invoke(LanProtocol.SleepCancel, 0, _intent.Attempt);
        }

        // Every frame: alone again (the others left), hurt, or a game menu: the waiting ends; a host
        // whose last player still up left starts the sleep.
        internal static void Tick()
        {
            if (!_waiting) return;
            bool partner = Others();
            if (partner && Hosting) { TryShared(); if (!_waiting) return; }
            var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
            var bar = player == null ? null : player.zombieFighterIndicatorsBar;
            if (bar != null && bar.currentHealth < _health - .5f) { StandUp(true); LanNotify.Message(LanText.T("Вас ранили — вы встали")); return; }
            if (!partner) { int hours = _hours; StandUp(false); Sleep(hours); return; } // alone now: the game's sleep
            if (player != null) player.controlEnabled = false;
        }

        // OnGUI: the waiting screen; Space or E gets up.
        internal static void Draw()
        {
            if (!_waiting) return;
            var e = Event.current;
            if (e.type == EventType.KeyDown && (e.keyCode == KeyCode.Space || e.keyCode == KeyCode.E) && Time.unscaledTime - _waitingSince > .5f)
            { e.Use(); StandUp(true); return; }
            if (_style == null) _style = new GUIStyle(GUI.skin.label) { fontSize = 22, alignment = TextAnchor.MiddleCenter, wordWrap = true };
            GUI.Label(new Rect(0f, Screen.height * .4f, Screen.width, 120f),
                LanText.T("Ждём, пока лягут остальные…\nПробел или E — встать"), _style);
        }

        // A session ended or changed world.
        internal static void Reset() { StandUp(false); _controller = null; _lying.Clear(); _attempts.Clear(); }
        // 2.0.0, host: a guest left: it no longer lies.
        internal static void Forget(int slot) { _lying.Remove(slot); _attempts.Remove(slot); }
    }
}
