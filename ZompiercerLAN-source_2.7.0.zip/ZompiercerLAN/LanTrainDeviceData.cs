using System;
using System.Collections.Generic;
using System.IO;

namespace ZompiercerLAN
{
    // Wire-only device state. No native types, events, paths, URLs or arbitrary clip names.
    internal sealed class LanTrainDeviceData
    {
        internal const int Switch = 1, Lamp = 2, Input = 3, Output = 4, Fire = 5, Music = 6;
        internal const int MaxIndex = 15, MaxDevices = 64, MaxRecords = 32, MaxRecord = 4095, MaxTime = 864000;
        internal const int MaxBytes = 1 + MaxDevices * (17 + MaxRecords * 2);
        internal int Kind, Index, Value, Extra, Record = -1;
        internal bool Active;
        internal int[] Records = new int[0];
        internal static int Control(int owner, int index, int action, int record = 0)
        {
            int result = owner | index << 1 | action << 5 | record << 8;
            if (action < 1 || action > 6 || owner < 0 || owner > 1 || index < 0 || index > MaxIndex || record < 0 || record > MaxRecord || !ValidControl(result)) throw new ArgumentException("Device command");
            return result;
        }
        internal static bool ValidControl(int value)
        {
            if (value < 0 || (value & ~0xfffff) != 0) return false;
            int action = (value >> 5) & 7, record = value >> 8;
            return action >= 1 && action <= 6 && (action == 3 || record == 0);
        }
        internal static void Fields(int value, out int owner, out int index, out int action, out int record)
        { owner = value & 1; index = value >> 1 & 15; action = value >> 5 & 7; record = value >> 8; }
        internal bool Valid()
        {
            if (Kind < Switch || Kind > Music || Index < 0 || Index > MaxIndex || Value < 0 || Value > MaxTime || Extra < 0 || Extra > MaxTime || Records == null || Records.Length > MaxRecords) return false;
            if (Kind < Fire) return Value == 0 && Extra == 0 && Record == -1 && Records.Length == 0;
            if (Kind == Fire) return Record == -1 && Records.Length == 0;
            if (Record < -1 || Record > MaxRecord || Extra != 0 || Active && Record < 0) return false;
            var seen = new HashSet<int>();
            foreach (int id in Records) if (id < 0 || id > MaxRecord || !seen.Add(id)) return false;
            // A removed record may still be playing until the native player next changes tracks.
            return true;
        }
        internal static void Write(BinaryWriter writer, List<LanTrainDeviceData> devices)
        {
            if (devices == null || devices.Count < 1 || devices.Count > MaxDevices) throw new InvalidDataException("Device count");
            writer.Write((byte)devices.Count);
            var seen = new HashSet<int>();
            foreach (var d in devices)
            {
                if (d == null || !d.Valid() || !seen.Add(d.Kind * 16 + d.Index)) throw new InvalidDataException("Device state");
                writer.Write((byte)d.Kind); writer.Write((byte)d.Index); writer.Write((byte)(d.Active ? 1 : 0));
                writer.Write(d.Value); writer.Write(d.Extra); writer.Write((short)d.Record);
                writer.Write((byte)d.Records.Length); foreach (int id in d.Records) writer.Write((ushort)id);
            }
        }
        internal static List<LanTrainDeviceData> Read(BinaryReader reader)
        {
            int count = reader.ReadByte();
            if (count < 1 || count > MaxDevices) throw new InvalidDataException("Device count");
            var result = new List<LanTrainDeviceData>(); var seen = new HashSet<int>();
            for (int i = 0; i < count; i++)
            {
                var d = new LanTrainDeviceData { Kind = reader.ReadByte(), Index = reader.ReadByte() };
                int active = reader.ReadByte(); if (active > 1) throw new InvalidDataException("Device flag");
                d.Active = active != 0; d.Value = reader.ReadInt32(); d.Extra = reader.ReadInt32(); d.Record = reader.ReadInt16();
                int n = reader.ReadByte(); if (n > MaxRecords) throw new InvalidDataException("Record count");
                d.Records = new int[n]; for (int j = 0; j < n; j++) d.Records[j] = reader.ReadUInt16();
                if (!d.Valid() || !seen.Add(d.Kind * 16 + d.Index)) throw new InvalidDataException("Device state");
                result.Add(d);
            }
            return result;
        }
    }
}

