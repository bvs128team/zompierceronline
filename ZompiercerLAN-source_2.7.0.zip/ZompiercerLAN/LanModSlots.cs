using System.Collections.Generic;
using UnityEngine;
using Zompiercer.Inventory;

namespace ZompiercerLAN
{
    // 2.4.3: the mod slots of an item as the game's EquipmentModsItem.Awake collects them on a spawned item
    // (GetComponentsInChildren: the active ones, in hierarchy order; its saved mods follow that order). A prefab is
    // never woken: its Slots field is empty on every firearm but the 1911 (whose list starts with a missing slot), so
    // read from the prefab the host saw none of a guest's mods (2.0.5-2.4.2: no larger magazine, silencer or
    // compensator), the partner's weapon showed none and only the 1911 was held as a pistol. Main thread only.
    internal static class LanModSlots
    {
        private static readonly Dictionary<int, EquipmentModSlotItem[]> Cache = new Dictionary<int, EquipmentModSlotItem[]>();

        // null: the item takes no mods.
        internal static EquipmentModSlotItem[] Of(InventoryItem prefab)
        {
            var mods = prefab == null ? null : prefab.GetComponent<EquipmentModsItem>();
            if (mods == null) return null;
            int key = mods.GetInstanceID();
            EquipmentModSlotItem[] slots;
            if (Cache.TryGetValue(key, out slots) && Whole(slots)) return slots;
            var root = mods.transform;
            var found = new List<EquipmentModSlotItem>();
            foreach (var slot in mods.GetComponentsInChildren<EquipmentModSlotItem>(true))
            {
                bool active = true;
                for (var t = slot.transform; t != null && t != root; t = t.parent)
                    if (!t.gameObject.activeSelf) { active = false; break; }
                if (active) found.Add(slot);
            }
            slots = found.ToArray();
            Cache[key] = slots;
            return slots;
        }

        // 2.4.5: a mod item's own mod part, as InventoryItem.Awake takes it (GetComponent<EquipmentModItem>). A prefab is never
        // woken: its equipmentMod field is empty, so the game's IsSuitableToFitHere refused every mod read from a prefab
        // (2.0.5-2.4.4: the host never booked a guest's larger magazine, silencer or compensator, and the partner's weapon
        // showed no mods, even after 2.4.3 found the slots).
        internal static EquipmentModItem ModOf(InventoryItem prefab)
        {
            if (prefab == null) return null;
            return prefab.equipmentMod != null ? prefab.equipmentMod : prefab.GetComponent<EquipmentModItem>();
        }
        // EquipmentModSlotItem.IsSuitableToFitHere, on the mod part itself: a muzzle device of muzzle type 3 fits slot
        // types 7 and 9; otherwise the slot type must match, the mount type too (0 fits any), and the scope tier stay
        // within the slot's.
        internal static bool Fits(EquipmentModSlotItem slot, EquipmentModItem mod)
        {
            if (slot == null || mod == null) return false;
            if ((int)mod.MuzzleModType == 3 && ((int)slot.Type == 7 || (int)slot.Type == 9)) return true;
            if (mod.Slot != slot.Type) return false;
            if ((int)mod.MountType != 0 && mod.MountType != slot.MountType) return false;
            return mod.ScopeTier <= slot.MaxAllowedScopeTier;
        }

        private static bool Whole(EquipmentModSlotItem[] slots)
        {
            foreach (var slot in slots) if (slot == null) return false;
            return true;
        }
    }
}
