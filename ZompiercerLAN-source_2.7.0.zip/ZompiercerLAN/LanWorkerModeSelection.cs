using System;
using System.IO;
using System.Security;
using System.Text;

namespace ZompiercerLAN
{
    internal static class LanWorkerModeSelection
    {
        internal const string FileName = "ZompiercerLAN.worker-mode";
        internal const string CacheValue = "user-cache-v1";

        // The opt-in lives beside the plugin, never among the three pinned assets.
        // Only absence means default; unreadable or malformed settings are errors.
        internal static bool UseCache(string pluginDirectory)
        {
            string path = Path.Combine(pluginDirectory, FileName);
            FileAttributes attributes;
            try { attributes = File.GetAttributes(path); }
            catch (FileNotFoundException) { return false; }
            if ((attributes & (FileAttributes.ReparsePoint | FileAttributes.Directory)) != 0)
                throw new SecurityException("Invalid worker mode file: linked path or directory.");
            using (var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                var expected = Encoding.ASCII.GetBytes(CacheValue);
                if (file.Length != expected.Length) throw new SecurityException("Invalid worker mode file. Use Set-Worker-Mode.ps1.");
                foreach (byte value in expected)
                    if (file.ReadByte() != value) throw new SecurityException("Invalid worker mode file. Use Set-Worker-Mode.ps1.");
            }
            return true;
        }
    }
}
