using System;
using System.Reflection;
using Object = UnityEngine.Object;

namespace ZompiercerLAN
{
    // 2.6.1: the game's managers built on Zompiercer.Singleton<T> (InputController, GUIManager, GlobalStatsController,
    // TerrainResourceDetector, ...) make a bare new one in their Global getter when the real one is gone: between
    // GlobalSceneManager.DeleteEverything2 on the way to the main menu and the menu's own Awake. That stand-in is kept
    // (DontDestroyOnLoad), and the menu's real manager, seeing it in Singleton.Awake, destroys itself: no controls until a
    // restart. The mod only reads the instance the game registered; null while there is none.
    internal static class LanGame
    {
        internal static Zompiercer.Inputs.InputController Input { get { return Instance<Zompiercer.Inputs.InputController>.Get(); } }
        internal static Zompiercer.GUI.GUIManager Gui { get { return Instance<Zompiercer.GUI.GUIManager>.Get(); } }
        internal static Zompiercer.GlobalStatsController Stats { get { return Instance<Zompiercer.GlobalStatsController>.Get(); } }
        internal static Zompiercer.Farm.TerrainResourceDetector Detector { get { return Instance<Zompiercer.Farm.TerrainResourceDetector>.Get(); } }
        internal static Zompiercer.GUI.GuiCore GuiCore { get { return Instance<Zompiercer.GUI.GuiCore>.Get(); } }

        private static class Instance<T> where T : Object
        {
            private static readonly FieldInfo Field = typeof(Zompiercer.Singleton<>).MakeGenericType(typeof(T))
                .GetField("_instance", BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public);

            internal static T Get()
            {
                if (Field == null) return null;
                var value = Field.GetValue(null) as T;
                return value == null ? null : value; // a destroyed manager reads as null
            }
        }
    }
}
