﻿using System;
using System.Collections.Generic;
using System.IO;

namespace ZompiercerLAN
{
    internal interface ITimedBuffRules { object[] Buffs(int item); }

    // Closed primitive representation, independent of native SaveBuff serialization.
    internal static class LanTimedBuffs
    {
        internal const int Limit = 18;
        internal const float MaxTime = 86400f;
        internal static bool Type(int type) { return type >= 1 && type <= 9 || type >= 21 && type <= 29; }
        internal static void Validate(object value)
        {
            if (value == null) return; // pre-2.5.6 profile
            var rows = value as object[];
            if (rows == null || rows.Length > Limit) throw new InvalidDataException("buff count");
            var seen = new HashSet<int>();
            foreach (var row in rows)
            {
                var r = row as object[];
                if (r == null || r.Length != 4 || !(r[0] is int) || !Type((int)r[0]) || !seen.Add((int)r[0]))
                    throw new InvalidDataException("buff type");
                for (int i = 1; i < 4; i++)
                    if (!(r[i] is float) || float.IsNaN((float)r[i]) || float.IsInfinity((float)r[i]) ||
                        Math.Abs((float)r[i]) > (i == 3 ? MaxTime : 10000f))
                        throw new InvalidDataException("buff value");
                if ((float)r[3] <= 0f) throw new InvalidDataException("buff duration");
            }
        }
        internal static object[] Find(object value, int type)
        {
            var rows = value as object[];
            if (rows != null) foreach (object[] row in rows) if ((int)row[0] == type) return row;
            return null;
        }
    }

    internal sealed class LanTimedBuffBudget
    {
        private sealed class Credit { internal object[] Row; internal double Until; }
        private readonly List<Credit> _credits = new List<Credit>();
        internal void Clear() { _credits.Clear(); }
        internal void CreditRows(object[] rows, double now)
        {
            LanTimedBuffs.Validate(rows);
            _credits.RemoveAll(c => c.Until <= now);
            if (rows != null) foreach (object[] row in rows)
            {
                if (_credits.Count == 128) break;
                _credits.Add(new Credit { Row = (object[])row.Clone(), Until = now + 60 });
            }
        }
        internal bool Check(object[] oldCharacter, object[] character, double now, float elapsed)
        {
            _credits.RemoveAll(c => c.Until <= now);
            var accepted = new List<object>(); bool ok = true;
            var rows = character[17] as object[];
            if (rows == null) return true;
            foreach (object[] row in rows)
            {
                int type = (int)row[0];
                var old = LanTimedBuffs.Find(oldCharacter[17], type);
                float remaining = old == null ? 0 : Math.Max(0, (float)old[3] - elapsed);
                bool same = old != null && EqualValues(row, old);
                float allowance = same ? remaining : 0f;
                var used = new List<Credit>();
                foreach (var credit in _credits)
                    if ((int)credit.Row[0] == type && EqualGrant(row, credit.Row, oldCharacter))
                    { allowance = Math.Min(LanTimedBuffs.MaxTime, allowance + (float)credit.Row[3]); used.Add(credit); }
                if (allowance <= 0) { ok = false; continue; }
                var saved = (object[])row.Clone();
                if ((float)saved[3] > allowance) { saved[3] = allowance; ok = false; }
                accepted.Add(saved);
                // Consume every matching grant once; remaining duration becomes the new baseline.
                foreach (var credit in used) _credits.Remove(credit);
            }
            character[17] = accepted.ToArray();
            return ok;
        }
        private static bool EqualGrant(object[] row, object[] grant, object[] character)
        {
            int type = (int)grant[0];
            if (type != 22 && type != 27) return EqualValues(row, grant);
            float maximum = (float)((object[])character[1])[0];
            return Math.Abs((float)row[1] - maximum * (float)grant[1] / 100f) < .001f && (float)row[2] == (float)grant[2];
        }
        private static bool EqualValues(object[] a, object[] b)
        { return (float)a[1] == (float)b[1] && (float)a[2] == (float)b[2]; }
    }
}
