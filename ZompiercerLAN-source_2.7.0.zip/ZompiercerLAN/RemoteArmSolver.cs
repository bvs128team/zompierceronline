using System;

namespace ZompiercerLAN
{
    // Scalar two-bone geometry. Kept independent of Unity so bad wrist/elbow cases can be
    // exercised in the offline checks without creating a game object or running an animator.
    // 2.7.0: only for free reaches (jabs, a stab, the use key); held items go through RemoteHoldPose.
    internal static class RemoteArmSolver
    {
        internal struct Point
        {
            internal float X, Y, Z;
            internal Point(float x, float y, float z) { X = x; Y = y; Z = z; }
            public static Point operator +(Point a, Point b) { return new Point(a.X + b.X, a.Y + b.Y, a.Z + b.Z); }
            public static Point operator -(Point a, Point b) { return new Point(a.X - b.X, a.Y - b.Y, a.Z - b.Z); }
            public static Point operator *(Point a, float k) { return new Point(a.X * k, a.Y * k, a.Z * k); }
            public static Point operator /(Point a, float k) { return a * (1f / k); }
            internal float Length { get { return (float)Math.Sqrt(Dot(this, this)); } }
        }

        internal struct Input
        {
            internal Point Shoulder, Elbow, Wrist, Target, Chest, Right, Forward, Up;
            internal float ShoulderWidth, TorsoHeight, Weight;
            internal bool Left;
        }

        internal struct Result
        {
            internal Point Wrist, Elbow;
            internal bool Valid, Clear, Reachable;
            internal float ContactError;
        }

        internal static Result Solve(Input input)
        {
            var result = new Result();
            if (!Finite(input.Shoulder) || !Finite(input.Elbow) || !Finite(input.Wrist) ||
                !Finite(input.Target) || !Finite(input.Chest) || !Finite(input.Right) ||
                !Finite(input.Forward) || !Finite(input.Up) || !Finite(input.ShoulderWidth) ||
                !Finite(input.TorsoHeight) || !Finite(input.Weight) || input.Weight <= .001f) return result;
            float upper = (input.Elbow - input.Shoulder).Length;
            float lower = (input.Wrist - input.Elbow).Length;
            if (upper < .001f || lower < .001f) return result;
            Point right = Unit(input.Right), forward = Unit(input.Forward), up = Unit(input.Up);
            if (right.Length < .5f || forward.Length < .5f || up.Length < .5f) return result;
            float width = Clamp(input.ShoulderWidth, .25f, .8f);
            float height = Clamp(input.TorsoHeight, .25f, .8f);
            float shoulderY = Dot(input.Shoulder - input.Chest, up);
            float top = shoulderY + width * .55f;
            float bottom = -height;
            float front = width * .42f, halfWidth = width * .40f;
            float sign = input.Left ? -1f : 1f;
            // Project torso-height hand targets onto the near/front surface. A mouth contact
            // sits above the shoulder line, so its measured position is kept intact.
            var desired = input.Target;
            var fromChest = desired - input.Chest;
            float x = Dot(fromChest, right), y = Dot(fromChest, up), z = Dot(fromChest, forward);
            if (y > bottom && y < top)
            {
                if (x * sign < 0f) { desired -= right * x; z = Dot(desired - input.Chest, forward); x = 0f; }
                if (Math.Abs(x) < halfWidth && z < front) desired += forward * (front - z);
            }
            // A legal wrist endpoint can still leave the upper arm or forearm inside the chest,
            // especially at full extension. Advance the goal in bounded, avatar-local steps
            // until both solved segments clear the torso proxy.
            for (int attempt = 0; attempt < 9; attempt++)
            {
                result = SolveCandidate(input, desired, upper, lower, right, forward, .55f);
                result.ContactError = (result.Wrist - input.Target).Length;
                result.Reachable = result.ContactError <= .002f;
                result.Clear = result.Valid && !Blocked(input, result, right, forward, up,
                    width, bottom, top, halfWidth, front);
                if (!result.Valid || !Blocked(input, result, right, forward, up,
                    width, bottom, top, halfWidth, front) ||
                    input.Weight < .2f) return result;
                desired += forward * (width * .11f) + right * (sign * width * .055f);
            }
            return result;
        }

        private static Result SolveCandidate(Input input, Point desired, float upper, float lower,
            Point right, Point forward, float forwardPole)
        {
            var result = new Result();
            var target = input.Wrist + (desired - input.Wrist) * Clamp(input.Weight, 0f, 1f);
            var vector = target - input.Shoulder;
            float distance = vector.Length;
            if (distance < .001f) return result;
            var direction = vector / distance;
            float reach = Clamp(distance, Math.Abs(upper - lower) + .001f, upper + lower - .001f);
            var wrist = input.Shoulder + direction * reach;
            // The animation's elbow can bend inward or behind the body. A pole in the avatar's
            // own lateral/front quadrant makes the upper arm leave the shoulder on its own side.
            var pole = right * (input.Left ? -1f : 1f) + forward * forwardPole;
            var preferred = pole - direction * Dot(pole, direction);
            var current = input.Elbow - input.Shoulder - direction * Dot(input.Elbow - input.Shoulder, direction);
            if (preferred.Length < .001f) preferred = current;
            if (current.Length < .001f) current = preferred;
            if (preferred.Length < .001f || current.Length < .001f) return result;
            preferred = Unit(preferred);
            current = Unit(current);
            float blend = Clamp(input.Weight, 0f, 1f);
            // Rotate along the signed arc in the reach plane. Unlike a linear mix, this also
            // remains defined for opposing poles and ends at the exact preferred direction.
            float angle = (float)Math.Atan2(Dot(direction, Cross(current, preferred)),
                Dot(current, preferred));
            Point bend = current * (float)Math.Cos(angle * blend) +
                Cross(direction, current) * (float)Math.Sin(angle * blend);
            float along = (upper * upper - lower * lower + reach * reach) / (2f * reach);
            float side = (float)Math.Sqrt(Math.Max(0f, upper * upper - along * along));
            result.Wrist = wrist;
            result.Elbow = input.Shoulder + direction * along + bend * side;
            result.Valid = Finite(result.Wrist) && Finite(result.Elbow);
            return result;
        }

        private static bool Blocked(Input input, Result result, Point right, Point forward, Point up,
            float width, float bottom, float top, float halfWidth, float front)
        {
            return BlockedCount(input, result, right, forward, up, width, bottom, top,
                halfWidth, front) != 0;
        }

        private static int BlockedCount(Input input, Result result, Point right, Point forward, Point up,
            float width, float bottom, float top, float halfWidth, float front)
        {
            return SegmentBlocked(input.Shoulder, result.Elbow, input.Chest, right, forward, up,
                width, bottom, top, halfWidth, front) ||
                SegmentBlocked(result.Elbow, result.Wrist, input.Chest, right, forward, up,
                width, bottom, top, halfWidth, front) ? 1 : 0;
        }

        private static bool SegmentBlocked(Point start, Point end, Point chest, Point right,
            Point forward, Point up, float width, float bottom, float top,
            float halfWidth, float front)
        {
            var delta = (end - start) * .1f;
            var body = start - chest;
            for (int step = 1; step <= 10; step++)
            {
                body += delta;
                float y = Dot(body, up);
                if (y < bottom || y > top) continue;
                float x = Dot(body, right);
                float z = Dot(body, forward);
                if (Math.Abs(x) < halfWidth && z > -width * .28f && z < front) return true;
            }
            return false;
        }

        private static float Dot(Point a, Point b) { return a.X * b.X + a.Y * b.Y + a.Z * b.Z; }
        private static Point Cross(Point a, Point b)
        { return new Point(a.Y * b.Z - a.Z * b.Y, a.Z * b.X - a.X * b.Z, a.X * b.Y - a.Y * b.X); }
        private static Point Unit(Point p) { float n = p.Length; return n < .000001f ? new Point() : p / n; }
        private static float Clamp(float x, float lo, float hi) { return Math.Max(lo, Math.Min(hi, x)); }
        private static bool Finite(float x) { return !float.IsNaN(x) && !float.IsInfinity(x); }
        private static bool Finite(Point p) { return Finite(p.X) && Finite(p.Y) && Finite(p.Z); }
    }
}
