using System;
using HarmonyLib;
using UnityEngine;
using UnityEngine.SceneManagement;
using Zompiercer.Inventory;
using Zompiercer.SaveLoad;
using Object = UnityEngine.Object;

namespace ZompiercerLAN
{
    // Exactly one additional starter kit per host world, including late joining
    // after the originals were taken. Authored anchors verified from level2:
    // InventoryItems 77522/77523/78222. Backpack's off-map transform is NOT its
    // location: InventoryInserter 77521 targets Cupboard (3), Inventory 81237.
    internal static class LanStarterLoot
    {
        private static readonly LanStarterLootReceipt Receipt = new LanStarterLootReceipt();
        private static Harmony _harmony;
        private static Action<string> _log;
        private static float _nextTry;
        private static readonly System.Reflection.FieldInfo SaveError = AccessTools.Field(typeof(SaveLoadCore), "ErrorDuringSave");
        private static readonly Vector3 CupboardAnchor = new Vector3(428.374f, 67.1f, 94.567f);
        private static readonly Vector3 BatAnchor = new Vector3(426.194f, 67.867f, 94.931f);
        private static readonly Vector3 KnifeAnchor = new Vector3(426.361f, 67.868f, 97.919f);

        internal static void Initialize(Action<string> log)
        {
            _log = log;
            if (_harmony != null) return;
            var harmony = new Harmony("local.zompiercer.lan.starter-loot");
            try
            {
                if (SaveError == null) throw new MissingFieldException("SaveLoadCore.ErrorDuringSave");
                harmony.Patch(AccessTools.Method(typeof(SaveLoadCore), "SaveWorldToData"), postfix: new HarmonyMethod(typeof(LanStarterLoot), nameof(Saved)));
                harmony.Patch(AccessTools.Method(typeof(SaveLoadCore), "LoadWorldFromData"), prefix: new HarmonyMethod(typeof(LanStarterLoot), nameof(Loading)));
                harmony.Patch(AccessTools.Method(typeof(SaveLoadCore), "LoadGame"), prefix: new HarmonyMethod(typeof(LanStarterLoot), nameof(BeforeLoad)));
                harmony.Patch(AccessTools.Method(typeof(Zompiercer.GUI.GUIManager), "StartNewGameButton"), prefix: new HarmonyMethod(typeof(LanStarterLoot), nameof(NewWorld)));
                _harmony = harmony;
            }
            catch (Exception ex) { harmony.UnpatchSelf(); Receipt.Block(); _log?.Invoke("Starter loot unavailable: " + ex.Message); }
        }
        internal static void Shutdown() { _harmony?.UnpatchSelf(); _harmony = null; Receipt.Block(); }
        private static void NewWorld() { if (!LanSaveIsolation.Active) { Receipt.NewWorld(); _nextTry = 0f; } }
        private static void BeforeLoad() { if (!LanSaveIsolation.Active) { Receipt.Block(); _nextTry = 0f; } }
        private static void Loading(object[] __0) { if (!LanSaveIsolation.Active) Receipt.Load(__0); }
        private static void Saved(ref object[] __result)
        {
            if (LanSaveIsolation.Active) return;
            try { __result = Receipt.Save(__result); }
            catch (Exception ex)
            {
                // Never let a save drop the receipt while keeping spawned loot.
                Receipt.Block();
                if (SaveLoadCore.global != null) SaveError.SetValue(SaveLoadCore.global, true);
                _log?.Invoke("Starter loot snapshot rejected: " + ex.Message);
            }
        }

        internal static void Tick(bool host, int admittedGuests)
        {
            var saves = SaveLoadCore.global;
            var scenes = GlobalSceneManager.global;
            if (_harmony == null || saves == null || scenes == null ||
                !Receipt.Eligible(host, LanSaveIsolation.Active, admittedGuests, scenes.CurrentSceneName,
                    saves.LoadingNow || saves.GetLoadingPhase || scenes.SceneCurrentlyLoading) || Time.unscaledTime < _nextTry) return;
            _nextTry = Time.unscaledTime + 1f;
            var scene = SceneManager.GetSceneByName(LanStarterLootReceipt.Scene);
            var db = ItemsDataBase.Global;
            if (!scene.IsValid() || !scene.isLoaded || db == null || db.itemPrefab == null) return;
            // A stable authored container anchor works after the original bag is
            // collected, and excludes other backpacks/cupboards elsewhere.
            Inventory cupboard = null;
            foreach (var root in scene.GetRootGameObjects())
                foreach (var inventory in root.GetComponentsInChildren<Inventory>(true))
                    if (inventory.name == "Cupboard (3)" && Vector3.Distance(inventory.transform.position, CupboardAnchor) < .05f)
                    { if (cupboard != null) { Receipt.Block(); return; } cupboard = inventory; }
            if (cupboard == null) return;
            var ids = new[] { LanStarterLootReceipt.Backpack, LanStarterLootReceipt.Bat, LanStarterLootReceipt.Knife };
            foreach (int id in ids) if (id >= db.itemPrefab.Length || db.itemPrefab[id] == null || db.itemPrefab[id].itemID != id) return;
            GameObject staging = null;
            var copies = new InventoryItem[3];
            try
            {
                // Stage all three before publishing any. No deferred inserters,
                // inventory ledger grants, or per-guest callbacks are involved.
                staging = new GameObject("LAN starter loot staging"); staging.SetActive(false);
                SceneManager.MoveGameObjectToScene(staging, scene);
                for (int i = 0; i < ids.Length; i++)
                {
                    copies[i] = Object.Instantiate(db.itemPrefab[ids[i]], staging.transform, false);
                    if (copies[i] == null) throw new InvalidOperationException("Starter prefab unavailable");
                    copies[i].amount = 1;
                    copies[i].inInventory = null;
                }
                copies[0].transform.position = cupboard.transform.position + cupboard.transform.forward * .7f + Vector3.up * .3f;
                copies[0].transform.rotation = Quaternion.identity;
                copies[1].transform.position = BatAnchor + new Vector3(.35f, .04f, 0f);
                copies[1].transform.rotation = new Quaternion(0f, .24232553f, 0f, .970195f);
                copies[2].transform.position = KnifeAnchor + new Vector3(.3f, .04f, 0f);
                copies[2].transform.rotation = new Quaternion(0f, .53456724f, 0f, .845126f);
                if (!Receipt.Commit()) throw new InvalidOperationException("Starter receipt already consumed");
                for (int i = 0; i < copies.Length; i++) { copies[i].transform.SetParent(null, true); copies[i].gameObject.SetActive(true); }
                // Use the same native cupboard as the original backpack. If full,
                // it remains ordinary loose loot directly in front of that cupboard.
                cupboard.Add(copies[0], false);
                _log?.Invoke("One extra starter kit placed in Terrain1 (backpack 7, bat 27, knife 56).");
            }
            catch (Exception ex)
            {
                // Fail closed even if native activation/add partially succeeded.
                Receipt.Block();
                foreach (var copy in copies) if (copy != null)
                {
                    // Native Add appends content before its UI refresh and only
                    // then assigns inInventory. An exception in that interval
                    // leaves an ownerless list entry: always clean the known
                    // destination, without invoking Remove's UI callbacks.
                    DetachFailedCopy(cupboard, copy);
                    if (copy.inInventory != cupboard) DetachFailedCopy(copy.inInventory, copy);
                    copy.inInventory = null;
                    copy.gameObject.SetActive(false); Object.Destroy(copy.gameObject);
                }
                _log?.Invoke("Starter kit creation aborted without retry: " + ex.Message);
            }
            finally { if (staging != null) Object.Destroy(staging); }
        }

        private static void DetachFailedCopy(Inventory inventory, InventoryItem copy)
        {
            if (inventory == null || inventory.content == null) return;
            // Remove all exact references before recalculating: even a failed
            // weight refresh must not leave a soon-destroyed item in the save.
            int removed = inventory.content.RemoveAll(item => ReferenceEquals(item, copy));
            if (removed != 0)
                try { inventory.RecaculateWaght(); } catch { }
        }
    }
}
