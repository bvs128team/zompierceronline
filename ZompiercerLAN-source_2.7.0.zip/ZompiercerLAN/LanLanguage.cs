using BepInEx.Configuration;

namespace ZompiercerLAN
{
    internal static class LanLanguage
    {
        private static ConfigEntry<string> _entry;

        internal static void Initialize(ConfigEntry<string> entry)
        {
            _entry = entry;
            string language = LanText.NormalizeLanguage(entry.Value);
            LanText.English = language == "en";
            if (entry.Value != language) entry.Value = language;
        }

        internal static void Toggle()
        {
            LanText.English = !LanText.English;
            if (_entry != null) _entry.Value = LanText.English ? "en" : "ru";
        }
    }
}
