using System;
using System.Collections.Generic;
using Zompiercer;

namespace ZompiercerLAN
{
    internal static class LanTimedBuffGame
    {
        internal static object[] Capture()
        {
            var global = LanGame.Stats;
            if (global == null) return null;
            var native = global.Save();
            var result = new List<object>();
            if (native != null && native.Length == 1 && native[0] is SaveBuff[])
                foreach (var b in (SaveBuff[])native[0])
                    if (LanTimedBuffs.Type((int)b.buffType) && b.remainingTime > 0)
                        result.Add(new object[] { (int)b.buffType, b.currentValue, b.currentAddValue, Math.Min(b.remainingTime, LanTimedBuffs.MaxTime) });
            var rows = result.ToArray(); LanTimedBuffs.Validate(rows); return rows;
        }
        internal static void Clear()
        {
            var global = LanGame.Stats;
            if (global == null) return;
            var saved = Capture();
            if (saved != null) foreach (object[] row in saved) global.StopBuff((EBuffType)(int)row[0]);
        }
        internal static object[] Native(object value)
        {
            LanTimedBuffs.Validate(value);
            var rows = value as object[];
            if (rows == null) return null;
            var native = new SaveBuff[rows.Length];
            for (int i = 0; i < rows.Length; i++)
            {
                var r = (object[])rows[i];
                native[i] = new SaveBuff { buffType = (EBuffType)(int)r[0], currentValue = (float)r[1],
                    currentAddValue = (float)r[2], remainingTime = (float)r[3] };
            }
            return new object[] { native };
        }
        // Values exposed by GetCurrentValue after AddBuff, established from native IL.
        internal static object[] Sources(Buff[] buffs)
        {
            var rows = new List<object>();
            var seen = new HashSet<int>();
            if (buffs != null) foreach (var b in buffs)
            {
                int type = (int)b.buffType;
                if (!LanTimedBuffs.Type(type) || b.timer <= 0 || !seen.Add(type)) continue;
                float value;
                switch (type)
                {
                    case 1: case 5: case 21: case 28: value = 1f - b.value / 100f; break;
                    case 2: case 4: case 6: case 7: value = 1f + b.value / 100f; break;
                    case 8: value = -10f; break;
                    case 22: case 27: value = b.value; break;
                    case 3: case 9: case 23: case 26: value = 1f; break;
                    default: continue; // need-triggered effects are not item/attack grants
                }
                rows.Add(new object[] { type, value, -1f, Math.Min(b.timer, LanTimedBuffs.MaxTime) });
            }
            var result = rows.ToArray(); LanTimedBuffs.Validate(result); return result;
        }
    }
}
