using System;

namespace ZompiercerLAN
{
    // Scalar checks of a consumable's shipped visible bounds, kept free of Unity calls so its scale and rejection rules
    // can be checked without opening the game. 2.7.0: the grip, the mouth contact and the support come from
    // RemoteHoldPose; only the size is measured here.
    internal static class RemoteConsumablePose
    {
        // The display scale: at most 30 cm long, never enlarged. False for bounds no hand can hold.
        internal static bool TryMeasure(float minX, float minY, float minZ, float maxX, float maxY, float maxZ, out float scale)
        {
            scale = 0f;
            if (!Finite(minX) || !Finite(minY) || !Finite(minZ) ||
                !Finite(maxX) || !Finite(maxY) || !Finite(maxZ)) return false;
            float width = maxX - minX, height = maxY - minY, depth = maxZ - minZ;
            if (width < 0f || height < 0f || depth < 0f) return false;
            float longest = Math.Max(width, Math.Max(height, depth));
            if (longest < .005f || longest > 10f) return false;
            scale = Math.Min(1f, .3f / longest);
            return true;
        }

        private static bool Finite(float value)
        { return !float.IsNaN(value) && !float.IsInfinity(value); }
    }
}
