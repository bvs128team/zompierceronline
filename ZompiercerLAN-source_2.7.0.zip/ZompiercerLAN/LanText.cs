using System;
using System.Collections.Generic;

namespace ZompiercerLAN
{
    // Only explicit mod-owned text is passed here. Player text and native game
    // names are never searched, split, or replaced by the localization layer.
    internal static partial class LanText
    {
        private static readonly Dictionary<string, string> Translations = CreateTranslations();
        private static volatile bool _english;
        internal static bool English { get { return _english; } set { _english = value; } }

        internal static string T(string russian)
        {
            if (!_english || russian == null) return russian;
            string english;
            return Translations.TryGetValue(russian, out english) ? english : russian;
        }

        internal static string[] T(string[] russian)
        {
            if (russian == null) return null;
            var result = new string[russian.Length];
            for (int i = 0; i < result.Length; i++) result[i] = T(russian[i]);
            return result;
        }

        internal static string NormalizeLanguage(string language)
        { return string.Equals(language, "en", StringComparison.OrdinalIgnoreCase) ? "en" : "ru"; }

        private static Dictionary<string, string> CreateTranslations()
        {
            var result = new Dictionary<string, string>(StringComparer.Ordinal);
            AddMain(result);
            AddGameplay(result);
            AddOther(result);
            return result;
        }
    }
}
