using System;
using System.IO;

namespace ZompiercerLAN
{
    // Local checkpoint envelope: independent bounded primitive sections. Network
    // profile/value-codec limits remain unchanged. One atomic sidecar holds all sections.
    internal static class LanGuestCheckpointCodec
    {
        private const uint Magic = 0x33534A5A;
        internal const int MaxBytes = 16 + 3 * LanValueCodec.MaxBytes;
        internal static byte[] Encode(object[] root)
        {
            if(root==null || root.Length!=10 || !(root[8] is object[]) || !(root[9] is object[])) throw new InvalidDataException("Checkpoint sections");
            var header=new object[8]; Array.Copy(root,header,8);
            using(var stream=new MemoryStream()) using(var writer=new BinaryWriter(stream)) {
                writer.Write(Magic);
                foreach(var part in new[]{header,(object[])root[8],(object[])root[9]}) {
                    var bytes=LanValueCodec.Encode(part); writer.Write(bytes.Length); writer.Write(bytes);
                }
                if(stream.Length>MaxBytes) throw new InvalidDataException("Checkpoint size");
                return stream.ToArray();
            }
        }
        internal static object[] Decode(byte[] bytes)
        {
            if(bytes==null || bytes.Length<4) throw new InvalidDataException("Checkpoint header");
            using(var stream=new MemoryStream(bytes,false)) using(var reader=new BinaryReader(stream)) {
                if(reader.ReadUInt32()!=Magic) return LanValueCodec.Decode(bytes); // legacy v1/v2 and early v3
                if(bytes.Length>MaxBytes) throw new InvalidDataException("Checkpoint size");
                var parts=new object[3][];
                for(int i=0;i<3;i++) {
                    int count=reader.ReadInt32();
                    if(count<1 || count>LanValueCodec.MaxBytes || count>stream.Length-stream.Position) throw new InvalidDataException("Checkpoint section size");
                    parts[i]=LanValueCodec.Decode(reader.ReadBytes(count));
                }
                if(stream.Position!=stream.Length || parts[0].Length!=8) throw new InvalidDataException("Checkpoint trailing data");
                var root=new object[10]; Array.Copy(parts[0],root,8); root[8]=parts[1]; root[9]=parts[2]; return root;
            }
        }
    }
}
