using System;

namespace ZompiercerLAN
{
    // Native ZombieAttackRays: normalize(delta) * (10 - length(delta)) * strength.
    // Pure arithmetic so malformed prefab values cannot put NaN or unbounded force on the wire.
    internal static class LanPowerfulHit
    {
        internal static bool TryCreate(float x, float y, float z, float strength, float duration,
            out float px, out float py, out float pz, out float stun)
        {
            px = py = pz = stun = 0;
            if (!Finite(x) || !Finite(y) || !Finite(z) || !Finite(strength) || !Finite(duration) || strength < 0 || duration < 0) return false;
            double length = Math.Sqrt((double)x * x + (double)y * y + (double)z * z);
            if (length > 20) return false; // Far beyond a melee reach: never manufacture a backwards long-range punch.
            if (length > .00001)
            {
                double magnitude = Math.Max(-LanProtocol.MaxChargePush, Math.Min(LanProtocol.MaxChargePush, (10 - length) * strength));
                px = (float)(x / length * magnitude); py = (float)(y / length * magnitude); pz = (float)(z / length * magnitude);
                // Float rounding on a vector exactly at the limit must not make its own decoder reject it.
                double squared = (double)px * px + (double)py * py + (double)pz * pz;
                if (squared > (double)LanProtocol.MaxChargePush * LanProtocol.MaxChargePush)
                {
                    double scale = (LanProtocol.MaxChargePush - .0001) / Math.Sqrt(squared);
                    px = (float)(px * scale); py = (float)(py * scale); pz = (float)(pz * scale);
                }
            }
            stun = Math.Min(duration, LanProtocol.MaxPowerfulStun);
            return LanProtocol.ValidPush(px, py, pz) && LanProtocol.ValidPowerfulStun(stun);
        }
        private static bool Finite(float value) { return !float.IsNaN(value) && !float.IsInfinity(value); }
    }
}
