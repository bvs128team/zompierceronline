using System;

namespace ZompiercerLAN
{
    // Application RTT, including transport and dispatch delay. Main thread only.
    // The link must authenticate/session-check and establish before calling this.
    // Create a fresh instance for every secure session, never for world changes.
    internal sealed class LanLatencyChannel
    {
        internal const int Unknown = -1, MaxMilliseconds = 3000;
        internal const double FreshSeconds = 5;
        private readonly bool _hosting;
        private readonly Action<Packet> _send;
        private ulong _nextNonce, _pending, _lastProbe, _reportSequence, _lastReport;
        private double _now = -1, _sent, _nextProbe, _nextEcho, _nextReport, _measuredAt = -1, _reportAt = -1;
        private int _milliseconds = Unknown;
        private LatencySeat[] _report = new LatencySeat[0];

        internal LanLatencyChannel(bool hosting, Action<Packet> send)
        { _hosting = hosting; _send = send ?? throw new ArgumentNullException(nameof(send)); }

        // Reject backwards/non-finite clocks without moving deadlines or manufacturing samples.
        private bool Advance(double now)
        {
            if(double.IsNaN(now) || double.IsInfinity(now) || now < 0 || now < _now) return false;
            _now = now;
            if(_pending != 0 && now - _sent > 3) _pending = 0;
            return true;
        }

        internal int Milliseconds(double now)
        {
            return ValidAge(now, _measuredAt) ? _milliseconds : Unknown;
        }
        private static bool ValidAge(double now, double at)
        { return !double.IsNaN(now) && !double.IsInfinity(now) && at >= 0 && now >= at && now - at <= FreshSeconds; }

        internal int ReportedMilliseconds(byte slot, ulong session, double now)
        {
            if(_hosting || session == 0 || !ValidAge(now, _reportAt)) return Unknown;
            foreach(var seat in _report)
                if(seat.Slot == slot && seat.Session == session) return seat.Milliseconds;
            return Unknown;
        }
        internal LatencySeat[] ReportedSeats(double now)
        { return !_hosting && ValidAge(now, _reportAt) ? (LatencySeat[])_report.Clone() : new LatencySeat[0]; }

        internal void Tick(double now, Func<LatencySeat[]> hostReport = null)
        {
            if(!Advance(now)) return;
            if(_pending == 0 && now >= _nextProbe && _nextNonce != ulong.MaxValue) {
                _pending = ++_nextNonce; _sent = now; _nextProbe = now + 1;
                _send(new Packet { Kind = PacketKind.Latency, Action = 1, LatencyNonce = _pending });
            }
            if(_hosting && hostReport != null && now >= _nextReport && _reportSequence != ulong.MaxValue) {
                _nextReport = now + 1;
                var packet = new Packet { Kind = PacketKind.Latency, Action = 3,
                    LatencyNonce = ++_reportSequence, LatencySeats = hostReport() };
                if(LanProtocol.ValidLatency(packet)) _send(packet);
            }
        }

        internal void Receive(Packet packet, double now)
        {
            if(!LanProtocol.ValidLatency(packet) || (_hosting && packet.Action == 3) || !Advance(now)) return;
            if(packet.Action == 1) {
                if(packet.LatencyNonce <= _lastProbe) return;
                // Remember even a throttled probe: duplicate traffic cannot cause later echoes.
                _lastProbe = packet.LatencyNonce;
                if(now < _nextEcho) return;
                _nextEcho = now + .5;
                _send(new Packet { Kind = PacketKind.Latency, Action = 2, LatencyNonce = packet.LatencyNonce });
            } else if(packet.Action == 2) {
                if(_pending == 0 || packet.LatencyNonce != _pending) return;
                _milliseconds = Math.Min(MaxMilliseconds, (int)Math.Round((now - _sent) * 1000));
                _measuredAt = now; _pending = 0;
            } else if(!_hosting && packet.LatencyNonce > _lastReport) {
                _lastReport = packet.LatencyNonce; _reportAt = now;
                _report = (LatencySeat[])packet.LatencySeats.Clone();
            }
        }
    }
}
