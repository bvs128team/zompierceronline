using UnityEngine;

namespace ZompiercerLAN
{
    // 2.0.0: everything this game knows and shows of one other player: its last state, the host's
    // checks of its moves, and its avatar. The plugin holds one per other player (one partner until
    // the network carries more).
    internal sealed class RemotePlayer
    {
        // Its slot (0: the host, 1..3: guests) and nickname (empty: none).
        internal readonly int Slot;
        internal string Name = "";
        internal RemotePlayer(int slot) { Slot = slot; }
        // Its states: the last sequence, whether one came, when, where (the world, or a car's space).
        internal uint Sequence;
        internal bool HaveState;
        internal float StateAt;
        internal string Scene;
        internal Vector3 Position, LocalPosition;
        internal float Yaw, LocalYaw, TrainPosition;
        internal int CarIndex = -1;
        // Host: how far its next state may move it, when that was counted; refused states (and their log).
        internal float MoveBudget, MoveBudgetAt, RejectedSince = -1f, RejectLogAt = -10f;
        // Host: where its shots come from relative to where it says it stands.
        internal Vector3 CombatOffset;
        // 1.0.8: its health in percent (LanProtocol.NoHealth: not known); 1.1.6: as its own bar shows it
        // (max 0: unknown), and the look it chose (LanProtocol.NoSkin: the default).
        internal byte Health = LanProtocol.NoHealth;
        internal ushort HealthNow, HealthMax;
        internal byte Skin = LanProtocol.NoSkin;
        // What it holds, its shots and swings, the item they were made with.
        internal int EquippedItem = -1, ShotItem = -1;
        internal uint ShotSequence;
        // 1.0.9: its ground speed (m/s, smoothed); 1.1.0: where it looks up (+) or down (degrees),
        // crouching, aiming; 1.1.9: downed or dead, its flashlights, a reload.
        internal float Speed, Pitch;
        internal bool Crouch, Aim, Downed, Dead, HelmetLight, GunLight, Reload;
        // 1.4.7: its motion flags, throws and (1.4.8) presses of the use key; what is still to show.
        internal byte MotionFlags, Throws, Interacts;
        internal bool ThrowPending, FlinchPending, InteractPending;
        internal int ShownPunches;
        // Its avatar: the model and the look it was made with (and when), how high it stands, its
        // animators and helpers; whether it lies (downed or dead); a ladder climb's start.
        internal GameObject Avatar;
        internal byte AvatarSkin = LanProtocol.NoSkin;
        internal float AvatarCreatedAt = -100f, AvatarYOffset;
        internal Animator Animator;
        internal RemoteAvatarMotion Motion;
        internal RemoteAvatarExtras Extras;
        // 2.3.0: what it wears (its state's Outfit) and the avatar's worn models.
        internal ushort[] Outfit;
        internal RemoteOutfitVisual Wear;
        // 2.4.0: the mods on the weapon in its hands (its state's HandMods).
        internal ushort[] HandMods;
        internal RemoteEquipmentVisual Equipment;
        internal bool Lying;
        internal Vector3 ClimbFrom;
        internal int ClimbCar = -1;
        // 1.4.6: its positions on its own clock, and when the log last told how far behind it is shown.
        internal readonly PlayerPoseBuffer Poses = new PlayerPoseBuffer();
        internal float NextDelayLog;

        // Where it stands in this world now (its car may have moved on since its state).
        internal Vector3 WorldPosition()
        {
            var car = CarIndex < 0 ? null : TrainSync.GetCar(CarIndex);
            return car == null ? Position : car.transform.TransformPoint(LocalPosition);
        }
    }
}
