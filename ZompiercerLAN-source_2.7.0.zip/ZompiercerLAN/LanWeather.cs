using System;
using HarmonyLib;
using UnityEngine;

namespace ZompiercerLAN
{
    // One weather for everyone (2.4.2): the host's. The game's WeatherManager picks a random weather on its own timer
    // (Update -> SetRandomWeather -> Enviro's ChangeWeather) in every game, so a guest had its own sky, clouds and
    // rain. Host: the name of the weather its sky shows (EnviroSkyMgr's current preset) goes with the world state.
    // Guest: while it plays in the host's world its own timer is held (WeatherManager.Update skipped), and its sky
    // turns to the host's weather the way the game turns it: smoothly, at once the first time. Only a weather its own
    // WeatherManager knows by that name is used; whatever changes it back (a scene's start), the next world state
    // turns it to the host's again. Main thread only.
    internal static class LanWeather
    {
        private static Harmony _harmony;
        private static Action<string> _log;
        internal static string Failure { get; private set; }
        // Guest: in the host's world (its own random weather held).
        internal static bool GuestHeld;
        private static WeatherManager _manager;
        private static string _applied;
        private static float _appliedAt = -100f;
        private static bool _unknownLogged;

        internal static void Initialize(Action<string> log)
        {
            _log = log;
            if (_harmony != null || Failure != null) return;
            _harmony = new Harmony("local.zompiercer.lan.weather");
            try
            {
                _harmony.Patch(AccessTools.Method(typeof(WeatherManager), "Update"), prefix: new HarmonyMethod(typeof(LanWeather), nameof(UpdatePrefix)));
            }
            catch (Exception ex)
            {
                // Without it the guest keeps its own weather, as before 2.4.2.
                Failure = ex.GetType().Name + ": " + ex.Message;
                _harmony.UnpatchSelf();
                log("Shared weather unavailable: " + Failure);
            }
        }
        internal static void Shutdown() { GuestRestore(); _harmony?.UnpatchSelf(); _harmony = null; }

        private static bool UpdatePrefix() { return !GuestHeld || Failure != null; }

        // Host: the weather its sky shows, or null.
        internal static string Capture()
        {
            if (Failure != null) return null;
            try
            {
                var sky = EnviroSkyMgr.instance;
                var preset = sky == null ? null : sky.GetCurrentWeatherPreset();
                string name = preset != null ? preset.Name : WeatherManager.Global != null ? WeatherManager.Global.CurrentWeatherName : null;
                return LanProtocol.ValidWeather(name) ? name : null;
            }
            catch (Exception) { return null; }
        }

        // Guest: with every world state; the host's weather if its own sky shows another (at most every 2 s).
        internal static void GuestApply(string name)
        {
            if (Failure != null || !GuestHeld || name == null || !LanProtocol.ValidWeather(name)) return;
            try
            {
                var manager = WeatherManager.Global;
                var sky = EnviroSkyMgr.instance;
                if (manager == null || sky == null) return;
                if (manager != _manager) { _manager = manager; _applied = null; }
                var current = sky.GetCurrentWeatherPreset();
                if (current != null && current.Name == name) { _applied = name; return; }
                float now = Time.unscaledTime;
                if (_applied != null && now - _appliedAt < 2f) return;
                if (manager.FindWeatherPresetWithName(name) == null)
                {
                    if (!_unknownLogged) { _unknownLogged = true; _log?.Invoke("Host weather '" + name + "' is not one of this game's; the guest keeps its own"); }
                    return;
                }
                bool first = _applied == null;
                _applied = name; _appliedAt = now;
                manager.CurrentWeatherName = name;
                if (first) manager.SetWeatherInstant(name); else manager.SetWeather(name);
                _log?.Invoke("Weather as the host's: " + name + (first ? " (at once)" : ""));
            }
            catch (Exception ex)
            {
                Failure = ex.GetType().Name + ": " + ex.Message;
                _log?.Invoke("Shared weather off: " + Failure);
            }
        }

        // The guest left the host's world: its own weather timer runs again from the weather it has.
        internal static void GuestRestore() { GuestHeld = false; _manager = null; _applied = null; _appliedAt = -100f; }
    }
}
