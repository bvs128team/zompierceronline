using System;
using System.Collections.Generic;

namespace ZompiercerLAN
{
    internal sealed class LanSleepIntent
    {
        internal uint Attempt { get; private set; }
        private bool _active;
        internal uint Begin()
        {
            if (Attempt == uint.MaxValue) throw new InvalidOperationException("Sleep attempt counter exhausted");
            _active = true; return ++Attempt;
        }
        internal void Cancel() { _active = false; }
        internal bool TryStart(uint attempt)
        {
            if (!_active || attempt != Attempt) return false;
            _active = false; return true;
        }
    }

    // Sleep messages describe the latest state of one player. A newer state supersedes
    // older states of that player, never those of another player relayed by the host.
    // Main thread only; world/session validation belongs to the link before Receive.
    internal sealed class LanSleepChannel
    {
        internal const double RetrySeconds = .5;
        internal const int MaxAttempts = 20;
        private sealed class Outgoing { internal Packet Packet; internal double Next; internal int Attempts; }
        private readonly Action<Packet> _send;
        private readonly Dictionary<byte, Outgoing> _pending = new Dictionary<byte, Outgoing>();
        private readonly Dictionary<byte, uint> _received = new Dictionary<byte, uint>();
        private readonly Dictionary<byte, uint> _acks = new Dictionary<byte, uint>();
        private uint _sequence;
        internal bool Failed { get; private set; }
        internal int Pending { get { return _pending.Count; } }
        internal LanSleepChannel(Action<Packet> send) { _send = send ?? throw new ArgumentNullException(nameof(send)); }

        internal bool Send(byte action, int hours, byte player, uint attempt, double now)
        {
            if (Failed || !LanProtocol.ValidPlayer(player) || attempt == 0 ||
                (action != LanProtocol.SleepWait && action != LanProtocol.SleepCancel && action != LanProtocol.SleepStart) ||
                (action == LanProtocol.SleepCancel ? hours != 0 : hours < 1 || hours > LanProtocol.MaxSleepHours)) return false;
            if (_sequence == uint.MaxValue) { Failed = true; return false; }
            _pending[player] = new Outgoing { Packet = new Packet { Kind = PacketKind.Sleep,
                Sequence = ++_sequence, Player = player, Action = action, Revision = hours, SleepAttempt = attempt } };
            Tick(now);
            return !Failed;
        }

        // True exactly once for a newly observed state. ACK packets are never delivered.
        internal bool Receive(Packet packet)
        {
            if (packet == null || Failed || packet.Sequence == 0) return false;
            if (packet.Kind == PacketKind.SleepAck)
            {
                byte? done = null;
                foreach (var pair in _pending)
                    if (pair.Value.Packet.Sequence == packet.Sequence) { done = pair.Key; break; }
                if (done.HasValue) _pending.Remove(done.Value);
                return false;
            }
            if (packet.Kind != PacketKind.Sleep || !LanProtocol.ValidPlayer(packet.Player)) return false;
            uint last; _received.TryGetValue(packet.Player, out last);
            _acks[packet.Player] = Math.Max(last, packet.Sequence);
            if (packet.Sequence <= last) return false;
            _received[packet.Player] = packet.Sequence;
            return true;
        }

        internal void Tick(double now)
        {
            if (Failed) return;
            var acks = new List<uint>(_acks.Values);
            _acks.Clear();
            foreach (uint sequence in acks) _send(new Packet { Kind = PacketKind.SleepAck, Sequence = sequence });
            // Snapshot permits synchronous ACKs or new states from a test/in-process transport.
            foreach (var item in new List<Outgoing>(_pending.Values))
            {
                Outgoing current;
                if (!_pending.TryGetValue(item.Packet.Player, out current) || current != item || now < item.Next) continue;
                if (item.Attempts >= MaxAttempts) { Failed = true; return; }
                item.Attempts++; item.Next = now + RetrySeconds;
                _send(item.Packet);
            }
        }

        // World transitions abandon pending work but keep ordering barriers. Only an
        // authenticated new secure session may restart sequence numbers on both ends.
        internal void Reset(bool newSession = false)
        {
            _pending.Clear(); _acks.Clear(); Failed = false;
            if (newSession) { _sequence = 0; _received.Clear(); }
        }
    }
}
