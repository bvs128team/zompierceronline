# Checks that every .NET method the built mod calls exists in the game's own Mono class libraries
# (Zompiercer_Data\Managed) and is not one of Mono's stubs that only throws NotImplementedException or
# PlatformNotSupportedException. The security checks run under .NET, where such members work: 2.0.4-2.4.5
# read WindowsIdentity.User, a stub in the game's Mono, and the worker cache never worked in the game.
# A virtual call on an unsealed type is skipped (the object's own override runs, e.g. MethodInfo.ReturnType).
#
#   powershell -NoProfile -ExecutionPolicy Bypass -File ZompiercerLAN/tools/check-mono-stubs.ps1 [-GameRoot <folder with Zompiercer.exe>]
#
# Read-only (Cecil). This file is ASCII on purpose (Windows PowerShell 5.1).
param([string]$GameRoot, [string]$ModPath)
$ErrorActionPreference = 'Stop'
$projectRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
if (-not $GameRoot) { $GameRoot = [IO.Path]::GetFullPath((Join-Path $projectRoot '..')) }
if (-not $ModPath) { $ModPath = Join-Path $projectRoot 'bin\Release\net472\ZompiercerLAN.dll' }
Add-Type -LiteralPath (Join-Path $GameRoot 'BepInEx\core\Mono.Cecil.dll')
$managed = Join-Path $GameRoot 'Zompiercer_Data\Managed'
if (-not (Test-Path -LiteralPath (Join-Path $managed 'mscorlib.dll'))) { throw 'The game''s mscorlib.dll was not found under Zompiercer_Data\Managed.' }
$resolver = New-Object Mono.Cecil.DefaultAssemblyResolver
$resolver.AddSearchDirectory($managed)
$resolver.AddSearchDirectory((Join-Path $GameRoot 'BepInEx\core'))
$read = New-Object Mono.Cecil.ReaderParameters
$read.AssemblyResolver = $resolver
$mod = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($ModPath, $read)
$framework = @('mscorlib', 'System', 'System.Core', 'System.Security', 'System.Xml', 'System.Xml.Linq', 'System.Net.Http', 'System.Numerics', 'System.Data', 'System.Configuration')

function Test-Stub($method) {
    if (-not $method.HasBody) { return $false }
    $body = @($method.Body.Instructions | Where-Object { $_.OpCode.Code -ne 'Nop' })
    if ($body.Count -gt 6) { return $false }
    foreach ($i in $body) {
        if ($i.OpCode.Code -eq 'Newobj' -and @('NotImplementedException', 'PlatformNotSupportedException') -contains $i.Operand.DeclaringType.Name) { return $true }
    }
    return $false
}

$seen = @{}
$failures = New-Object System.Collections.Generic.List[string]
foreach ($type in $mod.MainModule.GetTypes()) {
    foreach ($method in $type.Methods) {
        if (-not $method.HasBody) { continue }
        foreach ($i in $method.Body.Instructions) {
            $called = $i.Operand -as [Mono.Cecil.MethodReference]
            if ($null -eq $called) { continue }
            $scope = ($called.DeclaringType.Scope.Name -replace '\.dll$', '')
            if ($framework -notcontains $scope) { continue }
            $key = $called.FullName + '|' + $i.OpCode.Code
            if ($seen.ContainsKey($key)) { $verdict = $seen[$key] }
            else {
                $resolved = $null
                try { $resolved = $called.Resolve() } catch { }
                if ($null -eq $resolved) { $verdict = 'missing in the game''s Mono' }
                elseif ((Test-Stub $resolved) -and -not ($i.OpCode.Code -eq 'Callvirt' -and $resolved.IsVirtual -and -not $resolved.DeclaringType.IsSealed)) { $verdict = 'a stub in the game''s Mono' }
                else { $verdict = '' }
                $seen[$key] = $verdict
            }
            if ($verdict) { $failures.Add(('{0}.{1}: {2} is {3}' -f $type.Name, $method.Name, $called.FullName, $verdict)) }
        }
    }
}
$failures = @($failures | Sort-Object -Unique)
foreach ($failure in $failures) { Write-Output ('FAIL: ' + $failure) }
Write-Output ('Framework calls checked: ' + $seen.Count + ', failures: ' + $failures.Count)
if ($failures.Count) { exit 1 }
