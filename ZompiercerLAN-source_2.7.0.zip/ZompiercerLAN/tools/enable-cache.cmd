@echo off
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "%~dp0Set-Worker-Mode.ps1" -GameRoot "%~dp0." -Mode Cache
set "modeResult=%errorlevel%"
if not "%modeResult%"=="0" echo Failed to switch worker mode. See the error above.
pause
exit /b %modeResult%
