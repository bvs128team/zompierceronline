param(
    [string]$GameRoot = $PSScriptRoot,
    [Parameter(Mandatory=$true)][ValidateSet('Game','Cache')][string]$Mode
)
$ErrorActionPreference = 'Stop'

function Assert-Unlinked([string]$Path) {
    for ($part = [IO.DirectoryInfo][IO.Path]::GetFullPath($Path); $null -ne $part; $part = $part.Parent) {
        $attributes = $null
        try { $attributes = [IO.File]::GetAttributes($part.FullName) }
        catch [IO.FileNotFoundException] { }
        catch [IO.DirectoryNotFoundException] { }
        if ($null -ne $attributes -and ($attributes -band [IO.FileAttributes]::ReparsePoint)) {
            throw 'Linked installation or mode paths are not supported.'
        }
    }
}

if (Get-Process -Name Zompiercer -ErrorAction SilentlyContinue) { throw 'Close Zompiercer before switching worker mode.' }
$root = [IO.Path]::GetFullPath($GameRoot)
$plugins = Join-Path $root 'BepInEx\plugins'
$marker = Join-Path $plugins 'ZompiercerLAN.worker-mode'
Assert-Unlinked $marker
foreach ($required in @('Zompiercer.exe','BepInEx\plugins\ZompiercerLAN.dll','BepInEx\plugins\ZompiercerLAN.Network\ZompiercerLAN.Network.exe')) {
    $path = Join-Path $root $required
    Assert-Unlinked $path
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw 'Install this utility in the Zompiercer game folder containing the LAN mod.' }
}
$exists = Test-Path -LiteralPath $marker
if ($exists) {
    if (-not (Test-Path -LiteralPath $marker -PathType Leaf)) { throw 'Invalid worker mode marker; nothing changed.' }
    $info = Get-Item -LiteralPath $marker -Force
    if ($info.Length -ne 13 -or [Text.Encoding]::ASCII.GetString([IO.File]::ReadAllBytes($marker)) -cne 'user-cache-v1') {
        throw 'Unknown worker mode marker; nothing changed.'
    }
}
$temporary = $null
try {
    if ($Mode -eq 'Cache' -and -not $exists) {
        $temporary = Join-Path $plugins ('ZompiercerLAN.worker-mode.' + [Guid]::NewGuid().ToString('N') + '.tmp')
        $stream = [IO.File]::Open($temporary, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        try { $bytes = [Text.Encoding]::ASCII.GetBytes('user-cache-v1'); $stream.Write($bytes,0,$bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
        [IO.File]::Move($temporary, $marker)
        $temporary = $null
    }
    elseif ($Mode -eq 'Game' -and $exists) { [IO.File]::Delete($marker) }
} catch [UnauthorizedAccessException] {
    throw 'Cannot write the installation folder. Only this setup utility may need administrator permission. Always run the game normally, never as administrator.'
} finally {
    if ($temporary -and [IO.File]::Exists($temporary)) { [IO.File]::Delete($temporary) }
}
if ($Mode -eq 'Cache') {
    Write-Output 'User cache selected. The mod will verify and copy the helper on the next normal online start. Installed originals are retained.'
} else { Write-Output 'Game folder selected (default). Existing user cache is retained and will not be used by this installation.' }
Write-Output 'For direct LAN play, run LAN firewall setup again after switching. No firewall rules were changed by this utility.'
