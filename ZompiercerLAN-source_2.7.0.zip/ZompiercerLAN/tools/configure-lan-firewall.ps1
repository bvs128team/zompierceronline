param(
    [string]$GameRoot,
    [string]$UserLocalAppData,
    [switch]$Plan,
    [switch]$Remove
)
$ErrorActionPreference = 'Stop'

function Get-LanCacheDirectory {
    param([string]$Root, [string]$LocalData)
    if ($LocalData -notmatch '^[A-Za-z]:[\\/]' -or $LocalData.Contains('"')) { throw 'An absolute local user data path is required.' }
    $localRoot = [IO.Path]::GetFullPath($LocalData).TrimEnd('\','/')
    # Reflection-only metadata inspection never runs the installed plugin or its dependencies.
    # Setup explicitly uses Windows PowerShell 5.1, where this API is available.
    if ($PSVersionTable.PSEdition -eq 'Core') { throw 'Use Windows PowerShell 5.1 for LAN setup.' }
    $plugin = Join-Path $Root 'BepInEx\plugins\ZompiercerLAN.dll'
    $assembly = [Reflection.Assembly]::ReflectionOnlyLoadFrom($plugin)
    $pins = $assembly.GetType('ZompiercerLAN.LanWorkerIntegrity', $true)
    $hashes = @()
    foreach ($pair in @(@('Executable','ZompiercerLAN.Network.exe'),@('Crypto','BouncyCastle.Cryptography.dll'),@('Configuration','ZompiercerLAN.Network.exe.config'))) {
        $field = $pins.GetField($pair[0], [Reflection.BindingFlags]'Static,NonPublic,Public')
        if ($null -eq $field -or -not $field.IsLiteral) { throw 'Missing worker integrity metadata.' }
        $expected = [string]$field.GetRawConstantValue()
        if ($expected -notmatch '^[A-Fa-f0-9]{64}$') { throw 'Invalid worker integrity metadata.' }
        $asset = Join-Path $Root ('BepInEx\plugins\ZompiercerLAN.Network\' + $pair[1])
        Assert-LanUnlinkedPath $asset
        if ((Get-FileHash -LiteralPath $asset -Algorithm SHA256).Hash -ne $expected) { throw ('Worker integrity mismatch: ' + $pair[1]) }
        $hashes += $expected.ToUpperInvariant()
    }
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $key = [BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::ASCII.GetBytes(($hashes -join '')))).Replace('-','') }
    finally { $sha.Dispose() }
    return Join-Path $localRoot ('ZompiercerLAN\Network\' + $key)
}

function Test-LanCacheMode([string]$Root) {
    $marker = Join-Path $Root 'BepInEx\plugins\ZompiercerLAN.worker-mode'
    Assert-LanUnlinkedPath $marker
    if (-not (Test-Path -LiteralPath $marker)) { return $false }
    if (-not (Test-Path -LiteralPath $marker -PathType Leaf)) { throw 'Invalid worker mode marker.' }
    $info = Get-Item -LiteralPath $marker -Force
    if ($info.Length -ne 13 -or [Text.Encoding]::ASCII.GetString([IO.File]::ReadAllBytes($marker)) -cne 'user-cache-v1') { throw 'Invalid worker mode marker.' }
    return $true
}

function Assert-LanUnlinkedPath([string]$Path) {
    # Missing cache components are expected before the first normal game launch.
    # Never create the user's cache in an elevated setup process.
    for ($part = [IO.DirectoryInfo][IO.Path]::GetFullPath($Path); $null -ne $part; $part = $part.Parent) {
        $attributes = $null
        try { $attributes = [IO.File]::GetAttributes($part.FullName) }
        catch [IO.FileNotFoundException] { }
        catch [IO.DirectoryNotFoundException] { }
        if ($null -ne $attributes -and ($attributes -band [IO.FileAttributes]::ReparsePoint)) {
            throw 'Linked LAN paths are not supported.'
        }
    }
}

function Assert-LanFirewallRule {
    param($Rule, $App, $Port, $Address, $Interface, $Spec, [string]$Executable, [string]$Package)
    # NetSecurity unwraps a single RemoteAddress into a string on Windows
    # PowerShell 5.1. Index the captured array, never the original string.
    $remoteAddresses = @($Address.RemoteAddress)
    $interfaceNames = ((@($Interface.InterfaceType) -join ',') -replace '\s','') -split ',' | Sort-Object
    $expectedProtocol = $(if ($Spec.Protocol -eq 'UDP') { '17' } else { '6' })
    $checks = @(
        @{ Field='Enabled'; Actual=$Rule.Enabled; Expected='True'; Valid=([string]$Rule.Enabled -eq 'True') },
        @{ Field='Action'; Actual=$Rule.Action; Expected='Allow'; Valid=([string]$Rule.Action -eq 'Allow') },
        @{ Field='Direction'; Actual=$Rule.Direction; Expected='Inbound'; Valid=([string]$Rule.Direction -eq 'Inbound') },
        @{ Field='Profile'; Actual=$Rule.Profile; Expected='Private'; Valid=([string]$Rule.Profile -eq 'Private') },
        @{ Field='EdgeTraversalPolicy'; Actual=$Rule.EdgeTraversalPolicy; Expected='Block'; Valid=([string]$Rule.EdgeTraversalPolicy -eq 'Block') },
        @{ Field='Program'; Actual=$App.Program; Expected=$Executable; Valid=([string]$App.Program -eq $Executable) },
        @{ Field='Package'; Actual=$App.Package; Expected=$Package; Valid=([string]$App.Package -eq $Package) },
        @{ Field='Protocol'; Actual=$Port.Protocol; Expected=$Spec.Protocol; Valid=([string]$Port.Protocol -in @($Spec.Protocol,$expectedProtocol)) },
        @{ Field='RemoteAddress'; Actual=$remoteAddresses; Expected='LocalSubnet'; Valid=($remoteAddresses.Count -eq 1 -and $remoteAddresses[0] -eq 'LocalSubnet') },
        @{ Field='LocalPort'; Actual=$Port.LocalPort; Expected=$Spec.Ports; Valid=((@($Port.LocalPort | Sort-Object) -join ',') -eq (@($Spec.Ports | Sort-Object) -join ',')) },
        @{ Field='InterfaceType'; Actual=$Interface.InterfaceType; Expected='Wired,Wireless'; Valid=(($interfaceNames -join ',') -eq 'Wired,Wireless') }
    )
    $failures = @($checks | Where-Object { -not $_.Valid } | ForEach-Object {
        '{0}: expected [{1}], actual [{2}]' -f $_.Field, (@($_.Expected) -join ', '), (@($_.Actual) -join ', ')
    })
    if ($failures.Count -gt 0) {
        throw ('Firewall rule verification failed for {0}: {1}' -f $Spec.Name, ($failures -join '; '))
    }
}

if ([string]::IsNullOrWhiteSpace($GameRoot)) {
    if (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'Zompiercer.exe')) { $GameRoot = $PSScriptRoot }
    else { $GameRoot = Join-Path $PSScriptRoot '../..' }
}
$lanRoot = [IO.Path]::GetFullPath($GameRoot).TrimEnd('\','/')
$lanSourceDirectory = Join-Path $lanRoot 'BepInEx\plugins\ZompiercerLAN.Network'
if (-not (Test-Path -LiteralPath (Join-Path $lanRoot 'Zompiercer.exe') -PathType Leaf) -or
    -not (Test-Path -LiteralPath (Join-Path $lanSourceDirectory 'ZompiercerLAN.Network.exe') -PathType Leaf)) { throw 'Install Zompiercer LAN into the game directory first.' }
$lanUseCache = Test-LanCacheMode $lanRoot
if ([string]::IsNullOrWhiteSpace($UserLocalAppData)) {
    if ($lanUseCache -and -not $Plan) { throw 'Run Setup-LAN.ps1 normally so it can preserve the player user before Windows elevation.' }
    $UserLocalAppData = [Environment]::GetFolderPath('LocalApplicationData')
}
Assert-LanUnlinkedPath (Join-Path $lanRoot 'BepInEx\plugins\ZompiercerLAN.dll')
# Always verify source assets, including when the selected path is the installation.
$lanCacheDirectory = Get-LanCacheDirectory -Root $lanRoot -LocalData $UserLocalAppData
$lanDirectory = if ($lanUseCache) { $lanCacheDirectory } else { $lanSourceDirectory }
Assert-LanUnlinkedPath $lanDirectory
$lanExecutable = Join-Path $lanDirectory 'ZompiercerLAN.Network.exe'
Assert-LanUnlinkedPath $lanExecutable

# Use the same canonical path-derived AppContainer identity as the launcher.
# Deriving the SID does not create a profile or grant privileges.
if (-not ('LanFirewallSid' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
using System.Security.Principal;
public static class LanFirewallSid {
    [DllImport("userenv.dll", CharSet=CharSet.Unicode)] private static extern int DeriveAppContainerSidFromAppContainerName(string name, out IntPtr sid);
    [DllImport("advapi32.dll")] private static extern IntPtr FreeSid(IntPtr sid);
    public static string Derive(string name) {
        IntPtr sid;
        int hr = DeriveAppContainerSidFromAppContainerName(name, out sid);
        if (hr < 0) Marshal.ThrowExceptionForHR(hr);
        try { return new SecurityIdentifier(sid).Value; } finally { FreeSid(sid); }
    }
}
'@
}
function Get-LanRuleSet([string]$Directory) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { $digest = [BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Directory.ToUpperInvariant()))).Replace('-','') }
    finally { $sha.Dispose() }
    $prefix = 'ZompiercerLAN.Private.' + $digest.Substring(0,16)
    [pscustomobject]@{
        Executable = (Join-Path $Directory 'ZompiercerLAN.Network.exe')
        Package = [LanFirewallSid]::Derive('ZompiercerLAN.' + $digest.Substring(0,40))
        Specs = @(
            @{ Name = $prefix + '.UDP'; Protocol = 'UDP'; Ports = @('27776','27777','27779','27781','27783','27785','27787','27789') },
            @{ Name = $prefix + '.TCP'; Protocol = 'TCP'; Ports = @('27778') }
        )
    }
}
$lanSelected = Get-LanRuleSet $lanDirectory
$lanPackage = $lanSelected.Package
$lanRuleSpecs = $lanSelected.Specs
# 2.4.5: the rules of the other worker location (the game folder or this version's cache) never stay behind: setting
# LAN up after switching the worker mode takes them away, and so does removal (before, removal took only the current
# location's rules, and the other one's stayed after a switch).
$lanOther = Get-LanRuleSet $(if ($lanUseCache) { $lanSourceDirectory } else { $lanCacheDirectory })
if ($Plan) {
    foreach ($lanSpec in $lanRuleSpecs) {
        [pscustomobject]@{Name=$lanSpec.Name;Program=$lanExecutable;Package=$lanPackage;Direction='Inbound';Profile='Private';Protocol=$lanSpec.Protocol;LocalPort=$lanSpec.Ports;RemoteAddress='LocalSubnet';InterfaceType=@('Wired','Wireless');EdgeTraversal='Block';Action= $(if($Remove){'Remove owned rule'}else{'Allow'})}
    }
    foreach ($lanSpec in $lanOther.Specs) {
        [pscustomobject]@{Name=$lanSpec.Name;Program=$lanOther.Executable;Package=$lanOther.Package;Direction='Inbound';Profile='Private';Protocol=$lanSpec.Protocol;LocalPort=$lanSpec.Ports;RemoteAddress='LocalSubnet';InterfaceType=@('Wired','Wireless');EdgeTraversal='Block';Action='Remove other location rule'}
    }
    return
}
$lanIdentity = [Security.Principal.WindowsIdentity]::GetCurrent()
$lanPrincipal = New-Object Security.Principal.WindowsPrincipal($lanIdentity)
if (-not $lanPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Windows administrator permission is required only for firewall setup. Run the LAN setup command and accept the Windows prompt; run the game normally.'
}
Import-Module NetSecurity
$lanSetupLog = Join-Path $lanRoot 'LAN-firewall-setup.log'
if ((Test-Path -LiteralPath $lanSetupLog) -and ((Get-Item -LiteralPath $lanSetupLog).Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Linked setup log is not supported.' }
Start-Transcript -LiteralPath $lanSetupLog -Append | Out-Null
foreach ($lanSpec in $lanOther.Specs) {
    $lanStale = Get-NetFirewallRule -PolicyStore PersistentStore -Name $lanSpec.Name -ErrorAction SilentlyContinue
    if ($lanStale) { $lanStale | Remove-NetFirewallRule }
}
foreach ($lanSpec in $lanRuleSpecs) {
    $lanExisting = Get-NetFirewallRule -PolicyStore PersistentStore -Name $lanSpec.Name -ErrorAction SilentlyContinue
    if ($Remove) {
        if ($lanExisting) { $lanExisting | Remove-NetFirewallRule }
        continue
    }
    $lanParameters = @{
        Name=$lanSpec.Name;DisplayName=('Zompiercer LAN - Private ' + $lanSpec.Protocol);Group='ZompiercerLAN private network';
        Description='Only this isolated Zompiercer LAN worker, on a private wired/Wi-Fi local subnet.';
        Program=$lanExecutable;Package=$lanPackage;Direction='Inbound';Action='Allow';Enabled='True';Profile='Private';
        Protocol=$lanSpec.Protocol;LocalPort=$lanSpec.Ports;RemoteAddress='LocalSubnet';
        InterfaceType=@('Wired','Wireless');EdgeTraversalPolicy='Block';PolicyStore='PersistentStore'
    }
    if ($lanExisting) {
        $lanParameters.Remove('Group')
        $lanParameters.Remove('DisplayName')
        $lanParameters.NewDisplayName = 'Zompiercer LAN - Private ' + $lanSpec.Protocol
        Set-NetFirewallRule @lanParameters | Out-Null
    }
    else { New-NetFirewallRule @lanParameters | Out-Null }
}
if (-not $Remove) {
    foreach ($lanSpec in $lanRuleSpecs) {
        $lanRule = Get-NetFirewallRule -PolicyStore PersistentStore -Name $lanSpec.Name
        $lanApp = $lanRule | Get-NetFirewallApplicationFilter
        $lanPort = $lanRule | Get-NetFirewallPortFilter
        $lanAddress = $lanRule | Get-NetFirewallAddressFilter
        $lanInterface = $lanRule | Get-NetFirewallInterfaceTypeFilter
        Assert-LanFirewallRule -Rule $lanRule -App $lanApp -Port $lanPort -Address $lanAddress -Interface $lanInterface -Spec $lanSpec -Executable $lanExecutable -Package $lanPackage
    }
}
Write-Output $(if($Remove){'Zompiercer LAN rules removed.'}else{'Zompiercer LAN private-network rules configured and verified. Start the game normally.'})
Stop-Transcript | Out-Null
