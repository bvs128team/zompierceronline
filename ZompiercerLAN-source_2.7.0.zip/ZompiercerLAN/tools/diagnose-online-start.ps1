param([Parameter(Mandatory=$true)][string]$GameRoot, [string]$SteamRoot)
$ErrorActionPreference = 'Stop'
# Read-only. Does not launch/stop the game, change registry, ACLs, UAC or firewall.
$gamePath = [IO.Path]::GetFullPath((Join-Path $GameRoot 'Zompiercer.exe'))
if (-not (Test-Path -LiteralPath $gamePath -PathType Leaf)) { throw 'Zompiercer.exe not found in GameRoot.' }
if (-not $SteamRoot) {
    $steamKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Software\Valve\Steam')
    try { if ($steamKey) { $SteamRoot = [string]$steamKey.GetValue('SteamPath', '') } }
    finally { if ($steamKey) { $steamKey.Dispose() } }
}
if (-not ('LanElevationDiagnostic' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
public static class LanElevationDiagnostic {
    [DllImport("kernel32.dll", SetLastError=true)] static extern IntPtr OpenProcess(uint access, bool inherit, int pid);
    [DllImport("advapi32.dll", SetLastError=true)] static extern bool OpenProcessToken(IntPtr process, uint access, out IntPtr token);
    [DllImport("advapi32.dll", SetLastError=true)] static extern bool GetTokenInformation(IntPtr token, int info, out int value, int length, out int required);
    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
    public static bool Elevated(int pid) {
        IntPtr process = OpenProcess(0x1000, false, pid), token = IntPtr.Zero;
        if (process == IntPtr.Zero) throw new Win32Exception(Marshal.GetLastWin32Error());
        try {
            if (!OpenProcessToken(process, 8, out token)) throw new Win32Exception(Marshal.GetLastWin32Error());
            int value, required;
            if (!GetTokenInformation(token, 20, out value, 4, out required)) throw new Win32Exception(Marshal.GetLastWin32Error());
            return value != 0;
        } finally { if (token != IntPtr.Zero) CloseHandle(token); CloseHandle(process); }
    }
}
'@
}
Write-Output 'Read-only online startup diagnosis. No settings are changed.'
foreach ($name in @('Zompiercer','steam')) {
    $processes = @([Diagnostics.Process]::GetProcessesByName($name))
    if (-not $processes.Count) { Write-Output "$name process: not running (do not launch it just for this check)." }
    foreach ($process in $processes) {
        try { Write-Output ("{0} pid={1}: elevated={2}" -f $name,$process.Id,[LanElevationDiagnostic]::Elevated($process.Id)) }
        catch { Write-Output ("{0} pid={1}: elevation UNKNOWN ({2})" -f $name,$process.Id,$_.Exception.GetType().Name) }
        finally { $process.Dispose() }
    }
}
$targets = @{ Zompiercer = $gamePath }
if ($SteamRoot) { $targets.Steam = [IO.Path]::GetFullPath((Join-Path $SteamRoot 'steam.exe')) }
foreach ($view in @([Microsoft.Win32.RegistryView]::Registry64,[Microsoft.Win32.RegistryView]::Registry32)) {
    foreach ($hive in @([Microsoft.Win32.RegistryHive]::CurrentUser,[Microsoft.Win32.RegistryHive]::LocalMachine)) {
        $baseKey = $null; $layers = $null
        try {
            $baseKey = [Microsoft.Win32.RegistryKey]::OpenBaseKey($hive,$view)
            $layers = $baseKey.OpenSubKey('Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers')
            foreach ($name in $targets.Keys) {
                $flags = if ($layers) { [string]$layers.GetValue($targets[$name], '') } else { '' }
                Write-Output ("{0} compatibility {1}/{2}: RUNASADMIN={3}" -f $name,$hive,$view,([bool]($flags -match '(?i)(^|\s)RUNASADMIN(\s|$)')))
            }
        } catch { Write-Output "Compatibility $hive/$view : UNKNOWN (access/read failed)." }
        finally { if ($layers) { $layers.Dispose() }; if ($baseKey) { $baseKey.Dispose() } }
    }
}
$policy = [Microsoft.Win32.Registry]::LocalMachine.OpenSubKey('Software\Microsoft\Windows\CurrentVersion\Policies\System')
try {
    foreach ($name in @('EnableLUA','FilterAdministratorToken')) {
        $value = if ($policy) { $policy.GetValue($name, 'not set') } else { 'UNKNOWN' }
        Write-Output "Windows policy $name=$value"
    }
} finally { if ($policy) { $policy.Dispose() } }
Write-Output ('Diagnostic shell COMPAT_LAYER requests RUNASADMIN: ' + [bool]($env:__COMPAT_LAYER -match '(?i)(^|\s)RUNASADMIN(\s|$)'))
Write-Output 'An elevated process is incompatible with online isolation. Exit game and Steam; check both compatibility settings and UAC. This report cannot inspect shortcuts or another launcher environment.'
