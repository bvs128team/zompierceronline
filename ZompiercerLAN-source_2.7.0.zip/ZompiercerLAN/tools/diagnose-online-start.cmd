@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Diagnose-Online.ps1" -GameRoot "%~dp0."
pause
