using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using Zompiercer.Inventory;
using Object = UnityEngine.Object;

namespace ZompiercerLAN
{
    // Two of each firearm for a big group (2.4.1). The game has no firearms in its random loot (containers and zombie
    // bags get grenades and ammunition); each location's firearms are placed by hand, one of a kind, and most go into a
    // container a second after the location starts (InventoryInserter). When the host's world loads a location fresh
    // with MinPlayers or more players (the host and its connected guests), every firearm of that scene gets one copy:
    // the item's prefab given the original's state the way the game loads a saved item (InventoryItem.Save/Load), with
    // the original's inserters (the same container, after the same second); one lying in the open gets its copy beside
    // it. From then on it is an ordinary item: the guests get it like any other, the world's save keeps it.
    // Loading a save adds nothing: SaveLoadCore.LoadingNow is set while it loads, and the load destroys every item of
    // the scene and puts back the saved ones. Host only. Main thread only.
    internal static class LanExtraWeapons
    {
        internal const int MinPlayers = 4;
        // Item ids of the firearms (EInventoryItemType.Weapons without the bows): PPK, sawed-off, Beretta, Remington 870,
        // Glock, AKM, hunting rifle, revolver, M4 shotgun, old rifle.
        internal static readonly int[] Firearms = { 4, 5, 6, 17, 18, 19, 195, 196, 248, 249 };
        // Host: how many players there are now (null: not hosting, or switched off in [Coop]).
        internal static Func<int> Players;
        private static Action<string> _log;
        private static bool _hooked;
        internal static string Failure { get; private set; }

        internal static void Initialize(Action<string> log)
        {
            _log = log;
            if (_hooked || Failure != null) return;
            SceneManager.sceneLoaded += Loaded;
            _hooked = true;
        }
        internal static void Shutdown() { if (_hooked) SceneManager.sceneLoaded -= Loaded; _hooked = false; Players = null; }

        internal static bool IsFirearm(int id) { return Array.IndexOf(Firearms, id) >= 0; }

        // The scene's own objects are all there and awake, none has started: the inserters have not moved anything yet.
        private static void Loaded(Scene scene, LoadSceneMode mode)
        {
            var players = Players;
            if (players == null || Failure != null || LanSaveIsolation.Active) return;
            try
            {
                var saves = Zompiercer.SaveLoad.SaveLoadCore.global;
                if (saves != null && saves.LoadingNow) return;
                int count = players();
                var database = ItemsDataBase.Global;
                if (count < MinPlayers || database == null || database.itemPrefab == null) return;
                var found = new List<InventoryItem>();
                foreach (var root in scene.GetRootGameObjects())
                    foreach (var item in root.GetComponentsInChildren<InventoryItem>(true))
                        if (item != null && item.inInventory == null && IsFirearm(item.itemID)) found.Add(item);
                if (found.Count == 0) return;
                var ids = new List<string>();
                foreach (var item in found)
                {
                    int id = item.itemID;
                    var prefab = id >= 0 && id < database.itemPrefab.Length ? database.itemPrefab[id] : null;
                    if (prefab != null && Copy(item, prefab)) ids.Add(id.ToString());
                }
                _log?.Invoke("Firearms for " + count + " players in " + scene.name + ": " + ids.Count + " of " + found.Count + " doubled (items " + string.Join(", ", ids.ToArray()) + ")");
            }
            catch (Exception ex)
            {
                // Without it every firearm stays one of a kind, as in the game.
                Failure = ex.GetType().Name + ": " + ex.Message;
                _log?.Invoke("Extra firearms off: " + Failure);
            }
        }

        private static bool Copy(InventoryItem item, InventoryItem prefab)
        {
            var at = item.transform;
            var inserters = new List<InventoryInserter>();
            foreach (var inserter in item.GetComponents<InventoryInserter>())
                if (inserter != null && (inserter.forTrain || inserter.insertTo != null)) inserters.Add(inserter);
            var copy = Object.Instantiate(prefab, inserters.Count != 0 ? at.position : Beside(item), at.rotation);
            if (copy == null) return false;
            try
            {
                // In the original's scene, so that it goes when the location does.
                if (at.parent != null) copy.transform.SetParent(at.parent, true);
                else if (copy.gameObject.scene != item.gameObject.scene) SceneManager.MoveGameObjectToScene(copy.gameObject, item.gameObject.scene);
                copy.amount = item.amount;
                copy.Load(item.Save());
                foreach (var from in inserters)
                {
                    var to = copy.gameObject.AddComponent<InventoryInserter>();
                    to.insertTo = from.insertTo; to.forTrain = from.forTrain;
                }
                return true;
            }
            catch (Exception)
            {
                Object.Destroy(copy.gameObject);
                throw;
            }
        }

        // A firearm lying in the open (the M4 shotgun of the last location): the copy lies next to it on the same floor
        // if a ray finds one there, else it drops onto the original from just above and rolls off.
        private static Vector3 Beside(InventoryItem item)
        {
            var t = item.transform;
            var at = t.position;
            float floor;
            if (!Floor(at + Vector3.up * .3f, out floor)) return at + Vector3.up * .15f;
            var side = Vector3.ProjectOnPlane(t.right, Vector3.up);
            side = side.sqrMagnitude < .01f ? Vector3.right : side.normalized;
            var ahead = Vector3.Cross(Vector3.up, side);
            foreach (var step in new[] { side, -side, ahead, -ahead })
            {
                var spot = at + step * .4f;
                float y;
                if (Floor(spot + Vector3.up * .3f, out y) && Mathf.Abs(y - floor) < .08f) return new Vector3(spot.x, at.y - floor + y + .03f, spot.z);
            }
            return at + Vector3.up * .15f;
        }

        // The nearest solid surface below a point (within a metre), not an item.
        private static bool Floor(Vector3 from, out float y)
        {
            y = 0f;
            float best = float.MaxValue;
            foreach (var hit in Physics.RaycastAll(from, Vector3.down, 1f, ~0, QueryTriggerInteraction.Ignore))
                if (hit.collider != null && hit.distance < best && hit.collider.GetComponentInParent<InventoryItem>() == null) { best = hit.distance; y = hit.point.y; }
            return best < float.MaxValue;
        }
    }
}
