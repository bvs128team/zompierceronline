using System;
using System.Collections.Generic;
using UnityEngine;
using Zompiercer;
using Zompiercer.Inventory;
using Zompiercer.Train;

namespace ZompiercerLAN
{
    // Captured before replica scripts are stripped. Only Unity presentation references survive.
    internal sealed class LanTrainDeviceVisual : MonoBehaviour
    {
        internal sealed class View
        {
            internal int Kind, Index;
            internal Transform Switch, Needle, Reader;
            internal Vector3 On, Off;
            internal Light[] Lights;
            internal MeshRenderer[] Renderers;
            internal Material MaterialOn, MaterialOff;
            internal GameObject[] Objects;
            internal ParticleSystem[] Particles;
            internal AudioSource Audio;
            internal GameObject Record, Mechanism;
            internal float StartAngle, EndAngle, Speed, DefaultPosition, Height, Scale;
            internal LogicInput Input;
            internal LogicOutput Output;
            internal LanTrainDeviceData State;
        }
        internal readonly List<View> Views = new List<View>();
        private readonly List<Action> _restore = new List<Action>();
        internal void Remember(Action action) { _restore.Add(action); }
        internal void Restore()
        {
            foreach (var action in _restore) action();
            enabled = false;
            Destroy(this);
        }
        internal void Apply(List<LanTrainDeviceData> states)
        {
            foreach (var v in Views)
            {
                LanTrainDeviceData d = states == null ? null : states.Find(x => x.Kind == v.Kind && x.Index == v.Index);
                v.State = d;
                bool active = d != null && d.Active;
                if (v.Switch != null) v.Switch.localEulerAngles = active ? v.On : v.Off;
                if (v.Input != null) v.Input.State = active; // no UnityEvents or electrical simulation on guests
                if (v.Output != null) v.Output.State = active;
                if (v.Lights != null) foreach (var light in v.Lights) if (light != null) light.enabled = active;
                if (v.Renderers != null) foreach (var renderer in v.Renderers) if (renderer != null) renderer.sharedMaterial = active ? v.MaterialOn : v.MaterialOff;
                if (v.Objects != null) foreach (var obj in v.Objects) if (obj != null) obj.SetActive(active);
                if (v.Particles != null) foreach (var p in v.Particles) if (p != null) { if (active && !p.isPlaying) p.Play(); else if (!active && p.isPlaying) p.Stop(); }
                if (v.Kind == LanTrainDeviceData.Fire && v.Audio != null)
                {
                    v.Audio.enabled = true;
                    if (active && !v.Audio.isPlaying) v.Audio.Play(); else if (!active) v.Audio.Stop();
                }
                if (v.Kind != LanTrainDeviceData.Music || v.Audio == null) continue;
                var records = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.gramophoneRecords;
                var clip = d != null && records != null && d.Record >= 0 && d.Record < records.Count ? records[d.Record].music : null;
                v.Audio.enabled = true; v.Audio.playOnAwake = false; v.Audio.loop = false;
                bool changed = v.Audio.clip != clip;
                if (changed) { v.Audio.Stop(); v.Audio.clip = clip; }
                if (clip != null)
                {
                    float position = Mathf.Clamp(d.Value / 10f, 0f, Mathf.Max(0f, clip.length - .01f));
                    if (changed || !active || Mathf.Abs(v.Audio.time - position) > 2f) v.Audio.time = position;
                    if (active && !v.Audio.isPlaying) v.Audio.Play();
                    else if (!active && v.Audio.isPlaying) v.Audio.Pause();
                }
                else v.Audio.Stop();
                if (v.Record != null) v.Record.SetActive(clip != null);
                if (v.Mechanism != null) v.Mechanism.SetActive(false);
                if (v.Needle != null) v.Needle.localEulerAngles = new Vector3(0f, clip == null ? v.EndAngle : Mathf.Lerp(v.StartAngle, v.EndAngle, v.Audio.time / Mathf.Max(.01f, clip.length)), 0f);
            }
        }
        private void Update()
        {
            if (!LanSaveIsolation.Active || !LanTrainControl.GuestAttached) return;
            foreach (var v in Views)
            {
                if (v.Kind != LanTrainDeviceData.Music || v.Audio == null) continue;
                v.Audio.volume = LanTrainDevices.Volume;
                if (!v.Audio.isPlaying || v.Audio.clip == null) continue;
                if (v.Record != null) v.Record.transform.Rotate(Vector3.up * v.Speed * Time.deltaTime);
                if (v.Needle != null) v.Needle.localEulerAngles = new Vector3(0, Mathf.Lerp(v.StartAngle, v.EndAngle, v.Audio.time / Mathf.Max(.01f, v.Audio.clip.length)), 0);
                if (v.Reader != null) v.Reader.localEulerAngles = new Vector3(v.DefaultPosition + v.Height * Mathf.PerlinNoise(Time.time * v.Scale, 0), 0, 0);
            }
        }
    }

    internal static class LanTrainDevices
    {
        internal static float Volume = .5f; // per-client listening preference, never sent to the host
        private static int Quantize(float value) { return float.IsNaN(value) || float.IsInfinity(value) ? 0 : Mathf.RoundToInt(Mathf.Clamp(value * 10f, 0, LanTrainDeviceData.MaxTime)); }
        internal static List<LanTrainDeviceData> Capture(Component root)
        {
            var result = new List<LanTrainDeviceData>();
            CaptureStates(result, TrainLayout.OwnedBy<LightSwitcher>(root), LanTrainDeviceData.Switch, x => x.active);
            CaptureStates(result, TrainLayout.OwnedBy<Lamp>(root), LanTrainDeviceData.Lamp, x => x.active);
            CaptureStates(result, TrainLayout.OwnedBy<LogicInput>(root), LanTrainDeviceData.Input, x => x.State);
            CaptureStates(result, TrainLayout.OwnedBy<LogicOutput>(root), LanTrainDeviceData.Output, x => x.State);
            var fires = TrainLayout.OwnedBy<Fireplace>(root);
            for (int i = 0; i < fires.Length && i <= LanTrainDeviceData.MaxIndex && result.Count < LanTrainDeviceData.MaxDevices; i++)
                result.Add(new LanTrainDeviceData { Kind = LanTrainDeviceData.Fire, Index = i, Active = fires[i].Active, Value = Quantize(fires[i].SecondsLeft), Extra = Quantize(fires[i].CurrentBurning) });
            var music = TrainLayout.OwnedBy<AudioPlayer>(root);
            var records = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.gramophoneRecords;
            for (int i = 0; i < music.Length && i <= LanTrainDeviceData.MaxIndex && result.Count < LanTrainDeviceData.MaxDevices; i++)
            {
                var player = music[i]; var available = RecordIds(player);
                int selected = -1;
                if (records != null && player.audioSource != null && player.audioSource.clip != null)
                    for (int id = 0; id < records.Count && id <= LanTrainDeviceData.MaxRecord; id++) if (records[id].music == player.audioSource.clip) { selected = id; break; }
                result.Add(new LanTrainDeviceData { Kind = LanTrainDeviceData.Music, Index = i, Record = selected, Records = available.ToArray(), Active = selected >= 0 && player.audioSource != null && player.audioSource.isPlaying, Value = player.audioSource == null ? 0 : Quantize(player.audioSource.time) });
            }
            return result;
        }
        private static void CaptureStates<T>(List<LanTrainDeviceData> list, T[] components, int kind, Func<T, bool> state) where T : Component
        { for (int i = 0; i < components.Length && i <= LanTrainDeviceData.MaxIndex && list.Count < LanTrainDeviceData.MaxDevices; i++) list.Add(new LanTrainDeviceData { Kind = kind, Index = i, Active = state(components[i]) }); }
        private static List<int> RecordIds(AudioPlayer player)
        {
            var result = new List<int>();
            var box = player.ConnectedInventory != null ? player.ConnectedInventory : player.GetComponent<Inventory>();
            var db = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.gramophoneRecords;
            if (box == null || box.content == null || db == null) return result;
            foreach (var item in box.content)
            {
                if (item == null || (int)item.itemType != 19 || item.gramophoneRecord == null) continue;
                int id = item.gramophoneRecord.ID;
                if (id >= 0 && id < db.Count && id <= LanTrainDeviceData.MaxRecord && !result.Contains(id) && result.Count < LanTrainDeviceData.MaxRecords) result.Add(id);
            }
            return result;
        }
        internal static LanTrainDeviceVisual CaptureVisual(Component root)
        {
            var visual = root.gameObject.AddComponent<LanTrainDeviceVisual>();
            var switches = TrainLayout.OwnedBy<LightSwitcher>(root);
            for (int i = 0; i < switches.Length && i <= LanTrainDeviceData.MaxIndex; i++)
            {
                var s = switches[i];
                visual.Views.Add(new LanTrainDeviceVisual.View { Kind = LanTrainDeviceData.Switch, Index = i, Switch = s.moveblePart, On = s.rotationOn, Off = s.rotationOff });
                if (s.moveblePart != null) { var t = s.moveblePart; var rotation = t.localRotation; visual.Remember(() => { if (t != null) t.localRotation = rotation; }); }
            }
            var lamps = TrainLayout.OwnedBy<Lamp>(root);
            for (int i = 0; i < lamps.Length && i <= LanTrainDeviceData.MaxIndex; i++)
            {
                var l = lamps[i]; var renderers = new List<MeshRenderer>();
                if (l.meshRenderer != null) renderers.Add(l.meshRenderer);
                if (l.meshRenderers != null) foreach (var r in l.meshRenderers) if (r != null && !renderers.Contains(r)) renderers.Add(r);
                visual.Views.Add(new LanTrainDeviceVisual.View { Kind = LanTrainDeviceData.Lamp, Index = i, Lights = l.lights, Renderers = renderers.ToArray(), MaterialOn = l.MaterialOn, MaterialOff = l.MaterialOff });
                if (l.lights != null) foreach (var light in l.lights) if (light != null) { var saved = light; bool active = light.enabled; visual.Remember(() => { if (saved != null) saved.enabled = active; }); }
                foreach (var r in renderers) { var saved = r; var material = r.sharedMaterial; visual.Remember(() => { if (saved != null) saved.sharedMaterial = material; }); }
            }
            var inputs = TrainLayout.OwnedBy<LogicInput>(root);
            for (int i = 0; i < inputs.Length && i <= LanTrainDeviceData.MaxIndex; i++) { var node = inputs[i]; bool old = node.State; visual.Remember(() => { if (node != null) node.State = old; }); visual.Views.Add(new LanTrainDeviceVisual.View { Kind = LanTrainDeviceData.Input, Index = i, Input = node }); }
            var outputs = TrainLayout.OwnedBy<LogicOutput>(root);
            for (int i = 0; i < outputs.Length && i <= LanTrainDeviceData.MaxIndex; i++) { var node = outputs[i]; bool old = node.State; visual.Remember(() => { if (node != null) node.State = old; }); visual.Views.Add(new LanTrainDeviceVisual.View { Kind = LanTrainDeviceData.Output, Index = i, Output = node }); }
            var fires = TrainLayout.OwnedBy<Fireplace>(root);
            for (int i = 0; i < fires.Length && i <= LanTrainDeviceData.MaxIndex; i++)
            {
                var f = fires[i];
                visual.Views.Add(new LanTrainDeviceVisual.View { Kind = LanTrainDeviceData.Fire, Index = i, Objects = f.ActiveObjects == null ? null : f.ActiveObjects.ToArray(), Particles = f.ActiveParticleSystems == null ? null : f.ActiveParticleSystems.ToArray(), Audio = f.FireplaceAudioSource });
            }
            var players = TrainLayout.OwnedBy<AudioPlayer>(root);
            for (int i = 0; i < players.Length && i <= LanTrainDeviceData.MaxIndex; i++)
            {
                var p = players[i];
                visual.Views.Add(new LanTrainDeviceVisual.View { Kind = LanTrainDeviceData.Music, Index = i, Audio = p.audioSource, Record = p.turntableGramophoneRecord, Mechanism = p.gramophoneRecordOnMechanism, Needle = p.gramophoneNeedle, Reader = p.gramophoneReader, StartAngle = p.StartPlayAngle, EndAngle = p.EndPlayAngle, Speed = p.rotationSpeed, DefaultPosition = p.DefaultPosition, Height = p.heightScale, Scale = p.xScale });
            }
            foreach (var view in visual.Views)
            {
                if (view.Audio != null) { var audio = view.Audio; var clip = audio.clip; bool enabled = audio.enabled, playing = audio.isPlaying, loop = audio.loop; float time = audio.time, volume = audio.volume; visual.Remember(() => { if (audio == null) return; audio.Stop(); audio.clip = clip; audio.loop = loop; audio.volume = volume; audio.enabled = enabled; if (clip != null) { audio.time = time; if (playing) audio.Play(); } }); }
                var objects = new List<GameObject>(view.Objects ?? new GameObject[0]); objects.Add(view.Record); objects.Add(view.Mechanism);
                foreach (var obj in objects) if (obj != null) { var saved = obj; bool active = obj.activeSelf; visual.Remember(() => { if (saved != null) saved.SetActive(active); }); }
                if (view.Particles != null) foreach (var particle in view.Particles) if (particle != null) { var saved = particle; bool playing = particle.isPlaying; visual.Remember(() => { if (saved != null) { if (playing) saved.Play(); else saved.Stop(); } }); }
                foreach (var t in new[] { view.Needle, view.Reader, view.Record == null ? null : view.Record.transform }) if (t != null) { var saved = t; var rotation = t.localRotation; visual.Remember(() => { if (saved != null) saved.localRotation = rotation; }); }
            }
            return visual;
        }
        internal static byte Host(int car, int identity, int value, Vector3 guest)
        {
            if (!LanTrainDeviceData.ValidControl(value) || identity == 0) return LanStorage.Invalid;
            int owner, index, action, record; LanTrainDeviceData.Fields(value, out owner, out index, out action, out record);
            byte status;
            var target = LanTrainDecor.Find(GlobalManager.global.controlledTrain, car, owner == 1 ? LanStorage.TrainFurniture : LanStorage.TrainPart, identity, out status);
            if (target == null) return status;
            if (LanTrainDecor.Distance(target, guest) > LanTrainControl.Reach) return LanStorage.TooFar;
            var part = target as TrainPart;
            if (part != null && !part.IsFunctional()) return LanStorage.NotAllowed;
            if (action <= 2)
            {
                var fires = TrainLayout.OwnedBy<Fireplace>(target);
                if (index >= fires.Length || !fires[index].isActiveAndEnabled) return LanStorage.NotFound;
                fires[index].SetActivate(action == 2);
                return fires[index].Active == (action == 2) ? LanStorage.Ok : LanStorage.Empty;
            }
            var players = TrainLayout.OwnedBy<AudioPlayer>(target);
            if (index >= players.Length || !players[index].isActiveAndEnabled) return LanStorage.NotFound;
            var player = players[index];
            if (player.Cooldown && player.CooldownTimer > 0f) return LanStorage.Busy;
            if (action == 3)
            {
                if (!RecordIds(player).Contains(record)) return LanStorage.NotAllowed;
                player.CheckMusic();
                var db = ItemsDataBase.Global.gramophoneRecords;
                int selected = player.MusicList.IndexOf(db[record]);
                if (selected < 0) return LanStorage.NotFound;
                player.SetMusic(selected);
            }
            else if (action == 4) { if (player.audioSource == null || player.audioSource.clip == null) return LanStorage.NotAllowed; player.StartCoroutine(player.PlayCurrent()); }
            else if (action == 5) player.StartCoroutine(player.Pause());
            else player.Stop();
            return LanStorage.Ok;
        }

        private static LanTrainDeviceVisual _panel;
        private static int _car, _owner, _identity;
        private static bool _controlEnabled, _opened;
        private static ZombieFighterController _held;
        private static bool _restore, _cursorVisible;
        private static CursorLockMode _cursorLock;
        private static float _sentAt;
        private static Vector2 _scroll;
        internal static void Tick()
        {
            RestoreControl();
            if (_opened)
            {
                var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
                var controls = LanGame.Input;
                if (_panel == null || !LanSaveIsolation.Active || !LanTrainControl.GuestAttached || player == null || player != _held ||
                    controls == null || controls.CurrentState != Zompiercer.Inputs.EStateInput.InputWindow || LanDowned.Down || LanGuestDeath.Dead ||
                    Vector3.Distance(player.transform.position, _panel.transform.position) > 5f) Close();
                return;
            }
            if (_restore || !LanSaveIsolation.Active || !LanTrainControl.GuestAttached || LanStorageGame.WindowOpen || LanDowned.Down || LanGuestDeath.Dead) return;
            var input = LanGame.Input;
            if (input == null || (int)input.CurrentState != 1) return;
            RaycastHit hit; Component shown; int car, kind, identity;
            if (!LanTrainBuild.LookHit(out hit) || hit.distance > LanTrainControl.Reach || !TrainLayout.TryIdentifyDecor(hit.collider.transform, out car, out kind, out identity, out shown)) return;
            var visual = shown.GetComponent<LanTrainDeviceVisual>();
            if (visual == null || !visual.Views.Exists(x => x.Kind >= LanTrainDeviceData.Fire)) return;
            var info = InventoryController.global == null ? null : InventoryController.global.simpleInfoDisplayer;
            if (info != null) info.SetIconText("Edit", (Zompiercer.Inputs.Actions)(input.isKbMouseDevice ? 13 : 35), (Zompiercer.Inputs.Actions)0, true);
            if (!(input.isKbMouseDevice ? input.isLeverUpDown : input.gp_isAltUseDown)) return;
            input.isLeverUpDown = false; input.gp_isAltUseDown = false;
            _opened = true; _panel = visual; _car = car; _owner = kind == TrainLayout.FurnitureKindId ? 1 : 0; _identity = identity;
            var character = GlobalManager.global.controlledChar;
            _held = character; _cursorLock = Cursor.lockState; _cursorVisible = Cursor.visible;
            _controlEnabled = character.controlEnabled; character.controlEnabled = false;
            input.SetState(Zompiercer.Inputs.EStateInput.InputWindow);
            CursorChanger.CursorSetLock(false);
        }
        internal static void Close()
        {
            if (!_opened) return;
            _opened = false; _panel = null;
            var input = LanGame.Input;
            if (input != null && input.CurrentState == Zompiercer.Inputs.EStateInput.InputWindow) input.SetState(Zompiercer.Inputs.EStateInput.Game);
            _restore = true;
            RestoreControl();
        }
        internal static void RestoreControl()
        {
            if (!_restore) return;
            var character = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
            if (character == null || character != _held) { _restore = false; _held = null; return; }
            var input = LanGame.Input;
            if (input == null || input.CurrentState != Zompiercer.Inputs.EStateInput.Game || LanDowned.Down || LanGuestDeath.Dead) return;
            character.controlEnabled = _controlEnabled;
            Cursor.lockState = _cursorLock; Cursor.visible = _cursorVisible;
            _restore = false; _held = null;
        }
        private static void Send(int index, int action, int record = 0)
        {
            if (Time.unscaledTime - _sentAt < .3f) return;
            _sentAt = Time.unscaledTime;
            var send = LanTrainControl.GuestRequest;
            if (send == null || !send(LanStorage.ControlDevice, _car, _identity, LanTrainDeviceData.Control(_owner, index, action, record), null)) LanStorageGame.Notice(LanText.T("Хост ещё отвечает на прошлые запросы"));
        }
        internal static void Draw()
        {
            if (!_opened) return;
            if (Event.current.type == EventType.KeyDown && Event.current.keyCode == KeyCode.Escape) { Close(); Event.current.Use(); return; }
            if (_panel == null) { Close(); return; }
            if (!LanSaveIsolation.Active || !LanTrainControl.GuestAttached) { Close(); return; }
            GUILayout.BeginArea(new Rect(Mathf.Max(8, (Screen.width - 420) / 2f), 60, 420, Mathf.Min(540, Screen.height - 80)), GUI.skin.box);
            if (GUILayout.Button(LanText.T("Закрыть"))) { Close(); GUILayout.EndArea(); return; }
            _scroll = GUILayout.BeginScrollView(_scroll);
            foreach (var view in _panel.Views)
            {
                var d = view.State; if (d == null || d.Kind < LanTrainDeviceData.Fire) continue;
                if (d.Kind == LanTrainDeviceData.Fire)
                {
                    GUILayout.Label(LanText.T("Камин: ") + (d.Active ? LanText.T("горит") : LanText.T("выключен")) + " / " + Math.Round(d.Value / 10f) + " s");
                    if (GUILayout.Button(d.Active ? LanText.T("Выключить") : LanText.T("Включить"))) Send(d.Index, d.Active ? 1 : 2);
                }
                else
                {
                    var db = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.gramophoneRecords;
                    GUILayout.Label((db != null && d.Record >= 0 && d.Record < db.Count ? db[d.Record].musicName : LanText.T("Граммофон")) + " / " + Math.Round(d.Value / 10f) + " s");
                    GUILayout.BeginHorizontal();
                    if (GUILayout.Button(LanText.T("Играть"))) Send(d.Index, 4);
                    if (GUILayout.Button(LanText.T("Пауза"))) Send(d.Index, 5);
                    if (GUILayout.Button(LanText.T("Стоп"))) Send(d.Index, 6);
                    GUILayout.EndHorizontal();
                    GUILayout.Label(LanText.T("Громкость")); Volume = GUILayout.HorizontalSlider(Volume, 0f, 1f);
                    if (db != null) foreach (int record in d.Records) if (record < db.Count && GUILayout.Button(db[record].musicName)) Send(d.Index, 3, record);
                }
            }
            GUILayout.EndScrollView(); GUILayout.EndArea();
        }
    }
}

