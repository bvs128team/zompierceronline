using System;
using System.Collections.Generic;
using UnityEngine;
using Zompiercer.Inputs;

namespace ZompiercerLAN
{
    // Read-only overlay: it never takes character control or changes the cursor.
    internal sealed class LanPlayerList
    {
        internal sealed class Row
        {
            internal int Slot, Ping;
            internal string Name;
            internal bool Own;
        }

        private readonly Func<IList<Row>> _players;
        private IList<Row> _rows;
        private bool _ready, _held;
        private float _refreshAt;
        private GUIStyle _title, _name, _value, _hint;
        internal bool Open { get; private set; }

        internal LanPlayerList(Func<IList<Row>> players) { _players = players; }

        internal void Tick(bool ready)
        {
            var manager = GlobalManager.global;
            var input = LanGame.Input;
            // 2.6.3: not GameStarted: the game sets it only for a new game (a host in a loaded world never had the list).
            _ready = ready && manager != null && manager.controlledChar != null &&
                input != null && input.CurrentState == EStateInput.Game;
            if (!_ready) Close();
        }

        internal void Close() { Open = false; _held = false; _rows = null; }

        private static bool ListKey(Event e)
        { return e.keyCode == KeyCode.RightBracket || e.character == '\u044a' || e.character == '\u042a'; }

        internal void KeyEvent(Event e)
        {
            if (e.type == EventType.KeyUp && ListKey(e)) { _held = false; return; }
            if (e.type != EventType.KeyDown || !_ready) return;
            if (Open && e.keyCode == KeyCode.Escape) { Close(); e.Use(); return; }
            if (!ListKey(e)) return;
            if (!_held) { Open = !Open; _refreshAt = -1f; _rows = null; }
            _held = true;
            e.Use();
        }

        internal void Draw()
        {
            if (!Open || !_ready) return;
            if (_rows == null || Time.unscaledTime >= _refreshAt)
            {
                _refreshAt = Time.unscaledTime + .25f;
                _rows = _players();
            }
            int count = Math.Min(LanProtocol.MaxPlayers, _rows == null ? 0 : _rows.Count);
            float availableWidth = Mathf.Max(1f, Screen.width - 24f);
            float availableHeight = Mathf.Max(1f, Screen.height - 24f);
            float scale = Mathf.Clamp(Mathf.Min(availableWidth / 480f,
                availableHeight / (100f + 32f * count)), .3f, 1f);
            float width = Mathf.Min(620f, availableWidth);
            float height = Mathf.Min(availableHeight, (100f + 32f * count) * scale);
            float x = (Screen.width - width) * .5f, y = Mathf.Max(12f, (Screen.height - height) * .22f);
            if (_title == null)
            {
                _title = new GUIStyle(GUI.skin.label) { richText = false, alignment = TextAnchor.UpperLeft };
                _name = new GUIStyle(GUI.skin.label) { richText = false, wordWrap = false };
                _value = new GUIStyle(_name) { alignment = TextAnchor.MiddleRight };
                _hint = new GUIStyle(_name);
            }
            _title.fontSize = Mathf.Max(10, Mathf.RoundToInt(24f * scale));
            _name.fontSize = _value.fontSize = Mathf.Max(10, Mathf.RoundToInt(20f * scale));
            _hint.fontSize = Mathf.Max(9, Mathf.RoundToInt(14f * scale));
            GUI.Box(new Rect(x, y, width, height), GUIContent.none);
            GUI.BeginGroup(new Rect(x + 12f, y + 8f * scale, Mathf.Max(1f, width - 24f), Mathf.Max(1f, height - 12f * scale)));
            float inner = Mathf.Max(1f, width - 24f), pingWidth = 90f * scale, roleWidth = 90f * scale;
            float nameWidth = Mathf.Max(1f, inner - pingWidth - roleWidth - 10f);
            GUI.Label(new Rect(0f, 0f, inner, 32f * scale), LanText.T("Игроки") + "  " + count + "/" + LanProtocol.MaxPlayers, _title);
            GUI.Label(new Rect(0f, 34f * scale, nameWidth, 24f * scale), LanText.T("Игрок"), _hint);
            GUI.Label(new Rect(inner - pingWidth - roleWidth, 34f * scale, roleWidth, 24f * scale), LanText.T("Роль"), _hint);
            GUI.Label(new Rect(inner - pingWidth, 34f * scale, pingWidth, 24f * scale), LanText.T("Пинг"), _value);
            for (int i = 0; i < count; i++)
            {
                var row = _rows[i];
                float top = (60f + 32f * i) * scale;
                GUI.Label(new Rect(0f, top, nameWidth, 30f * scale), (row.Name ?? "") + (row.Own ? LanText.T(" (Вы)") : ""), _name);
                GUI.Label(new Rect(inner - pingWidth - roleWidth, top, roleWidth, 30f * scale), row.Slot == 0 ? LanText.T("Хост") : LanText.T("Гость"), _name);
                var previous = GUI.color;
                if (row.Ping >= 0) GUI.color = row.Ping < 100 ? new Color(.55f, 1f, .6f) : row.Ping < 250 ? new Color(1f, .85f, .4f) : new Color(1f, .5f, .45f);
                GUI.Label(new Rect(inner - pingWidth, top, pingWidth, 30f * scale), row.Ping < 0 ? "—" : row.Ping + LanText.T(" мс"), _value);
                GUI.color = previous;
            }
            GUI.Label(new Rect(0f, (62f + 32f * count) * scale, inner, 22f * scale), LanText.T("Пинг до хоста · Ъ / ] — закрыть · Esc — закрыть"), _hint);
            GUI.EndGroup();
        }
    }
}
