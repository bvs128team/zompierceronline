﻿using System;
using System.Collections.Generic;
using System.IO;

namespace ZompiercerLAN
{
    // Host-only, one snapshot per quest phase and world checkpoint. Profiles, never reusable slots,
    // own claims. Retain spent entries so a repeated completion cannot refill a receipt.
    internal sealed class LanQuestReceipts
    {
        internal const int Limit = 4096, MaxSavedBytes = 192 * 1024;
        private sealed class Receipt
        {
            internal readonly HashSet<string> Owners = new HashSet<string>(StringComparer.Ordinal);
            internal byte[] Items;
        }
        private readonly Dictionary<string, Receipt> _entries = new Dictionary<string, Receipt>(StringComparer.Ordinal);
        private static string Id(string scene, uint key) { return scene + "|" + key; }
        internal bool Quarantined { get; private set; }
        internal int Count { get { return _entries.Count; } }
        internal void Clear() { _entries.Clear(); Quarantined = false; }
        internal object[] Save()
        {
            var owners = new Dictionary<string, ushort>(StringComparer.Ordinal);
            foreach (var entry in _entries.Values) foreach (string owner in entry.Owners)
                if (!owners.ContainsKey(owner)) { if (owners.Count >= LanGuestStore.MaxWelcomeReceipts) throw new InvalidDataException("quest profile count"); owners.Add(owner, (ushort)owners.Count); }
            using (var stream = new MemoryStream()) using (var writer = new BinaryWriter(stream))
            {
                writer.Write((byte)1); writer.Write((ushort)owners.Count);
                var names = new string[owners.Count]; foreach (var pair in owners) names[pair.Value] = pair.Key;
                foreach (string owner in names) WriteString(writer, owner, 64);
                writer.Write((ushort)_entries.Count);
                foreach (var entry in _entries)
                {
                    WriteString(writer, entry.Key, 128); writer.Write((byte)entry.Value.Owners.Count);
                    foreach (string owner in entry.Value.Owners) writer.Write(owners[owner]);
                    var items = entry.Value.Items;
                    writer.Write(items == null ? -1 : items.Length); if (items != null) writer.Write(items);
                    if (stream.Length > MaxSavedBytes) throw new InvalidDataException("quest journal size");
                }
                var bytes = stream.ToArray(); var chunks = new List<object>();
                for (int offset = 0; offset < bytes.Length; offset += LanValueCodec.MaxBlobBytes)
                { int count = Math.Min(LanValueCodec.MaxBlobBytes, bytes.Length-offset); var chunk = new byte[count]; Array.Copy(bytes, offset, chunk, 0, count); chunks.Add(chunk); }
                return new object[] { Quarantined, chunks.ToArray() };
            }
        }
        private static void WriteString(BinaryWriter writer, string value, int max)
        {
            var bytes = new System.Text.UTF8Encoding(false, true).GetBytes(value);
            if(bytes.Length<1 || bytes.Length>max) throw new InvalidDataException("quest text");
            writer.Write((byte)bytes.Length); writer.Write(bytes);
        }
        private static string ReadString(BinaryReader reader, int max)
        { int size=reader.ReadByte(); if(size<1 || size>max || size>reader.BaseStream.Length-reader.BaseStream.Position) throw new InvalidDataException("quest text"); return new System.Text.UTF8Encoding(false,true).GetString(reader.ReadBytes(size)); }
        internal void Load(object value, bool checkpointMatches)
        {
            var root = value as object[];
            if (root == null || root.Length != 2 || !(root[0] is bool) || !(root[1] is object[])) throw new InvalidDataException("quest journal");
            var chunks = (object[])root[1];
            if(chunks.Length<1 || chunks.Length>3) throw new InvalidDataException("quest journal chunks");
            var loaded = new Dictionary<string, Receipt>(StringComparer.Ordinal);
            using(var stream=new MemoryStream())
            {
                foreach(var valueChunk in chunks) {
                    var chunk=valueChunk as byte[];
                    if(chunk==null || chunk.Length<1 || chunk.Length>LanValueCodec.MaxBlobBytes || stream.Length+chunk.Length>MaxSavedBytes) throw new InvalidDataException("quest journal size");
                    stream.Write(chunk,0,chunk.Length);
                }
                stream.Position=0;
                using(var reader=new BinaryReader(stream)) {
                    if(reader.ReadByte()!=1) throw new InvalidDataException("quest journal format");
                    int ownerCount=reader.ReadUInt16(); if(ownerCount>LanGuestStore.MaxWelcomeReceipts) throw new InvalidDataException("quest profile count");
                    var owners=new string[ownerCount]; var unique=new HashSet<string>(StringComparer.Ordinal);
                    for(int i=0;i<ownerCount;i++) { owners[i]=ReadString(reader,64); if(!LanGuestStore.ValidProfileId(owners[i]) || !unique.Add(owners[i])) throw new InvalidDataException("quest owner"); }
                    int count=reader.ReadUInt16(); if(count>Limit) throw new InvalidDataException("quest journal count");
                    for(int i=0;i<count;i++) {
                        string id=ReadString(reader,128); if(id.Length<3 || id.Length>110 || loaded.ContainsKey(id)) throw new InvalidDataException("quest receipt");
                        int number=reader.ReadByte(); if(number>LanProtocol.MaxPlayers-1) throw new InvalidDataException("quest owners");
                        var receipt=new Receipt();
                        for(int j=0;j<number;j++) { int index=reader.ReadUInt16(); if(index>=owners.Length || !receipt.Owners.Add(owners[index])) throw new InvalidDataException("quest owner index"); }
                        int size=reader.ReadInt32(); if(size < -1 || size>LanProtocol.MaxGuestBytes || size>stream.Length-stream.Position) throw new InvalidDataException("quest items");
                        if(size>=0) receipt.Items=reader.ReadBytes(size);
                        loaded.Add(id,receipt);
                    }
                    if(stream.Position!=stream.Length) throw new InvalidDataException("quest journal trailing data");
                }
            }
            Clear(); Quarantined = (bool)root[0] || !checkpointMatches;
            foreach (var entry in loaded) _entries.Add(entry.Key, entry.Value);
        }
        internal bool Keep(string scene, uint key, IList<string> profiles, string except, byte[] items = null)
        {
            if (Quarantined) return false;
            string id = Id(scene, key);
            if (_entries.ContainsKey(id)) return true;
            if (_entries.Count >= Limit) return false;
            var receipt = new Receipt { Items = items == null ? null : (byte[])items.Clone() };
            if (profiles != null) foreach (string profile in profiles)
                if (!string.IsNullOrEmpty(profile) && profile != except && receipt.Owners.Count < LanProtocol.MaxPlayers - 1) receipt.Owners.Add(profile);
            _entries.Add(id, receipt);
            // Reserve space for both journals alongside the maximum profile and welcome data.
            // Fail before creating a right that the bounded sidecar cannot retain.
            try { Save(); return true; }
            catch (InvalidDataException) { }
            _entries.Remove(id);
            return false;
        }
        internal bool Waits(string scene, uint key, string profile)
        {
            Receipt receipt;
            return !Quarantined && profile != null && _entries.TryGetValue(Id(scene, key), out receipt) && receipt.Owners.Contains(profile);
        }
        internal bool Claim(string scene, uint key, string profile, bool room, out byte[] items)
        {
            items = null;
            Receipt receipt;
            if (Quarantined || !room || profile == null || !_entries.TryGetValue(Id(scene, key), out receipt) || !receipt.Owners.Remove(profile)) return false;
            items = receipt.Items == null ? null : (byte[])receipt.Items.Clone();
            if (receipt.Owners.Count == 0) receipt.Items = null;
            return true;
        }
    }
}
