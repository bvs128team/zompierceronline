using System;
using System.Collections.Generic;
using System.IO;
#if !SECURITY_CHECKS
using System.Reflection;
using BepInEx.Logging;
#endif

namespace ZompiercerLAN
{
    // 2.4.5: the mod's log never names the Windows user. Folders under the user's profile (the player identity and the
    // network cache in %LOCALAPPDATA%, the game's saves in AppData\LocalLow, temporary files) and any file error that
    // quotes them are written as %LOCALAPPDATA%, %APPDATA%, %TEMP% or %USERPROFILE%. Players send this log with bug
    // reports.
    internal static class LanLogPrivacy
    {
        private static readonly KeyValuePair<string, string>[] Folders = Prepare(
            new KeyValuePair<string, string>("%LOCALAPPDATA%", Folder(Environment.SpecialFolder.LocalApplicationData)),
            new KeyValuePair<string, string>("%APPDATA%", Folder(Environment.SpecialFolder.ApplicationData)),
            new KeyValuePair<string, string>("%TEMP%", Temp()),
            new KeyValuePair<string, string>("%USERPROFILE%", Folder(Environment.SpecialFolder.UserProfile)));

        private static string Folder(Environment.SpecialFolder folder)
        {
            try { return Environment.GetFolderPath(folder); } catch (Exception) { return null; }
        }

        private static string Temp()
        {
            try { return Path.GetTempPath(); } catch (Exception) { return null; }
        }

        // Each folder with both separators (Unity writes paths with '/'), the longest first, so the most precise name wins.
        internal static KeyValuePair<string, string>[] Prepare(params KeyValuePair<string, string>[] named)
        {
            var list = new List<KeyValuePair<string, string>>();
            foreach (var pair in named)
            {
                string path = pair.Value == null ? null : pair.Value.TrimEnd('\\', '/');
                if (string.IsNullOrEmpty(path) || path.Length < 4 || path.IndexOf('\0') >= 0) continue;
                list.Add(new KeyValuePair<string, string>(path.Replace('/', '\\'), pair.Key));
                list.Add(new KeyValuePair<string, string>(path.Replace('\\', '/'), pair.Key));
            }
            list.Sort((a, b) => b.Key.Length.CompareTo(a.Key.Length));
            return list.ToArray();
        }

        internal static string Clean(string text)
        {
            return Clean(text, Folders);
        }

        // The same text when nothing in it names one of the folders (the reference itself, so callers can tell).
        internal static string Clean(string text, KeyValuePair<string, string>[] folders)
        {
            if (string.IsNullOrEmpty(text) || folders == null) return text;
            string result = text;
            foreach (var folder in folders)
            {
                int at = 0;
                while ((at = result.IndexOf(folder.Key, at, StringComparison.OrdinalIgnoreCase)) >= 0)
                {
                    int end = at + folder.Key.Length;
                    // Only the whole folder: C:\Users\Ann is not the start of C:\Users\Anna.
                    if (end < result.Length && (char.IsLetterOrDigit(result[end]) || result[end] == '_' || result[end] == '-'))
                    {
                        at = end;
                        continue;
                    }
                    result = result.Substring(0, at) + folder.Value + result.Substring(end);
                    at += folder.Value.Length;
                }
            }
            return result;
        }

#if !SECURITY_CHECKS
        // Every line of the plugin's log source passes through Clean before BepInEx's listeners (LogOutput.log, the
        // console, Unity's log) see it: ManualLogSource.Log raises its LogEvent field, whose handlers BepInEx added
        // when the source was created. Returns false if this BepInEx keeps its handlers elsewhere.
        internal static bool Install(ManualLogSource source)
        {
            var field = typeof(ManualLogSource).GetField("LogEvent", BindingFlags.Instance | BindingFlags.NonPublic);
            if (source == null || field == null || field.FieldType != typeof(EventHandler<LogEventArgs>)) return false;
            var listeners = field.GetValue(source) as EventHandler<LogEventArgs>;
            if (listeners == null) return false;
            EventHandler<LogEventArgs> cleaned = (sender, e) =>
            {
                string text = e.Data == null ? null : e.Data.ToString();
                string clean = Clean(text);
                listeners(sender, ReferenceEquals(clean, text) ? e : new LogEventArgs(clean, e.Level, e.Source));
            };
            field.SetValue(source, cleaned);
            return true;
        }
#endif
    }
}
