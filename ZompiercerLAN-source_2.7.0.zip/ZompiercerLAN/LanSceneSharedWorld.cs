using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
using UnityEngine.SceneManagement;
using Object = UnityEngine.Object;

namespace ZompiercerLAN
{
    internal sealed partial class LanSceneStates
    {
        private static readonly Dictionary<int, Dictionary<int, Vector3>> SeasonCatalogue = new Dictionary<int, Dictionary<int, Vector3>>();
        private static readonly HashSet<int> SeasonScannedScenes = new HashSet<int>();
        private static readonly Dictionary<int, HashSet<int>> AmbiguousSeason = new Dictionary<int, HashSet<int>>();
        private static readonly Dictionary<SceneEventTrigger, int> EventPulses = new Dictionary<SceneEventTrigger, int>();
        private static AccessTools.FieldRef<SceneEventTrigger, bool> _eventTriggered;
        // 2.6.0: UniqueShared was a FindObjectsOfType over the whole scene for every received frame (up to 32 a packet);
        // the place-key maps are now kept for a second (and dropped with the scene).
        private const float SharedIndexEvery = 1f;
        private sealed class SharedIndex { internal float At; internal object Map; }
        private static readonly Dictionary<Type, SharedIndex> SharedIndexes = new Dictionary<Type, SharedIndex>();
        private static AccessTools.FieldRef<ObjectBreak, bool> _seasonBroken;
        private readonly LanSceneEventReceipts _eventReceipts = new LanSceneEventReceipts();
        private float _sharedSendAt;
        private int _sharedCursor;
        private readonly List<Action> _restoreSeason = new List<Action>();
        private readonly HashSet<int> _capturedSeason = new HashSet<int>();
        private readonly Dictionary<int, ulong> _seasonProgress = new Dictionary<int, ulong>();
        private readonly Dictionary<ObjectBreak, bool> _seasonVisibility = new Dictionary<ObjectBreak, bool>();

        private static bool Seasonal(ObjectBreak c)
        {
            return c != null && (c.GetComponent<HalloweenEventCollectable>() != null || c.GetComponent<AprilFoolsDayEventCollectable>() != null);
        }
        private static void InitializeSharedWorld()
        {
            _eventTriggered = AccessTools.FieldRefAccess<SceneEventTrigger, bool>("Triggered");
            _seasonBroken = AccessTools.FieldRefAccess<ObjectBreak, bool>("objectBreakDetector");
            _harmony.Patch(AccessTools.Method(typeof(SaveableObject), "Awake"), prefix: new HarmonyMethod(typeof(LanSceneStates), nameof(CatalogueSeasonBeforeAwake)));
            _harmony.Patch(AccessTools.Method(typeof(ObjectBreak), "ObjectBreaks"), prefix: new HarmonyMethod(typeof(LanSceneStates), nameof(SeasonBreakPrefix)));
            _harmony.Patch(AccessTools.Method(typeof(SceneEventTrigger), "Trigger"), prefix: new HarmonyMethod(typeof(LanSceneStates), nameof(EventTriggerPrefix)));
            _harmony.Patch(AccessTools.Method(typeof(HalloweenEventCollectable), "Collect"), prefix: new HarmonyMethod(typeof(LanSceneStates), nameof(SeasonCollectPrefix)));
            _harmony.Patch(AccessTools.Method(typeof(AprilFoolsDayEventCollectable), "Collect"), prefix: new HarmonyMethod(typeof(LanSceneStates), nameof(SeasonCollectPrefix)));
            SceneManager.sceneUnloaded += SharedSceneUnloaded;
            CatalogueSeasonBeforeAwake(null);
        }
        private static void ShutdownSharedWorld()
        {
            SceneManager.sceneUnloaded -= SharedSceneUnloaded;
            SeasonCatalogue.Clear(); SeasonScannedScenes.Clear(); AmbiguousSeason.Clear(); EventPulses.Clear(); SharedIndexes.Clear();
        }
        private static void SharedSceneUnloaded(Scene scene)
        {
            SeasonCatalogue.Remove(scene.handle); SeasonScannedScenes.Remove(scene.handle); AmbiguousSeason.Remove(scene.handle);
            EventPulses.Clear(); SharedIndexes.Clear();
        }
        // Awake runs before native load destroys the scene's SaveableObjects and recreates
        // only saved survivors. Scan inactive objects as well, before SeasonalEventObject.Start.
        private static void CatalogueSeasonBeforeAwake(SaveableObject __instance)
        {
            if (__instance != null && !SeasonScannedScenes.Add(__instance.gameObject.scene.handle)) return;
            var pending = new Dictionary<int, Dictionary<int, Vector3>>();
            foreach (var c in Object.FindObjectsOfType<ObjectBreak>(true))
            {
                if (!Seasonal(c) || !c.gameObject.scene.IsValid() || c.name.IndexOf("(Clone)", StringComparison.Ordinal) >= 0) continue;
                int handle = c.gameObject.scene.handle;
                if (SeasonCatalogue.ContainsKey(handle)) continue;
                Dictionary<int, Vector3> catalogue;
                if (!pending.TryGetValue(handle, out catalogue)) pending[handle] = catalogue = new Dictionary<int, Vector3>();
                int id = PlaceKey(c);
                if (catalogue.ContainsKey(id))
                {
                    HashSet<int> ambiguous;
                    if (!AmbiguousSeason.TryGetValue(handle, out ambiguous)) AmbiguousSeason[handle] = ambiguous = new HashSet<int>();
                    ambiguous.Add(id);
                }
                else if (catalogue.Count < 4096) catalogue[id] = c.transform.position;
            }
            // Freeze the authored catalogue. Saved runtime clones cannot add phantom keys
            // from their prefab position before Load restores their transform.
            foreach (var pair in pending) { SeasonCatalogue[pair.Key] = pair.Value; SeasonScannedScenes.Add(pair.Key); }
        }
        // A null value: two objects share that place key (neither is used). A destroyed object stays in the map
        // until the next rebuild and compares equal to null in Unity's sense, but not by reference.
        private static Dictionary<int, T> UniqueShared<T>() where T : Component
        {
            SharedIndex index;
            float now = Time.unscaledTime;
            if (SharedIndexes.TryGetValue(typeof(T), out index) && now >= index.At && now - index.At < SharedIndexEvery)
                return (Dictionary<int, T>)index.Map;
            var result = BuildShared<T>();
            SharedIndexes[typeof(T)] = new SharedIndex { At = now, Map = result };
            return result;
        }
        private static Dictionary<int, T> BuildShared<T>() where T : Component
        {
            var result = new Dictionary<int, T>();
            var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrain;
            foreach (var c in Object.FindObjectsOfType<T>(true))
            {
                if (c == null || Foreign(c, train) || typeof(T) == typeof(ObjectBreak) && !Seasonal(c as ObjectBreak)) continue;
                int id = PlaceKey(c);
                HashSet<int> ambiguous;
                if (typeof(T) == typeof(ObjectBreak) && AmbiguousSeason.TryGetValue(c.gameObject.scene.handle, out ambiguous) && ambiguous.Contains(id)) continue;
                if (result.ContainsKey(id)) result[id] = null; // all ambiguous instances fail closed
                else if (result.Count < 4096) result.Add(id, c);
            }
            return result;
        }
        private static bool SeasonCollectPrefix() { return !LanSaveIsolation.Active; }
        private static bool SeasonBreakPrefix(ObjectBreak __instance)
        {
            if (!Seasonal(__instance) || !LanSaveIsolation.Active) return true;
            var owner = _guestCurrent;
            if (owner != null) owner.RequestShared(__instance, LanProtocol.SceneSeasonal);
            return false; // no local destruction, counter increment or reward
        }
        private static bool EventTriggerPrefix(SceneEventTrigger __instance)
        {
            if (__instance == null) return false;
            if (LanSaveIsolation.Active)
            {
                var owner = _guestCurrent;
                if (owner != null) owner.RequestShared(__instance, LanProtocol.SceneEvent);
                return false;
            }
            if (_eventTriggered(__instance)) return true; // observe only: preserve offline/native repeated Trigger semantics
            int pulse;
            EventPulses.TryGetValue(__instance, out pulse);
            EventPulses[__instance] = Math.Min(99999, pulse + 1);
            return true;
        }
        private void RequestShared(Component c, byte kind)
        {
            if (!_ready || c == null) return;
            int id = PlaceKey(c);
            Component unique;
            if (kind == LanProtocol.SceneSeasonal) { ObjectBreak b; UniqueShared<ObjectBreak>().TryGetValue(id, out b); unique = b; }
            else { SceneEventTrigger t; UniqueShared<SceneEventTrigger>().TryGetValue(id, out t); unique = t; }
            if (unique != c) return;
            Use(new Entry { Id = id, Kind = kind, Target = c });
        }
        private void HostSharedUse(int id, byte kind, Vector3 guest)
        {
            Component target;
            if (kind == LanProtocol.SceneSeasonal) { ObjectBreak b; UniqueShared<ObjectBreak>().TryGetValue(id, out b); target = b; }
            else { SceneEventTrigger t; UniqueShared<SceneEventTrigger>().TryGetValue(id, out t); target = t; }
            if (target == null || !target.gameObject.activeInHierarchy || (target.transform.position - guest).sqrMagnitude > ButtonReach * ButtonReach) return;
            float last, now = Time.unscaledTime;
            if (_usedAt.TryGetValue(id, out last) && now - last < UseEvery) return;
            _usedAt[id] = now;
            if (kind == LanProtocol.SceneSeasonal) { if (!_seasonBroken((ObjectBreak)target)) ((ObjectBreak)target).ObjectBreaks(); }
            else if (!_eventTriggered((SceneEventTrigger)target)) AccessTools.Method(typeof(SceneEventTrigger), "Trigger").Invoke(target, null);
            _sharedSendAt = 0;
        }
        private void SendSharedWorld(float now)
        {
            if (now < _sharedSendAt) return;
            _sharedSendAt = now + .5f;
            var frames = new List<SceneFrame>();
            var live = UniqueShared<ObjectBreak>();
            foreach (var scene in SeasonCatalogue)
            {
                bool loaded = false;
                for (int i = 0; i < SceneManager.sceneCount; i++) {
                    var candidate = SceneManager.GetSceneAt(i);
                    if (candidate.handle == scene.Key && candidate.isLoaded) { loaded = true; break; }
                }
                if (!loaded) continue;
                foreach (var pair in scene.Value)
                {
                    HashSet<int> ambiguous;
                    if (AmbiguousSeason.TryGetValue(scene.Key, out ambiguous) && ambiguous.Contains(pair.Key)) continue;
                    ObjectBreak c;
                    bool exists = live.TryGetValue(pair.Key, out c);
                    if (exists && ReferenceEquals(c, null)) continue; // ambiguous
                    frames.Add(new SceneFrame { Id = pair.Key, Kind = LanProtocol.SceneSeasonal, Flags = (byte)(!exists || c == null || _seasonBroken(c) ? 1 : 0) });
                }
            }
            int seasonalCount = frames.Count;
            foreach (var pair in UniqueShared<SceneEventTrigger>())
            {
                if (pair.Value == null) continue;
                int pulse; EventPulses.TryGetValue(pair.Value, out pulse);
                frames.Add(new SceneFrame { Id = pair.Key, Kind = LanProtocol.SceneEvent, Flags = (byte)(_eventTriggered(pair.Value) ? 1 : 0), Value = pulse });
            }
            var h = HalloweenEvent.Global;
            if (h != null) frames.Add(new SceneFrame { Id = 1, Kind = LanProtocol.SceneSeasonProgress, Flags = (byte)Mathf.Clamp(h.RewardLevel, 0, 255), Value = Mathf.Clamp(h.CollectedCurrent, 0, 99999) });
            var a = AprilFoolsDayEvent.Global;
            if (a != null) frames.Add(new SceneFrame { Id = 2, Kind = LanProtocol.SceneSeasonProgress, Flags = (byte)Mathf.Clamp(a.RewardLevel, 0, 255), Value = Mathf.Clamp(a.CollectedCurrent, 0, 99999) });
            if (frames.Count == 0) return;
            var batch = new List<SceneFrame>();
            for (int i = seasonalCount; i < frames.Count && batch.Count < LanProtocol.MaxSceneBatch; i++) batch.Add(frames[i]);
            for (int i = 0; i < seasonalCount && batch.Count < LanProtocol.MaxSceneBatch; i++)
            {
                if (_sharedCursor >= seasonalCount) _sharedCursor = 0;
                batch.Add(frames[_sharedCursor++]);
            }
            _send(new Packet { Kind = PacketKind.SceneStates, WorldEpoch = _epoch, Scene = _scene, Sequence = ++_sequence, SceneObjects = batch.ToArray() });
        }
        private void CaptureReward(Zompiercer.Inventory.InventoryItem item, Zompiercer.Train.TrainPart part)
        {
            if (item != null) { bool hidden = item.HideInMenu; _restoreSeason.Add(() => { if (item != null) item.HideInMenu = hidden; }); }
            if (part != null) { bool hidden = part.HideInMenu; _restoreSeason.Add(() => { if (part != null) part.HideInMenu = hidden; }); }
        }
        private void ClearSharedGuest()
        {
            foreach (var pair in _seasonVisibility) if (pair.Key != null) pair.Key.gameObject.SetActive(pair.Value);
            _seasonVisibility.Clear();
            foreach (var restore in _restoreSeason) restore();
            _restoreSeason.Clear(); _capturedSeason.Clear(); _seasonProgress.Clear(); _eventReceipts.Clear();
        }
        private bool ApplySharedWorld(SceneFrame frame)
        {
            if (frame.Kind == LanProtocol.SceneSeasonal)
            {
                ObjectBreak c;
                if (UniqueShared<ObjectBreak>().TryGetValue(frame.Id, out c) && c != null)
                {
                    bool original;
                    if (frame.Flags == 1)
                    {
                        if (!_seasonVisibility.ContainsKey(c)) _seasonVisibility[c] = c.gameObject.activeSelf;
                        c.gameObject.SetActive(false);
                    }
                    else if (_seasonVisibility.TryGetValue(c, out original)) c.gameObject.SetActive(original);
                }
                return true;
            }
            if (frame.Kind == LanProtocol.SceneEvent)
            {
                SceneEventTrigger c;
                if (!UniqueShared<SceneEventTrigger>().TryGetValue(frame.Id, out c) || c == null) return true;
                bool play = _eventReceipts.Observe(frame.Id, frame.Flags == 1, (int)frame.Value);
                _eventTriggered(c) = frame.Flags == 1;
                if (play && c.PlayAudioSource != null) c.PlayAudioSource.Play();
                return true;
            }
            if (frame.Kind != LanProtocol.SceneSeasonProgress) return false;
            if (frame.Id == 1 && HalloweenEvent.Global == null || frame.Id == 2 && AprilFoolsDayEvent.Global == null) return true;
            ulong signature = ((ulong)(int)frame.Value << 8) | frame.Flags, previous;
            if (_seasonProgress.TryGetValue(frame.Id, out previous) && previous == signature) return true;
            _seasonProgress[frame.Id] = signature;
            // Never call SetCollectedCurrent/OnCollected/Load: those can GiveReward.
            // Native Reward.Unlock only exposes recipes; SetRewardLevel is idempotent.
            if (frame.Id == 1 && HalloweenEvent.Global != null)
            {
                var h = HalloweenEvent.Global;
                if (_capturedSeason.Add(1))
                {
                    int count = h.CollectedCurrent, level = h.RewardLevel;
                    if (h.UIRoot != null) { bool active = h.UIRoot.activeSelf; _restoreSeason.Add(() => { if (h != null && h.UIRoot != null) h.UIRoot.SetActive(active); }); }
                    if (h.UIText != null) { string text = h.UIText.text; _restoreSeason.Add(() => { if (h != null && h.UIText != null) h.UIText.text = text; }); }
                    _restoreSeason.Add(() => { if (h != null) { h.CollectedCurrent = count; h.RewardLevel = level; } });
                    if (h.Rewards != null) foreach (var reward in h.Rewards) if (reward != null) CaptureReward(reward.item, reward.trainPart);
                }
                bool notify = h.ShowNotificationWhenUnlock;
                try { h.ShowNotificationWhenUnlock = false; if (h.Rewards != null) for (int i = 0; i < h.Rewards.Length; i++) { var r = h.Rewards[i]; if (r != null) { if (r.item != null) r.item.HideInMenu = i >= frame.Flags; if (r.trainPart != null) r.trainPart.HideInMenu = i >= frame.Flags; } } h.CollectedCurrent = (int)frame.Value; h.SetRewardLevel(Math.Min(frame.Flags, h.Rewards == null ? 0 : h.Rewards.Length)); if (h.UIText != null) h.UIText.text = h.CollectedCurrent + " / " + h.CollectedMax; }
                finally { h.ShowNotificationWhenUnlock = notify; }
            }
            if (frame.Id == 2 && AprilFoolsDayEvent.Global != null)
            {
                var a = AprilFoolsDayEvent.Global;
                if (_capturedSeason.Add(2))
                {
                    int count = a.CollectedCurrent, level = a.RewardLevel;
                    if (a.UIRoot != null) { bool active = a.UIRoot.activeSelf; _restoreSeason.Add(() => { if (a != null && a.UIRoot != null) a.UIRoot.SetActive(active); }); }
                    if (a.UIText != null) { string text = a.UIText.text; _restoreSeason.Add(() => { if (a != null && a.UIText != null) a.UIText.text = text; }); }
                    _restoreSeason.Add(() => { if (a != null) { a.CollectedCurrent = count; a.RewardLevel = level; } });
                    if (a.Rewards != null) foreach (var reward in a.Rewards) if (reward != null) CaptureReward(reward.item, reward.trainPart);
                }
                bool notify = a.ShowNotificationWhenUnlock;
                try { a.ShowNotificationWhenUnlock = false; if (a.Rewards != null) for (int i = 0; i < a.Rewards.Length; i++) { var r = a.Rewards[i]; if (r != null) { if (r.item != null) r.item.HideInMenu = i >= frame.Flags; if (r.trainPart != null) r.trainPart.HideInMenu = i >= frame.Flags; } } a.CollectedCurrent = (int)frame.Value; a.SetRewardLevel(Math.Min(frame.Flags, a.Rewards == null ? 0 : a.Rewards.Length)); if (a.UIText != null) a.UIText.text = a.CollectedCurrent + " / " + a.CollectedMax; }
                finally { a.ShowNotificationWhenUnlock = notify; }
            }
            return true;
        }
    }
}
