using System.Collections.Generic;

namespace ZompiercerLAN
{
    internal static partial class LanText
    {
        private static void AddGameplay(IDictionary<string, string> map)
        {
            map["Готово"] = "Done";
            map["У хоста нет такого хранилища или предмета"] = "The host has no such storage or item";
            map["Слишком далеко от хранилища"] = "Too far from storage";
            map["Не хватает места"] = "Not enough space";
            map["Этот предмет сюда нельзя положить"] = "This item cannot go here";
            map["Хост занят этим хранилищем; попробуйте ещё раз"] = "The host is using this storage; try again";
            map["Хранилище закрыто"] = "Storage is closed";
            map["Хост отклонил запрос"] = "The host rejected the request";
            map["Хост ещё не поставил ваши вещи на учёт (или ваш профиль не сохраняется)"] = "The host has not recorded your items yet (or your profile cannot be saved)";
            map["Слишком сложный предмет для передачи"] = "This item is too complex to transfer";
            map["По учёту хоста у вас нет такой вещи"] = "The host's records show you do not have this item";
            map["Здесь ничего не осталось"] = "Nothing left here";
            map["Для ручного крафта откройте окно этого верстака и оставайтесь рядом"] = "For manual crafting, open this workbench and stay nearby";
            map["Бак поезда уже полон"] = "The train tank is already full";
            map["Не хватает ресурсов для постройки"] = "Not enough resources to build";
            map["Это место у хоста уже занято"] = "The host has already occupied this spot";
            map["Хост сейчас не видит, где вы; подождите пару секунд"] = "The host cannot see your position yet; wait a few seconds";
            map["Сломано: вставьте запасной рычаг"] = "Broken: insert a spare lever";
            map["Хост не разрешил вам управлять поездом"] = "The host has not allowed you to control the train";
            map["У хоста этот квест ещё не готов к сдаче или уже сдан"] = "This quest is not ready to turn in at the host, or was already turned in";
            map["Это не ваш робопёс"] = "This is not your robot dog";
            map["Сначала освободите хранилище этого устройства"] = "Empty this device's storage first";
            map["Сначала выньте всё, что внутри"] = "Remove everything inside first";
            map["Ошибка хранилища "] = "Storage error ";
            map["У хоста нет такой двери"] = "The host has no such door";
            map["Подойдите к двери ближе"] = "Move closer to the door";
            map["Эту дверь нельзя открыть"] = "This door cannot be opened";
            map["Дверь сломана"] = "The door is broken";
            map["Дверь заперта"] = "The door is locked";
            map["Открытие…"] = "Opening…";
            map["Рюкзак полон"] = "Backpack is full";
            map["Хост прислал повреждённый предмет"] = "The host sent a damaged item";
            map["Предмет не удалось положить в рюкзак"] = "Could not put the item in the backpack";
            map["Чертёж поставлен у хоста"] = "Blueprint placed at the host";
            map["Починено"] = "Repaired";
            map["Построено"] = "Built";
            map["Поместилось "] = "Stored ";

            map["Это робопёс друга"] = "This is a friend's robot dog";
            map["Это несёт друг"] = "A friend is carrying this";
            map["ЧУЖОЙ РОБОПЁС"] = "FRIEND'S ROBOT DOG";
            map["РОБОПЁС (НИЧЕЙ)"] = "ROBOT DOG (UNOWNED)";
            map["Сначала выключите робопса"] = "Switch off the robot dog first";
            map["Это нельзя взять"] = "You cannot pick this up";
            map["Связь с хостом…"] = "Connecting to host…";
            map["Хост прислал повреждённое состояние"] = "The host sent a damaged state";
            map["Аптечка ещё не готова"] = "The medkit is not ready yet";
            map["Аптечка робопса лечит"] = "The robot dog's medkit is healing";
            map["Хост ещё отвечает на прошлые запросы"] = "The host is still answering earlier requests";
            map["Ждать"] = "Wait";
            map["Следовать"] = "Follow";
            map["Не открывать"] = "Do not open";
            map["Открывать"] = "Open";
            map["Ваш робопёс"] = "Your robot dog";
            map["Включён"] = "On";
            map["Выключен"] = "Off";
            map[" · сломан"] = " · broken";
            map[" · заряд "] = " · charge ";
            map["% · прочность "] = "% · durability ";
            map["Выключить"] = "Switch off";
            map["На поезде не включается"] = "Cannot switch on aboard the train";
            map["Включить"] = "Switch on";
            map["Поведение"] = "Behavior";
            map["Атака: "] = "Attack: ";
            map["Двери"] = "Doors";
            map["Устройства"] = "Devices";
            map["Хранилище"] = "Storage";
            map["Лечиться"] = "Heal";
            map["Аптечка…"] = "Medkit…";
            map["Улучшения"] = "Upgrades";
            map["Взять на руки: R, глядя на робопса."] = "Pick up: press R while looking at the robot dog.";
            map["Закрыть (E / Esc)"] = "Close (E / Esc)";
            map["пусто"] = "empty";

            map["Окно робопса не открылось"] = "The robot dog window did not open";
            map["Хост не ответил"] = "The host did not respond";
            map["Подождите: хост ещё меняет устройства"] = "Wait: the host is still changing devices";
            map["Сначала снимите то, что стоит в этой ячейке"] = "Remove what is in this slot first";
            map["Положите предмет в рюкзак, потом в ячейку"] = "Put the item in your backpack, then into the slot";
            map["В этой ячейке у хоста ничего нет"] = "The host has nothing in this slot";
            map["Сломан · "] = "Broken · ";
            map["Заряд "] = "Charge ";
            map["Хранилище "] = "Storage ";
            map["Аптечка "] = "Medkit ";

            map["Хранилища открываются только у хоста, во время игры вместе"] = "Storage can only be opened at the host while playing together";
            map["Это хранилище нельзя открыть по сети"] = "This storage cannot be opened over the network";
            map["Окно хранилища не открылось"] = "The storage window did not open";
            map["Крафт у верстака хоста недоступен в этой версии игры"] = "Crafting at the host's workbench is unavailable in this game version";
            map["Сначала возьмите предмет в рюкзак"] = "Put the item in your backpack first";
            map["Этот предмет уже взяли"] = "This item has already been taken";
            map["Хранилище хоста ещё загружается"] = "The host's storage is still loading";
            map["Хост ещё переносит вещи, подождите"] = "The host is still moving items; please wait";
            map["Сначала переложите предмет в рюкзак"] = "Move the item to your backpack first";
            map["Не хватает ресурсов"] = "Not enough resources";
            map["Хост ещё не принял прошлые заказы; подождите"] = "The host has not accepted the earlier orders yet; please wait";
            map["Хост ещё не ответил; нажмите ещё раз"] = "The host has not responded yet; press again";
            map["Этот предмет нельзя передать"] = "This item cannot be transferred";
            map["Предмет "] = "Item ";

            map["Квест сдан: "] = "Quest turned in: ";
            map["Нужно: "] = "Needed: ";
            map["Награда за квест «"] = "Quest reward for “";
            map["» достанется и друзьям"] = "” also goes to friends";
            map["Этот квест у хоста не найден"] = "The host could not find this quest";
            map["Квесты сейчас недоступны"] = "Quests are unavailable right now";
            map["Награда за квест ждёт: освободите место в рюкзаке"] = "Quest reward is waiting: make room in your backpack";
            map["По учёту хоста у вас нет: "] = "The host's records show you lack: ";
            map["Хост не принял квест: "] = "The host did not accept the quest: ";
            map["»: его сдал другой игрок"] = "”: another player turned it in";
            map[" взял квест «"] = " accepted the quest “";
            map[" сдал квест «"] = " turned in the quest “";
            map[" получил награду за квест «"] = " received a reward for the quest “";
            map["»"] = "”";

            map["Строить на поезде хоста можно, когда хост сохраняет ваш профиль"] = "You can build on the host's train when the host saves your profile";
            map["Красить и проводить провода на поезде хоста можно, когда хост сохраняет ваш профиль"] = "You can paint and wire the host's train when the host saves your profile";
            map["Строить можно только на поезде хоста"] = "You can only build on the host's train";
            map["Чертёж отправлен хосту"] = "Blueprint sent to the host";
            map["Хост ещё отвечает на прошлый запрос"] = "The host is still answering the previous request";
            map["Не хватает: "] = "Missing: ";
            map["Разбирать на поезде хоста можно, когда хост сохраняет ваш профиль"] = "You can dismantle on the host's train when the host saves your profile";
            map["Разобрано"] = "Dismantled";
            map["Это нельзя разобрать"] = "This cannot be dismantled";
            map["Этого у хоста уже нет"] = "The host no longer has this";
            map["Ставить мебель на поезд хоста можно, когда хост сохраняет ваш профиль"] = "You can place furniture on the host's train when the host saves your profile";
            map["Мебель поставлена у хоста: соберите её инструментом"] = "Furniture placed at the host: assemble it with a tool";
            map["Хост не поставил мебель: "] = "The host did not place the furniture: ";
            map["Убирать чертежи на поезде хоста можно, когда хост сохраняет ваш профиль"] = "You can remove blueprints on the host's train when the host saves your profile";

            map["Профиль друга: ожидание подключения"] = "Friend profile: waiting for connection";
            map["Профиль друга: проверка"] = "Friend profile: checking";
            map["Этот профиль друга уже подключён; повторный вход отклонён"] = "This friend profile is already connected; duplicate login rejected";
            map["Профиль друга найден; отправка"] = "Friend profile found; sending";
            map["Новый профиль друга"] = "New friend profile";
            map["Профиль друга восстановлен; вещи на учёте у хоста"] = "Friend profile restored; items recorded by the host";
            map["Новый друг: проверьте его вещи в панели"] = "New friend: review their items in the panel";
            map["Профиль друга сохранён в памяти ("] = "Friend profile saved in memory (";
            map["); на диск — при сохранении игры"] = "); to disk when the game is saved";
            map["У друга были уровень, здоровье или потребности сверх объяснимого; отправлена коррекция"] = "Friend had unexplained level, health, or needs; correction sent";
            map["У друга были вещи сверх учёта хоста; отправлена коррекция"] = "Friend had items beyond the host's records; correction sent";
            map["Вещи друга приняты; теперь они на учёте у хоста"] = "Friend's items accepted and recorded by the host";
            map["Друг начинает без вещей"] = "Friend starts without items";
            map["; приветственный подарок добавлен в рюкзак"] = "; welcome gift added to the backpack";
            map["Приветственный подарок добавлен в рюкзак"] = "Welcome gift added to the backpack";
            map["Профиль: ожидание хоста"] = "Profile: waiting for host";
            map["Хост ещё не прислал профиль; ждём его в игре"] = "The host has not sent the profile yet; waiting in game";
            map["Ключ игрока недоступен; профиль не сохраняется"] = "Player key unavailable; profile will not be saved";
            map["Хост создаёт новый профиль"] = "Host is creating a new profile";
            map["Получение профиля от хоста"] = "Receiving profile from host";
            map["Хост присылает вещи по своему учёту"] = "Host is sending items from its records";
            map["Профиль от хоста повреждён; прогресс этого входа не сохранится"] = "Host profile is damaged; progress from this session will not be saved";
            map["Не удалось восстановить персонажа ("] = "Could not restore character (";
            map["); прогресс этого входа не сохранится"] = "); progress from this session will not be saved";
            map["Новый профиль; прогресс сохраняется у хоста"] = "New profile; progress is saved by the host";
        }
    }
}
