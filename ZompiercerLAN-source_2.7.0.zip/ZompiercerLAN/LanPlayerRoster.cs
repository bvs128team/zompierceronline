using System;
using System.Collections.Generic;

namespace ZompiercerLAN
{
    // Ordered, complete snapshots. A slot can be reused; its secure session distinguishes occupants.
    internal sealed class LanPlayerRoster
    {
        private readonly Dictionary<int, ulong> _sessions = new Dictionary<int, ulong>();
        // Occupants the roster named whose first state has not been shown yet.
        private readonly HashSet<int> _fresh = new HashSet<int>();
        private uint _sequence;
        private bool _received;

        internal void Reset() { _sessions.Clear(); _fresh.Clear(); _sequence = 0; _received = false; }

        internal PlayerSeat[] Snapshot()
        {
            var seats = new PlayerSeat[_sessions.Count];
            int index = 0;
            foreach (var seat in _sessions) seats[index++] = new PlayerSeat { Player = (byte)seat.Key, Session = seat.Value };
            return seats;
        }

        // 2.1.0: every Players packet names all the other guests present (Roster); the newest packet decides who is
        // present. Its states are some of them (the host splits six over packets): a state is shown while its slot's
        // occupant is the one the current roster names, also from a packet that came late. False: nothing applied.
        internal bool Apply(Packet snapshot, int localSlot, Action<int> remove, Action<Packet, bool> show)
        {
            if (snapshot == null || snapshot.Roster == null || snapshot.Players == null || snapshot.Roster.Length > LanProtocol.MaxOthers ||
                snapshot.Players.Length > snapshot.Roster.Length) return false;
            var present = new Dictionary<int, ulong>();
            foreach (var seat in snapshot.Roster)
            {
                if (seat == null || seat.Player == 0 || seat.Player == localSlot || !LanProtocol.ValidPlayer(seat.Player) ||
                    seat.Session == 0 || present.ContainsKey(seat.Player)) return false;
                present.Add(seat.Player, seat.Session);
            }
            var stated = new HashSet<int>();
            foreach (var state in snapshot.Players)
            {
                ulong session;
                if (state == null || !present.TryGetValue(state.Player, out session) || session != state.Session || !stated.Add(state.Player)) return false;
            }
            bool newest = !_received || Newer(snapshot.Sequence, _sequence);
            if (newest)
            {
                _received = true; _sequence = snapshot.Sequence;
                foreach (int slot in new List<int>(_sessions.Keys))
                    if (!present.ContainsKey(slot)) { _sessions.Remove(slot); _fresh.Remove(slot); remove(slot); }
                foreach (var seat in present)
                {
                    ulong session;
                    if (_sessions.TryGetValue(seat.Key, out session) && session == seat.Value) continue;
                    if (_sessions.ContainsKey(seat.Key)) remove(seat.Key); // another player sits there now
                    _sessions[seat.Key] = seat.Value; _fresh.Add(seat.Key);
                }
            }
            int shown = 0;
            foreach (var state in snapshot.Players)
            {
                ulong session;
                if (!_sessions.TryGetValue(state.Player, out session) || session != state.Session) continue; // a former occupant
                show(state, _fresh.Remove(state.Player)); shown++;
            }
            return newest || shown > 0;
        }

        internal static bool Newer(uint value, uint previous) { return unchecked((int)(value - previous)) > 0; }
    }
}
