using System.Collections.Generic;
namespace ZompiercerLAN
{
    // A first observation is a silent baseline, even if its pulse is already nonzero.
    internal sealed class LanSceneEventReceipts
    {
        private readonly Dictionary<int, int> seen = new Dictionary<int, int>();
        internal bool Observe(int id, bool triggered, int pulse)
        {
            int previous;
            bool known = seen.TryGetValue(id, out previous);
            if (!known && seen.Count >= 4096) return false;
            if (!known || pulse > previous) seen[id] = pulse;
            return known && triggered && pulse > previous;
        }
        internal void Clear() { seen.Clear(); }
    }
}
