using UnityEngine;

namespace ZompiercerLAN
{
    // The same HUD used by InteractingObjectsController for native construction and wear.
    // Called after native Update, which clears this HUD before examining its own selection.
    internal static class LanWorkProgress
    {
        internal static float Fraction(float current, float maximum)
        {
            if (float.IsNaN(current) || float.IsInfinity(current) || float.IsNaN(maximum) ||
                float.IsInfinity(maximum) || maximum <= 0f) return 0f;
            return Mathf.Clamp01(current / maximum);
        }

        internal static void Show(float current, float maximum)
        {
            var manager = GlobalManager.global;
            if (manager == null || maximum <= 0f) return;
            float fraction = Fraction(current, maximum);
            if (manager.buildProgressInfoDisplayer != null) manager.buildProgressInfoDisplayer.SetActive(true);
            if (manager.buildProgressInfoBar != null) manager.buildProgressInfoBar.localScale = new Vector3(fraction, 1f, 1f);
            if (manager.buildProgressInfoText != null) manager.buildProgressInfoText.text = Mathf.RoundToInt(100f * fraction) + "%";
        }
    }
}
