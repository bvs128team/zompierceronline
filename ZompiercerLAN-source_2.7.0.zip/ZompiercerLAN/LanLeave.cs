using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;
using UnityEngine;
using Object = UnityEngine.Object;

namespace ZompiercerLAN
{
    // Leaving the game (1.4.5). The game's own "exit to main menu" ends this player's session (the
    // plugin tells the partner with a Leave packet), and a guest whose host left goes back to the main
    // menu the same way instead of staying in a frozen copy of the host's world. Main thread only.
    internal static class LanLeave
    {
        private static Harmony _harmony;
        private static bool _bypass;
        internal static string Failure { get; private set; }
        // The local player chose "exit to main menu" in the game's menu.
        internal static Action Leaving;

        internal static void Initialize(Action<string> log)
        {
            if (_harmony != null || Failure != null) return;
            _harmony = new Harmony("local.zompiercer.lan.leave");
            try
            {
                _harmony.Patch(AccessTools.Method(typeof(Zompiercer.GUI.GUIManager), "ExitGameToMainMenuYesButton"), prefix: new HarmonyMethod(typeof(LanLeave), nameof(ExitPrefix)));
                _harmony.Patch(AccessTools.Method(typeof(GlobalSceneManager), "DeleteEverything2"), transpiler: new HarmonyMethod(typeof(LanLeave), nameof(KeepPluginManager)));
            }
            catch (Exception ex)
            {
                // Without it the partner notices a player who left by the silence, as before 1.4.5.
                Failure = ex.GetType().Name + ": " + ex.Message;
                _harmony.UnpatchSelf();
                log("Leave hook unavailable: " + Failure);
            }
        }
        internal static void Shutdown() { _harmony?.UnpatchSelf(); _harmony = null; Leaving = null; }

        // The native menu reset destroys all visible GameObjects, including the
        // BepInEx manager when HideManagerGameObject=false. Keep its actual object
        // and children alive; every game object still follows native destruction.
        private static IEnumerable<CodeInstruction> KeepPluginManager(IEnumerable<CodeInstruction> instructions)
        {
            var destroy = AccessTools.Method(typeof(Object), nameof(Object.Destroy), new[] { typeof(Object) });
            int replaced = 0;
            foreach (var instruction in instructions)
            {
                if (instruction.Calls(destroy))
                {
                    instruction.opcode = OpCodes.Call;
                    instruction.operand = AccessTools.Method(typeof(LanLeave), nameof(DestroyWorldObject));
                    replaced++;
                }
                yield return instruction;
            }
            if (replaced != 1) throw new InvalidOperationException("Native main-menu cleanup changed.");
        }

        private static void DestroyWorldObject(Object target)
        {
            var manager = BepInEx.Bootstrap.Chainloader.ManagerObject;
            var go = target as GameObject;
            if (manager != null && go != null &&
                (go == manager || go.transform.IsChildOf(manager.transform))) return;
            Object.Destroy(target);
        }

        private static void ExitPrefix()
        {
            if (_bypass) return;
            try { Leaving?.Invoke(); }
            catch (Exception) { } // leaving the world goes on regardless
        }

        // The game's own way back to the main menu (as its menu's "yes").
        internal static bool ToMainMenu()
        {
            var gui = LanGame.Gui;
            if (gui == null) return false;
            _bypass = true;
            try { gui.ExitGameToMainMenuYesButton(); return true; }
            finally { _bypass = false; }
        }
    }
}
