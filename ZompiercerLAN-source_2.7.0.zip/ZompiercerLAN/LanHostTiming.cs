using System;
using System.Diagnostics;
using System.Text;

namespace ZompiercerLAN
{
    // 2.4.0, host: how long the mod's parts take in the host's frames, for finding what loads the host's PC. A
    // stopwatch around each part of LanPlugin.Update and LateUpdate; every 15 s, while guests are connected, one line
    // in the host's log: the frame time and rate the game had, and per part milliseconds per frame (average and the
    // worst frame). Numbers only (no names, addresses or positions), nothing is sent. A failure only stops the lines.
    internal static class LanHostTiming
    {
        internal const int Coop = 0, Network = 1, Guests = 2, Train = 3, Zombies = 4, World = 5, Avatars = 6, Parts = 7;
        private static readonly string[] Names = { "coop", "network", "guests", "train", "zombies", "world", "avatars" };
        private const float Every = 15f;
        private static readonly double TickMs = 1000.0 / Stopwatch.Frequency;
        private static readonly long[] Total = new long[Parts], Frame = new long[Parts], Worst = new long[Parts];
        private static long _worstMod;
        private static int _frames;
        private static double _frameSeconds, _worstFrame;
        private static float _nextReport = -1f;
        private static bool _failed;
        private static long _callbackFrame, _callbackTotal, _callbackWorst, _lastFrameAt;
        private static long _checkpointTotal, _checkpointWorst;
        private static int _checkpointCount;
        private static double _wallTotal, _wallWorst, _unattributedTotal, _unattributedWorst;

        internal static long Now { get { return Stopwatch.GetTimestamp(); } }

        // Wrap each complete Update/LateUpdate/OnGUI callback in try/finally, including early returns.
        // This is independent of the named sections, so nested checkpoint timings are not double counted.
        internal static void EndCallback(long start) { _callbackFrame += Now - start; }
        internal static void RecordCheckpoint(long start)
        {
            long elapsed = Now - start;
            _checkpointCount++; _checkpointTotal += elapsed;
            if (elapsed > _checkpointWorst) _checkpointWorst = elapsed;
        }

        // The time since `start` goes to `part`; returns the time now (the start of the next part).
        internal static long Add(int part, long start)
        {
            long now = Stopwatch.GetTimestamp();
            Frame[part] += now - start;
            return now;
        }

        // Once a frame (start of LanPlugin.Update): the frame that ended goes into the sums; every 15 s, while hosting
        // with guests, one line in the log. `zombies` is asked for only then.
        internal static void EndFrame(bool hosting, int guests, Func<int> zombies, float now, float deltaSeconds, Action<string> log)
        {
            if (_failed) return;
            try
            {
                long stamp = Now;
                double wall = _lastFrameAt == 0 ? deltaSeconds * 1000.0 : (stamp - _lastFrameAt) * TickMs;
                _lastFrameAt = stamp;
                _wallTotal += wall; _wallWorst = Math.Max(_wallWorst, wall);
                _callbackTotal += _callbackFrame; _callbackWorst = Math.Max(_callbackWorst, _callbackFrame);
                double unattributed = Math.Max(0, wall - _callbackFrame * TickMs);
                _unattributedTotal += unattributed; _unattributedWorst = Math.Max(_unattributedWorst, unattributed);
                _callbackFrame = 0;
                long mod = 0;
                for (int i = 0; i < Parts; i++)
                {
                    Total[i] += Frame[i]; mod += Frame[i];
                    if (Frame[i] > Worst[i]) Worst[i] = Frame[i];
                    Frame[i] = 0;
                }
                if (mod > _worstMod) _worstMod = mod;
                if (!hosting || guests == 0) { Reset(now); return; }
                _frames++; _frameSeconds += deltaSeconds;
                if (deltaSeconds > _worstFrame) _worstFrame = deltaSeconds;
                if (_nextReport < 0f) { Reset(now); return; }
                if (now < _nextReport || _frames == 0) return;
                double frameMs = _frameSeconds * 1000.0 / _frames;
                long all = 0; for (int i = 0; i < Parts; i++) all += Total[i];
                var line = new StringBuilder("Host load (").Append(Every.ToString("0")).Append(" s, ").Append(guests).Append(guests == 1 ? " guest" : " guests")
                    .Append(", ").Append(zombies == null ? 0 : zombies()).Append(" zombies awake): frame ").Append(frameMs.ToString("0.0")).Append(" ms (")
                    .Append((frameMs > 0 ? 1000.0 / frameMs : 0).ToString("0")).Append(" fps, worst ").Append((_worstFrame * 1000.0).ToString("0")).Append(" ms); mod ")
                    .Append(Ms(all)).Append(" ms per frame (worst ").Append((_worstMod * TickMs).ToString("0.0")).Append(")");
                for (int i = 0; i < Parts; i++)
                    line.Append(i == 0 ? ": " : ", ").Append(Names[i]).Append(' ').Append(Ms(Total[i])).Append(" (").Append((Worst[i] * TickMs).ToString("0.0")).Append(')');
                line.Append("; complete callbacks ").Append(Ms(_callbackTotal)).Append(" ms (worst ").Append((_callbackWorst * TickMs).ToString("0.0"))
                    .Append("); callback remainder ").Append(Ms(Math.Max(0, _callbackTotal - all)))
                    .Append("; wall frame ").Append((_wallTotal / _frames).ToString("0.0")).Append(" ms (worst ").Append(_wallWorst.ToString("0.0"))
                    .Append("); outside callbacks ").Append((_unattributedTotal / _frames).ToString("0.0")).Append(" ms (worst ").Append(_unattributedWorst.ToString("0.0"))
                    .Append("); checkpoint capture count=").Append(_checkpointCount).Append(" totalMs=").Append((_checkpointTotal * TickMs).ToString("0.0"))
                    .Append(" worstMs=").Append((_checkpointWorst * TickMs).ToString("0.0"))
                    .Append("; ").Append(LanInventoryGuard.WriterStatus());
                log(line.ToString());
                Reset(now);
            }
            catch (Exception ex) { _failed = true; log("Host load measurement stopped: " + ex.GetType().Name + ": " + ex.Message); }
        }

        private static string Ms(long ticks) { return (ticks * TickMs / Math.Max(1, _frames)).ToString("0.00"); }

        private static void Reset(float now)
        {
            Array.Clear(Total, 0, Parts); Array.Clear(Worst, 0, Parts);
            _worstMod = 0; _frames = 0; _frameSeconds = 0; _worstFrame = 0;
            _nextReport = now + Every;
            _callbackTotal = _callbackWorst = _checkpointTotal = _checkpointWorst = 0;
            _checkpointCount = 0;
            _wallTotal = _wallWorst = _unattributedTotal = _unattributedWorst = 0;
        }
    }
}
