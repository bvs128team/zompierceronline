using System;
using UnityEngine;

namespace ZompiercerLAN
{
    // 2.7.0: how the other player's avatar holds what it holds, worked out offline on the game's own meshes (both avatar
    // rigs, with the tire armour, gas mask and helmet, rendered from several sides): a long gun's butt in the right
    // shoulder over the armed NPC's twisted aiming torso (aimed, or lowered 30 degrees and turned in), a handgun in both
    // hands (out before the face, or low before the chest), the bow in the left hand with the right at the nock, a shovel
    // across the body, a one-hand tool or weapon at the hip, and eating, drinking, a medkit, a bandage and pills. Every
    // grip is the game's own first-person hand on that item (RemoteNativeGrip), the arms are a two-bone reach with an
    // anatomical elbow hinge, the forearm's twist bones share the wrist's turn. Pure geometry on positions and
    // rotations, so the offline checks run it on the same inputs as the renders; RemoteAvatarMotion supplies the body
    // and turns the bones.
    internal static class RemoteHoldPose
    {
        internal enum Kind : byte { None, Long, Handgun, Bow, TwoHand, OneHand }

        // By the game's Gun.ID of the native first-person weapon (RemoteNativeGrip's catalogue).
        internal static Kind KindOf(string gunId)
        {
            switch (gunId)
            {
                case "AKM": case "Hunting Rifle": case "OldRifle": case "Remington": case "ShotgunM4": case "Sawed-off shotgun":
                    return Kind.Long;
                case "Glock": case "Volter": case "M1911": case "Revolver":
                    return Kind.Handgun;
                case "Bow Rough": case "Bow Reinforced":
                    return Kind.Bow;
                case "Shovel Metal": case "Shovel Scrap":
                    return Kind.TwoHand;
                case null: case "":
                    return Kind.None;
                default:
                    return Kind.OneHand;
            }
        }

        // Stances (degrees, metres): a lowered long gun and how far its muzzle turns in, running lower still; the butt
        // from the right shoulder joint as the game's soldier holds its AK (MRAKMAimingIdle); a handgun held out
        // (share of the arm's reach), lowered; the bow arm's reach and its limbs' cant.
        internal const float LongLow = 30f, LongRun = 45f, LongInward = 15f, HandgunLow = 35f, BowLow = 50f, BowCant = 12f;
        internal static readonly Vector3 ButtFromShoulder = new Vector3(.015f, .028f, .133f);
        internal const float HandgunReach = .78f, BowReach = .93f;
        // A support grip may slide back along the bore this share of the hands' span (a shorter arm); the arm reaches
        // with this share of its length; the collarbone turns forward at most this far for it.
        internal const float SlideShare = .35f, ReachShare = .97f, Protraction = 25f;

        // The avatar after its own animation, the armed torso and the procedural layer: its own axes (yaw only), the
        // chest bone, the shoulder joints, the lips, how far ahead of the chest bone its torso (or armour) is, the arms'
        // lengths and the view's pitch (degrees, up positive).
        internal struct Body
        {
            internal Vector3 Right, Up, Forward, Chest, ShoulderR, ShoulderL, Mouth;
            internal float Front, ReachR, ReachL, Pitch;
            internal Vector3 Axes(float x, float y, float z) { return Right * x + Up * y + Forward * z; }
            internal Vector3 AtChest(float x, float y, float aheadOfFront) { return Chest + Axes(x, y, Front + aheadOfFront); }
        }

        // A palm bone's target: its position, rotation and the elbow's side.
        internal struct Hand
        {
            internal bool Valid;
            internal Vector3 Wrist, Pole;
            internal Quaternion Palm;
        }

        // The anatomical frame of a palm (RemoteNativeGrip.PalmFrame, in the palm bone's space).
        internal struct Palm
        {
            internal Vector3 Center;
            internal Quaternion Rotation;
            internal bool Valid;
        }

        // The native weapon on the primary palm: its holder's local pose under that palm (position, rotation, uniform
        // scale), its root's frame (bore +Z, top +Y), anchors in its own space (the butt plate, the primary grip, the bow's
        // limb tip, the far end of a tool), and the support palm in primary palm space.
        internal struct Weapon
        {
            internal Vector3 HeldPosition, Butt, Grip, Limb, Tool, SupportPosition;
            internal Quaternion HeldRotation, Aim, SupportRotation;
            internal float Scale;
            internal bool Support;
            internal Vector3 Bore { get { return Aim * Vector3.forward; } }
        }

        // The item's own space in the world: world = Position + Rotation * (Scale * x).
        internal struct Frame
        {
            internal Vector3 Position;
            internal Quaternion Rotation;
            internal float Scale;
            internal Vector3 World(Vector3 own) { return Position + Rotation * (own * Scale); }
        }

        // ---------- weapons ----------

        internal static Frame Place(Weapon w, Vector3 anchor, Vector3 anchorAt, Vector3 bore, Vector3 up)
        {
            var rotation = Quaternion.LookRotation(bore, up) * Quaternion.Inverse(w.Aim);
            return new Frame { Rotation = rotation, Scale = w.Scale, Position = anchorAt - rotation * (anchor * w.Scale) };
        }

        internal static Hand PrimaryPalm(Weapon w, Frame f, Vector3 pole)
        {
            var palm = f.Rotation * Quaternion.Inverse(w.HeldRotation);
            return new Hand { Valid = true, Palm = palm, Wrist = f.Position - palm * w.HeldPosition, Pole = pole };
        }

        internal static Hand SupportPalm(Weapon w, Hand primary, Vector3 slide, Vector3 pole)
        {
            if (!w.Support || !primary.Valid) return new Hand();
            return new Hand { Valid = true, Wrist = primary.Wrist + primary.Palm * w.SupportPosition - slide,
                Palm = primary.Palm * w.SupportRotation, Pole = pole };
        }

        // aim: 1 aimed, 0 at the low ready; lower: the low ready's angle (running lower still).
        internal static void LongGun(Body b, Weapon w, float lowered, out Frame f, out Hand right, out Hand left)
        {
            var view = Quaternion.AngleAxis(-b.Pitch, b.Right);
            float inward = LongInward * Mathf.Clamp01(lowered / LongLow);
            var turn = Quaternion.AngleAxis(-inward, b.Up) * Quaternion.AngleAxis(lowered, b.Right) * view;
            var butt = b.ShoulderR + view * b.Axes(ButtFromShoulder.x, ButtFromShoulder.y, ButtFromShoulder.z);
            f = Place(w, w.Butt, butt, turn * b.Forward, turn * b.Up);
            right = PrimaryPalm(w, f, b.Axes(.7f, -.7f, 0f));
            left = SupportPalm(w, right, Vector3.zero, b.Axes(-.3f, -1f, 0f));
        }

        // How far a support grip slides back along the bore so an arm from `shoulder` of length `reach` gets there
        // (0..limit; the closest point on that line when it cannot).
        internal static float Slide(Vector3 shoulder, float reach, Vector3 grip, Vector3 bore, float limit)
        {
            float length = reach * ReachShare;
            var d = grip - shoulder;
            float along = Vector3.Dot(d, bore);
            float disc = along * along - Vector3.Dot(d, d) + length * length;
            float slide = disc >= 0f ? along - Mathf.Sqrt(disc) : along;
            return Mathf.Clamp(slide, 0f, Mathf.Max(0f, limit));
        }

        // The collarbone's forward turn (degrees about the body's up, the shoulder towards the target) for a reach.
        internal static float Protract(Vector3 pivot, Vector3 shoulder, float reach, Vector3 target, Vector3 up, bool left)
        {
            float step = Mathf.Min(Protraction / 6f, 8f), angle = 0f;
            for (int i = 0; i < 6; i++)
            {
                var at = pivot + Quaternion.AngleAxis(angle, up) * (shoulder - pivot);
                if ((target - at).magnitude - reach * ReachShare <= 0f) break;
                angle += left ? step : -step;
            }
            return angle;
        }

        internal static void Handgun(Body b, Weapon w, float aim, out Frame f, out Hand right, out Hand left)
        {
            var view = Quaternion.AngleAxis(-b.Pitch, b.Right);
            var shoulders = (b.ShoulderR + b.ShoulderL) * .5f;
            var outAt = shoulders + view * b.Axes(0f, -.04f, b.ReachR * HandgunReach);
            var lowAt = b.AtChest(.05f, -.22f, .12f);
            var low = Quaternion.AngleAxis(HandgunLow, b.Right);
            var turn = Quaternion.Slerp(low, view, aim);
            f = Place(w, w.Grip, Vector3.Lerp(lowAt, outAt, aim), turn * b.Forward, turn * b.Up);
            right = PrimaryPalm(w, f, b.Axes(.6f, -1f, -.2f));
            left = SupportPalm(w, right, Vector3.zero, b.Axes(-.6f, -1f, -.2f));
        }

        // The bow (left primary): out at the left arm's reach, its limbs stood up; low in the left hand otherwise.
        internal static void Bow(Body b, Weapon w, float aim, out Frame f, out Hand bowHand, out Hand stringHand)
        {
            var view = Quaternion.AngleAxis(-b.Pitch, b.Right);
            var outAt = b.ShoulderL + view * b.Axes(.10f, .02f, b.ReachL * BowReach);
            var lowAt = b.AtChest(-.20f, -.42f, .08f);
            var turn = Quaternion.Slerp(Quaternion.AngleAxis(BowLow, b.Right), view, aim);
            var at = Vector3.Lerp(lowAt, outAt, aim);
            f = Place(w, w.Grip, at, turn * b.Forward, turn * b.Up);
            // The first-person bow is canted far over: turn it about the arrow until its limbs stand (top to the right).
            var bore = f.Rotation * w.Bore;
            var grip = w.Grip; var ownBore = w.Bore;
            var limb = w.Limb - grip; limb -= ownBore * Vector3.Dot(limb, ownBore);
            var limbAt = Flat(f.Rotation * limb, bore);
            var want = Flat(Quaternion.AngleAxis(-BowCant, bore) * (turn * b.Up), bore);
            if (Vector3.Dot(limbAt, want) < 0f) want = -want;
            if (limbAt.sqrMagnitude > 1e-6f && want.sqrMagnitude > 1e-6f)
            {
                var roll = Quaternion.FromToRotation(limbAt, want);
                f.Rotation = roll * f.Rotation;
                f.Position = at - f.Rotation * (grip * w.Scale);
            }
            bowHand = PrimaryPalm(w, f, b.Axes(-.6f, -.8f, -.2f));
            stringHand = aim > .5f ? SupportPalm(w, bowHand, Vector3.zero, b.Axes(1f, -.2f, -.3f)) : new Hand();
        }

        // A long tool in both hands: the primary grip at the right hip, the tool down, ahead and across the body.
        internal static void TwoHand(Body b, Weapon w, out Frame f, out Hand right, out Hand left)
        {
            var at = b.AtChest(.16f, -.38f, .06f);
            var direction = b.Axes(-.25f, -.55f, .8f).normalized;
            var start = Quaternion.LookRotation(b.Forward, b.Up) * Quaternion.Inverse(w.Aim);
            var axis = (w.Tool - w.Grip).normalized;
            var rotation = Quaternion.FromToRotation(start * axis, direction) * start;
            f = new Frame { Rotation = rotation, Scale = w.Scale, Position = at - rotation * (w.Grip * w.Scale) };
            right = PrimaryPalm(w, f, b.Axes(.5f, -1f, -.3f));
            left = SupportPalm(w, right, Vector3.zero, b.Axes(-.6f, -1f, -.2f));
        }

        // A one-hand tool or weapon at the right hip, the fist's thumb up and forward, the item where its grip puts it.
        internal static Hand OneHand(Body b, Palm palm)
        {
            var rotation = PalmRotation(palm, false, b.Axes(0f, -.55f, 1f), b.Axes(-1f, 0f, .15f));
            return new Hand { Valid = palm.Valid, Wrist = b.ShoulderR + b.Axes(.02f, -.47f, .22f), Palm = rotation, Pole = b.Axes(.3f, -1f, -.6f) };
        }

        // ---------- consumables ----------

        // The item's model bounds in its own space and its display scale (RemoteConsumablePose.TryMeasure).
        internal struct Item
        {
            internal Vector3 Min, Max;
            internal float Scale;
            internal Vector3 Size { get { return (Max - Min) * Scale; } }
            internal Vector3 Centre { get { return (Min + Max) * .5f; } }
        }

        // The palm holding an item whose axis (towards its used end) is `axis`, the used end at endAt, gripped `fromEnd`
        // back along the axis; the palm's inner side faces the axis from the side of `normal`; index finger towards the end.
        internal static Hand HeldCylinder(Palm palm, Vector3 axis, Vector3 endAt, float fromEnd, float radius, Vector3 normal, Vector3 pole)
        {
            var a = axis.normalized;
            var n = Flat(normal, a);
            var distal = Vector3.Cross(n, -a);
            var rotation = PalmRotation(palm, false, distal, n);
            var grip = endAt - a * fromEnd;
            var centre = grip - n * (radius + .016f) + distal * (radius * .55f);
            return new Hand { Valid = palm.Valid, Wrist = centre - rotation * palm.Center, Palm = rotation, Pole = pole };
        }

        // Drinking (a bottle, a can, pills): phase 0 held before the chest upright, 1 at the lips with the bottom up.
        internal static Hand Drink(Body b, Palm palm, Item item, float phase, float tilt, out Vector3 position, out Quaternion rotation)
        {
            var size = item.Size;
            float height = size.y, radius = Mathf.Max(size.x, size.z) * .5f;
            var axis = Quaternion.AngleAxis(-tilt, b.Right) * b.Up;
            var topAt = Vector3.Lerp(b.AtChest(.10f, -.02f, .12f), b.Mouth, phase);
            var hand = HeldCylinder(palm, axis, topAt, height * .62f, radius, -b.Right, b.Axes(.5f, -1f, -.2f));
            rotation = Quaternion.LookRotation(Vector3.Cross(b.Right, axis), axis);
            var top = new Vector3(item.Centre.x, item.Max.y, item.Centre.z) * item.Scale;
            position = topAt - rotation * top;
            return hand;
        }

        // Eating: the long side of the food towards the mouth, held near the bitten end; phase 1 at the lips.
        internal static Hand Eat(Body b, Palm palm, Item item, float phase, out Vector3 position, out Quaternion rotation)
        {
            var size = item.Size;
            bool alongZ = size.z >= size.x;
            float longSide = alongZ ? size.z : size.x;
            float thick = Mathf.Min(size.y, alongZ ? size.x : size.z) * .5f;
            var rest = b.Axes(-.6f, .8f, 0f).normalized;
            var bite = b.Axes(-.75f, 0f, -.65f).normalized;
            var axis = Vector3.Lerp(rest, bite, phase).normalized;
            var endAt = Vector3.Lerp(b.AtChest(.08f, -.06f, .10f), b.Mouth, phase);
            var hand = HeldCylinder(palm, axis, endAt, Mathf.Min(.07f, longSide * .45f), thick, b.Axes(-1f, -.4f, 0f), b.Axes(.5f, -1f, -.2f));
            var up = Flat(b.Up, axis);
            rotation = Quaternion.LookRotation(axis, up) * (alongZ ? Quaternion.identity : Quaternion.AngleAxis(-90f, Vector3.up));
            var far = item.Centre;
            if (alongZ) far.z = item.Max.z; else far.x = item.Max.x;
            position = endAt - rotation * (far * item.Scale);
            return hand;
        }

        // A medkit flat on the left palm before the belly; the right hand dips into it (phase 0) and dabs the chest (1).
        internal static void Medkit(Body b, Palm left, Palm right, Item item, float phase, out Hand kitHand, out Hand workHand,
            out Vector3 position, out Quaternion rotation)
        {
            var size = item.Size;
            var centre = b.AtChest(-.02f, -.30f, size.z * .5f + .02f);
            rotation = Quaternion.LookRotation(b.Forward, b.Up);
            position = centre - rotation * (new Vector3(item.Centre.x, item.Min.y, item.Centre.z) * item.Scale);
            var flat = PalmRotation(left, true, b.Axes(.5f, 0f, 1f), b.Up);
            kitHand = new Hand { Valid = left.Valid, Palm = flat, Wrist = centre - b.Up * .03f - flat * left.Center - b.Forward * .02f, Pole = b.Axes(-.6f, -1f, -.4f) };
            var tip = Vector3.Lerp(centre + b.Up * (size.y + .04f), b.AtChest(-.08f, -.06f, .03f), phase);
            var work = PalmRotation(right, false, b.Axes(0f, -1f, .3f), Vector3.Lerp(-b.Up, -b.Forward, phase));
            workHand = new Hand { Valid = right.Valid, Palm = work, Wrist = tip - work * right.Center, Pole = b.Axes(.6f, -1f, -.3f) };
        }

        // A bandage: the left forearm across the chest (its hand first), then the right fist with the roll goes round
        // that forearm (turn 0..1). forearm/hand: the left forearm bone and palm once that arm is placed.
        internal static Hand BandageArm(Body b, Palm left)
        {
            var rotation = PalmRotation(left, true, b.Axes(1f, 0f, -.2f), -b.Up);
            return new Hand { Valid = left.Valid, Wrist = b.AtChest(.08f, -.20f, .10f), Palm = rotation, Pole = b.Axes(-1f, -.5f, 0f) };
        }

        internal static Hand BandageWrap(Body b, Palm right, Item item, Vector3 forearm, Vector3 hand, float turn,
            out Vector3 position, out Quaternion rotation)
        {
            var axis = (hand - forearm).normalized;
            var mid = Vector3.Lerp(forearm, hand, .6f);
            var u = Flat(b.Up, axis);
            var v = Vector3.Cross(axis, u);
            float angle = turn * 2f * Mathf.PI;
            var radial = u * Mathf.Cos(angle) + v * Mathf.Sin(angle);
            var roll = mid + radial * .07f;
            var grip = HeldCylinder(right, axis, roll + axis * .03f, .03f, .03f, -radial, b.Axes(.5f, -1f, -.4f));
            rotation = Quaternion.LookRotation(Vector3.Cross(axis, radial), axis);
            position = roll - rotation * (new Vector3(0f, item.Centre.y, 0f) * item.Scale);
            return grip;
        }

        // ---------- arms ----------

        // The palm bone's rotation whose anatomical frame has these directions: distal (wrist to knuckles) and normal
        // (out of the palm's inner side). The frame's up is the palm side on a right hand, the back on a left one.
        internal static Quaternion PalmRotation(Palm palm, bool left, Vector3 distal, Vector3 normal)
        {
            var d = distal.normalized;
            var n = Flat(normal, d);
            var up = left ? -n : n;
            var lateral = Vector3.Cross(d, up);
            return Quaternion.LookRotation(lateral, up) * Quaternion.Inverse(palm.Rotation);
        }

        // One arm's bones, measured once in the prefab pose: the upper arm's bone axis and the side its elbow bends
        // to (its local space), the forearm's and both twist bones' axes (their own), the twist bones' rest turns and
        // the two lengths (shoulder to elbow, elbow to the palm bone).
        internal struct Arm
        {
            internal Vector3 UpperAxis, Bend, ForearmAxis, Twist2Axis, Twist3Axis;
            internal Quaternion Twist2Rest, Twist3Rest;
            internal float Upper, Lower;
            internal bool Valid;
        }

        internal struct ArmPose
        {
            internal Quaternion Upper, Lower, Twist2, Twist3, Palm;  // world, world, local, local, world
            internal Vector3 Elbow, Wrist;
            internal bool Valid, Reached;
        }

        // Two-bone reach to the hand's target: the elbow towards its pole, the upper arm turned so its bone points at
        // the elbow and its bending side towards the wrist, the forearm bent about that hinge only (from its current
        // turn), a third of the wrist's roll in each twist bone.
        internal static ArmPose Solve(Arm a, Vector3 shoulder, Vector3 up, Quaternion forearmLocal, Hand hand)
        {
            var pose = new ArmPose();
            if (!a.Valid || !hand.Valid || !Finite(hand.Wrist) || !Finite(hand.Palm)) return pose;
            var d = hand.Wrist - shoulder;
            float distance = d.magnitude;
            if (distance < 1e-4f) return pose;
            float reach = Mathf.Clamp(distance, Mathf.Abs(a.Upper - a.Lower) + 1e-3f, a.Upper + a.Lower - 1e-3f);
            var along = d / distance;
            var wrist = shoulder + along * reach;
            float onLine = (a.Upper * a.Upper - a.Lower * a.Lower + reach * reach) / (2f * reach);
            float off = Mathf.Sqrt(Mathf.Max(0f, a.Upper * a.Upper - onLine * onLine));
            var side = Flat(hand.Pole, along);
            if (side.sqrMagnitude < 1e-8f) side = Flat(up, along);
            var elbow = shoulder + along * onLine + side * off;
            var toElbow = (elbow - shoulder).normalized;
            var toWrist = (wrist - elbow).normalized;
            var bend = Flat(toWrist, toElbow);
            if (bend.sqrMagnitude < 1e-8f) bend = side;
            pose.Upper = Quaternion.LookRotation(toElbow, bend) * Quaternion.Inverse(Quaternion.LookRotation(a.UpperAxis, a.Bend));
            var forearm = pose.Upper * forearmLocal;
            pose.Lower = Quaternion.FromToRotation(forearm * a.ForearmAxis, toWrist) * forearm;
            var third = pose.Lower * a.Twist2Rest * a.Twist3Rest;
            var local = Quaternion.Inverse(third) * hand.Palm;
            float roll = 2f * Mathf.Atan2(local.x * a.Twist3Axis.x + local.y * a.Twist3Axis.y + local.z * a.Twist3Axis.z, local.w) * Mathf.Rad2Deg;
            if (roll > 180f) roll -= 360f;
            if (roll < -180f) roll += 360f;
            pose.Twist2 = a.Twist2Rest * Quaternion.AngleAxis(roll / 3f, a.Twist2Axis);
            pose.Twist3 = a.Twist3Rest * Quaternion.AngleAxis(roll / 3f, a.Twist3Axis);
            pose.Palm = hand.Palm;
            pose.Elbow = elbow; pose.Wrist = wrist;
            pose.Reached = distance <= a.Upper + a.Lower;
            pose.Valid = Finite(pose.Upper) && Finite(pose.Lower) && Finite(pose.Twist2) && Finite(pose.Twist3);
            return pose;
        }

        // v without its part along a unit axis, normalized (zero when nothing is left).
        internal static Vector3 Flat(Vector3 v, Vector3 axis)
        {
            var flat = v - axis * Vector3.Dot(v, axis);
            float m = flat.magnitude;
            return m < 1e-6f ? Vector3.zero : flat / m;
        }

        private static bool Finite(float x) { return !float.IsNaN(x) && !float.IsInfinity(x); }
        internal static bool Finite(Vector3 v) { return Finite(v.x) && Finite(v.y) && Finite(v.z); }
        internal static bool Finite(Quaternion q) { return Finite(q.x) && Finite(q.y) && Finite(q.z) && Finite(q.w); }
    }
}
