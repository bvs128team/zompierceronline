using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;

namespace ZompiercerLAN
{
    // Owns strings only. No Unity objects, game state, or logging APIs on this thread.
    internal sealed class LanCheckpointWriter
    {
        private const int MaxPending = 160, MaxCharacters = 8 * 1024 * 1024;
        private readonly object _gate = new object();
        private readonly Dictionary<string, string> _pending = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        private readonly Action<string, string> _write;
        private Thread _thread;
        private bool _stopping;
        private int _characters, _written, _coalesced, _rejected, _failed;
        private double _writeMs, _worstWriteMs;
        private string _error;

        internal LanCheckpointWriter(Action<string, string> write) { _write = write ?? WriteFile; }

        internal bool Enqueue(string path, string text)
        {
            lock (_gate)
            {
                string previous;
                bool replacing = _pending.TryGetValue(path, out previous);
                long size = (long)_characters + text.Length - (replacing ? previous.Length : 0);
                if (_stopping || (!replacing && _pending.Count >= MaxPending) || size > MaxCharacters)
                { _rejected++; return false; }
                _pending[path] = text;
                _characters = (int)size;
                if (replacing) _coalesced++;
                if (_thread == null)
                {
                    _thread = new Thread(Run) { IsBackground = true, Name = "LAN checkpoint writer" };
                    _thread.Start();
                }
                Monitor.Pulse(_gate);
                return true;
            }
        }

        private void Run()
        {
            while (true)
            {
                string path = null, text = null;
                lock (_gate)
                {
                    while (_pending.Count == 0 && !_stopping) Monitor.Wait(_gate);
                    if (_pending.Count == 0) return;
                    foreach (var entry in _pending) { path = entry.Key; text = entry.Value; break; }
                    _pending.Remove(path); _characters -= text.Length;
                }
                long started = Stopwatch.GetTimestamp();
                string error = null;
                try { _write(path, text); }
                catch (Exception ex) { error = ex.GetType().Name + ": " + ex.Message; }
                double elapsed = (Stopwatch.GetTimestamp() - started) * 1000.0 / Stopwatch.Frequency;
                lock (_gate)
                {
                    if (error == null) _written++; else { _failed++; _error = error; }
                    _writeMs += elapsed; _worstWriteMs = Math.Max(_worstWriteMs, elapsed);
                }
            }
        }

        // Called on plugin destruction only; never wait on disk from Update/LateUpdate.
        internal bool Shutdown(int milliseconds)
        {
            Thread thread;
            lock (_gate) { _stopping = true; thread = _thread; Monitor.Pulse(_gate); }
            return thread == null || thread.Join(Math.Max(0, Math.Min(100, milliseconds)));
        }

        internal string Status()
        {
            lock (_gate)
                return "checkpoint writer: written=" + _written + " pending=" + _pending.Count + " coalesced=" + _coalesced +
                    " rejected=" + _rejected + " failed=" + _failed + " diskMs=" + _writeMs.ToString("0.0") +
                    " worstDiskMs=" + _worstWriteMs.ToString("0.0") + (_error == null ? "" : " lastError=" + _error);
        }

        private static void WriteFile(string path, string text)
        {
            // Recheck on the writer thread, including the destination file itself.
            for (string current = Path.GetFullPath(path); !string.IsNullOrEmpty(current); current = Path.GetDirectoryName(current))
                if ((Directory.Exists(current) || File.Exists(current)) && (File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0)
                    throw new IOException("Refusing linked checkpoint path: " + current);
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            File.WriteAllText(path, text, Encoding.UTF8);
        }
    }
}
