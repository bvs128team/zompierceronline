using System;

namespace ZompiercerLAN
{
    // Cosmetic curves only. Scalar sampling permits checks without running Unity.
    internal static class RemoteMotionStyle
    {
        internal const float TiredEnter = .25f, TiredExit = .35f;
        internal const float EatPeriod = 2.4f, DrinkPeriod = 2.8f;
        internal struct Consumption
        {
            internal float Contact, Chew, Tilt, Head;
        }

        internal static bool Tired(bool previous, float current, float maximum)
        {
            if (!Finite(current) || !Finite(maximum) || maximum <= 0f || current < 0f) return false;
            float share = current / maximum;
            return previous ? share < TiredExit : share <= TiredEnter;
        }

        internal static Consumption Sample(float age, bool drink)
        {
            if (!Finite(age) || age < 0f) return new Consumption();
            float phase = age % (drink ? DrinkPeriod : EatPeriod);
            float contact = Window(phase, drink ? .6f : .5f, drink ? 1.3f : .22f, drink ? .5f : .43f);
            float chew = drink ? 0f : Window(phase - .72f, .2f, 1.05f, .35f);
            float beat = (float)Math.Sin(phase * (drink ? 12f : 17f));
            return new Consumption {
                Contact = contact,
                Chew = chew,
                Tilt = drink ? contact * (1f + .025f * beat) : contact,
                Head = drink ? -10f * contact : 3f * contact + .7f * chew * beat
            };
        }

        private static float Window(float age, float rise, float hold, float fall)
        {
            if (age < 0f) return 0f;
            if (age < rise) return Smooth(age / rise);
            age -= rise;
            if (age < hold) return 1f;
            age -= hold;
            return age < fall ? 1f - Smooth(age / fall) : 0f;
        }
        private static float Smooth(float x) { return x * x * (3f - 2f * x); }
        private static bool Finite(float value) { return !float.IsNaN(value) && !float.IsInfinity(value); }
    }
}
