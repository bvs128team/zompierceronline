using System;

namespace ZompiercerLAN
{
    internal static partial class Program
    {
        private static void TrainRecoveryChecks()
        {
            var recovery = new LanTrainRecovery();
            Require(recovery.Recover("Terrain1", 1) == null, "uncommitted train was recoverable");
            var layout = new byte[] { 1, 2, 3 };
            recovery.Remember("Terrain1", 9, layout);
            layout[0] = 99;
            var rebuilt = recovery.Recover("Terrain1", 9);
            Require(rebuilt != null && rebuilt[0] == 1, "ACKed train layout was lost or aliased");
            rebuilt[0] = 88;
            Require(recovery.Recover("Terrain1", 9)[0] == 1, "rebuild modified committed layout");
            Require(recovery.Recover("Terrain2", 9) == null && recovery.Recover("Terrain1", 10) == null,
                "recovery reused another scene or an obsolete layout");
            recovery.Remember("Terrain1", 10, new byte[] { 4 });
            Require(recovery.Recover("Terrain1", 9) == null && recovery.Recover("Terrain1", 10)[0] == 4,
                "new commit did not replace recovery state");
            recovery.Clear();
            Require(recovery.Recover("Terrain1", 10) == null, "old session train survived reset");
            Console.WriteLine("PASS: train replacement recovery (committed layout retained, immutable copies, scene/revision/session isolation)");
        }
    }
}
