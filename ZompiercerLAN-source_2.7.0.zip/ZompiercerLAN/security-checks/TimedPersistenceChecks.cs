﻿using System;
using System.IO;

namespace ZompiercerLAN
{
    internal static partial class Program
    {
        private static void TimedBuffPersistenceChecks()
        {
            object[] row = { 1, .8f, -1f, 30f };
            object[] old = new object[18], next = new object[18];
            old[1] = new object[] { 100f }; next[1] = old[1];
            var budget = new LanTimedBuffBudget();
            next[17] = new object[] { row };
            Require(!budget.Check(old, next, 0, 0) && ((object[])next[17]).Length == 0, "forged beneficial effect rejected");
            budget.CreditRows(new object[] { row }, 0);
            next[17] = new object[] { row };
            Require(budget.Check(old, next, 1, 0), "host grant accepts matching effect");
            old[17] = next[17];
            next[17] = new object[] { new object[] { 1, .8f, -1f, 30f } };
            Require(!budget.Check(old, next, 11, 10) && (float)((object[])((object[])next[17])[0])[3] == 20f, "grant cannot replay or freeze time");
            next[17] = new object[] { new object[] { 1, .1f, -1f, 20f } };
            Require(!budget.Check(old, next, 12, 1) && ((object[])next[17]).Length == 0, "magnitude escalation rejected");
            ExpectRejected(() => LanTimedBuffs.Validate(new object[] { row, row }), "duplicate effects rejected");
            ExpectRejected(() => LanTimedBuffs.Validate(new object[] { new object[] { 1, float.NaN, -1f, 1f } }), "nonfinite effect rejected");
            ExpectRejected(() => LanTimedBuffs.Validate(new object[] { new object[] { 99, 1f, -1f, 1f } }), "unknown effect rejected");
            budget.CreditRows(new object[] { row }, 20);
            next[17] = new object[] { row }; old[17] = null;
            Require(!budget.Check(old, next, 81, 0), "expired unused grant rejected");
            LanTimedBuffs.Validate(null);
            var encoded = LanValueCodec.Encode(new object[] { new object[] { row } });
            LanTimedBuffs.Validate(LanValueCodec.Decode(encoded)[0]);
            Console.WriteLine("PASS: timed effect persistence, host grants, duration decay, replay/magnitude rejection and legacy profiles");
        }
        private static void QuestJournalPersistenceChecks()
        {
            string owner = new string('A', 64), other = new string('B', 64);
            var receipt = new LanQuestReceipts();
            Require(receipt.Keep("scene", 1, new[] { owner, other }, null, new byte[] { 7 }), "create receipt");
            byte[] payload;
            Require(!receipt.Claim("scene", 1, owner, false, out payload), "full pack retains receipt");
            var reload = new LanQuestReceipts();
            reload.Load(LanValueCodec.Decode(LanValueCodec.Encode(receipt.Save())), true);
            Require(reload.Claim("scene", 1, owner, true, out payload) && payload[0] == 7, "pending gift survives reload");
            receipt.Load(reload.Save(), true);
            Require(!receipt.Claim("scene", 1, owner, true, out payload) && receipt.Waits("scene", 1, other), "spent claim and other owner survive reload");
            receipt.Keep("scene", 1, new[] { owner }, null);
            Require(!receipt.Waits("scene", 1, owner), "repeated completion does not refill");
            reload.Load(receipt.Save(), false);
            Require(reload.Count == 1 && reload.Quarantined && !reload.Waits("scene", 1, other), "checkpoint mismatch retains but disables journal");
            receipt.Load(reload.Save(), true);
            Require(receipt.Quarantined, "resave cannot unquarantine old rights");
            receipt.Clear();
            Require(receipt.Count == 0 && !receipt.Quarantined, "new world clears journal");
            string dir = Path.Combine(Path.GetTempPath(), "lan-journal-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(dir);
            try
            {
                foreach (string file in LanGuestStore.NativeFiles) File.WriteAllText(Path.Combine(dir, file), "checkpoint");
                var store = new LanGuestStore(); store.EnsureWorld();
                store.QuestRewards.Keep("scene", 3, new[] { owner }, null);
                string result;
                Require(store.Write(dir, out result), "journal-only world saved");
                var restored = new LanGuestStore();
                Require(restored.Load(dir, out result) && restored.QuestRewards.Waits("scene", 3, owner), "v3 journal loaded");
                File.AppendAllText(Path.Combine(dir, LanGuestStore.NativeFiles[0]), "changed");
                Require(restored.Load(dir, out result) && restored.QuestRewards.Quarantined, "mismatch keeps lineage but blocks quest replay");
                restored.NewWorld();
                Require(restored.QuestRewards.Count == 0, "new world drops old rights");
            }
            finally { Directory.Delete(dir, true); }
            Console.WriteLine("PASS: pending quest journals, checkpoint reload, spent claims, mismatch quarantine and new-world reset");
        }
    }
}
