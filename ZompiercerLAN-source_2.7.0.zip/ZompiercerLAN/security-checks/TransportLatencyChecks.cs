using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading;

namespace ZompiercerLAN
{
    // 2.6.2: a packet crosses an established DTLS pair (loopback) without waiting out a fixed receive slice, the owner
    // is told when it is queued, and idle sessions stay cheap. Like the network worker, this process asks for a 1 ms
    // timer step first; without it Windows rounds every wait up to ~15.6 ms.
    internal static partial class Program
    {
        [DllImport("winmm.dll")] private static extern uint timeBeginPeriod(uint period);
        [DllImport("winmm.dll")] private static extern uint timeEndPeriod(uint period);

        private static void TransportLatencyChecks()
        {
            bool raised = timeBeginPeriod(1) == 0;
            try
            {
                int port = FreeUdpPort(); var secret = TestKey(6262);
                using (var host = LanSecureTransport.HostWithKey(port, IPAddress.Loopback, "checks", secret))
                using (var client = LanSecureTransport.JoinWithKey(port, IPAddress.Loopback, "checks", secret))
                using (var process = Process.GetCurrentProcess())
                using (var toClient = new AutoResetEvent(false))
                using (var toHost = new AutoResetEvent(false))
                {
                    Establish(host, client); ulong session = host.Session;
                    client.Arrived = () => toClient.Set(); host.Arrived = () => toHost.Set();
                    var there = Trip(host, client, toClient, session, 1);
                    var back = Trip(client, host, toHost, session, 1001);
                    // Idle: both DTLS threads wait in 2 ms slices; the cost must stay far below a core.
                    process.Refresh(); var cpu = process.TotalProcessorTime; var idle = Stopwatch.StartNew();
                    Thread.Sleep(3000);
                    process.Refresh(); double busy = (process.TotalProcessorTime - cpu).TotalSeconds / idle.Elapsed.TotalSeconds;
                    Require(host.SecurityFailure == null && client.SecurityFailure == null && host.Session == session, "Latency probe disturbed the session");
                    Require(there[there.Length / 2] < 6 && back[back.Length / 2] < 6, "Median one-way delay over loopback is not below 6 ms");
                    Require(busy < .05, "Idle DTLS sessions use more than 5% of a core: " + busy.ToString("P1"));
                    Console.WriteLine("PASS: loopback one-way delay host->client median {0:F1} ms (95% {1:F1}), client->host {2:F1} ms (95% {3:F1}); " +
                        "owner woken per packet; idle pair {4:P1} of a core; 1 ms timer {5}",
                        there[there.Length / 2], there[there.Length * 95 / 100], back[back.Length / 2], back[back.Length * 95 / 100], busy, raised ? "on" : "unavailable");
                }
            }
            finally { if (raised) timeEndPeriod(1); }
        }

        // One packet at a time, at random phases, until the receiver's owner is rung and finds it.
        private static double[] Trip(LanSecureTransport from, LanSecureTransport to, AutoResetEvent rung, ulong session, uint first)
        {
            var delays = new List<double>(); var random = new Random(626); Packet packet; IPEndPoint peer;
            for (uint i = 0; i < 60; i++)
            {
                Thread.Sleep(random.Next(1, 12));
                while (to.TryReceive(out peer, out packet)) { }
                rung.Reset();
                var state = State(first + i); state.Session = session;
                var watch = Stopwatch.StartNew(); from.Send(state);
                bool found = false;
                while (!found && watch.ElapsedMilliseconds < 1000)
                {
                    rung.WaitOne(50);
                    while (to.TryReceive(out peer, out packet)) if (packet.Kind == PacketKind.State && packet.Sequence == first + i) found = true;
                }
                Require(found, "Latency probe packet was lost on loopback");
                delays.Add(watch.Elapsed.TotalMilliseconds);
            }
            delays.Sort(); return delays.ToArray();
        }
    }
}
