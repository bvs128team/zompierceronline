using System;
using System.Collections.Generic;

namespace ZompiercerLAN
{
    internal static partial class Program
    {
        private static void SharedWorldProtocolChecks()
        {
            var packet=new Packet { Kind=PacketKind.SceneStates,GameVersion="checks",Session=42,WorldEpoch=9,Sequence=3,Scene="Terrain1",
                SceneObjects=new[] { new SceneFrame {Id=-13,Kind=LanProtocol.SceneSeasonal,Flags=1},
                    new SceneFrame {Id=22,Kind=LanProtocol.SceneEvent,Flags=1,Value=99999},
                    new SceneFrame {Id=1,Kind=LanProtocol.SceneSeasonProgress,Flags=255,Value=99999} } };
            Packet decoded;
            var bytes=LanProtocol.Encode(packet);
            Require(LanProtocol.TryDecode(bytes,out decoded) && decoded.SceneObjects[0].Id==-13 && decoded.SceneObjects[2].Flags==255,"shared world bounded frames roundtrip");
            for(int i=0;i<bytes.Length;i++) { var cut=new byte[i]; Array.Copy(bytes,cut,i); Require(!LanProtocol.TryDecode(cut,out decoded),"truncated shared world frame rejected"); }
            foreach(var frame in new[]{ new SceneFrame {Id=3,Kind=LanProtocol.SceneSeasonProgress}, new SceneFrame {Id=1,Kind=LanProtocol.SceneSeasonProgress,Value=.5f},
                new SceneFrame {Id=1,Kind=LanProtocol.SceneSeasonProgress,Value=100000}, new SceneFrame {Id=2,Kind=LanProtocol.SceneSeasonProgress,Value=float.NaN},
                new SceneFrame {Id=1,Kind=LanProtocol.SceneEvent,Flags=2}, new SceneFrame {Id=1,Kind=LanProtocol.SceneEvent,Value=.5f},
                new SceneFrame {Id=1,Kind=LanProtocol.SceneSeasonal,Value=1} })
                Require(!LanProtocol.ValidSceneFrame(frame),"malformed shared world state rejected");
            Require(!LanProtocol.ValidSceneUse(1,LanProtocol.SceneSeasonProgress),"guest cannot request progress or rewards");
            Require(!LanNetworkPolicy.Allowed(true,PacketKind.SceneStates,true),"guest cannot author shared world state");
            foreach(byte kind in new[]{LanProtocol.SceneSeasonal,LanProtocol.SceneEvent}) {
                var use=new Packet {Kind=PacketKind.SceneUse,GameVersion="checks",Session=42,WorldEpoch=9,Sequence=3,Scene="Terrain1",Revision=-1,Action=kind};
                Require(LanProtocol.TryDecode(LanProtocol.Encode(use),out decoded) && decoded.Action==kind,"bounded world request roundtrip");
            }
            Console.WriteLine("PASS: seasonal/event/progression codec bounds and host-only state authority");
        }
        private static void ConfirmedWorkTargetChecks()
        {
            var requests=new List<Packet>(); var seen=new List<int>(); uint last=0;
            var client=new LanStorageClient(new FakeGuestWorld(),requests.Add,_=>{},()=>{});
            client.Begin();
            client.WorkConfirmed=(kind,detail,identity,car,tx)=> { Require(kind==LanStorage.WorkWaterLevel && detail==1200 && car==2 && tx>last,"confirmed water context"); last=tx; seen.Add(identity); };
            Require(client.Work(LanStorage.WorkWaterLevel,1,2,3,-70,2,null),"first exact tank read queued"); client.Tick(0);
            Require(requests.Count==1,"first request transmitted");
            var result=new Packet {Kind=PacketKind.StorageResult,Sequence=requests[0].Sequence,Action=LanStorage.Ok,Revision=1200};
            client.Receive(result);
            Require(seen.Count==1 && seen[0]==-70,"result retains original tank identity");
            Require(client.Work(LanStorage.WorkWaterLevel,1,2,3,80,2,null),"second tank on same car queued"); client.Tick(1);
            client.Receive(result); Require(seen.Count==1,"stale previous tank response cannot apply to new pending request");
            result.Sequence=requests[requests.Count-1].Sequence; client.Receive(result);
            client.Receive(result); Require(seen.Count==2 && seen[1]==80,"second tank reply applies once with its identity");
            Console.WriteLine("PASS: confirmed tank target survives delayed replies, same-car switching and duplicate delivery");
        }
    }
}
