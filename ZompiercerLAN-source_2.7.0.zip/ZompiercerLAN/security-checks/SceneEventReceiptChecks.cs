using System;
namespace ZompiercerLAN
{
    internal static class SceneEventReceiptChecks
    {
        private static void Check(bool v, string message) { if (!v) throw new Exception(message); }
        internal static void Run()
        {
            var r = new LanSceneEventReceipts();
            Check(!r.Observe(7, true, 5), "Late join must not replay old event");
            Check(!r.Observe(7, true, 5), "Repeated snapshot must be silent");
            Check(r.Observe(7, true, 6), "A new pulse plays once");
            Check(!r.Observe(7, true, 6), "Duplicate pulse must be silent");
            Check(!r.Observe(7, true, 2), "Stale pulse must be silent");
            Check(!r.Observe(8, false, 0), "Untriggered baseline is silent");
            Check(r.Observe(8, true, 1), "First live activation after baseline plays");
            r.Clear();
            Check(!r.Observe(8, true, 1), "Reconnect/epoch baseline is silent");
            r.Clear();
            for (int i = 1; i <= 4096; i++) Check(!r.Observe(i, false, 0), "Baselines are silent");
            Check(!r.Observe(4097, true, 1), "Capacity fails closed");
            Check(r.Observe(1, true, 1), "Known object still works at capacity");
        }
    }
}
