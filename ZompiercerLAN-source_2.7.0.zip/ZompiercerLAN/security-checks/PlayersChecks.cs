using System;
using System.Collections.Generic;
using System.Net;

namespace ZompiercerLAN
{
    // 2.0.0 (schema 39), up to four players: the guest's slot in Welcome, the slot in marks and revives,
    // the host's Players packet (the other guests' states), the seats' LAN game ports, and a guest
    // paired on a seat's own port. 2.1.0 (schema 44): up to eight players; Players names the whole roster and
    // carries the states of some of it (the host splits six over packets).
    internal static partial class Program
    {
        private static Packet OtherGuest(byte slot, uint sequence)
        {
            var state = State(sequence); state.Player = slot; state.Name = "Друг " + slot; state.X = slot; state.SentAt = 1000u * slot;
            return state;
        }
        private static PlayerSeat[] RosterOf(Packet[] others)
        {
            if (others == null) return null;
            var roster = new PlayerSeat[others.Length];
            for (int i = 0; i < others.Length; i++) roster[i] = others[i] == null ? null : new PlayerSeat { Player = others[i].Player, Session = others[i].Session };
            return roster;
        }
        private static Packet PlayersPacket(params Packet[] others)
        { return new Packet { Kind = PacketKind.Players, GameVersion = "checks", Session = 42, WorldEpoch = 1, Sequence = 7, Roster = RosterOf(others), Players = others }; }
        private static Packet PlayersPart(Packet[] roster, params Packet[] states)
        { return new Packet { Kind = PacketKind.Players, GameVersion = "checks", Session = 42, WorldEpoch = 1, Sequence = 7, Roster = RosterOf(roster), Players = states }; }

        private static void PlayersChecks()
        {
            Packet parsed;
            // Welcome: the slot it gives the guest (the decoder takes 0..3, the plugin never gives 0 to a guest).
            for (byte slot = 0; slot < LanProtocol.MaxPlayers; slot++)
            {
                var welcome = Control(PacketKind.Welcome); welcome.Player = slot;
                Require(LanProtocol.TryDecode(LanProtocol.Encode(welcome), out parsed) && parsed.Player == slot, "Welcome slot lost");
            }
            var beyond = Control(PacketKind.Welcome); beyond.Player = LanProtocol.MaxPlayers;
            ExpectRejected(() => LanProtocol.Encode(beyond), "Welcome to a slot past the last encoded");
            var welcomeBytes = LanProtocol.Encode(Control(PacketKind.Welcome));
            foreach (byte bad in new byte[] { LanProtocol.MaxPlayers, 255 })
            {
                var tampered = (byte[])welcomeBytes.Clone(); tampered[tampered.Length - 1] = bad;
                Require(!LanProtocol.TryDecode(tampered, out parsed), "Welcome to a slot past the last decoded");
            }

            // Marks and revives name a slot too.
            var mark = new Packet { Kind = PacketKind.Mark, GameVersion = "checks", Session = 42, WorldEpoch = 1, Scene = "Terrain1", Sequence = 3,
                Action = LanProtocol.MarkEnemy, Revision = 9, CarIndex = -1, X = 1, Y = 2, Z = 3, Player = 2 };
            var revive = new Packet { Kind = PacketKind.Revive, GameVersion = "checks", Session = 42, WorldEpoch = 1, Scene = "Terrain1", Sequence = 4,
                Action = LanProtocol.ReviveDone, Player = 3 };
            foreach (var p in new[] { mark, revive })
            {
                Require(LanProtocol.TryDecode(LanProtocol.Encode(p), out parsed) && parsed.Player == p.Player && parsed.Kind == p.Kind, "Slot lost: " + p.Kind);
                var bytes = LanProtocol.Encode(p); bytes[bytes.Length - 1] = LanProtocol.MaxPlayers;
                Require(!LanProtocol.TryDecode(bytes, out parsed), "Slot past the last decoded: " + p.Kind);
                byte keep = p.Player; p.Player = LanProtocol.MaxPlayers;
                ExpectRejected(() => LanProtocol.Encode(p), "Slot past the last encoded: " + p.Kind);
                p.Player = keep;
            }

            // Players: none up to six other guests, each with its own state and slot, the roster naming them all.
            for (int count = 0; count <= LanProtocol.MaxOthers; count++)
            {
                var others = new List<Packet>();
                for (int i = 0; i < count; i++) others.Add(OtherGuest((byte)(i + 2), 100u + (uint)i));
                var bytes = LanProtocol.Encode(PlayersPacket(others.ToArray()));
                Require(LanProtocol.TryDecode(bytes, out parsed) && parsed.Kind == PacketKind.Players && parsed.Sequence == 7 && parsed.Players.Length == count &&
                    parsed.Roster.Length == count, "Players rejected");
                for (int i = 0; i < count; i++)
                {
                    var other = parsed.Players[i];
                    Require(other.Kind == PacketKind.State && other.Player == i + 2 && other.Sequence == 100 + i && other.Scene == "Terrain1" && other.X == i + 2 &&
                        other.Name == "Друг " + (i + 2) && other.SentAt == 1000u * (uint)(i + 2) && other.WorldEpoch == 1 && other.Session == 42 &&
                        parsed.Roster[i].Player == i + 2 && parsed.Roster[i].Session == 42, "A guest's state in Players lost");
                }
                for (int size = 0; size < bytes.Length; size++) { var t = new byte[size]; Array.Copy(bytes, t, size); Require(!LanProtocol.TryDecode(t, out parsed), "Truncated Players accepted"); }
                var trailing = new byte[bytes.Length + 1]; Array.Copy(bytes, trailing, bytes.Length);
                Require(!LanProtocol.TryDecode(trailing, out parsed), "Players with trailing data accepted");
            }
            // A roster with only some of the states (a part of a split snapshot).
            var three = new[] { OtherGuest(2, 1), OtherGuest(3, 2), OtherGuest(4, 3) };
            Require(LanProtocol.TryDecode(LanProtocol.Encode(PlayersPart(three, three[1])), out parsed) && parsed.Roster.Length == 3 &&
                parsed.Players.Length == 1 && parsed.Players[0].Player == 3 && parsed.Players[0].Session == 42, "A part of a roster rejected");
            // The largest snapshot (six guests, the longest scene and names, every field at its edge) does not fit one
            // datagram; split as the host splits it, every part fits, at most two, and together they carry all six.
            var wide = new Packet[LanProtocol.MaxOthers];
            for (int i = 0; i < wide.Length; i++)
            {
                wide[i] = OtherGuest((byte)(i + 2), uint.MaxValue - (uint)i);
                wide[i].Scene = new string('x', 96); wide[i].Name = new string('ж', LanProtocol.MaxNameChars); wide[i].CarIndex = LanProtocol.MaxCars - 1;
            }
            ExpectRejected(() => LanProtocol.Encode(PlayersPacket(wide)), "Six of the largest states in one datagram encoded");
            var parts = new List<Packet[]>(); var part = new List<Packet>();
            foreach (var state in wide)
            {
                part.Add(state);
                if (part.Count > 1 && LanProtocol.Size(PlayersPart(wide, part.ToArray())) > LanProtocol.MaxBytes) { part.RemoveAt(part.Count - 1); parts.Add(part.ToArray()); part = new List<Packet> { state }; }
            }
            parts.Add(part.ToArray());
            var carried = new HashSet<int>();
            foreach (var states in parts)
            {
                var encoded = LanProtocol.Encode(PlayersPart(wide, states));
                Require(encoded.Length <= LanProtocol.MaxBytes && LanProtocol.TryDecode(encoded, out parsed) && parsed.Roster.Length == LanProtocol.MaxOthers, "A part of the largest snapshot");
                foreach (var state in parsed.Players) Require(carried.Add(state.Player), "A state in two parts");
            }
            Require(parts.Count == 2 && carried.Count == LanProtocol.MaxOthers, "The largest snapshot did not split into two parts carrying all six");
            // Never more than six, never the host, never one guest twice, never a slot past the last, never a state the
            // roster does not name, never more states than the roster.
            var seven = new Packet[LanProtocol.MaxOthers + 1];
            for (int i = 0; i < seven.Length; i++) seven[i] = OtherGuest((byte)(i + 1), (uint)i + 1);
            ExpectRejected(() => LanProtocol.Encode(PlayersPacket(seven)), "Seven other guests encoded");
            ExpectRejected(() => LanProtocol.Encode(PlayersPacket(OtherGuest(0, 1))), "The host's own state in Players encoded");
            ExpectRejected(() => LanProtocol.Encode(PlayersPacket(OtherGuest(2, 1), OtherGuest(2, 2))), "One guest twice in Players encoded");
            ExpectRejected(() => LanProtocol.Encode(PlayersPacket(OtherGuest(LanProtocol.MaxPlayers, 1))), "A slot past the last in Players encoded");
            ExpectRejected(() => LanProtocol.Encode(PlayersPacket(null)), "Players without a list encoded");
            ExpectRejected(() => LanProtocol.Encode(PlayersPart(new[] { OtherGuest(2, 1) }, OtherGuest(3, 1))), "A state outside the roster encoded");
            var other42 = OtherGuest(2, 1); var other43 = OtherGuest(2, 1); other43.Session = 43;
            ExpectRejected(() => LanProtocol.Encode(PlayersPart(new[] { other42 }, other43)), "A state of another occupant encoded");
            // The same refusals on the wire (byte offsets from the encoder): roster count, roster slots, state count, state slot.
            int empty = LanProtocol.Encode(PlayersPacket()).Length; // ... sequence, roster count 0, state count 0
            int oneState = LanProtocol.Encode(PlayersPart(new[] { OtherGuest(2, 1) }, OtherGuest(2, 1))).Length - LanProtocol.Encode(PlayersPart(new[] { OtherGuest(2, 1) })).Length - 1;
            var two = LanProtocol.Encode(PlayersPacket(OtherGuest(2, 1), OtherGuest(3, 2)));
            int rosterCount = empty - 2, firstSeat = empty - 1, secondSeat = firstSeat + 9, stateCount = firstSeat + 18, firstState = stateCount + 1, secondState = firstState + 1 + oneState;
            Require(two[rosterCount] == 2 && two[firstSeat] == 2 && two[secondSeat] == 3 && two[stateCount] == 2 && two[firstState] == 2 && two[secondState] == 3, "Players layout assumption");
            Func<int, byte, bool> refusedAt = (offset, value) => { var t = (byte[])two.Clone(); t[offset] = value; return !LanProtocol.TryDecode(t, out parsed); };
            Require(refusedAt(rosterCount, (byte)(LanProtocol.MaxOthers + 1)) && refusedAt(rosterCount, 255), "Roster count past six decoded");
            Require(refusedAt(firstSeat, 0) && refusedAt(firstSeat, LanProtocol.MaxPlayers) && refusedAt(secondSeat, 2), "A roster with the host, a slot past the last or one guest twice decoded");
            Require(refusedAt(stateCount, 3) && refusedAt(firstState, 4) && refusedAt(secondState, 2), "More states than the roster, a state outside it or one twice decoded");
            // Only the host sends it, in a session, within its own budget (20 snapshots a second for each guest, two packets each).
            Require(LanNetworkPolicy.Allowed(false, PacketKind.Players, true) && !LanNetworkPolicy.Allowed(true, PacketKind.Players, true) &&
                !LanNetworkPolicy.Allowed(false, PacketKind.Players, false), "Players direction or stage");
            var limits = new LanMessageLimits(); int burst = 0;
            for (int i = 0; i < 1000; i++) if (limits.Take(PacketKind.Players, 0)) burst++;
            Require(burst == 96, "Players burst not bounded");
            limits = new LanMessageLimits();
            for (int tick = 1; tick <= 2400; tick++) Require(limits.Take(PacketKind.Players, tick * .025), "Players cadence (40 a second) refused");

            // Seats: seven LAN game ports of their own, none of them the discovery, pairing or relay port.
            var ports = new HashSet<int>(LanSeats.GamePorts);
            Require(LanSeats.GamePorts.Length == LanSeats.MaxGuests && ports.Count == LanSeats.MaxGuests && LanSeats.MaxGuests == LanProtocol.MaxPlayers - 1, "Seat ports");
            Require(LanSeats.GamePorts[0] == LanDiscovery.GamePort && LanSeats.GamePorts[0] == LanRelayText.VirtualPort, "The first seat is the 1.x game port");
            foreach (int port in new[] { LanDiscovery.DiscoveryPort, LanDiscovery.PairingPort, LanRelayText.DefaultPort, 0, 1, 27780, 65535 })
                Require(!LanSeats.ValidGamePort(port), "A seat on a reserved port: " + port);
            foreach (int port in LanSeats.GamePorts) Require(LanSeats.ValidGamePort(port), "Seat port refused: " + port);
            bool refused = false;
            try { using (LanPairing.Host("checks", LanDiscovery.PairingPort)) { } }
            catch (ArgumentException) { refused = true; }
            Require(refused, "A LAN host opened on a port that is not a seat's");
            // A guest's broker takes its host on any seat port (and only the relay's virtual port over the relay).
            foreach (int port in LanSeats.GamePorts)
            {
                var guest = new LanBrokerState(LanWorkerMode.Join, "checks", IPAddress.Loopback); Boot(guest); Snapshot(guest, Active(42, port));
                Require(guest.Peer != null && guest.Peer.Port == port, "Seat port refused by the guest's broker: " + port);
            }
            foreach (int port in new[] { LanDiscovery.PairingPort, LanDiscovery.DiscoveryPort, 27780 })
            {
                var guest = new LanBrokerState(LanWorkerMode.Join, "checks", IPAddress.Loopback); Boot(guest);
                ExpectRejected(() => Snapshot(guest, Active(42, port)), "A host on a port that is not a seat's: " + port);
            }
            Console.WriteLine("PASS: eight players (Welcome slots, slots of marks and revives, the host's Players packet: roster, parts, the largest split in two, bounds, wire refusals, direction and budget; seven seat ports, the guest's broker on a seat port)");
        }

        // --admission: a guest paired with the host's last seat learns that seat's game port.
        private static void SeatAdmissionChecks()
        {
            int seat = LanSeats.GamePorts[LanSeats.MaxGuests - 1];
            using (var host = LanPairing.HostLoopbackForChecks(seat))
            using (var client = LanPairing.JoinLoopbackForChecks(host.Code, host.ListenPortForChecks))
            {
                Require(Wait(() => host.PendingApproval, 9000), "Seat pairing did not reach approval: " + host.Status + "; " + client.Status);
                host.Approve(); byte[] hostKey = null, clientKey = null; IPAddress peer;
                Require(Wait(() => host.TryTakeCredentials(out hostKey, out peer), 1500), "Seat host credentials missing");
                host.TransportReady();
                Require(Wait(() => client.TryTakeCredentials(out clientKey, out peer), 1500), "Seat guest credentials missing");
                Require(Org.BouncyCastle.Utilities.Arrays.AreEqual(hostKey, clientKey), "Seat keys differ");
                LanPake.Clear(hostKey); LanPake.Clear(clientKey);
                Require(client.GamePort == seat, "The guest did not learn its seat's game port");
            }
            Console.WriteLine("PASS: a guest paired with a host's seat learns the seat's own game port");
        }
    }
}
