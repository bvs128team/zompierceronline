using System;
using System.Collections.Generic;

namespace ZompiercerLAN
{
    internal static partial class Program
    {
        private static void SleepDeliveryChecks()
        {
            var sleepPacket = new Packet { Kind = PacketKind.Sleep, GameVersion = "checks", Session = 42,
                WorldEpoch = 7, Scene = "Terrain1", Sequence = 31, Player = 1,
                Action = LanProtocol.SleepStart, Revision = 4, SleepAttempt = 123 };
            Packet decoded;
            Require(LanProtocol.TryDecode(LanProtocol.Encode(sleepPacket), out decoded) &&
                decoded.SleepAttempt == 123 && decoded.Sequence == 31 && decoded.WorldEpoch == 7,
                "sleep attempt and delivery identity survive wire encoding");
            sleepPacket.Kind = PacketKind.SleepAck;
            Require(LanProtocol.TryDecode(LanProtocol.Encode(sleepPacket), out decoded) &&
                decoded.Sequence == 31 && decoded.Scene == "Terrain1" && decoded.WorldEpoch == 7,
                "sleep acknowledgement survives wire encoding");
            var wire = new List<Packet>();
            var ackWire = new List<Packet>();
            var sender = new LanSleepChannel(p => wire.Add(p));
            var receiver = new LanSleepChannel(p => ackWire.Add(p));
            Require(sender.Send(LanProtocol.SleepWait, 4, 1, 1, 0), "sleep queued");
            var wait = wire[0]; wire.Clear(); // lose initial datagram
            sender.Tick(.49); Require(wire.Count == 0, "sleep retry bounded");
            sender.Tick(.5); Require(wire.Count == 1 && receiver.Receive(wire[0]), "lost sleep retried");
            receiver.Tick(.5); ackWire.Clear(); wire.Clear(); // lose ACK
            sender.Tick(1); Require(wire.Count == 1 && !receiver.Receive(wire[0]), "sleep duplicate suppressed");
            receiver.Tick(1); Require(ackWire.Count == 1, "duplicate sleep reacknowledged");
            sender.Receive(ackWire[0]); Require(sender.Pending == 0, "sleep ack clears pending");

            Require(sender.Send(LanProtocol.SleepWait, 5, 1, 2, 2), "second wait queued");
            var oldWait = wire[wire.Count - 1];
            Require(sender.Send(LanProtocol.SleepCancel, 0, 1, 2, 2), "cancel supersedes wait");
            var cancel = wire[wire.Count - 1];
            Require(sender.Pending == 1 && receiver.Receive(cancel), "new cancel delivered first");
            Require(!receiver.Receive(oldWait) && !receiver.Receive(wait), "reordered waits cannot revive cancelled sleep");
            Require(sender.Send(LanProtocol.SleepWait, 3, 2, 1, 2), "independent guest wait queued");
            Require(receiver.Receive(wire[wire.Count - 1]) && sender.Pending == 2, "origin ordering independent");
            receiver.Receive(new Packet { Kind = PacketKind.SleepAck, Sequence = uint.MaxValue });
            sender.Receive(new Packet { Kind = PacketKind.SleepAck, Sequence = uint.MaxValue });
            Require(sender.Pending == 2, "unsent sleep ack ignored");

            sender.Reset(); receiver.Reset();
            Require(sender.Pending == 0 && !receiver.Receive(oldWait), "world reset drops queue and retains replay barrier");
            Require(sender.Send(LanProtocol.SleepWait, 2, 1, 3, 3) && receiver.Receive(wire[wire.Count - 1]), "world reset allows sequence gap");
            sender.Reset(true); receiver.Reset(true);
            Require(sender.Send(LanProtocol.SleepWait, 2, 1, 4, 4), "new session queues sleep");
            Require(wire[wire.Count - 1].Sequence == 1 && receiver.Receive(wire[wire.Count - 1]), "new secure session restarts counters");

            var lost = new LanSleepChannel(p => { });
            lost.Send(LanProtocol.SleepWait, 1, 1, 1, 0);
            for (int i = 1; i <= LanSleepChannel.MaxAttempts; i++) lost.Tick(i * LanSleepChannel.RetrySeconds);
            Require(lost.Failed && !lost.Send(LanProtocol.SleepCancel, 0, 1, 1, 20), "retry exhaustion fails closed");
            lost.Reset(true); Require(!lost.Failed && lost.Pending == 0, "session reset clears failure");

            LanSleepChannel synchronous = null;
            synchronous = new LanSleepChannel(p => synchronous.Receive(new Packet { Kind = PacketKind.SleepAck, Sequence = p.Sequence }));
            Require(synchronous.Send(LanProtocol.SleepWait, 1, 1, 1, 0) && synchronous.Pending == 0, "synchronous ACK safe");
            var intent = new LanSleepIntent();
            uint first = intent.Begin(); intent.Cancel();
            Require(!intent.TryStart(first), "late start after local cancel rejected");
            uint second = intent.Begin();
            Require(!intent.TryStart(first) && intent.TryStart(second) && !intent.TryStart(second), "start bound to current wait exactly once");
            intent.Begin(); intent.Cancel(); Require(!intent.TryStart(intent.Attempt), "lifecycle cancellation invalidates start");
            Console.WriteLine("PASS: sleep delivery (loss, ACK loss, duplicates, reordering, per-player state, world/session reset, exhaustion, cancelled and superseded attempts)");
        }
    }
}
