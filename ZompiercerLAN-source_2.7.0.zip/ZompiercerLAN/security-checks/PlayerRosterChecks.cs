using System;
using System.Collections.Generic;

namespace ZompiercerLAN
{
    internal static partial class Program
    {
        private static void PlayerRosterChecks()
        {
            var roster = new LanPlayerRoster();
            var shown = new Dictionary<int, Packet>();
            int replacements = 0, removals = 0;
            Action<int> remove = slot => { removals++; shown.Remove(slot); };
            Action<Packet, bool> show = (state, replaced) => { if (replaced) replacements++; shown[state.Player] = state; };
            Func<uint, Packet[], Packet> snapshot = (seq, states) => new Packet { Sequence = seq, Roster = RosterOf(states), Players = states };
            Func<uint, Packet[], Packet[], Packet> partial = (seq, all, states) => new Packet { Sequence = seq, Roster = RosterOf(all), Players = states };
            var original = OtherGuest(2, 900); original.Session = 100;
            Require(roster.Apply(snapshot(1, new[] { original }), 1, remove, show) && shown.Count == 1 && replacements == 1, "Roster initial snapshot");
            // Slot reused before a disappearance packet arrives; lower sender sequence is valid for a new occupant.
            var newcomer = OtherGuest(2, 1); newcomer.Session = 101;
            Require(roster.Apply(snapshot(3, new[] { newcomer }), 1, remove, show) && replacements == 2 && removals == 1 && shown[2].Sequence == 1,
                "Reused slot retained previous occupant");
            Require(!roster.Apply(snapshot(2, new[] { original }), 1, remove, show) && shown[2].Session == 101, "Old snapshot resurrected occupant");
            Require(roster.Apply(snapshot(5, new Packet[0]), 1, remove, show) && shown.Count == 0, "Empty snapshot did not remove departed guest");
            Require(!roster.Apply(snapshot(5, new[] { original }), 1, remove, show), "Duplicate roster reapplied");
            var self = OtherGuest(1, 1);
            Require(!roster.Apply(snapshot(6, new[] { self }), 1, remove, show), "Roster accepted local player");
            Require(roster.Apply(snapshot(6, new[] { newcomer }), 1, remove, show), "Invalid roster advanced sequence");
            // 2.1.0: a snapshot split in two: the roster of the first part names both, the second part's state comes later.
            roster.Reset(); shown.Clear(); replacements = 0; removals = 0;
            var a = OtherGuest(2, 10); a.Session = 200; var b = OtherGuest(3, 10); b.Session = 300;
            var both = new[] { a, b };
            Require(roster.Apply(partial(10, both, new[] { a }), 1, remove, show) && shown.Count == 1 && shown.ContainsKey(2), "First part of a split snapshot");
            Require(roster.Apply(partial(11, both, new[] { b }), 1, remove, show) && shown.Count == 2 && replacements == 2, "Second part of a split snapshot");
            // A part that arrives late (an older packet) still shows the current occupant's state, never a former one's.
            var bNext = OtherGuest(3, 11); bNext.Session = 300;
            Require(roster.Apply(partial(12, both, new[] { a }), 1, remove, show) && roster.Apply(partial(9, both, new[] { bNext }), 1, remove, show) &&
                shown[3].Sequence == 11, "A late part of the current roster dropped");
            var former = OtherGuest(3, 99); former.Session = 299;
            Require(!roster.Apply(partial(8, new[] { a, former }, new[] { former }), 1, remove, show) && shown[3].Session == 300, "A late part showed a former occupant");
            // A seat taken by someone else: the old one goes at once, the new one is shown as new with its first state.
            var c = OtherGuest(3, 1); c.Session = 301;
            Require(roster.Apply(partial(13, new[] { a, c }, new[] { a }), 1, remove, show) && !shown.ContainsKey(3) && removals == 1, "Replaced occupant kept");
            Require(roster.Apply(partial(14, new[] { a, c }, new[] { c }), 1, remove, show) && shown[3].Session == 301 && replacements == 3, "New occupant not shown as new");
            // A state the roster does not name, more states than the roster, or a state twice: refused whole.
            Require(!roster.Apply(partial(15, new[] { a }, new[] { a, c }), 1, remove, show), "States beyond the roster accepted");
            Require(!roster.Apply(new Packet { Sequence = 15, Roster = RosterOf(new[] { a, c }), Players = new[] { c, c } }, 1, remove, show), "A state twice accepted");
            Require(!roster.Apply(new Packet { Sequence = 15, Roster = null, Players = new Packet[0] }, 1, remove, show), "A packet without a roster accepted");
            roster.Reset(); shown.Clear();
            Require(roster.Apply(snapshot(uint.MaxValue, new[] { original }), 1, remove, show) &&
                roster.Apply(snapshot(1, new Packet[0]), 1, remove, show) && shown.Count == 0, "Roster sequence wrap");
            Packet decoded;
            var wire = PlayersPacket(newcomer);
            Require(LanProtocol.TryDecode(LanProtocol.Encode(wire), out decoded) && decoded.Players[0].Session == 101 && decoded.Roster[0].Session == 101,
                "Players occupant session lost on wire");
            newcomer.Session = 0;
            ExpectRejected(() => LanProtocol.Encode(PlayersPacket(newcomer)), "Players accepted missing occupant session");
            Console.WriteLine("PASS: complete player rosters (departure, packet loss/reordering, reused slots, session identity, wrap; 2.1.0: split snapshots, late parts, replaced seats)");
        }
    }
}
