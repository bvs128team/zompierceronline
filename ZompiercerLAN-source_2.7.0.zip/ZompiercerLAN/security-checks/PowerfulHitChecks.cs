using System;
using System.IO;

namespace ZompiercerLAN
{
    internal static partial class Program
    {
        private static void PowerfulHitChecks()
        {
            float x,y,z,stun;
            Require(LanPowerfulHit.TryCreate(3,0,4,2,3,out x,out y,out z,out stun) && Math.Abs(x-6)<.0001f && Math.Abs(z-8)<.0001f && stun==3,
                "powerful punch follows native distance and direction");
            Require(LanPowerfulHit.TryCreate(1,1,1,float.MaxValue,100,out x,out y,out z,out stun) && LanProtocol.ValidPush(x,y,z) && stun==30,
                "powerful punch caps extreme prefab force and stun");
            Require(LanPowerfulHit.TryCreate(0,0,0,2,0,out x,out y,out z,out stun) && x==0 && y==0 && z==0 && stun==0,"coincident punch is finite");
            foreach(float bad in new[]{float.NaN,float.PositiveInfinity,float.NegativeInfinity})
                Require(!LanPowerfulHit.TryCreate(bad,0,0,1,1,out x,out y,out z,out stun) && !LanPowerfulHit.TryCreate(1,0,0,bad,1,out x,out y,out z,out stun),"nonfinite native punch rejected");
            Require(!LanPowerfulHit.TryCreate(21,0,0,1,1,out x,out y,out z,out stun) && !LanPowerfulHit.TryCreate(1,0,0,-1,1,out x,out y,out z,out stun),"invalid native punch rejected");
            var hit=new Packet { Kind=PacketKind.ZombieHurt,GameVersion="checks",Session=42,WorldEpoch=1,Sequence=9,Scene="Terrain1",Damage=30,
                Action=LanProtocol.HurtPowerfulMelee,Text="ZombieHeavy_01",AimX=6,AimZ=8,PowerfulStun=3 };
            Packet decoded;
            var bytes=LanProtocol.Encode(hit);
            Require(LanProtocol.TryDecode(bytes,out decoded) && decoded.AimX==6 && decoded.AimZ==8 && decoded.PowerfulStun==3 && decoded.Text==hit.Text,"powerful melee codec preserves effects and prefab");
            for(int i=0;i<bytes.Length;i++) { var shortBytes=new byte[i]; Array.Copy(bytes,shortBytes,i); Require(!LanProtocol.TryDecode(shortBytes,out decoded),"truncated powerful punch rejected"); }
            var tail=new byte[bytes.Length+1]; Array.Copy(bytes,tail,bytes.Length); Require(!LanProtocol.TryDecode(tail,out decoded),"powerful punch trailing bytes rejected");
            foreach(float bad in new[]{-.01f,30.01f,float.NaN,float.PositiveInfinity}) {
                hit.PowerfulStun=bad; ExpectRejected(()=>LanProtocol.Encode(hit),"invalid stun rejected by encoder");
                var forged=(byte[])bytes.Clone(); var value=BitConverter.GetBytes(bad); Array.Copy(value,0,forged,forged.Length-4,4);
                Require(!LanProtocol.TryDecode(forged,out decoded),"invalid stun rejected by decoder");
            }
            hit.PowerfulStun=3; hit.AimX=51; ExpectRejected(()=>LanProtocol.Encode(hit),"overlarge melee push rejected");
            Require(!LanNetworkPolicy.Allowed(true,PacketKind.ZombieHurt,true) && LanNetworkPolicy.Allowed(false,PacketKind.ZombieHurt,true) && !LanNetworkPolicy.Allowed(false,PacketKind.ZombieHurt,false),"guest cannot author host melee outcomes");
            Console.WriteLine("PASS: powerful melee native force, finite bounds, stun, codec truncation/mutations and host authority");
        }
    }
}
