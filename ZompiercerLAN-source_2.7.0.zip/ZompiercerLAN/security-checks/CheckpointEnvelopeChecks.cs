using System;
using System.IO;

namespace ZompiercerLAN
{
    internal static partial class Program
    {
        private static void CheckpointEnvelopeChecks()
        {
            var journal=new LanQuestReceipts(); string owner=new string('A',64);
            for(uint i=1;i<=LanQuestReceipts.Limit;i++) Require(journal.Keep("Terrain8",i,new[]{owner},null),"full receipt capacity remains persistable");
            var restored=new LanQuestReceipts(); restored.Load(LanValueCodec.Decode(LanValueCodec.Encode(journal.Save())),true);
            Require(restored.Count==LanQuestReceipts.Limit && restored.Waits("Terrain8",4096,owner),"4096 compact persisted rights survive reload");
            var root=new object[]{"ZLANGUESTS",3,Guid.NewGuid().ToString("N"),"hash1","hash2","hash3",new object[0],new object[0],journal.Save(),new LanQuestReceipts().Save()};
            var bytes=LanGuestCheckpointCodec.Encode(root); var decoded=LanGuestCheckpointCodec.Decode(bytes);
            Require(decoded.Length==10 && (int)decoded[1]==3,"separate bounded checkpoint sections roundtrip");
            foreach(int length in new[]{0,3,4,7,8,bytes.Length-1}) { var cut=new byte[length]; Array.Copy(bytes,cut,length); ExpectRejected(()=>LanGuestCheckpointCodec.Decode(cut),"truncated checkpoint rejected"); }
            var tail=new byte[bytes.Length+1]; Array.Copy(bytes,tail,bytes.Length); ExpectRejected(()=>LanGuestCheckpointCodec.Decode(tail),"checkpoint trailing data rejected");
            foreach(int bad in new[]{-1,0,int.MaxValue,LanValueCodec.MaxBytes+1}) {
                var forged=(byte[])bytes.Clone(); Array.Copy(BitConverter.GetBytes(bad),0,forged,4,4); ExpectRejected(()=>LanGuestCheckpointCodec.Decode(forged),"checkpoint section allocation bounded");
            }
            var old=new object[]{"ZLANGUESTS",2,Guid.NewGuid().ToString("N"),"hash1","hash2","hash3",new object[0],new object[0]};
            Require(LanGuestCheckpointCodec.Decode(LanValueCodec.Encode(old)).Length==8,"legacy checkpoint remains readable");
            int inputs=Fuzz("local checkpoint envelope",Inputs(new Random(2956),new[]{bytes,LanValueCodec.Encode(old)},300,300,1201),
                data=>{ LanGuestCheckpointCodec.Decode(data); },CodecRejects);
            Console.WriteLine("PASS: 4096 durable quest rights, bounded checkpoint sections, legacy data and "+inputs+" hostile envelope inputs");
        }
    }
}
