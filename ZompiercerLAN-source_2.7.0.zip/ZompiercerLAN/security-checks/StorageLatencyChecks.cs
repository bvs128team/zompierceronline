using System;
using System.IO;
using System.Linq;

namespace ZompiercerLAN
{
    internal static partial class Program
    {
        private static void StorageLatencyChecks()
        {
            // Small chest contents share the reliable open answer. Dropping every
            // bulk-view packet cannot keep this ordinary chest empty.
            var rig = new StorageRig();
            rig.HostWorld.Box.Items.Add(Item(1, 3));
            rig.Link.Drop = p => p.Kind == PacketKind.StorageViewChunk;
            rig.Client.Open(BoxTarget()); rig.Pump(.1);
            Require(rig.Client.Current != null && rig.Client.Current.Items.Length == 1 && !rig.Client.Loading,
                "Small chest waits for a separate bulk view");

            rig = new StorageRig();
            rig.HostWorld.Box.Items.Add(Item(1, 3));
            bool lost = false;
            rig.Link.Drop = p =>
            {
                if (!lost && p.Kind == PacketKind.StorageResult) { lost = true; return true; }
                return false;
            };
            rig.Client.Open(BoxTarget()); rig.Pump(.45);
            Require(lost && rig.Client.Current != null && rig.HostWorld.Resolves == 1,
                "Lost open answer costs a second or repeats the opening side effect");

            rig = new StorageRig();
            rig.HostWorld.Box.Items.Add(Item(1, 3));
            lost = false;
            rig.Link.Drop = p =>
            {
                if (!lost && p.Kind == PacketKind.StorageResult) { lost = true; return true; }
                return false;
            };
            rig.Client.Open(BoxTarget()); rig.Pump(.05);
            rig.HostWorld.Box.Items.Add(Item(2, 1));
            rig.Pump(.5);
            Require(rig.Client.Current != null && rig.Client.Current.Items.Length == 2,
                "Cached inline opening snapshot overwrote newer early view after answer loss");

            // A view requiring more than 250 ms must finish even while the host
            // craft timer changes at every poll. The newest update follows it.
            rig = new StorageRig();
            for (int i = 0; i < 180; i++) rig.HostWorld.Box.Items.Add(Item(i, 1, (float)i));
            rig.HostWorld.BenchQueue = new System.Collections.Generic.List<int[]> { new[] { 41, 2 } };
            rig.HostWorld.BenchWorking = 41; rig.HostWorld.BenchRuns = true;
            rig.Client.Open(BoxTarget());
            for (int i = 0; i < 80 && rig.Client.Current == null; i++)
            { rig.HostWorld.BenchElapsed = i; rig.Pump(.05); }
            Require(rig.Client.Current != null && rig.Client.Current.Items.Length == 180,
                "Changing large view restarts before the guest can assemble it");

            // Confirmed per-target progress arrives with the hit answer, without
            // a train layout poll. Duplicate answers cannot repeat feedback.
            rig = new StorageRig();
            rig.HostWorld.Blueprints[70] = new[] { (float)LanStorage.TrainFurniture, 0f, 8f };
            int feedback = 0, refresh = 0;
            float confirmed = -1f;
            rig.Host.TrainChanged = () => refresh++;
            rig.Host.TrainRevision = () => 5;
            rig.Client.BuildDone = (car, kind, id, progress, maximum, done, revision) =>
            {
                Require(car == 0 && kind == LanStorage.TrainFurniture && id == 70, "Build feedback target changed");
                Require(revision == 5, "Build feedback lost its host layout ordering bound");
                if (maximum > 0f) { Require(maximum == 8f, "Build maximum changed"); confirmed = progress; }
                feedback++;
            };
            Require(rig.Client.Build(0, LanStorage.TrainFurniture, 70, 2, null), "Build not queued");
            rig.Pump(.1);
            Require(feedback == 1 && confirmed == 4f && refresh == 0, "Partial build progress waits for a layout");
            rig.Link.Duplicate = true;
            rig.Pump(.4);
            Require(rig.Client.Build(0, LanStorage.TrainFurniture, 70, 2, null), "Completion not queued");
            rig.Pump(.4);
            Require(feedback == 2 && refresh == 1 && rig.HostWorld.Completed == 1,
                "Completion refresh or duplicate handling failed");
            rig.Host.Receive(new Packet { Kind = PacketKind.StorageRequest, Sequence = 2,
                Action = LanProtocol.StorageBuild, Chunk = LanStorage.BuildPayload(0, LanStorage.TrainFurniture, 70, 2) }, rig.Now);
            foreach (var answer in rig.Link.Take(rig.Link.ToGuest)) rig.Client.Receive(answer);
            Require(feedback == 2 && refresh == 1 && rig.HostWorld.Completed == 1,
                "Replayed completion ran structural refresh or item operation again");

            float value, limit;
            foreach (var bad in new[]
            {
                new object[] { -1f, 2f }, new object[] { 3f, 2f }, new object[] { 0f, 0f },
                new object[] { 0f, 100001f }, new object[] { 1, 2f }, new object[] { 1f },
                new object[] { 1f, 2f, 3f }
            }) ExpectRejected(() => LanStorage.DecodeBuildProgress(LanValueCodec.Encode(bad), out value, out limit),
                "Malformed build display feedback accepted");
            ExpectRejected(() => LanStorage.BuildProgressPayload(float.NaN, 2f), "NaN build feedback encoded");
            ExpectRejected(() => LanStorage.BuildProgressPayload(1f, float.PositiveInfinity), "Infinite build maximum encoded");

            var craft = new LanStorage.View { Handle = 1, Craft = new LanStorage.CraftState { Completed = 7 } };
            Require(LanStorage.DecodeView(LanStorage.EncodeView(craft)).Craft.Completed == 7,
                "Craft completion counter lost");
            ExpectRejected(() => LanStorage.EncodeView(new LanStorage.View
                { Handle = 1, Craft = new LanStorage.CraftState { Completed = -1 } }), "Negative completion counter accepted");

            rig = new StorageRig(); rig.Client.Open(BoxTarget()); rig.Client.Tick(0);
            uint tx = rig.Link.ToHost[0].Sequence;
            rig.Client.Receive(new Packet { Kind = PacketKind.StorageResult, Sequence = tx, Action = LanStorage.Ok,
                Revision = 1, Chunk = LanStorage.EncodeView(new LanStorage.View { Handle = 2 }) });
            Require(rig.Client.Current == null && !rig.Client.IsOpen, "Foreign inline storage handle applied");
            Console.WriteLine("PASS: immediate small chest / bounded lost-answer retry / large changing view completion / per-hit build progress / single structural refresh / malformed feedback rejection");
        }
    }
}
