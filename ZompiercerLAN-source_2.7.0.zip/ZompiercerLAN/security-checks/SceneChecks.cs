using System;
using System.Linq;

namespace ZompiercerLAN
{
    // 1.4.4: location objects of the host's world and the host's difficulty (packet schema 34).
    internal static partial class Program
    {
        private static void SceneChecks()
        {
            Packet decoded;
            Func<Packet, Packet> world = p => { p.GameVersion = "checks"; p.Session = 42; p.WorldEpoch = 3; p.Sequence = 9; p.Scene = new string('S', 96); return p; };
            var states = world(new Packet { Kind = PacketKind.SceneStates, SceneObjects = Enumerable.Range(0, LanProtocol.MaxSceneBatch).Select(i => new SceneFrame {
                Id = i % 2 == 0 ? i + 1 : -(i + 1), Kind = (byte)(LanProtocol.SceneBomb + i % LanProtocol.SceneFireworks), Flags = (byte)(i % 2),
                Value = LanProtocol.SceneBomb + i % LanProtocol.SceneFireworks == LanProtocol.SceneDrainer ? 12.5f : 0f }).ToArray() });
            var use = world(new Packet { Kind = PacketKind.SceneUse, Revision = int.MinValue, Action = LanProtocol.SceneButton });
            foreach (var p in new[] { states, use })
            {
                var bytes = LanProtocol.Encode(p);
                Require(bytes.Length <= 1200 && LanProtocol.TryDecode(bytes, out decoded) && decoded.Kind == p.Kind && decoded.Sequence == 9, "Valid scene packet rejected: " + p.Kind);
                for (int size = 0; size < bytes.Length; size++) { var t = new byte[size]; Array.Copy(bytes, t, size); Require(!LanProtocol.TryDecode(t, out decoded), "Truncated scene packet accepted"); }
                var tail = new byte[bytes.Length + 1]; Array.Copy(bytes, tail, bytes.Length); Require(!LanProtocol.TryDecode(tail, out decoded), "Scene packet trailing bytes accepted");
            }
            LanProtocol.TryDecode(LanProtocol.Encode(states), out decoded);
            var drainer = decoded.SceneObjects.First(s => s.Kind == LanProtocol.SceneDrainer);
            Require(decoded.SceneObjects.Length == LanProtocol.MaxSceneBatch && decoded.SceneObjects[1].Id == -2 && decoded.SceneObjects[1].Flags == 1 && drainer.Value == 12.5f, "Scene object fields");
            LanProtocol.TryDecode(LanProtocol.Encode(use), out decoded);
            Require(decoded.Revision == int.MinValue && decoded.Action == LanProtocol.SceneButton, "Scene use fields");
            foreach (byte kind in new[] { LanProtocol.SceneTrap, LanProtocol.SceneCollapse, LanProtocol.SceneActivator, LanProtocol.SceneTrigger })
            {
                use.Action = kind;
                Require(LanProtocol.TryDecode(LanProtocol.Encode(use), out decoded) && decoded.Action == kind, "Guest scene use rejected: " + kind);
            }
            use.Action = LanProtocol.SceneButton;
            Func<Action<Packet>, Packet, bool> rejected = (change, source) =>
            {
                Packet copy; LanProtocol.TryDecode(LanProtocol.Encode(source), out copy);
                copy.GameVersion = "checks"; change(copy);
                try { return !LanProtocol.TryDecode(LanProtocol.Encode(copy), out decoded); }
                catch (System.IO.InvalidDataException) { return true; }
            };
            var bad = new[]
            {
                rejected(p => p.SceneObjects[0].Id = 0, states), rejected(p => p.SceneObjects[0].Kind = 0, states), rejected(p => p.SceneObjects[0].Kind = LanProtocol.MaxSceneKind + 1, states),
                rejected(p => p.SceneObjects[0].Flags = 2, states), rejected(p => p.SceneObjects[0].Value = 1f, states), rejected(p => p.SceneObjects[4].Value = -1f, states),
                rejected(p => p.SceneObjects[4].Value = float.NaN, states), rejected(p => p.SceneObjects[4].Value = 100000f, states),
                rejected(p => p.SceneObjects = new SceneFrame[LanProtocol.MaxSceneBatch + 1], states), rejected(p => p.SceneObjects = null, states),
                rejected(p => p.Sequence = 0, states), rejected(p => p.WorldEpoch = 0, states), rejected(p => p.Scene = "", states),
                rejected(p => p.Revision = 0, use), rejected(p => p.Action = LanProtocol.SceneBomb, use), rejected(p => p.Action = LanProtocol.SceneDrainer, use),
                rejected(p => p.Action = LanProtocol.SceneResource, use), rejected(p => p.Action = 0, use), rejected(p => p.Action = LanProtocol.MaxSceneKind + 1, use),
                rejected(p => p.Action = LanProtocol.SceneParsed, use),
                rejected(p => p.WorldEpoch = 0, use), rejected(p => p.Sequence = 0, use),
            };
            Require(bad.All(x => x), "Malformed scene packet accepted: #" + Array.IndexOf(bad, false));
            // The same on the wire: a drainer's time is the last float, a guest's use ends with what it is.
            var wire = LanProtocol.Encode(world(new Packet { Kind = PacketKind.SceneStates, SceneObjects = new[] { new SceneFrame { Id = 5, Kind = LanProtocol.SceneBomb, Flags = 1 } } }));
            Require(LanProtocol.TryDecode(wire, out decoded), "One-object scene batch rejected");
            foreach (var change in new[] { new[] { 6, LanProtocol.MaxSceneKind + 1 }, new[] { 5, 2 } }) // an unknown kind, Flags 2
            { var copy = (byte[])wire.Clone(); copy[copy.Length - change[0]] = (byte)change[1]; Require(!LanProtocol.TryDecode(copy, out decoded), "Invalid scene bytes accepted"); }
            // 2.5.0 (schema 50): a loot cabinet: searched (1) and empty (2), both or neither; no other bit, no value.
            var loot = LanProtocol.Encode(world(new Packet { Kind = PacketKind.SceneStates, SceneObjects = new[] { new SceneFrame { Id = 7, Kind = LanProtocol.SceneLoot, Flags = 3 } } }));
            Require(LanProtocol.TryDecode(loot, out decoded) && decoded.SceneObjects[0].Kind == LanProtocol.SceneLoot && decoded.SceneObjects[0].Flags == 3, "A searched empty cabinet rejected");
            for (int flags = 0; flags <= 255; flags++)
            { var copy = (byte[])loot.Clone(); copy[copy.Length - 5] = (byte)flags; Require(LanProtocol.TryDecode(copy, out decoded) == flags <= LanProtocol.MaxLootFlags, "Cabinet flags " + flags); }
            var valued = (byte[])loot.Clone(); BitConverter.GetBytes(1f).CopyTo(valued, valued.Length - 4);
            Require(!LanProtocol.TryDecode(valued, out decoded), "A cabinet with a value accepted");
            foreach (byte kind in new[] { LanProtocol.SceneLid, LanProtocol.SceneFireworks })
            {
                var effect = LanProtocol.Encode(world(new Packet { Kind = PacketKind.SceneStates,
                    SceneObjects = new[] { new SceneFrame { Id = 9, Kind = kind, Flags = 1 } } }));
                Require(LanProtocol.TryDecode(effect, out decoded), "Host scene feedback rejected");
                for (int flag = 0; flag <= 255; flag++)
                {
                    var copy = (byte[])effect.Clone(); copy[copy.Length - 5] = (byte)flag;
                    Require(LanProtocol.TryDecode(copy, out decoded) == (flag <= 1), "Invalid lid/firework flag accepted");
                }
                var copyValue = (byte[])effect.Clone(); BitConverter.GetBytes(1f).CopyTo(copyValue, copyValue.Length - 4);
                Require(!LanProtocol.TryDecode(copyValue, out decoded) && !LanProtocol.ValidSceneUse(9, kind),
                    "Guest may request a scene lid/fireworks effect or supply an arbitrary value");
            }
            var nonzero = (byte[])wire.Clone(); BitConverter.GetBytes(3f).CopyTo(nonzero, nonzero.Length - 4);
            Require(!LanProtocol.TryDecode(nonzero, out decoded), "A wall with a drained time accepted");
            var useWire = LanProtocol.Encode(use); useWire[useWire.Length - 1] = LanProtocol.SceneBomb;
            Require(!LanProtocol.TryDecode(useWire, out decoded), "A guest blowing a wall up accepted");
            // Directions and bursts.
            Require(LanNetworkPolicy.Allowed(true, PacketKind.SceneUse, true) && !LanNetworkPolicy.Allowed(false, PacketKind.SceneUse, true) && !LanNetworkPolicy.Allowed(true, PacketKind.SceneUse, false) &&
                !LanNetworkPolicy.Allowed(true, PacketKind.SceneStates, true) && LanNetworkPolicy.Allowed(false, PacketKind.SceneStates, true) && !LanNetworkPolicy.Allowed(false, PacketKind.SceneStates, false) &&
                LanProtocol.WorldBound(PacketKind.SceneStates) && LanProtocol.WorldBound(PacketKind.SceneUse), "Scene packet directions");
            var limits = new LanMessageLimits(); int batches = 0, uses = 0;
            for (int i = 0; i < 1000; i++) { if (limits.Take(PacketKind.SceneStates, 0)) batches++; if (limits.Take(PacketKind.SceneUse, 0)) uses++; }
            Require(batches == 10 && uses == 4, "Scene packet bursts not bounded");

            // The host's difficulty in WorldState.
            var state = new Packet { Kind = PacketKind.WorldState, GameVersion = "checks", Session = 42, WorldEpoch = 1, Sequence = 2, Scene = "Terrain1", Location = 2, RailsId = 5, TrainPosition = 10,
                Clock = new ClockSnapshot { Year = 1, Day = 3, Hour = 12, HoursPerRealSecond = .01f }, Difficulty = new DifficultySnapshot { ZombieDamage = 1.5f, Recoil = .25f, Wobble = 10f, ShowOnMap = true } };
            var stateBytes = LanProtocol.Encode(state);
            Require(LanProtocol.TryDecode(stateBytes, out decoded) && decoded.Difficulty != null && decoded.Difficulty.ZombieDamage == 1.5f && decoded.Difficulty.Wobble == 10f && decoded.Difficulty.ShowOnMap, "Difficulty roundtrip");
            for (int size = 0; size < stateBytes.Length; size++) { var t = new byte[size]; Array.Copy(stateBytes, t, size); Require(!LanProtocol.TryDecode(t, out decoded), "Truncated world state accepted"); }
            state.Difficulty = null;
            Require(LanProtocol.TryDecode(LanProtocol.Encode(state), out decoded) && decoded.Difficulty == null, "World state without difficulty rejected");
            foreach (var d in new[] { new DifficultySnapshot { ZombieDamage = -1 }, new DifficultySnapshot { ZombieDamage = 10.5f }, new DifficultySnapshot { Recoil = float.NaN }, new DifficultySnapshot { Wobble = 11 } })
            {
                state.Difficulty = d;
                ExpectRejected(() => LanProtocol.Encode(state), "Invalid difficulty encoded");
            }
            state.Difficulty = new DifficultySnapshot { ZombieDamage = 1f, Recoil = 1f, Wobble = 1f, ShowOnMap = false };
            // 2.4.2: the weather's length byte (0: none) follows the difficulty.
            var flagBytes = LanProtocol.Encode(state); flagBytes[flagBytes.Length - 2] = 2; // ShowOnMap is 0 or 1
            Require(!LanProtocol.TryDecode(flagBytes, out decoded), "Map flag 2 accepted");
            var damageBytes = LanProtocol.Encode(state); BitConverter.GetBytes(50f).CopyTo(damageBytes, damageBytes.Length - 14);
            Require(!LanProtocol.TryDecode(damageBytes, out decoded), "Zombie damage x50 accepted");
            var hasBytes = LanProtocol.Encode(state); hasBytes[hasBytes.Length - 15] = 2;
            Require(!LanProtocol.TryDecode(hasBytes, out decoded), "Difficulty presence 2 accepted");
            // 2.4.2: the host's weather in WorldState: a short preset name of plain characters, or none.
            state.Weather = "Cloudy 1";
            var weatherBytes = LanProtocol.Encode(state);
            Require(LanProtocol.TryDecode(weatherBytes, out decoded) && decoded.Weather == "Cloudy 1" && decoded.Difficulty != null && decoded.Clock != null, "Weather roundtrip");
            for (int size = 0; size < weatherBytes.Length; size++) { var t = new byte[size]; Array.Copy(weatherBytes, t, size); Require(!LanProtocol.TryDecode(t, out decoded), "Truncated world state with weather accepted"); }
            var weatherTail = new byte[weatherBytes.Length + 1]; Array.Copy(weatherBytes, weatherTail, weatherBytes.Length);
            Require(!LanProtocol.TryDecode(weatherTail, out decoded), "World state with a trailing byte accepted");
            state.Weather = new string('a', LanProtocol.MaxWeatherName);
            Require(LanProtocol.TryDecode(LanProtocol.Encode(state), out decoded) && decoded.Weather == state.Weather, "Weather of 32 characters rejected");
            state.Weather = null;
            Require(LanProtocol.TryDecode(LanProtocol.Encode(state), out decoded) && decoded.Weather == null, "World state without weather rejected");
            foreach (var badWeather in new[] { "", new string('a', LanProtocol.MaxWeatherName + 1), "Rain\n", "Rain\0", "\u0414\u043e\u0436\u0434\u044c", "a/b", "<b>", "Clear.Sky" })
            {
                state.Weather = badWeather;
                ExpectRejected(() => LanProtocol.Encode(state), "Invalid weather encoded: " + badWeather.Length);
            }
            state.Weather = "Clear Sky";
            var forgedWeather = LanProtocol.Encode(state); forgedWeather[forgedWeather.Length - 1] = (byte)'!';
            Require(!LanProtocol.TryDecode(forgedWeather, out decoded), "Weather with '!' accepted");
            var forgedUtf = LanProtocol.Encode(state); forgedUtf[forgedUtf.Length - 1] = 0xC3;
            Require(!LanProtocol.TryDecode(forgedUtf, out decoded), "Weather with a broken character accepted");
            var longWeather = LanProtocol.Encode(state); longWeather[longWeather.Length - 1 - "Clear Sky".Length] = (byte)(LanProtocol.MaxWeatherName + 1);
            Require(!LanProtocol.TryDecode(longWeather, out decoded), "Weather length 33 accepted");
            var emptyMarked = LanProtocol.Encode(state); emptyMarked[emptyMarked.Length - 1 - "Clear Sky".Length] = 0;
            Require(!LanProtocol.TryDecode(emptyMarked, out decoded), "Weather length 0 with bytes after it accepted");
            state.Weather = null;
            // 1.4.5: Leave is the header only, either way once a session stands, a few at once.
            var leave = new Packet { Kind = PacketKind.Leave, GameVersion = "checks", Session = 42 };
            var leaveBytes = LanProtocol.Encode(leave);
            Require(LanProtocol.TryDecode(leaveBytes, out decoded) && decoded.Kind == PacketKind.Leave && decoded.Session == 42, "Leave rejected");
            for (int size = 0; size < leaveBytes.Length; size++) { var t = new byte[size]; Array.Copy(leaveBytes, t, size); Require(!LanProtocol.TryDecode(t, out decoded), "Truncated leave accepted"); }
            var leaveTail = new byte[leaveBytes.Length + 1]; Array.Copy(leaveBytes, leaveTail, leaveBytes.Length);
            Require(!LanProtocol.TryDecode(leaveTail, out decoded), "Leave with a payload accepted");
            var unknown = (byte[])leaveBytes.Clone(); unknown[5] = (byte)PacketKind.Leave + 1;
            Require(!LanProtocol.TryDecode(unknown, out decoded), "A packet kind beyond Leave accepted");
            Require(LanNetworkPolicy.Allowed(true, PacketKind.Leave, true) && LanNetworkPolicy.Allowed(false, PacketKind.Leave, true) &&
                !LanNetworkPolicy.Allowed(true, PacketKind.Leave, false) && !LanNetworkPolicy.Allowed(false, PacketKind.Leave, false) && !LanProtocol.WorldBound(PacketKind.Leave), "Leave directions");
            int leaves = 0; for (int i = 0; i < 1000; i++) if (limits.Take(PacketKind.Leave, 0)) leaves++;
            Require(leaves == 4, "Leave bursts not bounded");
            // A taken-apart object only comes from the host.
            var parsed = world(new Packet { Kind = PacketKind.SceneStates, SceneObjects = new[] { new SceneFrame { Id = -77, Kind = LanProtocol.SceneParsed, Flags = 1 }, new SceneFrame { Id = 5, Kind = LanProtocol.SceneTrigger, Flags = 1 } } });
            Require(LanProtocol.TryDecode(LanProtocol.Encode(parsed), out decoded) && decoded.SceneObjects[0].Kind == LanProtocol.SceneParsed && decoded.SceneObjects[1].Kind == LanProtocol.SceneTrigger, "Taken-apart object or trigger rejected");
            Console.WriteLine("PASS: location objects (scene batch and guest use shapes and bounds, byte tampering, 2.5.0 loot cabinets, a guest cannot blow a wall up or drain a swamp, directions, bursts) and the host's difficulty in WorldState");
        }
    }
}
