using System;

namespace ZompiercerLAN
{
    internal static partial class Program
    {
        private static void StarterLootChecks()
        {
            Func<LanStarterLootReceipt, int, bool> eligible = (r, n) => r.Eligible(true, false, n, "Terrain1", false);
            var receipt = new LanStarterLootReceipt();
            Require(!eligible(receipt, 1), "Unknown startup world must fail closed");
            for (int guests = 1; guests <= 7; guests++)
            {
                receipt.NewWorld();
                Require(!eligible(receipt, 0) && eligible(receipt, guests), "Exactly two through eight admitted players eligible");
                Require(!receipt.Eligible(false, false, guests, "Terrain1", false), "Client must never spawn kit");
                Require(!receipt.Eligible(true, true, guests, "Terrain1", false), "Isolated guest world must never spawn kit");
                Require(!receipt.Eligible(true, false, guests, "Terrain1", true), "Load must finish before spawn");
                foreach (string scene in new[] { null, "", "Terrain2", "ZCSBaseTerrain", "Terrain1(Clone)", "terrain1" })
                    Require(!receipt.Eligible(true, false, guests, scene, false), "Unrelated scene must never spawn kit");
                Require(receipt.Commit() && !receipt.Commit(), "Only one kit can commit");
                for (int reconnect = 0; reconnect < 25; reconnect++)
                    Require(!eligible(receipt, guests) && !receipt.Commit(), "Reconnect/extra guests must not multiply kit");
                var native = new object[21]; native[3] = "Terrain1"; native[10] = new object[] { "native loot sentinel" };
                var saved = receipt.Save(native);
                Require(native.Length == 21 && saved.Length == 22 && ReferenceEquals(saved[10], native[10]), "Preserve native snapshot fields");
                var loaded = new LanStarterLootReceipt();
                loaded.Load(LanValueCodec.Decode(LanValueCodec.Encode(saved)));
                Require(loaded.Granted && !eligible(loaded, guests), "Native checkpoint retains grant after collection and reload");
                // Travel does not load old snapshots: the current receipt travels
                // with every later checkpoint, including one saved while solo.
                native[3] = "Terrain8";
                loaded.Load(loaded.Save(native));
                Require(loaded.Granted && !eligible(loaded, 1), "Other-scene/solo checkpoint retains world grant");
            }
            receipt.Load(new object[21]);
            Require(eligible(receipt, 1), "Legacy save supports late join even when originals were already taken");
            receipt.Load(receipt.Save(new object[21]));
            Require(eligible(receipt, 1), "Solo checkpoint preserves pending eligibility");
            Require(!eligible(receipt, -1) && !eligible(receipt, 8), "Invalid admitted guest count rejected");
            foreach (object[] data in new[] { null, new object[0], new object[20], new object[23], new object[22] })
            { receipt.Load(data); Require(!eligible(receipt, 1) && !receipt.Commit(), "Malformed native extension must fail closed"); }
            foreach (object tail in new object[] { true, 1, "receipt", new object[0],
                new object[] { LanStarterLootReceipt.Magic, 2, 0 }, new object[] { "other mod", 1, 0 },
                new object[] { LanStarterLootReceipt.Magic, 1L, 0 }, new object[] { LanStarterLootReceipt.Magic, 1, false },
                new object[] { LanStarterLootReceipt.Magic, 1, -1 }, new object[] { LanStarterLootReceipt.Magic, 1, 3 },
                new object[] { LanStarterLootReceipt.Magic, 1, 0, 0 } })
            {
                var data = new object[22]; data[21] = tail;
                receipt.Load(data); Require(!eligible(receipt, 1) && !receipt.Commit(), "Unknown/versioned/forged extension accepted");
                receipt.Load(receipt.Save(new object[21]));
                Require(!eligible(receipt, 1), "Saving blocked world must not turn it eligible");
            }
            receipt.NewWorld(); Require(eligible(receipt, 1), "New world resets previous blocked/granted state");
            foreach (object[] data in new[] { null, new object[20], new object[22], new object[23] })
                ExpectRejected(() => receipt.Save(data), "Unknown native shape must refuse save, never silently drop receipt");
            Require(LanStarterLootReceipt.Backpack == 7 && LanStarterLootReceipt.Bat == 27 && LanStarterLootReceipt.Knife == 56,
                "Only authored starter item IDs allowed");
            Console.WriteLine("PASS: starter loot host/admission gates, 2-8 players, one world grant, reconnect/travel/solo checkpoint, legacy saves, malformed/versioned receipts");
        }
    }
}
