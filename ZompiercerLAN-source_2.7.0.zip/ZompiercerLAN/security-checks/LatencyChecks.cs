using System;
using System.Collections.Generic;

namespace ZompiercerLAN
{
    internal static partial class Program
    {
        private static Packet Latency(byte action, ulong nonce, params LatencySeat[] seats)
        { return new Packet { Kind=PacketKind.Latency, GameVersion="checks", Session=42, Action=action, LatencyNonce=nonce, LatencySeats=action==3 ? seats : null }; }

        private static void LatencyChecks()
        {
            var seats=new LatencySeat[7];
            for(int i=0;i<7;i++) seats[i]=new LatencySeat { Slot=(byte)(i+1), Session=(ulong)(100+i), Milliseconds=i==0 ? -1 : i==6 ? 3000 : 123 };
            var seeds=new[] { Latency(1,1), Latency(2,ulong.MaxValue), Latency(3,1,seats), Latency(3,2) };
            Packet decoded;
            foreach(var seed in seeds) {
                var wire=LanProtocol.Encode(seed);
                Require(wire.Length<=1200 && LanProtocol.TryDecode(wire,out decoded) && decoded.Action==seed.Action &&
                    decoded.LatencyNonce==seed.LatencyNonce, "Latency codec roundtrip");
                for(int size=0;size<wire.Length;size++) {
                    var truncated=new byte[size]; Array.Copy(wire,truncated,size);
                    Require(!LanProtocol.TryDecode(truncated,out decoded),"Truncated latency accepted");
                }
                var trailing=new byte[wire.Length+1]; Array.Copy(wire,trailing,wire.Length);
                Require(!LanProtocol.TryDecode(trailing,out decoded),"Trailing latency accepted");
            }
            var reportWire=LanProtocol.Encode(seeds[2]);
            int payload=reportWire.Length-(1+8+1+7*11);
            // Every field's invalid boundary must be rejected by the wire decoder.
            foreach(int action in new[] { 0,4,255 }) {
                var bad=(byte[])reportWire.Clone(); bad[payload]=(byte)action;
                Require(!LanProtocol.TryDecode(bad,out decoded),"Unknown latency action");
            }
            var zero=(byte[])reportWire.Clone(); Array.Clear(zero,payload+1,8);
            Require(!LanProtocol.TryDecode(zero,out decoded),"Zero latency nonce");
            var tooMany=(byte[])reportWire.Clone(); tooMany[payload+9]=8;
            Require(!LanProtocol.TryDecode(tooMany,out decoded),"Oversized latency report");
            foreach(byte slot in new byte[] { 0,8,255 }) {
                var bad=(byte[])reportWire.Clone(); bad[payload+10]=slot;
                Require(!LanProtocol.TryDecode(bad,out decoded),"Invalid latency seat");
            }
            var duplicate=(byte[])reportWire.Clone(); duplicate[payload+21]=1;
            Require(!LanProtocol.TryDecode(duplicate,out decoded),"Duplicate latency slot");
            var noSession=(byte[])reportWire.Clone(); Array.Clear(noSession,payload+11,8);
            Require(!LanProtocol.TryDecode(noSession,out decoded),"Zero latency seat session");
            foreach(short value in new short[] { -2,3001,short.MaxValue,short.MinValue }) {
                var bad=(byte[])reportWire.Clone(); Array.Copy(BitConverter.GetBytes(value),0,bad,payload+19,2);
                Require(!LanProtocol.TryDecode(bad,out decoded),"Invalid latency milliseconds");
            }
            Require(LanNetworkPolicy.Allowed(true,PacketKind.Latency,true) &&
                LanNetworkPolicy.Allowed(false,PacketKind.Latency,true) &&
                !LanNetworkPolicy.Allowed(true,PacketKind.Latency,false) &&
                !LanNetworkPolicy.Allowed(false,PacketKind.Latency,false) &&
                !LanProtocol.WorldBound(PacketKind.Latency),"Latency establishment policy");
            var limits=new LanMessageLimits(); int allowed=0;
            for(int i=0;i<10000;i++) if(limits.Take(PacketKind.Latency,0)) allowed++;
            Require(allowed==8,"Latency network flood bounded");

            var outgoing=new List<Packet>(); var host=new LanLatencyChannel(true,outgoing.Add);
            Require(host.Milliseconds(0)==-1,"Latency starts unknown");
            host.Tick(0); Require(outgoing.Count==1 && outgoing[0].Action==1,"Initial probe");
            ulong nonce=outgoing[0].LatencyNonce;
            host.Receive(Latency(2,nonce+1),.05); Require(host.Milliseconds(.05)==-1,"Unmatched echo measured");
            host.Receive(Latency(2,nonce),.125); Require(host.Milliseconds(.125)==125,"Actual application RTT");
            host.Receive(Latency(2,nonce),.9); Require(host.Milliseconds(.9)==125,"Echo replay changed sample");
            host.Tick(.9); Require(outgoing.Count==1,"Probe cadence exceeded");
            host.Tick(1); Require(outgoing.Count==2,"Next probe");
            host.Receive(Latency(2,nonce),1.1); Require(host.Milliseconds(1.1)==125,"Delayed old echo");
            ulong second=outgoing[1].LatencyNonce;
            host.Receive(Latency(2,second),.5); Require(host.Milliseconds(1.1)==125,"Backwards clock accepted");
            host.Receive(Latency(2,second),double.NaN);
            host.Receive(Latency(2,second),double.PositiveInfinity);
            host.Receive(Latency(2,second),4.01); Require(host.Milliseconds(4.01)==125,"Expired echo accepted");
            Require(host.Milliseconds(5.126)==-1,"Old RTT did not become unknown");
            host.Tick(4.02); Require(outgoing.Count==3,"Lost probe never retried");
            host.Receive(Latency(2,outgoing[2].LatencyNonce),4.07);
            Require(host.Milliseconds(4.07)==50,"Recovery after loss");
            int before=outgoing.Count;
            host.Receive(Latency(3,99,seats),1e6);
            host.Tick(5.1); Require(outgoing.Count==before+1,"Guest report mutated host clock");
            Require(host.ReportedSeats(5.1).Length==0,"Guest report mutated host table");

            var echoes=new List<Packet>(); var guest=new LanLatencyChannel(false,echoes.Add);
            for(ulong i=1;i<=10000;i++) guest.Receive(Latency(1,i),0);
            Require(echoes.Count==1 && echoes[0].Action==2,"Probe flood amplified");
            guest.Receive(Latency(1,10000),1); Require(echoes.Count==1,"Throttled duplicate echoed later");
            guest.Receive(Latency(1,10001),1); Require(echoes.Count==2,"Fresh probe no echo");
            guest.Receive(echoes[1],1.1); Require(echoes.Count==2,"Echo loop");
            guest.Receive(Latency(3,5,seats),2);
            Require(guest.ReportedMilliseconds(2,101,2)==123 && guest.ReportedMilliseconds(2,999,2)==-1,"Report occupant identity");
            var snapshot=guest.ReportedSeats(2); snapshot[1].Milliseconds=999;
            seats[1].Milliseconds=888;
            Require(guest.ReportedMilliseconds(2,101,2)==123,"Report aliases mutable arrays");
            guest.Receive(Latency(3,4),2.1);
            Require(guest.ReportedSeats(2.1).Length==7,"Reordered report replaced latest");
            guest.Receive(Latency(3,5),6);
            Require(guest.ReportedSeats(7.01).Length==0,"Report replay extended freshness");
            guest.Receive(Latency(3,6,new LatencySeat { Slot=2,Session=202,Milliseconds=80 }),8);
            Require(guest.ReportedMilliseconds(2,101,8)==-1 && guest.ReportedMilliseconds(2,202,8)==80,"Reused seat retained old latency");
            guest.Receive(Latency(3,7),9); Require(guest.ReportedSeats(9).Length==0,"Empty report failed to clear departures");
            var reports=new List<Packet>(); var reporting=new LanLatencyChannel(true,reports.Add);
            for(int i=0;i<1000;i++) reporting.Tick(0,()=>seats);
            Require(reports.Count==2 && reports[1].Action==3,"Host report cadence");
            var neverReports=new List<Packet>(); var receiving=new LanLatencyChannel(false,neverReports.Add);
            receiving.Tick(0,()=>seats);
            Require(neverReports.Count==1 && neverReports[0].Action==1,"Guest originated report");
            // Both ends independently measure a full encoded request/response path.
            var hToG=new Queue<byte[]>(); var gToH=new Queue<byte[]>();
            var pairedHost=new LanLatencyChannel(true,p=>hToG.Enqueue(LanProtocol.Encode(p)));
            var pairedGuest=new LanLatencyChannel(false,p=>gToH.Enqueue(LanProtocol.Encode(p)));
            pairedHost.Tick(10); pairedGuest.Tick(10);
            Require(LanProtocol.TryDecode(hToG.Dequeue(),out decoded),"Host probe decode");
            pairedGuest.Receive(decoded,10.02);
            Require(LanProtocol.TryDecode(gToH.Dequeue(),out decoded),"Guest probe decode");
            pairedHost.Receive(decoded,10.02);
            Require(LanProtocol.TryDecode(hToG.Dequeue(),out decoded),"Host echo decode");
            pairedGuest.Receive(decoded,10.04);
            Require(LanProtocol.TryDecode(gToH.Dequeue(),out decoded),"Guest echo decode");
            pairedHost.Receive(decoded,10.04);
            Require(pairedHost.Milliseconds(10.04)==40 && pairedGuest.Milliseconds(10.04)==40 &&
                hToG.Count==0 && gToH.Count==0,"Bidirectional application roundtrip");
            // Boundary 3 seconds is valid; greater values expire, never clamp a late echo.
            var boundaryPackets=new List<Packet>(); var boundary=new LanLatencyChannel(false,boundaryPackets.Add);
            boundary.Tick(0); boundary.Receive(Latency(2,boundaryPackets[0].LatencyNonce),3);
            Require(boundary.Milliseconds(3)==3000,"Maximum RTT boundary");
            boundary.Tick(3); boundary.Receive(Latency(2,boundaryPackets[1].LatencyNonce),6.001);
            Require(boundary.Milliseconds(6.001)==3000,"Late echo changed bounded sample");
            Console.WriteLine("PASS: bounded application latency codec, RTT, roles, replay, loss, clocks, reports and seat reuse");
        }
    }
}
