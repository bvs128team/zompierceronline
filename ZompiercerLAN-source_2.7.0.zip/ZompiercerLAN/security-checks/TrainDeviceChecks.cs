using System;
using System.Collections.Generic;
using System.IO;

namespace ZompiercerLAN
{
    internal static partial class Program
    {
        private static void TrainDeviceChecks()
        {
            for (int owner = 0; owner <= 1; owner++) for (int index = 0; index <= 15; index++) for (int action = 1; action <= 6; action++)
            {
                int value = LanTrainDeviceData.Control(owner, index, action, action == 3 ? 4095 : 0);
                int o, i, a, r; LanTrainDeviceData.Fields(value, out o, out i, out a, out r);
                Require(LanTrainDeviceData.ValidControl(value) && o == owner && i == index && a == action && r == (action == 3 ? 4095 : 0), "device control packing");
            }
            foreach (int bad in new[] { -1, int.MinValue, int.MaxValue, 0, 7 << 5, 1 << 20, (1 << 5) | 256, (6 << 5) | 256 }) Require(!LanTrainDeviceData.ValidControl(bad), "device malformed command rejected");
            var decor = new TrainDecor();
            decor.Devices.Add(new LanTrainDeviceData { Kind = 1, Active = true });
            decor.Devices.Add(new LanTrainDeviceData { Kind = 5, Index = 15, Active = true, Value = 864000, Extra = 65 });
            decor.Devices.Add(new LanTrainDeviceData { Kind = 6, Active = true, Record = 4095, Value = 100, Records = new[] { 0, 4095 } });
            var bytes = decor.Encode(); var decoded = TrainDecor.Decode(bytes);
            Require(decoded.Devices.Count == 3 && decoded.Devices[1].Extra == 65 && decoded.Devices[2].Record == 4095 && decoded.Devices[2].Records[1] == 4095, "device states roundtrip");
            for (int n = 0; n < bytes.Length; n++) { var cut = new byte[n]; Array.Copy(bytes, cut, n); ExpectRejected(() => TrainDecor.Decode(cut), "truncated device data rejected"); }
            var tail = new byte[bytes.Length + 1]; Array.Copy(bytes, tail, bytes.Length); ExpectRejected(() => TrainDecor.Decode(tail), "device trailing data rejected");
            // Raw invalid records bypass the encoder, verifying the decoder's trust boundary.
            foreach (var mutation in new Action<BinaryWriter>[] {
                w => RawDevice(w, 7, 0, 0, 0, 0, -1, new int[0]),
                w => RawDevice(w, 1, 16, 0, 0, 0, -1, new int[0]),
                w => RawDevice(w, 1, 0, 2, 0, 0, -1, new int[0]),
                w => RawDevice(w, 5, 0, 1, -1, 0, -1, new int[0]),
                w => RawDevice(w, 5, 0, 1, 864001, 0, -1, new int[0]),
                w => RawDevice(w, 1, 0, 0, 1, 0, -1, new int[0]),
                w => RawDevice(w, 6, 0, 1, 0, 0, -1, new int[0]),
                w => RawDevice(w, 6, 0, 0, 0, 0, 4096, new int[0]),
                w => RawDevice(w, 6, 0, 0, 0, 0, -1, new[] { 1, 1 }),
                w => RawDevice(w, 6, 0, 0, 0, 0, -1, new[] { 4096 }),
                w => RawDevice(w, 6, 0, 0, 0, 0, -1, new int[33]) })
            {
                using (var stream = new MemoryStream()) using (var writer = new BinaryWriter(stream))
                { writer.Write((byte)16); writer.Write((byte)1); mutation(writer); var invalid = stream.ToArray(); ExpectRejected(() => TrainDecor.Decode(invalid), "invalid device state rejected"); }
            }
            decor.Devices.Add(decor.Devices[0]); ExpectRejected(() => decor.Encode(), "duplicate device encoder rejected");
            foreach (int count in new[] { 0, 65, 255 }) ExpectRejected(() => TrainDecor.Decode(new byte[] { 16, (byte)count }), "device count bounded");
            var random = new Random(2956);
            for (int n = 0; n < 2000; n++)
            {
                var fuzz = new byte[random.Next(1, 512)]; random.NextBytes(fuzz); fuzz[0] = 16;
                try { var d = TrainDecor.Decode(fuzz); Require(d.Devices.Count <= 64, "fuzz devices bounded"); foreach (var v in d.Devices) Require(v.Valid(), "fuzz state canonical"); }
                catch (InvalidDataException) { }
            }
            Console.WriteLine("PASS: train device commands, state roundtrip, forged bounds, truncation and 2000 fuzz records");
        }
        private static void RawDevice(BinaryWriter w, int kind, int index, int active, int value, int extra, int record, int[] records)
        { w.Write((byte)kind); w.Write((byte)index); w.Write((byte)active); w.Write(value); w.Write(extra); w.Write((short)record); w.Write((byte)records.Length); foreach (int r in records) w.Write((ushort)r); }
    }
}
