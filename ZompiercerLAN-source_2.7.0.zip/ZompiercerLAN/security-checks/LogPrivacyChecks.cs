using System;
using System.Collections.Generic;

namespace ZompiercerLAN
{
    // 2.4.5: the mod's log names no Windows user: folders under the profile become %LOCALAPPDATA% and the like.
    internal static partial class Program
    {
        private static void LogPrivacyChecks()
        {
            var folders = LanLogPrivacy.Prepare(
                new KeyValuePair<string, string>("%LOCALAPPDATA%", @"C:\Users\Test User\AppData\Local"),
                new KeyValuePair<string, string>("%APPDATA%", @"C:\Users\Test User\AppData\Roaming"),
                new KeyValuePair<string, string>("%TEMP%", @"C:\Users\TESTUS~1\AppData\Local\Temp\"),
                new KeyValuePair<string, string>("%USERPROFILE%", @"C:\Users\Test User"),
                new KeyValuePair<string, string>("%NONE%", null),
                new KeyValuePair<string, string>("%SHORT%", @"C:\"));
            Func<string, string> clean = text => LanLogPrivacy.Clean(text, folders);

            string identity = @"Guest identity unavailable (C:\Users\Test User\AppData\Local\ZompiercerLAN): UnauthorizedAccessException: " +
                @"Access to the path 'C:\Users\Test User\AppData\Local\ZompiercerLAN\identity.dat' is denied.";
            Require(clean(identity) == @"Guest identity unavailable (%LOCALAPPDATA%\ZompiercerLAN): UnauthorizedAccessException: " +
                @"Access to the path '%LOCALAPPDATA%\ZompiercerLAN\identity.dat' is denied.", "Identity path not cleaned: " + clean(identity));
            // Unity writes '/', case differs, the short 8.3 name of a temporary folder, the profile itself.
            Require(clean("Linked save path: C:/Users/Test User/AppData/LocalLow/Studio/Zompiercer/Saves") ==
                "Linked save path: %USERPROFILE%/AppData/LocalLow/Studio/Zompiercer/Saves", "Unity path not cleaned");
            Require(clean(@"c:\users\test user\appdata\roaming\x.cfg") == @"%APPDATA%\x.cfg", "Case-insensitive path not cleaned");
            Require(clean(@"temp C:\Users\TESTUS~1\AppData\Local\Temp\zl.tmp") == @"temp %TEMP%\zl.tmp", "Short temp path not cleaned");
            Require(clean(@"profile C:\Users\Test User") == "profile %USERPROFILE%", "Profile at the end not cleaned");
            Require(clean(@"two C:\Users\Test User\a and C:\Users\Test User\b") == @"two %USERPROFILE%\a and %USERPROFILE%\b", "Second path not cleaned");
            // Another user's folder that starts with the same letters stays; nothing else changes, and unchanged text is the same object.
            Require(clean(@"C:\Users\Test Username\a") == @"C:\Users\Test Username\a", "Another user's folder changed");
            string plain = @"Train layout change held back by kind 1 prefab 32 car 1 removed, D:\Games\Zompiercer";
            Require(ReferenceEquals(clean(plain), plain), "Text without profile folders changed");
            Require(clean(null) == null && clean("") == "", "Empty text changed");
            Require(Array.TrueForAll(folders, f => f.Key.Length >= 4 && f.Value != "%NONE%" && f.Value != "%SHORT%"), "Empty or drive-only folder kept");
            Require(folders.Length == 8 && folders[0].Key.Length >= folders[folders.Length - 1].Key.Length, "Folders not ordered longest first");
            Console.WriteLine("PASS: log privacy (profile folders in identity, save, temp and file-error text become %LOCALAPPDATA%, %APPDATA%, %TEMP%, %USERPROFILE%; other users' folders and plain text untouched)");
        }
    }
}
