# ZompiercerLAN_2.8.6

Windows x64, Zompiercer 22.0 Alpha, Steam build 26672113. Requires your own installed game.
Close the game and extract ALL archive contents into the folder containing Zompiercer.exe, merging folders. BepInEx and runtime dependencies are included. Launch the game normally. Back up saves before using mods.

Windows x64, Zompiercer 22.0 Alpha, сборка Steam 26672113. Нужна установленная игра.
Закройте игру и распакуйте ВСЁ содержимое архива в папку с Zompiercer.exe, объединяя папки. BepInEx и зависимости включены. Запустите игру обычным способом. Перед использованием модов сохраните резервную копию сохранений.

F8 opens co-op for a host and up to seven guests. Choose RU/EN in the main menu. All players need the same game and mod version. This public build contains no private relay credentials. Direct LAN works; internet sessions require your own relay and [Relay] Custom* settings.

F8 открывает кооператив для хоста и семи гостей. Язык RU/EN выбирается в главном меню. У всех должна быть одна версия игры и мода. В публичной сборке нет частных ключей ретранслятора. Локальная сеть доступна; для игры через интернет настройте свой сервер в разделе [Relay] Custom*.

The source edition also includes Source/ and build instructions. You do not need to compile to play.
Вариант с исходниками также содержит Source/ и инструкции сборки. Для игры сборка не требуется.

Build and offline compatibility checks passed. Live gameplay on this VM remains unverified because of the game startup failure.
Сборка и автономные проверки совместимости выполнены. Игровая проверка на этой виртуальной машине недоступна из-за ошибки запуска игры.
