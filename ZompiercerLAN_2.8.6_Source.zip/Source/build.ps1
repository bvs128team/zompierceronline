param([Parameter(Mandatory=$true)][string]$GameDir)
$ErrorActionPreference = 'Stop'
$GameDir = (Resolve-Path -LiteralPath $GameDir).Path
if (!(Test-Path -LiteralPath (Join-Path $GameDir 'Zompiercer_Data/Managed/Assembly-CSharp.dll'))) { throw 'Choose the installed game folder.' }
& dotnet build (Join-Path $PSScriptRoot 'ZompiercerLAN.csproj') -c Release "-p:GameDir=$GameDir" -p:NuGetAudit=false -warnaserror
if ($LASTEXITCODE -ne 0) { throw 'Build failed.' }
