# Build / Сборка

Install the .NET SDK (10 for the LAN security checks). Extract the runtime files into your installed game folder first. Run PowerShell from this Source folder:

```powershell
./build.ps1 -GameDir "<installed game folder>"
```

Установите .NET SDK (10 для проверок безопасности LAN). Сначала распакуйте готовые файлы мода в установленную игру. Выполните команду выше в PowerShell из папки Source, указав путь к игре.

Output / Результат: bin/Release/net472. Build script does not install or overwrite game files. Скрипт не устанавливает сборку и не меняет файлы игры.
Game assemblies are referenced from your installation and are not redistributed. Игровые библиотеки берутся из установленной игры и не распространяются.
Runtime third-party licenses are in ../licenses or ../Licenses. Existing copyright and license notices are retained. No new license is assigned to code that has no license notice.
Лицензии сторонних библиотек находятся в ../licenses или ../Licenses. Существующие уведомления об авторстве сохранены. Для кода без лицензии новая лицензия не назначалась.
