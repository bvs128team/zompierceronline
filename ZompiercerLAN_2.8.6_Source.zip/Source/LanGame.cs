using System;
using System.Collections.Generic;
using System.Reflection;
using Object = UnityEngine.Object;

namespace ZompiercerLAN
{
    // 2.6.1: the game's managers built on Zompiercer.Singleton<T> (InputController, GUIManager, GlobalStatsController,
    // TerrainResourceDetector, ...) make a bare new one in their Global getter when the real one is gone: between
    // GlobalSceneManager.DeleteEverything2 on the way to the main menu and the menu's own Awake. That stand-in is kept
    // (DontDestroyOnLoad), and the menu's real manager, seeing it in Singleton.Awake, destroys itself: no controls until a
    // restart. The mod only reads the instance the game registered; null while there is none.
    internal static class LanGame
    {
        internal static Zompiercer.Inputs.InputController Input { get { return Instance<Zompiercer.Inputs.InputController>.Get(); } }
        internal static Zompiercer.GUI.GUIManager Gui { get { return Instance<Zompiercer.GUI.GUIManager>.Get(); } }
        internal static Zompiercer.GlobalStatsController Stats { get { return Instance<Zompiercer.GlobalStatsController>.Get(); } }
        internal static Zompiercer.Farm.TerrainResourceDetector Detector { get { return Instance<Zompiercer.Farm.TerrainResourceDetector>.Get(); } }
        internal static Zompiercer.GUI.GuiCore GuiCore { get { return Instance<Zompiercer.GUI.GuiCore>.Get(); } }

        // Mod overlays may use stock item names and hints while the game's own
        // menus use another language. Read the selected column without changing
        // the native locale or creating a replacement game singleton.
        private static string[,] _nativeRows;
        private static readonly Dictionary<string, int> NativeKeys = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

        internal static string Localize(string key)
        {
            if (string.IsNullOrEmpty(key)) return key ?? "";
            var localization = Instance<Zompiercer.GUI.LocalizationCore>.Get();
            if (localization == null || !localization.keysLoaded || localization.ArrayData == null) return key;
            if (!ReferenceEquals(_nativeRows, localization.ArrayData))
            {
                NativeKeys.Clear();
                for (int i = 0; i < localization.Keys.Count; i++)
                {
                    string name = localization.Keys[i];
                    if (!NativeKeys.ContainsKey(name)) NativeKeys.Add(name, i);
                }
                _nativeRows = localization.ArrayData;
            }
            int index;
            return NativeKeys.TryGetValue(key, out index) ? LanText.Native(_nativeRows, index, key) : key;
        }

        internal static string ItemName(int id)
        {
            var database = Zompiercer.Inventory.ItemsDataBase.Global;
            if (database == null || database.items == null || id < 0 || id >= database.items.Count) return "";
            var item = database.items[id];
            return item == null ? "" : Localize(item.name);
        }

        private static class Instance<T> where T : Object
        {
            private static readonly FieldInfo Field = typeof(Zompiercer.Singleton<>).MakeGenericType(typeof(T))
                .GetField("_instance", BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.Public);

            internal static T Get()
            {
                if (Field == null) return null;
                var value = Field.GetValue(null) as T;
                return value == null ? null : value; // a destroyed manager reads as null
            }
        }
    }
}
