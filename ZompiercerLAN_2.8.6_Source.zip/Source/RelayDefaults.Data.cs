// Public distribution: no private relay endpoint or access key.
namespace ZompiercerLAN {
 internal static partial class RelayDefaults {
  private const int PortValue = 27780;
  private static readonly byte[] Mask = new byte[0];
  private static readonly byte[] ServerData = new byte[0];
  private static readonly byte[] FingerprintData = new byte[0];
  private static readonly byte[] AccessKeyData = new byte[0];
 }
}
