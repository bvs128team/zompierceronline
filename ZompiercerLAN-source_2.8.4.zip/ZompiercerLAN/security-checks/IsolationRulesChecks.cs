using System;
using System.IO;

namespace ZompiercerLAN
{
    internal static partial class Program
    {
        // 2.8.4: where a guest's saves may go (LanSaveIsolation.Activate): the first session and every later one in the
        // same run of the game get a fresh folder of their own; never the player's own saves, never the previous session's.
        private static void IsolationRulesChecks()
        {
            string games = Path.GetFullPath(Path.Combine(Path.GetTempPath(), "zlan-rules", "Zompiercer"));
            string root = Path.Combine(games, "BepInEx", "LAN-sessions");
            string original = Path.Combine(Path.GetTempPath(), "zlan-rules", "LocalLow", "Saves");
            string first = Path.Combine(root, "20261025-100000-000-aaaa"), second = Path.Combine(root, "20261025-110000-000-bbbb");
            Func<string, string, bool, bool, string> refusal = (target, current, world, loading) =>
                LanIsolationRules.Refusal(target, current, original, root, world, loading);

            Require(refusal(first, null, false, false) == null, "The first guest session gets its folder");
            Require(refusal(first, null, false, true) != null, "No isolation while the game loads");
            Require(refusal(second, first, false, false) == null, "A later session gets a fresh folder without a restart");
            Require(refusal(second, first, true, false) != null, "The folder never changes under a loaded world");
            Require(refusal(second, first, false, true) != null, "The folder never changes while the game loads");
            Require(refusal(first, first, false, false) != null, "A later session never reuses the previous folder");
            foreach (string wrong in new[] { root, Path.Combine(first, "nested"), Path.Combine(games, "BepInEx", "other"),
                Path.Combine(games, "BepInEx", "LAN-sessions-x", "a"), original, Path.Combine(original, "LAN"), "" })
                foreach (string current in new[] { null, first })
                    Require(refusal(wrong, current, false, false) != null, "Saves pointed outside a fresh session folder: " + wrong);
            // The player's own saves inside the sessions folder (or holding it) are never taken as a session folder.
            Require(LanIsolationRules.Refusal(first, null, first, root, false, false) != null, "Session folder overlaps the player's saves");
            Require(LanIsolationRules.Refusal(first, null, Path.GetDirectoryName(games), root, false, false) != null, "Player's saves hold the session folder");
            Require(LanIsolationRules.Refusal(second, first, second, root, false, false) != null, "A later session never goes to the player's own saves");
            Require(LanIsolationRules.Refusal(first.ToUpperInvariant(), null, original, root.ToLowerInvariant(), false, false) == null &&
                LanIsolationRules.Refusal(second.ToUpperInvariant(), first.ToLowerInvariant(), original, root, false, false) == null &&
                LanIsolationRules.Refusal(first.ToUpperInvariant(), first.ToLowerInvariant(), original, root, false, false) != null,
                "Paths compared without letter case, as Windows does");
            Require(LanIsolationRules.Within(Path.Combine(first, "x"), first) && !LanIsolationRules.Within(first + "x", first),
                "A folder's name prefix is not inside it");
            Console.WriteLine("PASS: guest save folders: first and later sessions fresh, never the player's own saves or the previous session, not under a loaded world or a load");
        }
    }
}
