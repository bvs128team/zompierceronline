using System;
using System.Linq;

namespace ZompiercerLAN
{
    // 2.4.4 (packet schema 49): the garden beds of the host's train, the guest's work on them, on fallen trees and host
    // barrels, a box of a car itself, how worn an object being taken apart is.
    internal static partial class Program
    {
        private static void FarmChecks()
        {
            Packet decoded = null;
            Func<int, FarmFrame> bed = i => new FarmFrame
            {
                Car = (byte)(i % LanProtocol.MaxCars), Identity = i % 2 == 0 ? -(i + 1000) : i + 1000, Flags = (byte)(i % 4), Water = (byte)(i % 3), Fertilize = (byte)(255 - i),
                Points = Enumerable.Range(0, LanProtocol.MaxFarmPoints).Select(j => j % 3 == 0 ? new FarmPoint() :
                    new FarmPoint { Plant = (byte)(1 + j % LanProtocol.MaxFarmPlants), Stage = (byte)(j % (LanProtocol.MaxFarmStage + 1)), Flags = (byte)(j % 2), Growth = (ushort)(j * 1000 / (LanProtocol.MaxFarmPoints - 1)), Efficiency = (byte)(j * 250 / (LanProtocol.MaxFarmPoints - 1)) }).ToArray()
            };
            var states = new Packet { Kind = PacketKind.FarmStates, GameVersion = new string('v', 40), Session = 42, WorldEpoch = 3, Sequence = uint.MaxValue,
                Farms = Enumerable.Range(0, LanProtocol.MaxFarmBatch).Select(bed).ToArray() };
            var bytes = LanProtocol.Encode(states);
            Require(LanProtocol.MaxFarmPoints >= 17 && states.Farms.All(f => f.Points.Length == 17), "Shipped large bed's 17 planting points are not supported");
            Require(bytes.Length <= 1200 && LanProtocol.TryDecode(bytes, out decoded) && decoded.Kind == PacketKind.FarmStates && decoded.Sequence == uint.MaxValue && decoded.Farms.Length == LanProtocol.MaxFarmBatch, "Full farm batch rejected");
            Require(decoded.Farms.All(f => f.Points.Length == 17 && f.Points[16].Plant != 0 && f.Points[16].Growth == 1000), "Large bed's last plant lost in transport");
            Console.WriteLine("PASS: eight 17-point large beds fit in one " + bytes.Length + "-byte packet; last plant survives encode/decode");
            for (int i = 0; i < states.Farms.Length; i++)
            {
                FarmFrame a = states.Farms[i], b = decoded.Farms[i];
                Require(a.Car == b.Car && a.Identity == b.Identity && a.Flags == b.Flags && a.Water == b.Water && a.Fertilize == b.Fertilize && a.Points.Length == b.Points.Length &&
                    a.Points.Zip(b.Points, (u, v) => u.Plant == v.Plant && u.Stage == v.Stage && u.Flags == v.Flags && u.Growth == v.Growth && u.Efficiency == v.Efficiency).All(ok => ok), "Farm frame fields");
            }
            for (int size = 0; size < bytes.Length; size++) { var t = new byte[size]; Array.Copy(bytes, t, size); Require(!LanProtocol.TryDecode(t, out decoded), "Truncated farm batch accepted"); }
            var tail = new byte[bytes.Length + 1]; Array.Copy(bytes, tail, bytes.Length); Require(!LanProtocol.TryDecode(tail, out decoded), "Farm batch trailing bytes accepted");
            Func<Action<Packet>, bool> rejected = change =>
            {
                Packet copy; LanProtocol.TryDecode(LanProtocol.Encode(states), out copy);
                copy.GameVersion = "checks"; change(copy);
                try { return !LanProtocol.TryDecode(LanProtocol.Encode(copy), out decoded); }
                catch (System.IO.InvalidDataException) { return true; }
            };
            var bad = new[]
            {
                rejected(p => p.Sequence = 0), rejected(p => p.Farms = null), rejected(p => p.Farms = new FarmFrame[0]),
                rejected(p => p.Farms = Enumerable.Range(0, LanProtocol.MaxFarmBatch + 1).Select(bed).ToArray()), rejected(p => p.Farms[1] = null),
                rejected(p => p.Farms[0].Identity = 0), rejected(p => p.Farms[0].Car = LanProtocol.MaxCars), rejected(p => p.Farms[0].Flags = LanProtocol.MaxFarmFlags + 1),
                rejected(p => p.Farms[0].Points = null), rejected(p => p.Farms[0].Points = new FarmPoint[0]), rejected(p => p.Farms[0].Points[2] = null),
                rejected(p => p.Farms[0].Points = Enumerable.Range(0, LanProtocol.MaxFarmPoints + 1).Select(j => new FarmPoint()).ToArray()),
                rejected(p => p.Farms[0].Points[1].Plant = LanProtocol.MaxFarmPlants + 1), rejected(p => p.Farms[0].Points[1].Stage = LanProtocol.MaxFarmStage + 1),
                rejected(p => p.Farms[0].Points[1].Flags = 2), rejected(p => p.Farms[0].Points[1].Growth = 1001), rejected(p => p.Farms[0].Points[1].Efficiency = 251),
                // An empty point carries nothing else.
                rejected(p => p.Farms[0].Points[0].Growth = 1), rejected(p => p.Farms[0].Points[0].Stage = 1), rejected(p => p.Farms[0].Points[0].Flags = 1), rejected(p => p.Farms[0].Points[0].Efficiency = 1),
            };
            Require(bad.All(ok => ok), "Malformed farm batch accepted: #" + Array.IndexOf(bad, false));
            // The same on the wire: one bed of one point (Plant, Stage, Flags, Growth, Efficiency last).
            var one = new Packet { Kind = PacketKind.FarmStates, GameVersion = "checks", Session = 42, WorldEpoch = 3, Sequence = 1,
                Farms = new[] { new FarmFrame { Car = 1, Identity = 77, Flags = 3, Water = 1, Fertilize = 2, Points = new[] { new FarmPoint { Plant = 3, Stage = 2, Flags = 1, Growth = 1000, Efficiency = 100 } } } } };
            var wire = LanProtocol.Encode(one);
            Require(LanProtocol.TryDecode(wire, out decoded) && decoded.Farms[0].Points[0].Growth == 1000, "One-bed farm batch rejected");
            foreach (var change in new[] { new[] { 7, 0 }, new[] { 7, LanProtocol.MaxFarmPoints + 1 }, new[] { 6, LanProtocol.MaxFarmPlants + 1 }, new[] { 4, 2 }, new[] { 1, 251 }, new[] { 10, 4 }, new[] { 15, LanProtocol.MaxCars } })
            { var copy = (byte[])wire.Clone(); copy[copy.Length - change[0]] = (byte)change[1]; Require(!LanProtocol.TryDecode(copy, out decoded), "Invalid farm bytes accepted: " + change[0]); }
            var growth = (byte[])wire.Clone(); BitConverter.GetBytes((ushort)1001).CopyTo(growth, growth.Length - 3);
            Require(!LanProtocol.TryDecode(growth, out decoded), "Growth over 1000 accepted");
            var count = (byte[])wire.Clone(); count[count.Length - 16] = 0;
            Require(!LanProtocol.TryDecode(count, out decoded), "Empty farm batch accepted");
            // Only the host sends beds, once a session stands; not bound to a scene; a few batches at once.
            Require(!LanNetworkPolicy.Allowed(true, PacketKind.FarmStates, true) && LanNetworkPolicy.Allowed(false, PacketKind.FarmStates, true) &&
                !LanNetworkPolicy.Allowed(false, PacketKind.FarmStates, false) && !LanProtocol.WorldBound(PacketKind.FarmStates), "Farm packet directions");
            var limits = new LanMessageLimits(); int batches = 0;
            for (int i = 0; i < 1000; i++) if (limits.Take(PacketKind.FarmStates, 0)) batches++;
            Require(batches == 16, "Farm batch bursts not bounded");
            var beyond = (byte[])wire.Clone(); beyond[5] = (byte)PacketKind.AnimalState + 1;
            Require(!LanProtocol.TryDecode(beyond, out decoded), "A packet kind beyond AnimalState accepted");

            // Work on the beds: dirty water and fertilizer (escrow, at most 50), one seed, a harvest (nothing carried); car-local.
            float x, y, z; int tool, extra; object[] escrow;
            Require(LanStorage.DecodeWork(LanStorage.WorkPayload(LanStorage.WorkFarmWater, 1f, 2f, -250f, -1, 7, Item(61, 50)), out x, out y, out z, out tool, out extra, out escrow) == LanStorage.WorkFarmWater &&
                extra == 7 && tool == -1 && (int)escrow[1] == 50 && z == -250f, "Bed water roundtrip");
            Require(LanStorage.DecodeWork(LanStorage.WorkPayload(LanStorage.WorkFarmFertilize, 1f, 2f, 3f, -1, 0, Item(297, 3)), out x, out y, out z, out tool, out extra, out escrow) == LanStorage.WorkFarmFertilize, "Fertilizer roundtrip");
            Require(LanStorage.DecodeWork(LanStorage.WorkPayload(LanStorage.WorkFarmPlant, 1f, 2f, 3f, -1, 1, Item(400, 1)), out x, out y, out z, out tool, out extra, out escrow) == LanStorage.WorkFarmPlant && (int)escrow[0] == 400, "Seed roundtrip");
            Require(LanStorage.DecodeWork(LanStorage.WorkPayload(LanStorage.WorkFarmHarvest, 1f, 2f, 3f, -1, 2, null), out x, out y, out z, out tool, out extra, out escrow) == LanStorage.WorkFarmHarvest && escrow == null, "Harvest roundtrip");
            // A blow on a fallen tree (the host takes the strength from its ledger) and a hit on a host barrel (its host id).
            Require(LanStorage.DecodeWork(LanStorage.WorkPayload(LanStorage.WorkChop, 100f, -5f, 900f, 40, 0, null), out x, out y, out z, out tool, out extra, out escrow) == LanStorage.WorkChop && tool == 40 && extra == 0, "Chop roundtrip");
            Require(LanStorage.DecodeWork(LanStorage.WorkPayload(LanStorage.WorkHitHeld, 1f, 2f, 3f, 40, -12345, null), out x, out y, out z, out tool, out extra, out escrow) == LanStorage.WorkHitHeld && extra == -12345, "Barrel hit roundtrip");
            foreach (var payload in new[]
            {
                new object[] { LanStorage.WorkFarmWater, 1f, 2f, 3f, 5, 0, Item(61, 1) }, new object[] { LanStorage.WorkFarmWater, 1f, 2f, 3f, -1, 0, null },
                new object[] { LanStorage.WorkFarmWater, 1f, 2f, 3f, -1, 0, Item(61, LanStorage.MaxWaterBottles + 1) }, new object[] { LanStorage.WorkFarmWater, 1f, 2f, 3f, -1, LanProtocol.MaxCars, Item(61, 1) },
                new object[] { LanStorage.WorkFarmWater, 1f, 2f, 300f, -1, 0, Item(61, 1) }, new object[] { LanStorage.WorkFarmWater, 1f, 2f, 3f, -1, -1, Item(61, 1) },
                new object[] { LanStorage.WorkFarmFertilize, 1f, 2f, 3f, -1, 0, null }, new object[] { LanStorage.WorkFarmPlant, 1f, 2f, 3f, -1, 0, Item(400, 2) },
                new object[] { LanStorage.WorkFarmPlant, 1f, 2f, 3f, -1, 0, null }, new object[] { LanStorage.WorkFarmHarvest, 1f, 2f, 3f, -1, 0, Item(400, 1) },
                new object[] { LanStorage.WorkFarmHarvest, 1f, 2f, 3f, 0, 0, null }, new object[] { LanStorage.WorkFarmHarvest + 1, 1f, 2f, 3f, -1, 0, null },
                new object[] { LanStorage.WorkChop, 1f, 2f, 3f, 40, 1, null }, new object[] { LanStorage.WorkChop, 1f, 2f, 3f, -1, 0, null }, new object[] { LanStorage.WorkChop, 1f, 2f, 3f, 40, 0, Item(30, 1) },
                new object[] { LanStorage.WorkHitHeld, 1f, 2f, 3f, 40, 0, null }, new object[] { LanStorage.WorkHitHeld, 1f, 2f, 3f, 70000, 5, null },
            })
                ExpectRejected(() => LanStorage.DecodeWork(LanValueCodec.Encode(payload), out x, out y, out z, out tool, out extra, out escrow), "Invalid bed, tree or barrel work accepted: " + payload[0]);

            // A box of a car itself (the cab's): its car and place among the car's boxes, 1..16.
            var box = LanStorage.DecodeTarget(LanStorage.TrainPayload(LanProtocol.MaxCars - 1, LanStorage.TrainCarBox, LanStorage.MaxCarBoxes));
            Require((int)box[1] == LanProtocol.MaxCars - 1 && (int)box[2] == LanStorage.TrainCarBox && (int)box[3] == LanStorage.MaxCarBoxes, "Car box target roundtrip");
            foreach (var target in new[] { new object[] { 2, 0, LanStorage.TrainCarBox, 0 }, new object[] { 2, 0, LanStorage.TrainCarBox, LanStorage.MaxCarBoxes + 1 },
                new object[] { 2, 0, LanStorage.TrainCarBox, -1 }, new object[] { 2, 0, LanStorage.TrainCarBox + 1, 1 } })
                ExpectRejected(() => LanStorage.DecodeTarget(LanValueCodec.Encode(target)), "Invalid car box accepted");

            // How worn an object being taken apart or chopped is: hit points (Flags 1) or durability left, from the host only.
            var wear = new Packet { Kind = PacketKind.SceneStates, GameVersion = "checks", Session = 42, WorldEpoch = 3, Sequence = 9, Scene = "Terrain1",
                SceneObjects = new[] { new SceneFrame { Id = -9, Kind = LanProtocol.SceneWear, Flags = 1, Value = 212.5f }, new SceneFrame { Id = 9, Kind = LanProtocol.SceneWear, Flags = 0, Value = 0f } } };
            Require(LanProtocol.TryDecode(LanProtocol.Encode(wear), out decoded) && decoded.SceneObjects[0].Value == 212.5f && decoded.SceneObjects[0].Flags == 1, "Wear frame rejected");
            foreach (var value in new[] { -1f, float.NaN, 100000f, float.PositiveInfinity })
            {
                wear.SceneObjects[0].Value = value;
                ExpectRejected(() => LanProtocol.Encode(wear), "Invalid wear encoded: " + value);
            }
            wear.SceneObjects[0].Value = 1f; wear.SceneObjects[0].Flags = 2;
            ExpectRejected(() => LanProtocol.Encode(wear), "Wear flags 2 encoded");
            var guestUse = new Packet { Kind = PacketKind.SceneUse, GameVersion = "checks", Session = 42, WorldEpoch = 3, Sequence = 9, Scene = "Terrain1", Revision = 5, Action = LanProtocol.SceneWear };
            Require(!LanProtocol.TryDecode(SafeEncode(guestUse), out decoded), "A guest's wear accepted");
            Console.WriteLine("PASS: garden beds (batch shapes and bounds, byte tampering, empty points, directions, bursts), bed/tree/barrel work requests, car box targets, wear frames (schema 49)");
        }
        private static byte[] SafeEncode(Packet p)
        {
            try { return LanProtocol.Encode(p); }
            catch (System.IO.InvalidDataException) { return new byte[0]; }
        }
    }
}
