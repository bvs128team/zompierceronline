using System;

namespace ZompiercerLAN
{
    internal static partial class Program
    {
        private static void StarterLootChecks()
        {
            string first = LanStarterLootReceipt.Scene;
            Require(first == "ZCSBaseTerrain", "The kit belongs to the first location (level2, ZCSBaseTerrain)");
            Func<LanStarterLootReceipt, int, bool> eligible = (r, n) => r.Eligible(true, false, n, first, false);
            var receipt = new LanStarterLootReceipt();
            Require(!eligible(receipt, 1), "Unknown startup world must fail closed");
            // 21.4 snapshots have 21 native fields, 22.0 snapshots 22 (its animal spawners in [21]).
            foreach (int fields in new[] { 21, 22 })
                for (int guests = 1; guests <= 7; guests++)
                {
                    receipt.NewWorld();
                    Require(!eligible(receipt, 0) && eligible(receipt, guests), "Exactly two through eight admitted players eligible");
                    Require(!receipt.Eligible(false, false, guests, first, false), "Client must never spawn kit");
                    Require(!receipt.Eligible(true, true, guests, first, false), "Isolated guest world must never spawn kit");
                    Require(!receipt.Eligible(true, false, guests, first, true), "Load must finish before spawn");
                    foreach (string scene in new[] { null, "", "Terrain1", "Terrain2", "ZCSBaseTerrain(Clone)", "zcsbaseterrain" })
                        Require(!receipt.Eligible(true, false, guests, scene, false), "Unrelated scene must never spawn kit");
                    Require(receipt.Commit() && !receipt.Commit(), "Only one kit can commit");
                    for (int reconnect = 0; reconnect < 25; reconnect++)
                        Require(!eligible(receipt, guests) && !receipt.Commit(), "Reconnect/extra guests must not multiply kit");
                    var native = Native(fields); native[3] = first; native[10] = new object[] { "native loot sentinel" };
                    var saved = receipt.Save(native);
                    Require(native.Length == fields && saved.Length == fields + 1 && ReferenceEquals(saved[10], native[10]) &&
                        ReferenceEquals(saved[20], native[20]), "Preserve native snapshot fields");
                    var loaded = new LanStarterLootReceipt();
                    var forGame = loaded.Load(LanValueCodec.Decode(LanValueCodec.Encode(saved)));
                    Require(loaded.Granted && !eligible(loaded, guests), "Native checkpoint retains grant after collection and reload");
                    Require(forGame.Length == fields && first.Equals(forGame[3]) && Same(forGame[fields - 1], native[fields - 1]),
                        "The game must read its own fields only, the receipt taken out");
                    // Travel does not load old snapshots: the current receipt travels
                    // with every later checkpoint, including one saved while solo.
                    native[3] = "Terrain8";
                    Require(loaded.Load(loaded.Save(native)).Length == fields, "Receipt taken out after travel");
                    Require(loaded.Granted && !eligible(loaded, 1), "Other-scene/solo checkpoint retains world grant");
                }
            // A 2.0-2.8.1 save from 21.4 (receipt in [21]) loaded in 22.0: the game must not read the receipt as its animals.
            var old = Native(21); old[3] = first;
            var oldSaved = new object[22]; Array.Copy(old, oldSaved, 21); oldSaved[21] = new object[] { LanStarterLootReceipt.Magic, 1, 1 };
            var oldForGame = receipt.Load(oldSaved);
            Require(receipt.Granted && oldForGame.Length == 21 && first.Equals(oldForGame[3]), "2.8.1 receipt in the game's new field not taken out");
            foreach (int fields in new[] { 21, 22, 23 })
            {
                var legacy = Native(fields);
                Require(ReferenceEquals(receipt.Load(legacy), legacy) && eligible(receipt, 1),
                    "Legacy save supports late join even when originals were already taken");
                receipt.Load(receipt.Save(Native(fields)));
                Require(eligible(receipt, 1), "Solo checkpoint preserves pending eligibility");
            }
            Require(!eligible(receipt, -1) && !eligible(receipt, 8), "Invalid admitted guest count rejected");
            foreach (object[] data in new[] { null, new object[0], new object[20] })
            { receipt.Load(data); Require(!eligible(receipt, 1) && !receipt.Commit(), "Malformed native snapshot must fail closed"); }
            // Fields after the game's that are not ours (a later game's own) stay for the game.
            foreach (object tail in new object[] { null, true, 1, "receipt", new object[0], new object[] { "other mod", 1, 0 } })
            {
                var data = Native(22); data[21] = tail;
                Require(ReferenceEquals(receipt.Load(data), data) && eligible(receipt, 1), "A field of the game read as a receipt");
            }
            foreach (object tail in new object[] { new object[] { LanStarterLootReceipt.Magic },
                new object[] { LanStarterLootReceipt.Magic, 2, 0 }, new object[] { LanStarterLootReceipt.Magic, 1L, 0 },
                new object[] { LanStarterLootReceipt.Magic, 1, false }, new object[] { LanStarterLootReceipt.Magic, 1, -1 },
                new object[] { LanStarterLootReceipt.Magic, 1, 3 }, new object[] { LanStarterLootReceipt.Magic, 1, 0, 0 } })
                foreach (int at in new[] { 21, 22 })
                {
                    var data = Native(23); data[at] = tail;
                    var forGame = receipt.Load(data);
                    Require(!eligible(receipt, 1) && !receipt.Commit(), "Unknown/versioned/forged extension accepted");
                    Require(forGame.Length == 22, "Unknown/versioned receipt left for the game to read");
                    receipt.Load(receipt.Save(Native(22)));
                    Require(!eligible(receipt, 1), "Saving blocked world must not turn it eligible");
                }
            var twice = Native(24); twice[22] = new object[] { LanStarterLootReceipt.Magic, 1, 0 }; twice[23] = new object[] { LanStarterLootReceipt.Magic, 1, 0 };
            Require(receipt.Load(twice).Length == 22 && !eligible(receipt, 1), "Two receipts must fail closed and both be taken out");
            var early = Native(22); early[5] = new object[] { LanStarterLootReceipt.Magic, 1, 0 };
            Require(ReferenceEquals(receipt.Load(early), early), "Only fields after the game's first 21 may be a receipt");
            receipt.NewWorld(); Require(eligible(receipt, 1), "New world resets previous blocked/granted state");
            var held = Native(22); held[21] = new object[] { LanStarterLootReceipt.Magic, 1, 0 };
            foreach (object[] data in new[] { null, new object[0], new object[20], held })
                ExpectRejected(() => receipt.Save(data), "Unknown native shape or a second receipt must be rejected");
            Require(LanStarterLootReceipt.Backpack == 7 && LanStarterLootReceipt.Bat == 27 && LanStarterLootReceipt.Knife == 56,
                "Only authored starter item IDs allowed");
            Console.WriteLine("PASS: starter loot host/admission gates, 2-8 players, one world grant, reconnect/travel/solo checkpoint, legacy saves, first location only, 21/22 native fields, receipt out of the game's fields, malformed/versioned receipts");
        }
        private static object[] Native(int fields)
        {
            var data = new object[fields];
            for (int i = 0; i < fields; i++) data[i] = new object[] { "native " + i };
            return data;
        }
        private static bool Same(object a, object b)
        {
            var x = a as object[]; var y = b as object[];
            return x != null && y != null && x.Length == y.Length && x.Length == 1 && Equals(x[0], y[0]);
        }
    }
}
