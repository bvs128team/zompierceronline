using System;
using System.Linq;

namespace ZompiercerLAN
{
    // 2.8.0 (packet schema 54): the host's animals near the guest (AnimalState), a hit claim on an animal, an animal's bite,
    // and the guest's work on them (a carcass to cut, a chicken to catch).
    internal static partial class Program
    {
        private static void AnimalChecks()
        {
            Packet decoded = null;
            Func<int, AnimalFrame> animal = i => new AnimalFrame
            {
                Id = (uint)(LanProtocol.MaxAnimalIds - i), Prefab = new string('a', 64), X = -99999f + i, Y = 50f, Z = 99999f - i, Yaw = i * 45f % 360f,
                Flags = (byte)(i == 0 ? 1 | LanProtocol.AnimalButcher : LanProtocol.AnimalBleeding | LanProtocol.AnimalCatch), Animation = -123456789 + i,
                AnimationTime = i / 8f, Speed = i - 4f, Idle = (sbyte)(i - 1), Bools = (byte)(255 - i), Voice = LanProtocol.MaxAnimalClips, VoiceCount = (byte)(250 + i),
                Steps = (byte)i, StepsCount = (byte)i, Loops = (byte)(i % 4), Left = Enumerable.Range(0, LanProtocol.MaxAnimalLeft).Select(j => (byte)(255 - j)).ToArray()
            };
            var state = new Packet { Kind = PacketKind.AnimalState, GameVersion = new string('v', 40), Session = 42, WorldEpoch = 3, Sequence = uint.MaxValue,
                Scene = new string('s', 96), HostTime = 12345.5f, Animals = Enumerable.Range(0, LanProtocol.MaxAnimalBatch).Select(animal).ToArray() };
            var wire = LanProtocol.Encode(state);
            Require(wire.Length <= LanProtocol.MaxBytes && LanProtocol.TryDecode(wire, out decoded) && decoded.Animals.Length == LanProtocol.MaxAnimalBatch, "Maximum animal batch rejected");
            for (int i = 0; i < state.Animals.Length; i++)
            {
                var a = state.Animals[i]; var b = decoded.Animals[i];
                Require(a.Id == b.Id && a.Prefab == b.Prefab && a.X == b.X && a.Z == b.Z && a.Yaw == b.Yaw && a.Flags == b.Flags && a.Animation == b.Animation &&
                    a.AnimationTime == b.AnimationTime && a.Speed == b.Speed && a.Idle == b.Idle && a.Bools == b.Bools && a.Voice == b.Voice && a.VoiceCount == b.VoiceCount &&
                    a.Steps == b.Steps && a.StepsCount == b.StepsCount && a.Loops == b.Loops && a.Left.SequenceEqual(b.Left), "Animal frame roundtrip " + i);
            }
            Require(decoded.HostTime == 12345.5f && decoded.Scene == state.Scene, "Animal batch clock or scene");
            for (int size = 0; size < wire.Length; size++) { var cut = new byte[size]; Array.Copy(wire, cut, size); Require(!LanProtocol.TryDecode(cut, out decoded), "Truncated animal batch accepted"); }
            var tail = new byte[wire.Length + 1]; Array.Copy(wire, tail, wire.Length);
            Require(!LanProtocol.TryDecode(tail, out decoded), "Animal batch with trailing bytes accepted");
            // Frames the encoder refuses: no id or beyond the last, no prefab, a control character, NaN or a place beyond the
            // world, a facing out of a turn, unknown flags or state 3, a gone animal showing more, an animation moment out of
            // 0..1, a wild speed, a clip index beyond the clips, unknown loops, too many resources left.
            foreach (Action<AnimalFrame> bad in new Action<AnimalFrame>[]
            {
                a => a.Id = 0, a => a.Id = LanProtocol.MaxAnimalIds + 1, a => a.Prefab = "", a => a.Prefab = "wolf\n", a => a.Prefab = new string('a', 65),
                a => a.X = float.NaN, a => a.Y = 100000f, a => a.Yaw = -1f, a => a.Yaw = 361f, a => a.Flags = LanProtocol.MaxAnimalFlags + 1, a => a.Flags = 3,
                a => a.Flags = 2 | LanProtocol.AnimalBleeding, a => a.AnimationTime = 1.01f, a => a.AnimationTime = float.NaN, a => a.Speed = 101f,
                a => a.Speed = float.NaN, a => a.Voice = LanProtocol.MaxAnimalClips + 1, a => a.Steps = 255, a => a.Loops = LanProtocol.MaxAnimalLoops + 1,
                a => a.Left = new byte[LanProtocol.MaxAnimalLeft + 1],
            })
            {
                var one = animal(1); bad(one);
                Require(!LanProtocol.ValidAnimal(one) && !Encodes(new Packet { Kind = PacketKind.AnimalState, GameVersion = "checks", Session = 42, WorldEpoch = 3, Sequence = 1, Scene = "Terrain1", Animals = new[] { one } }), "Invalid animal frame encoded");
            }
            // The same refused on the wire: forged bytes past what the encoder writes.
            var single = new Packet { Kind = PacketKind.AnimalState, GameVersion = "checks", Session = 42, WorldEpoch = 3, Sequence = 1, Scene = "Terrain1", HostTime = 1f,
                Animals = new[] { new AnimalFrame { Id = 7, Prefab = "Wolf", X = 1, Y = 2, Z = 3, Yaw = 90 } } };
            var bytes = LanProtocol.Encode(single);
            Require(LanProtocol.TryDecode(bytes, out decoded) && decoded.Animals[0].Left == null && decoded.Animals[0].Id == 7, "Plain animal frame rejected");
            // From the end: Id(-44) Prefab(-42: length 4) X Y Z Yaw Flags(-21) Animation(-20) AnimationTime(-16) Speed(-12) Idle(-8) Bools(-7)
            // Voice(-6) VoiceCount(-5) Steps(-4) StepsCount(-3) Loops(-2) Left count(-1).
            foreach (var change in new[] { new[] { 21, 3 }, new[] { 21, 2 | LanProtocol.AnimalCatch }, new[] { 21, 64 }, new[] { 6, 201 }, new[] { 4, 201 }, new[] { 2, 4 }, new[] { 1, 4 }, new[] { 1, 5 } })
            { var copy = (byte[])bytes.Clone(); copy[copy.Length - change[0]] = (byte)change[1]; Require(!LanProtocol.TryDecode(copy, out decoded), "Invalid animal bytes accepted: " + change[0]); }
            var time = (byte[])bytes.Clone(); BitConverter.GetBytes(1.5f).CopyTo(time, time.Length - 16);
            Require(!LanProtocol.TryDecode(time, out decoded), "Animal animation moment past its end accepted");
            var id = (byte[])bytes.Clone(); BitConverter.GetBytes((ushort)0).CopyTo(id, id.Length - 44);
            Require(!LanProtocol.TryDecode(id, out decoded), "Animal without an id accepted");
            var twice = new Packet { Kind = PacketKind.AnimalState, GameVersion = "checks", Session = 42, WorldEpoch = 3, Sequence = 1, Scene = "Terrain1", HostTime = 1f,
                Animals = new[] { single.Animals[0], single.Animals[0] } };
            Require(!LanProtocol.TryDecode(LanProtocol.Encode(twice), out decoded), "The same animal twice in a batch accepted");
            Require(!Encodes(new Packet { Kind = PacketKind.AnimalState, GameVersion = "checks", Session = 42, WorldEpoch = 3, Sequence = 1, Scene = "Terrain1",
                Animals = new AnimalFrame[LanProtocol.MaxAnimalBatch + 1].Select((_, i) => animal(i % 8)).ToArray() }), "Animal batch over its bound encoded");
            single.WorldEpoch = 0;
            Require(!LanProtocol.TryDecode(LanProtocol.Encode(single), out decoded), "Worldless animal batch accepted");
            // Only the host sends animals, once a session stands; bound to a world and scene; as often as zombie batches.
            Require(!LanNetworkPolicy.Allowed(true, PacketKind.AnimalState, true) && LanNetworkPolicy.Allowed(false, PacketKind.AnimalState, true) &&
                !LanNetworkPolicy.Allowed(false, PacketKind.AnimalState, false) && LanProtocol.WorldBound(PacketKind.AnimalState), "Animal packet directions");
            var limits = new LanMessageLimits(); int batches = 0;
            for (int i = 0; i < 1000; i++) if (limits.Take(PacketKind.AnimalState, 0)) batches++;
            Require(batches == 32, "Animal batch bursts not bounded");
            var beyond = (byte[])bytes.Clone(); beyond[5] = (byte)PacketKind.AnimalState + 1;
            Require(!LanProtocol.TryDecode(beyond, out decoded), "A packet kind beyond AnimalState accepted");

            // A hit claim on an animal: its own id range, the flag on the wire (0 or 1), a swing meets one animal once.
            var action = new Packet { Kind = PacketKind.ZombieAction, GameVersion = "checks", Session = 42, WorldEpoch = 1, Sequence = 1, Scene = "Terrain1", EquippedItemId = 1,
                Action = 0, AimZ = 1, Revision = 1, Hits = new[] { new HitClaim { Zombie = LanProtocol.MaxAnimalIds, Animal = true, Limb = 3, DZ = 1 }, new HitClaim { Zombie = LanProtocol.MaxAnimalIds + 5, Limb = 1, DX = 1 } } };
            Require(LanProtocol.TryDecode(LanProtocol.Encode(action), out decoded) && decoded.Hits[0].Animal && decoded.Hits[0].Zombie == LanProtocol.MaxAnimalIds && !decoded.Hits[1].Animal,
                "Animal hit claim roundtrip");
            action.Hits = new[] { new HitClaim { Zombie = LanProtocol.MaxAnimalIds + 1, Animal = true, DZ = 1 } };
            Require(!LanProtocol.TryDecode(LanProtocol.Encode(action), out decoded), "Animal hit claim beyond the animal ids accepted");
            action.Hits = new[] { new HitClaim { Zombie = 9, Animal = true, DZ = 1 } };
            var claimBytes = LanProtocol.Encode(action);
            var flag = (byte[])claimBytes.Clone(); flag[flag.Length - 38] = 2; // Zombie(4) Animal(1) Limb(1) and nine floats
            Require(LanProtocol.TryDecode(claimBytes, out decoded) && !LanProtocol.TryDecode(flag, out decoded), "Hit claim target flag other than 0 or 1 accepted");
            action.EquippedItemId = -1; action.Action = 1;
            action.Hits = new[] { new HitClaim { Zombie = 9, Animal = true, DZ = 1 }, new HitClaim { Zombie = 9, DZ = 1 } };
            Require(!Encodes(action), "Swing with two hit claims encoded");

            // A bite: damage only, no prefab; the kind after it unknown.
            var bite = new Packet { Kind = PacketKind.ZombieHurt, GameVersion = "checks", Session = 42, WorldEpoch = 1, Sequence = 1, Scene = "Terrain1", Damage = 25, Action = LanProtocol.HurtAnimal, Text = "" };
            Require(LanProtocol.TryDecode(LanProtocol.Encode(bite), out decoded) && decoded.Action == LanProtocol.HurtAnimal && decoded.Damage == 25, "Animal bite rejected");
            bite.Text = "Wolf";
            Require(!Encodes(bite), "Animal bite naming a prefab encoded");
            bite.Text = ""; bite.Action = LanProtocol.HurtAnimal + 1;
            Require(!Encodes(bite), "Unknown hurt kind encoded");

            // Work on animals: a cut on a carcass (a tool, the animal's id), a catch by hand (no tool, the id).
            float x, y, z; int tool, extra; object[] escrow;
            Require(LanStorage.DecodeWork(LanStorage.WorkPayload(LanStorage.WorkButcher, 1f, 2f, 3f, 77, LanProtocol.MaxAnimalIds, null), out x, out y, out z, out tool, out extra, out escrow) == LanStorage.WorkButcher &&
                tool == 77 && extra == LanProtocol.MaxAnimalIds && escrow == null, "Butcher roundtrip");
            Require(LanStorage.DecodeWork(LanStorage.WorkPayload(LanStorage.WorkCatch, 1f, 2f, 3f, -1, 1, null), out x, out y, out z, out tool, out extra, out escrow) == LanStorage.WorkCatch &&
                tool == -1 && extra == 1, "Catch roundtrip");
            foreach (var payload in new[]
            {
                new object[] { LanStorage.WorkButcher, 1f, 2f, 3f, -1, 5, null }, new object[] { LanStorage.WorkButcher, 1f, 2f, 3f, 70000, 5, null },
                new object[] { LanStorage.WorkButcher, 1f, 2f, 3f, 77, 0, null }, new object[] { LanStorage.WorkButcher, 1f, 2f, 3f, 77, LanProtocol.MaxAnimalIds + 1, null },
                new object[] { LanStorage.WorkButcher, 1f, 2f, 3f, 77, 5, Item(30, 1) }, new object[] { LanStorage.WorkCatch, 1f, 2f, 3f, 5, 5, null },
                new object[] { LanStorage.WorkCatch, 1f, 2f, 3f, -1, -5, null }, new object[] { LanStorage.WorkCatch, 1f, 2f, 3f, -1, 5, Item(30, 1) },
                new object[] { LanStorage.WorkCatch + 1, 1f, 2f, 3f, -1, 5, null },
            })
                ExpectRejected(() => LanStorage.DecodeWork(LanValueCodec.Encode(payload), out x, out y, out z, out tool, out extra, out escrow), "Invalid animal work accepted: " + payload[0] + "/" + payload[4] + "/" + payload[5]);
            // What a cut gives comes back as a list (meat and skin), bounded like a refund.
            var meat = new object[] { new object[] { 500, 3, new object[4] }, new object[] { 501, 1, new object[4] } };
            var back = LanStorage.DecodeRefund(LanStorage.RefundPayload(meat));
            Require(back.Length == 2 && (int)((object[])back[0])[0] == 500 && (int)((object[])back[1])[1] == 1, "Butchered items roundtrip");
            Console.WriteLine("PASS: animals (batch shapes and bounds, byte tampering, duplicates, directions, bursts), animal hit claims, bites, carcass and catch work requests");
        }
    }
}
