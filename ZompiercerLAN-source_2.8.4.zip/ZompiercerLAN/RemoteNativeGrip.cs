using System;
using System.Collections.Generic;
using UnityEngine;
using Zompiercer.Inventory;
using Object = UnityEngine.Object;

namespace ZompiercerLAN
{
    // A display-only copy of the game's first-person weapon at its own idle grip. The copied
    // hierarchy is never activated: no Gun, WeaponAnimation, Animator, collider or effect is
    // attached to the returned geometry. The local player's gun is read but never moved.
    internal static class RemoteNativeGrip
    {
        internal struct FingerPose
        {
            internal string Suffix;
            internal Quaternion LocalPose, LocalRest;
        }

        internal struct FingerBase
        {
            internal string Suffix;
            internal Vector3 Position;
        }

        // A right-handed anatomical frame: its centre is the four finger bases, its forward
        // axis points from the palm origin toward them, and its up axis spans index to little.
        // Source and target frames are local to their respective palm transforms.
        internal struct PalmFrame
        {
            internal Vector3 Center;
            internal Quaternion Rotation;
            internal float Width;
        }

        internal struct Mount
        {
            internal EquipmentModSlotType Type;
            internal EquipmentModSlotMountType MountType;
            internal Vector3 Position, Scale;
            internal Quaternion Rotation;
        }

        internal sealed class Pose
        {
            internal GameObject Geometry;
            internal Vector3 HeldPosition, HeldScale, SupportPosition, MuzzlePosition;
            internal Quaternion HeldRotation, SupportRotation, AimInPalm;
            internal bool PrimaryLeft, SupportValid, MuzzleValid;
            internal float Length;
            // 2.7.0: how the partner holds it (RemoteHoldPose) and its anchors in this palm space: the butt plate's
            // middle, the bow's limb tip, a tool's far end.
            internal RemoteHoldPose.Kind Kind;
            internal Vector3 Butt, Limb, Tool, Magazine; // 2.8.1: the magazine (or the receiver's underside) for a reload
            internal Mount[] Mounts = new Mount[0];
            internal FingerPose[] Fingers = new FingerPose[0];
            internal FingerBase[] PrimaryFingerBases = new FingerBase[0];
            internal FingerBase[] SupportFingerBases = new FingerBase[0];
            internal PalmFrame PrimaryFrame, SupportFrame;
            internal bool PrimaryFrameValid, SupportFrameValid;
            internal Recipe _recipe;
            private bool _released;

            internal void Release()
            {
                if (_released) return;
                _released = true;
                if (Geometry != null) Object.Destroy(Geometry);
                Geometry = null;
                if (_recipe == null) return;
                _recipe.Users--;
                if (_recipe.Retired && _recipe.Users == 0) Dispose(_recipe);
                _recipe = null;
            }
        }

        internal sealed class Part
        {
            internal string Name;
            internal Mesh Mesh;
            internal Material[] Materials;
            internal Vector3 Position, Scale;
            internal Quaternion Rotation;
            internal UnityEngine.Rendering.ShadowCastingMode Shadows;
            internal bool ReceiveShadows;
        }

        internal sealed class Recipe
        {
            internal InventoryItem Prefab;
            internal Gun Gun;
            internal RuntimeAnimatorController Controller;
            internal Part[] Parts;
            internal Mesh[] Baked;
            internal Mount[] Mounts;
            internal FingerPose[] Fingers;
            internal FingerBase[] PrimaryFingerBases, SupportFingerBases;
            internal PalmFrame PrimaryFrame, SupportFrame;
            internal bool PrimaryFrameValid, SupportFrameValid;
            internal Vector3 SupportPosition, MuzzlePosition, Butt, Limb, Tool, Magazine;
            internal RemoteHoldPose.Kind Kind;
            internal Quaternion SupportRotation, AimInPalm;
            internal bool PrimaryLeft, SupportValid, MuzzleValid;
            internal float Length;
            internal int Users;
            internal bool Retired;
        }

        private struct SlotSource
        {
            internal Transform Transform, Spawned;
            internal EquipmentModSlotType Type;
            internal EquipmentModSlotMountType MountType;
        }

        private static readonly Dictionary<int, Recipe> Cache = new Dictionary<int, Recipe>();
        private const int MaxCachedItems = 64;

        // Verified against the game's Gun.ID and first-person prefab hierarchy (2.5.6).
        // A source with an unknown ID is left to the caller's existing fallback.
        private static string MainMesh(string id, out bool left)
        {
            left = false;
            switch (id)
            {
                case "Hammer": return "Hammer";
                case "Hammer Quality": return "QualityHammer";
                case "Hammer Scrap": return "ScrapHammer";
                case "Glock": return "Eder22";
                case "Sawed-off shotgun": return "DBShotgunForearm";
                case "Remington": return "R870";
                case "Adjustable Wrench Quality": return "QualityAdjustableWrench";
                case "Adjustable Wrench": return "AdjustableWrench";
                case "Adjustable Wrench Scrap": return "ScrapAdjustableWrench";
                case "Revolver": return "Revolver";
                case "Volter": return "WPPK_Base";
                case "Bow Reinforced": left = true; return "MetalBow";
                case "Bow Rough": left = true; return "RoughWoodenBow";
                case "Baseball Bat Lucille": return "LucilleBat";
                case "Baseball Bat Nails": return "BaseballBatNails";
                case "Baseball Bat": return "BaseballBat";
                case "Dynamite": return "DynamiteTrash";
                case "Dynamite Bundle": return "DynamiteBundle";
                case "Grenade Mk2": return "FragGrenade";
                case "M1911": return "M1911";
                case "ShotgunM4": return "WPN_M4";
                case "Flashlight": return "Flashlight";
                case "Flashlight Scrap": return "ScrapFlashlight";
                case "C4": return "C4_geo";
                case "Shovel Metal": return "Shovel";
                case "Shovel Scrap": return "ScrapShovel";
                case "Knife Combat": return "MetaltKnife";
                case "Knife Tactical": return "TacticalKnife";
                case "Knife Scrap": return "ScrapKnife";
                case "Axe Quality": return "QualityAxe";
                case "Axe Scrap": return "ScrapAxe";
                case "Axe Old Fire": return "OldFireAxe";
                case "Hunting Rifle": return "HuntingRifle";
                case "AKM": return "AKM";
                case "OldRifle": return "OldRifle";
                default: return null;
            }
        }

        internal static bool TryBuild(InventoryItem prefab, Gun gun, out Pose pose)
        {
            pose = null;
            if (prefab == null || gun == null || string.IsNullOrEmpty(gun.ID)) return false;
            var weapon = prefab.GetComponent<WeaponData>();
            if (weapon == null || weapon.ID != gun.ID) return false;
            bool primaryLeft;
            string main = MainMesh(gun.ID, out primaryLeft);
            if (main == null) return false;
            var animator = gun.GetComponent<Animator>();
            var controller = animator == null ? null : animator.runtimeAnimatorController;
            Recipe recipe;
            if (!Cache.TryGetValue(prefab.itemID, out recipe) || recipe.Prefab != prefab || recipe.Gun != gun ||
                recipe.Controller != controller || !Alive(recipe))
            {
                if (recipe != null) Retire(recipe);
                Cache.Remove(prefab.itemID);
                try { recipe = Extract(prefab, gun, controller, main, primaryLeft); }
                catch (Exception) { recipe = null; }
                if (recipe == null) return false;
                if (Cache.Count >= MaxCachedItems)
                {
                    int first = -1;
                    foreach (var key in Cache.Keys) { first = key; break; }
                    if (first >= 0) { Retire(Cache[first]); Cache.Remove(first); }
                }
                Cache[prefab.itemID] = recipe;
            }
            var geometry = NewGeometry(recipe);
            if (geometry == null) return false;
            recipe.Users++;
            pose = new Pose
            {
                Geometry = geometry, HeldPosition = Vector3.zero, HeldRotation = Quaternion.identity,
                HeldScale = Vector3.one, PrimaryLeft = recipe.PrimaryLeft,
                SupportValid = recipe.SupportValid, SupportPosition = recipe.SupportPosition,
                SupportRotation = recipe.SupportRotation, AimInPalm = recipe.AimInPalm,
                Length = recipe.Length, MuzzleValid = recipe.MuzzleValid, MuzzlePosition = recipe.MuzzlePosition,
                Kind = recipe.Kind, Butt = recipe.Butt, Limb = recipe.Limb, Tool = recipe.Tool, Magazine = recipe.Magazine,
                Mounts = recipe.Mounts, Fingers = recipe.Fingers,
                PrimaryFingerBases = recipe.PrimaryFingerBases, SupportFingerBases = recipe.SupportFingerBases,
                PrimaryFrame = recipe.PrimaryFrame, SupportFrame = recipe.SupportFrame,
                PrimaryFrameValid = recipe.PrimaryFrameValid, SupportFrameValid = recipe.SupportFrameValid,
                _recipe = recipe
            };
            return true;
        }

        internal static void Clear()
        {
            foreach (var entry in Cache.Values) Retire(entry);
            Cache.Clear();
        }

        private static bool Alive(Recipe recipe)
        {
            if (recipe == null || recipe.Parts == null || recipe.Parts.Length == 0) return false;
            foreach (var part in recipe.Parts) if (part.Mesh == null) return false;
            return true;
        }

        private static void Retire(Recipe recipe)
        {
            recipe.Retired = true;
            if (recipe.Users == 0) Dispose(recipe);
        }

        private static void Dispose(Recipe recipe)
        {
            if (recipe.Baked == null) return;
            foreach (var mesh in recipe.Baked) if (mesh != null) Object.Destroy(mesh);
            recipe.Baked = null;
        }

        private static Recipe Extract(InventoryItem prefab, Gun gun, RuntimeAnimatorController controller,
            string mainName, bool primaryLeft)
        {
            GameObject shelter = null;
            var baked = new List<Mesh>();
            bool complete = false;
            try
            {
                // Parenting during Instantiate keeps even an active selected Gun inactiveInHierarchy.
                shelter = new GameObject("LAN native grip sample");
                shelter.SetActive(false);
                var clone = Object.Instantiate(gun.gameObject, shelter.transform, false);
                clone.SetActive(false);
                var cloneGun = clone.GetComponent<Gun>();
                var sampleAnimator = clone.GetComponent<Animator>();
                if (cloneGun == null || sampleAnimator == null) return null;
                var muzzle = cloneGun.bulletSpawnPoint;
                var animation = clone.GetComponent<WeaponAnimation>();
                float length = animation == null ? 0f : animation.Length;
                var slots = Slots(cloneGun);
                // Strip every game script before the clip is sampled. Never activate the clone.
                sampleAnimator.enabled = false;
                foreach (var script in clone.GetComponentsInChildren<MonoBehaviour>(true))
                    if (script != null) Object.DestroyImmediate(script);
                var idle = Idle(controller);
                if (idle == null) return null;
                idle.SampleAnimation(clone, 0f);
                var right = Named(clone.transform, "CATRigRArmPalm");
                var left = Named(clone.transform, "CATRigLArmPalm");
                var palm = primaryLeft ? left : right;
                var support = primaryLeft ? right : left;
                var main = Named(clone.transform, mainName);
                if (palm == null || main == null || !HasMesh(main)) return null;
                var parts = new List<Part>();
                var excluded = new List<Transform>();
                foreach (var slot in slots) if (slot.Spawned != null) excluded.Add(slot.Spawned);
                bool rootMounted = !main.IsChildOf(right) && !main.IsChildOf(left);
                foreach (var renderer in clone.GetComponentsInChildren<Renderer>(true))
                {
                    if (!(renderer is MeshRenderer) && !(renderer is SkinnedMeshRenderer)) continue;
                    var t = renderer.transform;
                    if (!WeaponPart(t, main, rootMounted, right, left, excluded)) continue;
                    if (!VisibleFrom(clone.transform, t) && t != main) continue;
                    if (!renderer.enabled && t != main) continue;
                    var part = Capture(renderer, palm, baked);
                    if (part != null) parts.Add(part);
                }
                if (parts.Count == 0 || parts.Count > 80) return null;
                var recipe = new Recipe
                {
                    Prefab = prefab, Gun = gun, Controller = controller, Parts = parts.ToArray(),
                    Baked = baked.ToArray(), PrimaryLeft = primaryLeft,
                    Length = Valid(length) && length > .02f && length < 8f ? length : MeasuredLength(parts, palm, clone.transform),
                    Mounts = CaptureMounts(slots, palm), Fingers = CaptureFingers(clone.transform),
                    PrimaryFingerBases = CaptureBases(palm, primaryLeft),
                    SupportFingerBases = CaptureBases(support, !primaryLeft),
                    AimInPalm = Quaternion.Inverse(palm.rotation) * clone.transform.rotation
                };
                recipe.PrimaryFrameValid = TryFrame(recipe.PrimaryFingerBases, out recipe.PrimaryFrame);
                recipe.SupportFrameValid = TryFrame(recipe.SupportFingerBases, out recipe.SupportFrame);
                if (!recipe.PrimaryFrameValid) return null;
                // 2.7.0: the partner's stance by the item, its anchors from the shipped vertices (all readable).
                recipe.Kind = RemoteHoldPose.KindOf(gun.ID);
                if (!Anchors(recipe, out recipe.Butt, out recipe.Limb, out recipe.Tool, out recipe.Magazine)) return null;
                if (support != null)
                {
                    recipe.SupportPosition = palm.InverseTransformPoint(support.position);
                    recipe.SupportRotation = Quaternion.Inverse(palm.rotation) * support.rotation;
                    // The other first-person hand holds the item in its idle frame for long guns, handguns, the bow
                    // (the string hand) and a shovel; with the rest it rests or works a reload, so it is no grip.
                    var kind = recipe.Kind;
                    recipe.SupportValid = (kind == RemoteHoldPose.Kind.Long || kind == RemoteHoldPose.Kind.Handgun ||
                        kind == RemoteHoldPose.Kind.Bow || kind == RemoteHoldPose.Kind.TwoHand) &&
                        recipe.SupportFrameValid && Finite(recipe.SupportPosition) && Finite(recipe.SupportRotation);
                }
                if (muzzle != null)
                {
                    recipe.MuzzlePosition = palm.InverseTransformPoint(muzzle.position);
                    recipe.MuzzleValid = Finite(recipe.MuzzlePosition);
                }
                if (!Finite(recipe.AimInPalm) || !Valid(recipe.Length) || recipe.Length <= 0f) return null;
                complete = true;
                return recipe;
            }
            finally
            {
                if (!complete) foreach (var mesh in baked) if (mesh != null) Object.Destroy(mesh);
                if (shelter != null) Object.DestroyImmediate(shelter);
            }
        }

        private static SlotSource[] Slots(Gun gun)
        {
            // Gun.Awake populates equipmentMods, but the source template may never have awakened.
            var equipment = gun.equipmentMods != null ? gun.equipmentMods : gun.GetComponent<EquipmentMods>();
            var list = equipment == null ? null : equipment.Slots;
            var sources = new List<SlotSource>();
            if (list != null)
                foreach (var slot in list)
                    if (slot != null) sources.Add(new SlotSource { Transform = slot.transform, Spawned = slot.SpawnedModel,
                        Type = slot.Type, MountType = slot.MountType });
            if (sources.Count == 0 && equipment != null)
                foreach (var slot in equipment.GetComponentsInChildren<EquipmentModSlot>(true))
                    if (slot != null) sources.Add(new SlotSource { Transform = slot.transform, Spawned = slot.SpawnedModel,
                        Type = slot.Type, MountType = slot.MountType });
            return sources.ToArray();
        }

        private static Mount[] CaptureMounts(SlotSource[] sources, Transform palm)
        {
            var mounts = new List<Mount>();
            foreach (var source in sources)
            {
                Vector3 p, s; Quaternion q;
                if (source.Transform == null || !Relative(palm, source.Transform, out p, out q, out s)) continue;
                mounts.Add(new Mount { Type = source.Type, MountType = source.MountType,
                    Position = p, Rotation = q, Scale = s });
            }
            return mounts.ToArray();
        }

        private static AnimationClip Idle(RuntimeAnimatorController controller)
        {
            if (controller == null) return null;
            AnimationClip chosen = null;
            foreach (var clip in controller.animationClips)
            {
                if (clip == null) continue;
                string name = clip.name;
                if (name.IndexOf("Idle", StringComparison.OrdinalIgnoreCase) < 0 &&
                    name.IndexOf("Aimong", StringComparison.OrdinalIgnoreCase) < 0) continue;
                if (chosen == null || name.Length < chosen.name.Length) chosen = clip;
            }
            return chosen;
        }

        private static Transform Named(Transform root, string name)
        {
            foreach (var t in root.GetComponentsInChildren<Transform>(true))
                if (t.name == name) return t;
            return null;
        }

        private static bool HasMesh(Transform t)
        {
            var filter = t.GetComponent<MeshFilter>();
            var skin = t.GetComponent<SkinnedMeshRenderer>();
            return filter != null && filter.sharedMesh != null || skin != null && skin.sharedMesh != null;
        }

        private static bool WeaponPart(Transform t, Transform main, bool rootMounted, Transform right,
            Transform left, List<Transform> excluded)
        {
            foreach (var x in excluded) if (x != null && (t == x || t.IsChildOf(x))) return false;
            if (t.name == "CharacterHands" || t.name == "CharacterShirt" || t.name == "CharacterBase") return false;
            if (t.name.IndexOf("Casing", StringComparison.OrdinalIgnoreCase) >= 0 ||
                t.name.IndexOf("Ammo", StringComparison.OrdinalIgnoreCase) >= 0 ||
                t.name.IndexOf("Bullet", StringComparison.OrdinalIgnoreCase) >= 0 ||
                t.name.IndexOf("magazineHand", StringComparison.OrdinalIgnoreCase) >= 0 ||
                t.name.IndexOf("magazineHend", StringComparison.OrdinalIgnoreCase) >= 0) return false;
            if (t == main || t.IsChildOf(main)) return true;
            if (!rootMounted || right != null && t.IsChildOf(right) || left != null && t.IsChildOf(left)) return false;
            // Root-mounted rifles keep working parts under a separate CATRigHub* branch.
            return t.name.StartsWith(main.name + "_", StringComparison.Ordinal) ||
                main.name == "HuntingRifle" && (t.name == "PicatinnyRail" || t.name == "RifleDummy");
        }

        private static bool VisibleFrom(Transform root, Transform t)
        {
            for (var current = t; current != null && current != root; current = current.parent)
                if (!current.gameObject.activeSelf) return false;
            return true;
        }

        private static Part Capture(Renderer renderer, Transform palm, List<Mesh> baked)
        {
            Mesh mesh;
            var skin = renderer as SkinnedMeshRenderer;
            if (skin != null)
            {
                if (skin.sharedMesh == null) return null;
                mesh = new Mesh { name = "LAN native " + skin.sharedMesh.name };
                try { skin.BakeMesh(mesh); }
                catch (Exception) { Object.Destroy(mesh); return null; }
                if (mesh.vertexCount == 0) { Object.Destroy(mesh); return null; }
            }
            else
            {
                var filter = renderer.GetComponent<MeshFilter>();
                mesh = filter == null ? null : filter.sharedMesh;
                if (mesh == null) return null;
            }
            Vector3 p, s; Quaternion q;
            if (!Relative(palm, renderer.transform, out p, out q, out s))
            {
                if (skin != null) Object.Destroy(mesh);
                return null;
            }
            if (skin != null) baked.Add(mesh);
            return new Part { Name = renderer.name, Mesh = mesh, Materials = renderer.sharedMaterials,
                Position = p, Rotation = q, Scale = s, Shadows = renderer.shadowCastingMode,
                ReceiveShadows = renderer.receiveShadows };
        }

        // 2.7.0: the item's anchors in the native palm's space, from every vertex of its parts: the middle of the rear
        // 2.5 cm along the bore (a long gun's butt plate), the vertex farthest from the bore line through the grip (a
        // bow's limb tip) and the one farthest from the grip (a tool's far end). 2.8.1: the magazine: 3..25 cm ahead of
        // the grip, a third of the way up from the lowest vertex there to the highest, in the grip's plane (a shotgun:
        // its receiver's underside); 10 cm ahead of the grip when nothing is there.
        private static bool Anchors(Recipe recipe, out Vector3 butt, out Vector3 limb, out Vector3 tool, out Vector3 magazine)
        {
            butt = limb = tool = magazine = Vector3.zero;
            var bore = recipe.AimInPalm * Vector3.forward;
            var grip = recipe.PrimaryFrame.Center;
            var points = new List<Vector3>();
            foreach (var part in recipe.Parts)
            {
                Vector3[] vertices;
                try { vertices = part.Mesh.isReadable ? part.Mesh.vertices : null; }
                catch (Exception) { vertices = null; }
                if (vertices == null) continue;
                foreach (var v in vertices) points.Add(part.Position + part.Rotation * Vector3.Scale(part.Scale, v));
            }
            if (points.Count == 0) return false;
            float rearmost = float.MaxValue, far = -1f, wide = -1f;
            foreach (var p in points)
            {
                rearmost = Mathf.Min(rearmost, Vector3.Dot(p, bore));
                float distance = (p - grip).sqrMagnitude;
                if (distance > far) { far = distance; tool = p; }
                var off = p - grip; off -= bore * Vector3.Dot(off, bore);
                if (off.sqrMagnitude > wide) { wide = off.sqrMagnitude; limb = p; }
            }
            var sum = Vector3.zero; int rear = 0;
            foreach (var p in points)
                if (Vector3.Dot(p, bore) < rearmost + .025f) { sum += p; rear++; }
            butt = sum / rear;
            var up = recipe.AimInPalm * Vector3.up; var side = Vector3.Cross(up, bore);
            float gripAlong = Vector3.Dot(grip, bore), lowest = float.MaxValue, highest = float.MinValue;
            var low = Vector3.zero;
            foreach (var p in points)
            {
                float along = Vector3.Dot(p, bore);
                if (along <= gripAlong + .03f || along >= gripAlong + .25f) continue;
                float height = Vector3.Dot(p, up);
                if (height < lowest) { lowest = height; low = p; }
                highest = Mathf.Max(highest, height);
            }
            magazine = lowest == float.MaxValue ? grip + bore * .10f :
                bore * Vector3.Dot(low, bore) + up * (lowest + .35f * (highest - lowest)) + side * Vector3.Dot(grip, side);
            return Finite(butt) && Finite(limb) && Finite(tool) && Finite(magazine);
        }

        private static GameObject NewGeometry(Recipe recipe)
        {
            GameObject root = null;
            try
            {
                root = new GameObject("LAN native held geometry");
                foreach (var part in recipe.Parts)
                {
                    if (part.Mesh == null) throw new InvalidOperationException("native mesh missing");
                    var child = new GameObject(part.Name);
                    child.transform.SetParent(root.transform, false);
                    child.transform.localPosition = part.Position;
                    child.transform.localRotation = part.Rotation;
                    child.transform.localScale = part.Scale;
                    child.AddComponent<MeshFilter>().sharedMesh = part.Mesh;
                    var display = child.AddComponent<MeshRenderer>();
                    display.sharedMaterials = part.Materials;
                    display.shadowCastingMode = part.Shadows;
                    display.receiveShadows = part.ReceiveShadows;
                }
                return root;
            }
            catch (Exception)
            {
                if (root != null) Object.Destroy(root);
                return null;
            }
        }

        private static float MeasuredLength(List<Part> parts, Transform palm, Transform root)
        {
            float min = float.PositiveInfinity, max = float.NegativeInfinity;
            var along = Quaternion.Inverse(palm.rotation) * root.forward;
            foreach (var part in parts)
            {
                var bounds = part.Mesh.bounds;
                for (int i = 0; i < 8; i++)
                {
                    var corner = bounds.center + Vector3.Scale(bounds.extents,
                        new Vector3((i & 1) == 0 ? -1f : 1f, (i & 2) == 0 ? -1f : 1f, (i & 4) == 0 ? -1f : 1f));
                    float d = Vector3.Dot(part.Position + part.Rotation * Vector3.Scale(part.Scale, corner), along);
                    min = Mathf.Min(min, d); max = Mathf.Max(max, d);
                }
            }
            return Mathf.Clamp(max - min, .01f, 8f);
        }

        // A Transform's complete local-to-palm matrix, rejecting shear or mirrored axes that
        // cannot be reproduced by one child Transform's position/rotation/scale.
        private static bool Relative(Transform palm, Transform child, out Vector3 position,
            out Quaternion rotation, out Vector3 scale)
        {
            var m = palm.worldToLocalMatrix * child.localToWorldMatrix;
            position = m.GetColumn(3);
            Vector3 x = m.GetColumn(0), y = m.GetColumn(1), z = m.GetColumn(2);
            scale = new Vector3(x.magnitude, y.magnitude, z.magnitude);
            rotation = Quaternion.identity;
            if (!Finite(position) || !Finite(scale) || scale.x < 1e-5f || scale.y < 1e-5f || scale.z < 1e-5f ||
                scale.x > 1000f || scale.y > 1000f || scale.z > 1000f) return false;
            x /= scale.x; y /= scale.y; z /= scale.z;
            if (Mathf.Abs(Vector3.Dot(x, y)) > .01f || Mathf.Abs(Vector3.Dot(x, z)) > .01f ||
                Mathf.Abs(Vector3.Dot(y, z)) > .01f || Vector3.Dot(Vector3.Cross(x, y), z) < .99f) return false;
            rotation = Quaternion.LookRotation(z, y);
            return Finite(rotation);
        }

        private static FingerPose[] CaptureFingers(Transform root)
        {
            SkinnedMeshRenderer hands = null;
            foreach (var skin in root.GetComponentsInChildren<SkinnedMeshRenderer>(true))
                if (skin.name == "CharacterHands" && skin.sharedMesh != null) { hands = skin; break; }
            if (hands == null) return new FingerPose[0];
            var bones = hands.bones;
            var bind = hands.sharedMesh.bindposes;
            if (bones == null || bind == null || bones.Length != bind.Length) return new FingerPose[0];
            var index = new Dictionary<Transform, int>();
            for (int i = 0; i < bones.Length; i++) if (bones[i] != null && !index.ContainsKey(bones[i])) index.Add(bones[i], i);
            var fingers = new List<FingerPose>();
            for (int i = 0; i < bones.Length; i++)
            {
                var bone = bones[i];
                if (bone == null || !bone.name.StartsWith("CATRig", StringComparison.Ordinal)) continue;
                string suffix = bone.name.Substring(6);
                if (!suffix.StartsWith("RArmDigit", StringComparison.Ordinal) &&
                    !suffix.StartsWith("LArmDigit", StringComparison.Ordinal)) continue;
                int parentIndex;
                if (bone.parent == null || !index.TryGetValue(bone.parent, out parentIndex)) continue;
                var localBind = bind[parentIndex] * bind[i].inverse;
                Vector3 x = localBind.GetColumn(0), y = localBind.GetColumn(1), z = localBind.GetColumn(2);
                if (x.sqrMagnitude < .5f || y.sqrMagnitude < .5f || z.sqrMagnitude < .5f) continue;
                x.Normalize(); y.Normalize(); z.Normalize();
                if (Mathf.Abs(Vector3.Dot(x, y)) > .01f || Mathf.Abs(Vector3.Dot(x, z)) > .01f ||
                    Mathf.Abs(Vector3.Dot(y, z)) > .01f || Vector3.Dot(Vector3.Cross(x, y), z) < .99f) continue;
                var rest = Quaternion.LookRotation(z, y);
                if (Finite(rest) && Finite(bone.localRotation)) fingers.Add(new FingerPose
                    { Suffix = suffix, LocalRest = rest, LocalPose = bone.localRotation });
            }
            return fingers.ToArray();
        }

        private static FingerBase[] CaptureBases(Transform palm, bool left)
        {
            if (palm == null) return new FingerBase[0];
            var bases = new List<FingerBase>();
            string side = left ? "LArmDigit" : "RArmDigit";
            foreach (var bone in palm.GetComponentsInChildren<Transform>(true))
            {
                if (bone.parent != palm) continue;
                string suffix = null;
                for (int digit = 1; digit <= 5; digit++)
                {
                    string candidate = side + digit + "1";
                    if (bone.name.EndsWith(candidate, StringComparison.Ordinal)) { suffix = candidate; break; }
                }
                if (suffix == null) continue;
                var position = palm.InverseTransformPoint(bone.position);
                if (Finite(position)) bases.Add(new FingerBase { Suffix = suffix, Position = position });
            }
            return bases.ToArray();
        }

        private static bool TryFrame(FingerBase[] bases, out PalmFrame frame)
        {
            frame = new PalmFrame();
            if (bases == null) return false;
            Vector3 index = Vector3.zero, middle = Vector3.zero, ring = Vector3.zero, little = Vector3.zero;
            int found = 0;
            foreach (var finger in bases)
            {
                if (finger.Suffix.EndsWith("21", StringComparison.Ordinal)) { index = finger.Position; found |= 1; }
                if (finger.Suffix.EndsWith("31", StringComparison.Ordinal)) { middle = finger.Position; found |= 2; }
                if (finger.Suffix.EndsWith("41", StringComparison.Ordinal)) { ring = finger.Position; found |= 4; }
                if (finger.Suffix.EndsWith("51", StringComparison.Ordinal)) { little = finger.Position; found |= 8; }
            }
            if (found != 15) return false;
            Vector3 center = (index + middle + ring + little) * .25f;
            Vector3 distal = center.normalized;
            Vector3 lateral = little - index;
            lateral -= Vector3.Dot(lateral, distal) * distal;
            if (!Finite(center) || center.sqrMagnitude < .0001f || lateral.sqrMagnitude < .0001f) return false;
            lateral.Normalize();
            var up = Vector3.Cross(lateral, distal).normalized;
            var rotation = Quaternion.LookRotation(lateral, up);
            if (!Finite(rotation)) return false;
            frame.Center = center;
            frame.Rotation = rotation;
            frame.Width = (little - index).magnitude;
            return true;
        }

        internal static bool CaptureTargetFrame(Transform targetPalm, out PalmFrame frame)
        {
            frame = new PalmFrame();
            if (targetPalm == null) return false;
            bool left = targetPalm.name.IndexOf("LArmPalm", StringComparison.Ordinal) >= 0;
            return TryFrame(CaptureBases(targetPalm, left), out frame);
        }

        // Map CAT-palm local space into NPC-palm local space (2.7.0: scaled about the palm by `scale`, the avatar's
        // hand against the native one). The returned transform is the native geometry's local pose (with that uniform
        // scale) when parented beneath the NPC palm.
        internal static bool FitPalm(PalmFrame source, PalmFrame target, float scale,
            out Vector3 translation, out Quaternion rotation)
        {
            rotation = target.Rotation * Quaternion.Inverse(source.Rotation);
            translation = target.Center - rotation * (source.Center * scale);
            return Finite(translation) && Finite(rotation);
        }

        // 2.7.0: a closed fist for what has no first-person hand of its own (a bottle, food, a bandage roll): the
        // finger curl of the local player's own hammer at its idle frame, captured once from a script-free copy.
        private static FingerPose[] _fist;
        private static bool _fistTried;
        internal static bool TryFist(out FingerPose[] fingers)
        {
            fingers = _fist;
            if (_fist != null || _fistTried) return _fist != null;
            var manager = GlobalManager.global;
            var character = manager == null ? null : manager.controlledChar;
            var guns = character == null || character.zombieFighterFireArmWeapon == null ? null : character.zombieFighterFireArmWeapon.gunList;
            if (guns == null) return false;
            _fistTried = true;
            Gun hammer = null;
            foreach (var gun in guns) if (gun != null && gun.ID == "Hammer") { hammer = gun; break; }
            var animator = hammer == null ? null : hammer.GetComponent<Animator>();
            var idle = animator == null ? null : Idle(animator.runtimeAnimatorController);
            if (idle == null) return false;
            GameObject shelter = null;
            try
            {
                shelter = new GameObject("LAN native fist sample");
                shelter.SetActive(false);
                var clone = Object.Instantiate(hammer.gameObject, shelter.transform, false);
                clone.SetActive(false);
                var cloneAnimator = clone.GetComponent<Animator>();
                if (cloneAnimator != null) cloneAnimator.enabled = false;
                foreach (var script in clone.GetComponentsInChildren<MonoBehaviour>(true))
                    if (script != null) Object.DestroyImmediate(script);
                idle.SampleAnimation(clone, 0f);
                var captured = CaptureFingers(clone.transform);
                if (captured.Length != 0) _fist = captured;
            }
            catch (Exception) { _fist = null; }
            finally { if (shelter != null) Object.DestroyImmediate(shelter); }
            fingers = _fist;
            return _fist != null;
        }

        private static bool Valid(float value) { return !float.IsNaN(value) && !float.IsInfinity(value); }
        private static bool Finite(Vector3 v) { return Valid(v.x) && Valid(v.y) && Valid(v.z); }
        private static bool Finite(Quaternion q) { return Valid(q.x) && Valid(q.y) && Valid(q.z) && Valid(q.w); }
    }
}
