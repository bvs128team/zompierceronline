using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
using Zompiercer.Animals;
using Zompiercer.Interfaces;
using Zompiercer.Inventory;
using Object = UnityEngine.Object;

namespace ZompiercerLAN
{
    // 2.8.0 (game 22.0): the animals of the host's world, beside its zombies. The host's animals are the game's own (AnimalSpawner
    // makes them, AnimalAIController drives them); a guest's own world makes none (its spawners and animals are switched off) and
    // shows copies of the host's near it (AnimalState): their animation, voice, steps and blood trail. A guest's shot or blow at a
    // copy is a hit claim the host stands by, as at a zombie; its rounds, blows and noise make the host's animal take that guest
    // for its enemy, and the host's animals notice, chase and bite the guests through a stand-in per guest (LanAnimalTarget). A
    // carcass is cut and a live chicken caught through the host (LanWorldWork: work kinds Butcher and Catch).
    internal sealed partial class ZombieSync
    {
        internal static string AnimalFailure { get; private set; }
        private const float AnimalRange=150f, AnimalNearRange=15f;
        private const int AnimalNearCount=4;

        // ---- Host ----
        // Voice and Steps: the animal's own sources; *Clip the last clip each played (its prefab's clips' index + 1), *Count how
        // many each started; Animation the last state its animator ran (a carcass shows it at its end).
        private sealed class HostAnimal
        {
            internal AnimalAIController AI; internal uint Id; internal string Prefab; internal AnimalPartDetector[] Parts;
            internal Animator Animator; internal CollectedResource Resource; internal AudioSource Voice, Steps; internal AudioClip[] Clips;
            internal AnimalFrame Last; internal float LastAlive; internal int Animation;
            internal byte VoiceClip, VoiceCount, StepsClip, StepsCount; internal bool Bleeding;
            internal int Sensed=-1; // the guest (slot) its detector takes for its enemy now, or -1
        }
        // A guest as the host's animals see it: its stand-in, and its own numbering of animal batches and turn.
        private sealed class AnimalSeat { internal int Slot; internal GameObject Target; internal uint Sequence; internal int Cursor; }
        private readonly Dictionary<int,HostAnimal> _animalIds=new Dictionary<int,HostAnimal>();
        private readonly List<HostAnimal> _animals=new List<HostAnimal>();
        private readonly Dictionary<int,AnimalSeat> _animalSeats=new Dictionary<int,AnimalSeat>();
        private float _animalScanAt,_animalSendAt,_animalSenseAt;
        private int _sentAnimals,_receivedAnimals,_createdAnimals;

        // ---- Guest ----
        // The copy's sounds (its prefab's two sources), its carcass stand-in (the prefab's CollectedResource, with its colliders,
        // that the game's knife meets: LanWorldWork sends the cut to the host), its blood trail, what catching it gives.
        private sealed class AnimalVisual
        {
            internal AudioSource Voice, Steps; internal AudioClip[] Clips; internal byte VoiceCount, StepsCount; internal bool CountsSeen;
            internal GameObject Carcass; internal CollectedResource Resource;
            internal AnimalBaseSO Settings; internal Transform BloodPoint; internal int BloodMask; internal float BloodAt; internal bool Bleeding;
            internal int Item=-1, ItemAmount; internal bool Butcher, Catch, Frozen;
            internal bool ParamsKnown, HasSpeed, HasIdle; internal int[] Bools;
        }
        private readonly Dictionary<uint,Replica> _animalReplicas=new Dictionary<uint,Replica>();
        private readonly Dictionary<string,GameObject> _animalPrefabs=new Dictionary<string,GameObject>(StringComparer.Ordinal);
        private readonly uint[] _animalSeen=new uint[LanProtocol.MaxAnimalIds+1];
        private readonly bool[] _animalGone=new bool[LanProtocol.MaxAnimalIds+1];
        private float _animalCatalogAt=-100f, _catchAt;

        // The game's own members the animals need (a missing one leaves the animals out: AnimalFailure).
        private static AccessTools.FieldRef<AnimalSpawner,GameObject> _spawnerPrefab;
        private static AccessTools.FieldRef<AnimalAIController,AudioSource> _animalVoice, _animalSteps;
        private static AccessTools.FieldRef<AnimalAIController,TrailOfBlood> _animalTrail;
        private static AccessTools.FieldRef<AnimalEnemyDetector,bool> _detectorActive, _detectorPlayer;
        private static AccessTools.FieldRef<AnimalEnemyDetector,float> _detectorRadius;
        private static AccessTools.FieldRef<AnimalEnemyDetector,LayerMask> _detectorMask;
        private static AccessTools.FieldRef<TrailOfBlood,LayerMask> _trailMask;
        private static AccessTools.FieldRef<Zompiercer.Animals.AnimationEvent,AnimalAIController> _eventController;
        private static AccessTools.FieldRef<CollectedResource,CollectedResource.TakableResource[]> _takables;
        private static Harmony _animalHooks;

        private static void InstallAnimals()
        {
            if(_animalHooks!=null || AnimalFailure!=null) return;
            var harmony=new Harmony("local.zompiercer.lan.animals");
            try {
                _spawnerPrefab=AccessTools.FieldRefAccess<AnimalSpawner,GameObject>("animalPrefab");
                _animalVoice=AccessTools.FieldRefAccess<AnimalAIController,AudioSource>("audioSource");
                _animalSteps=AccessTools.FieldRefAccess<AnimalAIController,AudioSource>("audioSourceSteps");
                _animalTrail=AccessTools.FieldRefAccess<AnimalAIController,TrailOfBlood>("trailOfBloodRayPoint");
                _detectorActive=AccessTools.FieldRefAccess<AnimalEnemyDetector,bool>("_isActive");
                _detectorPlayer=AccessTools.FieldRefAccess<AnimalEnemyDetector,bool>("_playerInZone");
                _detectorRadius=AccessTools.FieldRefAccess<AnimalEnemyDetector,float>("_lastRadius");
                _detectorMask=AccessTools.FieldRefAccess<AnimalEnemyDetector,LayerMask>("layerMask");
                _trailMask=AccessTools.FieldRefAccess<TrailOfBlood,LayerMask>("layerMask");
                _eventController=AccessTools.FieldRefAccess<Zompiercer.Animals.AnimationEvent,AnimalAIController>("controller");
                _takables=AccessTools.FieldRefAccess<CollectedResource,CollectedResource.TakableResource[]>("takableResources");
                // Guest: its own world's spawners make no animals, its animals never run.
                foreach(var method in new[]{"LateStart","Load","OnOneSecondTime"}) AnimalPatch(harmony,typeof(AnimalSpawner),method,nameof(AllowNative));
                foreach(var method in new[]{"Start","InvokeStart","Update"}) AnimalPatch(harmony,typeof(AnimalAIController),method,nameof(ClientAnimal));
                AnimalPatch(harmony,typeof(FlockController),"Update",nameof(AllowNative));
                // Host: what its animals sound like and whether they bleed, for the guests' copies.
                harmony.Patch(AccessTools.Method(typeof(AnimalAIController),"PlaySound"),postfix:new HarmonyMethod(typeof(ZombieSync),nameof(AfterAnimalVoice)));
                harmony.Patch(AccessTools.Method(typeof(AnimalAIController),"PlaySoundSteps"),postfix:new HarmonyMethod(typeof(ZombieSync),nameof(AfterAnimalSteps)));
                harmony.Patch(AccessTools.Method(typeof(AnimalAIController),"SetBloodLose"),postfix:new HarmonyMethod(typeof(ZombieSync),nameof(AfterAnimalBleeding)));
                // Host: a bite of an animal chasing a guest lands on that guest; a guest's round, blow or noise is that guest's.
                AnimalPatch(harmony,typeof(Zompiercer.Animals.AnimationEvent),"OnHit",nameof(BeforeAnimalBite));
                AnimalPatch(harmony,typeof(AnimalHP),"CauseDamage",nameof(BeforeAnimalDamage));
                AnimalPatch(harmony,typeof(AnimalAIController),"OnEnemyDetectedDelay",nameof(BeforeAnimalNoise));
                harmony.Patch(AccessTools.Method(typeof(BulletScript),"BulletContact"),new HarmonyMethod(typeof(ZombieSync),nameof(BeforeGuestRound)),new HarmonyMethod(typeof(ZombieSync),nameof(AfterGuestRound)));
                _animalHooks=harmony;
            }
            catch(Exception ex) { harmony.UnpatchSelf(); AnimalFailure=ex.GetType().Name+": "+ex.Message; }
        }
        private static void AnimalPatch(Harmony h,Type type,string method,string prefix) { h.Patch(AccessTools.Method(type,method),new HarmonyMethod(typeof(ZombieSync),prefix)); }
        private static bool ClientAnimal(AnimalAIController __instance) { if(!IsClientWorld) return true; __instance.gameObject.SetActive(false); return false; }

        // ---- Host: the guests' stand-ins ----
        private void AddAnimalSeat(int slot)
        {
            RemoveAnimalSeat(slot);
            var target=new GameObject("LAN remote animal target "+slot); Object.DontDestroyOnLoad(target);
            var stand=target.AddComponent<LanAnimalTarget>(); stand.Slot=slot; stand.Owner=this;
            _animalSeats[slot]=new AnimalSeat {Slot=slot,Target=target};
        }
        private void RemoveAnimalSeat(int slot)
        {
            AnimalSeat seat;
            if(!_animalSeats.TryGetValue(slot,out seat)) return;
            ReleaseAnimals(seat);
            _animalSeats.Remove(slot);
            if(seat.Target!=null) Object.Destroy(seat.Target);
        }
        // The host's animals let go of this guest before its stand-in goes (their AI would chase a destroyed object): a flock goes
        // home (FlockController.SetTarget(null), each one back to its place), a single animal forgets it and goes back too.
        private void ReleaseAnimals(AnimalSeat seat)
        {
            if(seat==null || seat.Target==null) return;
            foreach(var h in _animals) {
                var ai=h.AI;
                if(h.Sensed==seat.Slot) h.Sensed=-1;
                if(ai==null || ai.IsDead || ai.Target!=seat.Target) continue;
                try {
                    var flock=ai.ParentSpawner==null?null:ai.ParentSpawner.FlockController;
                    if(flock!=null && flock.GetTarget()==seat.Target) flock.SetTarget(null);
                    ai.OnEnemyDetected(false);
                    ai.SetState(EAnimalState.Return);
                }
                catch(Exception ex) { AnimalReport("Animal not released: "+ex.GetType().Name+": "+ex.Message); }
            }
        }
        private GameObject SeatTarget(int slot) { AnimalSeat seat; return _animalSeats.TryGetValue(slot,out seat)?seat.Target:null; }
        internal bool GuestAlive(int slot) { Remote r; return _ready && _remotes.TryGetValue(slot,out r) && r.Usable; }

        // ---- Host: every frame ----
        private void TickHostAnimals(float now)
        {
            if(AnimalFailure!=null) return;
            foreach(var seat in _animalSeats.Values) {
                Remote r;
                if(seat.Target!=null && _remotes.TryGetValue(seat.Slot,out r)) seat.Target.transform.position=r.Position;
            }
            ScanAnimals(now);
            SenseGuests(now);
            if(now>=_animalSendAt) {
                _animalSendAt=now+.05f;
                foreach(var seat in _animalSeats.Values) { Remote r; if(_remotes.TryGetValue(seat.Slot,out r) && r.Ready) SendAnimals(r,seat,now); }
            }
        }
        private void ScanAnimals(float now)
        {
            if(now<_animalScanAt) return;
            _animalScanAt=now+.5f;
            foreach(var ai in Object.FindObjectsOfType<AnimalAIController>()) {
                if(_animals.Count>=LanProtocol.MaxAnimalIds || _animalIds.ContainsKey(ai.GetInstanceID())) continue;
                string prefab=AnimalPrefabName(ai); if(prefab==null) continue;
                var h=new HostAnimal {AI=ai,Id=(uint)_animals.Count+1,Prefab=prefab,LastAlive=now,Parts=ai.GetComponentsInChildren<AnimalPartDetector>(true),
                    Animator=VisualAnimator(ai),Resource=ai.ResourceObject==null?null:ai.ResourceObject.GetComponent<CollectedResource>(),
                    Voice=_animalVoice(ai),Steps=_animalSteps(ai),Clips=AnimalClips(ai.AnimalBaseSo)};
                _animals.Add(h); _animalIds.Add(ai.GetInstanceID(),h);
            }
        }
        // The name of the prefab its spawner makes (the same in every world of this scene); none: not shown to the guests.
        private static string AnimalPrefabName(AnimalAIController ai)
        {
            var spawner=ai.ParentSpawner; var prefab=spawner==null?null:_spawnerPrefab(spawner);
            if(prefab==null) return null;
            string name=prefab.name;
            if(string.IsNullOrEmpty(name) || System.Text.Encoding.UTF8.GetByteCount(name)>64) return null;
            foreach(char c in name) if(c<0x20 || c==0x7F) return null;
            return name;
        }
        // Every clip of its settings (AnimalBaseSO: its voices, steps, roars, death), in the order of its fields; the same on
        // every side for the same settings. A sound is sent as its place here + 1.
        private static readonly Dictionary<AnimalBaseSO,AudioClip[]> _clips=new Dictionary<AnimalBaseSO,AudioClip[]>();
        private static AudioClip[] AnimalClips(AnimalBaseSO settings)
        {
            AudioClip[] clips;
            if(settings==null) return new AudioClip[0];
            if(_clips.TryGetValue(settings,out clips)) return clips;
            var list=new List<AudioClip>();
            foreach(var field in typeof(AnimalBaseSO).GetFields(BindingFlags.Instance|BindingFlags.Public|BindingFlags.NonPublic)) {
                if(field.FieldType==typeof(AudioClip)) { var clip=field.GetValue(settings) as AudioClip; if(clip!=null && !list.Contains(clip)) list.Add(clip); }
                else if(field.FieldType==typeof(AudioClip[])) { var many=field.GetValue(settings) as AudioClip[]; if(many!=null) foreach(var clip in many) if(clip!=null && !list.Contains(clip)) list.Add(clip); }
                if(list.Count>=LanProtocol.MaxAnimalClips) break;
            }
            clips=list.ToArray(); if(_clips.Count<64) _clips[settings]=clips;
            return clips;
        }
        private static byte ClipIndex(AudioClip[] clips,AudioClip clip)
        {
            if(clips==null || clip==null) return 0;
            for(int i=0;i<clips.Length && i<LanProtocol.MaxAnimalClips;i++) if(clips[i]==clip) return (byte)(i+1);
            return 0;
        }
        private static void AfterAnimalVoice(AnimalAIController __instance,AudioClip clip) { var a=Active; if(a!=null) a.AnimalSound(__instance,clip,false); }
        private static void AfterAnimalSteps(AnimalAIController __instance,AudioClip clip) { var a=Active; if(a!=null) a.AnimalSound(__instance,clip,true); }
        private void AnimalSound(AnimalAIController ai,AudioClip clip,bool steps)
        {
            HostAnimal h;
            if(!_host || ai==null || !_animalIds.TryGetValue(ai.GetInstanceID(),out h)) return;
            byte index=ClipIndex(h.Clips,clip); if(index==0) return;
            if(steps) { h.StepsClip=index; h.StepsCount++; } else { h.VoiceClip=index; h.VoiceCount++; }
        }
        private static void AfterAnimalBleeding(AnimalAIController __instance,bool active)
        {
            var a=Active; HostAnimal h;
            if(a!=null && a._host && __instance!=null && a._animalIds.TryGetValue(__instance.GetInstanceID(),out h)) h.Bleeding=active && _animalTrail(__instance)!=null;
        }

        // The animals near this guest (within AnimalRange), the nearest first: those within AnimalNearRange in every batch (20 a
        // second), the others by turns in the rest, as the zombies' (SendBatch); one gone lately is said gone a while.
        private void SendAnimals(Remote to,AnimalSeat seat,float now)
        {
            var relevant=new List<HostAnimal>();
            foreach(var h in _animals) {
                bool live=h.AI!=null && h.AI.gameObject.activeInHierarchy;
                if(!live && (h.Last==null || now-h.LastAlive>=12)) continue;
                var at=live?h.AI.transform.position:new Vector3(h.Last.X,h.Last.Y,h.Last.Z);
                if((at-to.Position).sqrMagnitude<=AnimalRange*AnimalRange) relevant.Add(h);
            }
            if(relevant.Count==0) return;
            relevant.Sort((a,b)=>AnimalDistance(a,to).CompareTo(AnimalDistance(b,to)));
            if(relevant.Count>LanProtocol.MaxAnimalReplicas) relevant.RemoveRange(LanProtocol.MaxAnimalReplicas,relevant.Count-LanProtocol.MaxAnimalReplicas);
            var batch=new List<AnimalFrame>(); var near=new List<HostAnimal>();
            foreach(var h in relevant) {
                if(near.Count>=AnimalNearCount) break;
                if(h.AI!=null && h.AI.gameObject.activeInHierarchy && AnimalDistance(h,to)<=AnimalNearRange*AnimalNearRange) near.Add(h);
            }
            foreach(var h in near) AddAnimalFrame(batch,h,now);
            int visited=0;
            while(visited++<relevant.Count && batch.Count<LanProtocol.MaxAnimalBatch) {
                if(seat.Cursor>=relevant.Count) seat.Cursor=0;
                var h=relevant[seat.Cursor++];
                if(!near.Contains(h)) AddAnimalFrame(batch,h,now);
            }
            if(batch.Count==0) return;
            var packet=Message(PacketKind.AnimalState,++seat.Sequence); packet.Animals=batch.ToArray(); packet.HostTime=Time.unscaledTime;
            to.Send(packet); _sentAnimals+=batch.Count;
        }
        private static float AnimalDistance(HostAnimal h,Remote to)
        {
            var at=h.AI!=null?h.AI.transform.position:new Vector3(h.Last.X,h.Last.Y,h.Last.Z);
            return (at-to.Position).sqrMagnitude;
        }
        private void AddAnimalFrame(List<AnimalFrame> batch,HostAnimal h,float now)
        {
            var ai=h.AI;
            if(ai!=null && ai.gameObject.activeInHierarchy) {
                var p=ai.transform.position;
                var f=new AnimalFrame {Id=h.Id,Prefab=h.Prefab,X=p.x,Y=p.y,Z=p.z,Yaw=Mathf.Repeat(ai.transform.eulerAngles.y,360f)%360f};
                int flags=ai.IsDead?1:0;
                if(!ai.IsDead && h.Bleeding) flags|=LanProtocol.AnimalBleeding;
                if(ai.IsDead && Butcherable(h)) flags|=LanProtocol.AnimalButcher;
                if(!ai.IsDead && Catchable(ai)) flags|=LanProtocol.AnimalCatch;
                f.Flags=(byte)flags;
                var anim=h.Animator;
                if(anim!=null && anim.enabled && anim.isInitialized && anim.runtimeAnimatorController!=null) {
                    var state=anim.GetCurrentAnimatorStateInfo(0);
                    h.Animation=state.fullPathHash; f.Animation=state.fullPathHash;
                    f.AnimationTime=state.loop?Mathf.Repeat(state.normalizedTime,1):Mathf.Clamp01(state.normalizedTime);
                    var parameters=AnimalParameters(anim);
                    if(parameters.Speed) f.Speed=Mathf.Clamp(anim.GetFloat(AnimalBaseSO.SPEED),-100f,100f);
                    if(parameters.Idle) f.Idle=(sbyte)Mathf.Clamp(anim.GetInteger(AnimalBaseSO.IDLE_INDEX),-128,127);
                    int bools=0; for(int i=0;i<parameters.Bools.Length;i++) if(anim.GetBool(parameters.Bools[i])) bools|=1<<i;
                    f.Bools=(byte)bools;
                } else { f.Animation=h.Animation; f.AnimationTime=1f; } // a carcass lies as its death ended (DieEnd stops its animator)
                f.Voice=h.VoiceClip; f.VoiceCount=h.VoiceCount; f.Steps=h.StepsClip; f.StepsCount=h.StepsCount;
                int loops=0;
                if(h.Voice!=null && h.Voice.loop && h.Voice.isPlaying) { byte clip=ClipIndex(h.Clips,h.Voice.clip); if(clip!=0) { f.Voice=clip; loops|=LanProtocol.AnimalVoiceLoop; } }
                if(h.Steps!=null && h.Steps.loop && h.Steps.isPlaying) { byte clip=ClipIndex(h.Clips,h.Steps.clip); if(clip!=0) { f.Steps=clip; loops|=LanProtocol.AnimalStepsLoop; } }
                f.Loops=(byte)loops;
                if((flags&LanProtocol.AnimalButcher)!=0) f.Left=Left(h.Resource);
                if(!LanProtocol.ValidAnimal(f)) return;
                h.Last=f; h.LastAlive=now; batch.Add(f);
            } else if(h.Last!=null && now-h.LastAlive<12) {
                batch.Add(new AnimalFrame {Id=h.Id,Prefab=h.Prefab,X=h.Last.X,Y=h.Last.Y,Z=h.Last.Z,Yaw=h.Last.Yaw,Flags=2});
            }
        }
        private static bool Butcherable(HostAnimal h)
        {
            var r=h.Resource;
            return r!=null && r.gameObject.activeInHierarchy && r.IsCanUse && r.UseForButchering();
        }
        private static bool Catchable(AnimalAIController ai)
        {
            var takable=ai.TakableComponent;
            return takable!=null && takable.enabled && takable.amount>0;
        }
        // What the carcass still gives of each of its resources (the game's hint on it lists them).
        private static byte[] Left(CollectedResource r)
        {
            if(r==null) return null;
            if(!r.UseNewSystem) return new[] {(byte)Mathf.Clamp(r.resourceQuantity,0,255)};
            var list=_takables(r); if(list==null || list.Length==0) return null;
            var left=new byte[Math.Min(list.Length,LanProtocol.MaxAnimalLeft)];
            for(int i=0;i<left.Length;i++) left[i]=(byte)Mathf.Clamp(list[i].resourceQuantity,0,255);
            return left;
        }
        // An animator's "speed" and "idleIndex" and its bool parameters (at most 8), by controller.
        private sealed class AnimalParams { internal bool Speed, Idle; internal int[] Bools; }
        private static readonly Dictionary<RuntimeAnimatorController,AnimalParams> _animalParams=new Dictionary<RuntimeAnimatorController,AnimalParams>();
        private static AnimalParams AnimalParameters(Animator animator)
        {
            AnimalParams found; var controller=animator.runtimeAnimatorController;
            if(controller!=null && _animalParams.TryGetValue(controller,out found)) return found;
            found=new AnimalParams(); var bools=new List<int>();
            foreach(var parameter in animator.parameters) {
                if(parameter.nameHash==AnimalBaseSO.SPEED && parameter.type==AnimatorControllerParameterType.Float) found.Speed=true;
                else if(parameter.nameHash==AnimalBaseSO.IDLE_INDEX && parameter.type==AnimatorControllerParameterType.Int) found.Idle=true;
                else if(parameter.type==AnimatorControllerParameterType.Bool && bools.Count<8) bools.Add(parameter.nameHash);
            }
            found.Bools=bools.ToArray();
            if(controller!=null && _animalParams.Count<64) _animalParams[controller]=found;
            return found;
        }

        // ---- Host: the guests the animals notice ----
        // As the game's AnimalEnemyDetector does for its own player (OnTriggerStay): a guest inside its sphere (in its chase the
        // larger RadiusDetectorFollow), seen along a clear line (the detector's own layers), alive. The nearest such guest is its
        // enemy unless the host's own player is nearer in its sphere (the game's trigger has the host then); a guest it had that
        // left the sphere is let go (OnTriggerExit's OnEnemyDetected(false)).
        private void SenseGuests(float now)
        {
            if(now<_animalSenseAt || _animalSeats.Count==0) return;
            _animalSenseAt=now+.2f;
            var local=LocalPlayer();
            foreach(var h in _animals) {
                var ai=h.AI;
                if(ai==null || !ai.gameObject.activeInHierarchy || ai.IsDead) { h.Sensed=-1; continue; }
                var detector=ai.EnemyDetector;
                if(detector==null || !_detectorActive(detector) || ai.AnimalBaseSo==null) { Lose(h); continue; }
                var state=ai.CurrentStateSo;
                float radius=ai.AnimalBaseSo.CanBeAngry && state!=null && state.State==EAnimalState.Follow ? ai.AnimalBaseSo.RadiusDetectorFollow : _detectorRadius(detector);
                var scale=detector.transform.lossyScale; radius*=Mathf.Max(Mathf.Abs(scale.x),Mathf.Abs(scale.y),Mathf.Abs(scale.z));
                var at=detector.Position; int mask=_detectorMask(detector).value;
                AnimalSeat best=null; float bestDistance=radius;
                foreach(var seat in _animalSeats.Values) {
                    Remote r;
                    if(seat.Target==null || !_remotes.TryGetValue(seat.Slot,out r) || !r.Usable) continue;
                    var body=r.Position+Vector3.up; var way=body-at; float d=way.magnitude;
                    if(d>bestDistance) continue;
                    // short of the guest's own avatar, which may stand on the detector's layers here
                    if(d>.6f && Physics.Raycast(at,way/d,d-.5f,mask,QueryTriggerInteraction.Ignore)) continue;
                    best=seat; bestDistance=d;
                }
                if(best==null) { Lose(h); continue; }
                if(local!=null && local.GetIsAlive() && _detectorPlayer(detector) && Vector3.Distance(at,local.transform.position+Vector3.up)<bestDistance) { Lose(h); continue; }
                h.Sensed=best.Slot;
                try { ai.OnEnemyDetected(true,best.Target); }
                catch(Exception ex) { AnimalReport("Animal did not notice a guest: "+ex.GetType().Name+": "+ex.Message); }
            }
        }
        private void Lose(HostAnimal h)
        {
            if(h.Sensed<0) return;
            var target=SeatTarget(h.Sensed); h.Sensed=-1;
            var ai=h.AI;
            if(ai==null || ai.IsDead || target==null || ai.Target!=target) return;
            try { ai.OnEnemyDetected(false); }
            catch(Exception ex) { AnimalReport("Animal did not let a guest go: "+ex.GetType().Name+": "+ex.Message); }
        }

        // Host: the bite of an animal whose enemy is a guest (the game's AnimationEvent.OnHit at the bite's moment): the guest
        // is hurt when its body is within the attack's reach of the jaws (the attack state's AttackRadius, as the game's sphere
        // there meets its own player's collider); the game's own bite (its sphere, the host's player) is not run for a guest.
        private static bool BeforeAnimalBite(Zompiercer.Animals.AnimationEvent __instance)
        {
            var a=Active;
            if(a==null || !a._host || IsClientWorld || __instance==null) return true;
            var ai=_eventController(__instance); var target=ai==null?null:ai.Target;
            var stand=target==null?null:target.GetComponent<LanAnimalTarget>();
            if(stand==null) return true;
            a.AnimalBite(ai,stand.Slot);
            return false;
        }
        private void AnimalBite(AnimalAIController ai,int slot)
        {
            Remote r;
            if(!_ready || ai==null || ai.IsDead || ai.AnimalBaseSo==null || !_remotes.TryGetValue(slot,out r) || !r.Usable) return;
            var jaws=ai.HitPointTransform!=null?ai.HitPointTransform.position:ai.transform.position;
            if(SegmentDistance(jaws,r.Position+Vector3.up*.2f,r.Position+Vector3.up*1.7f)>AttackRadius(ai)+.45f) return;
            float damage=ai.AnimalBaseSo.Damage;
            if(!(damage>0) || float.IsInfinity(damage) || r.Hurts.Count>=64) return;
            var hurt=Message(PacketKind.ZombieHurt,++r.HurtSequence);
            hurt.Action=LanProtocol.HurtAnimal; hurt.Damage=Mathf.Min(1000,damage); hurt.Text="";
            r.Hurts.Enqueue(hurt);
        }
        private static readonly Dictionary<Type,PropertyInfo> _attackRadius=new Dictionary<Type,PropertyInfo>();
        private static float AttackRadius(AnimalAIController ai)
        {
            var so=ai.AttackStateSo; if(so==null) return 1.2f;
            PropertyInfo property; var type=so.GetType();
            if(!_attackRadius.TryGetValue(type,out property)) { property=AccessTools.Property(type,"AttackRadius"); _attackRadius[type]=property; }
            try { float radius=property==null?1.2f:Convert.ToSingle(property.GetValue(so,null)); return float.IsNaN(radius)?1.2f:Mathf.Clamp(radius,.2f,5f); }
            catch(Exception) { return 1.2f; }
        }
        private static float SegmentDistance(Vector3 p,Vector3 a,Vector3 b)
        {
            var ab=b-a; float t=Mathf.Clamp01(Vector3.Dot(p-a,ab)/Mathf.Max(1e-6f,ab.sqrMagnitude));
            return Vector3.Distance(p,a+ab*t);
        }

        // Host: the guest whose round (a native round the host fires for it), blow or shot's noise reaches the animals now; the game
        // names its own player as the attacker (BulletScript, Gun.MeleeHitTarget, Gun.AttractByNoise), and the animal turns on that
        // guest's stand-in instead.
        private static GameObject _animalAttacker;
        private static Remote _firingFor;
        private static readonly Dictionary<int,int> _guestRounds=new Dictionary<int,int>();
        private static void GuestRound(Component round)
        {
            var by=_firingFor; if(by==null || round==null) return;
            if(_guestRounds.Count>512) _guestRounds.Clear();
            _guestRounds[round.GetInstanceID()]=by.Slot;
        }
        private static void BeforeGuestRound(BulletScript __instance)
        {
            var a=Active; int slot;
            if(a!=null && a._host && __instance!=null && _guestRounds.TryGetValue(__instance.GetInstanceID(),out slot)) _animalAttacker=a.SeatTarget(slot);
        }
        private static void AfterGuestRound() { _animalAttacker=null; }
        private static void BeforeAnimalDamage(ref GameObject target) { Attacker(ref target); }
        private static void BeforeAnimalNoise(ref GameObject target) { Attacker(ref target); }
        private static void Attacker(ref GameObject target)
        {
            var by=_animalAttacker; var player=LocalPlayer();
            if(by!=null && (target==null || player!=null && target==player.gameObject)) target=by;
        }
        // Host: a guest's claimed blow or arrow on an animal's part here, as the game's own: a blow (Gun.MeleeHitTarget) a wound and
        // blood, its body-hit sound and the damage over the world's zombie health factor to the whole animal; an arrow
        // (BulletScript.BulletContact) the part's own share. A carcass takes no more.
        private void AnimalStrike(Remote r,AnimalPartDetector part,RaycastHit hit,Gun gun,float damage,bool blow)
        {
            var health=part.AnimalHp;
            if(health==null || health.IsDead || health.Controller==null || !_animalIds.ContainsKey(health.Controller.GetInstanceID())) return;
            var target=SeatTarget(r.Slot);
            try {
                var effects=GlobalEffects.Global;
                if(effects!=null && effects.bloodHole!=null && effects.bloodHole.Length!=0) {
                    var hole=effects.bloodHole[UnityEngine.Random.Range(0,effects.bloodHole.Length)];
                    if(hole!=null) Object.Instantiate(hole,hit.point+hit.normal*.1f,Quaternion.LookRotation(-hit.normal)).parent=hit.transform;
                }
                if(effects!=null) effects.SpawnBloodDecal(hit.point,hit.normal,part.transform.position);
                if(blow && gun.meleeHitBodySound!=null) AudioSource.PlayClipAtPoint(gun.meleeHitBodySound,hit.point);
            }
            catch(Exception ex) { AnimalReport("Strike effects failed: "+ex.GetType().Name+": "+ex.Message); }
            if(blow) {
                float factor=DifficultyManager.Global==null?1f:Mathf.Max(.05f,DifficultyManager.Global.ZombieHP);
                health.CauseDamage(damage/factor,target,false);
            }
            else part.CauseDamage(damage,target);
        }
        // Host, 1.5.0's hit claim (Claimed) on an animal: a live animal the guest was shown, one of its parts, the guest's eye within
        // reach of where it saw the hit, no wall between, that place no farther from the part now than it moves in the guest's view
        // delay; then where the round or blade goes into that part's own hitbox here.
        private bool ClaimedAnimal(HitClaim c,Vector3 origin,float range,int mask,out Vector3 from,out Vector3 toward,out RaycastHit hit)
        {
            from=toward=Vector3.zero; hit=default(RaycastHit);
            var h=c.Zombie>=1 && c.Zombie<=_animals.Count?_animals[(int)c.Zombie-1]:null; var ai=h==null?null:h.AI;
            if(ai==null || ai.IsDead || !ai.gameObject.activeInHierarchy || h.Parts==null || c.Limb>=h.Parts.Length) { _claimRefused[0]++; return false; }
            var part=h.Parts[c.Limb];
            if(part==null || !part.gameObject.activeInHierarchy) { _claimRefused[0]++; return false; }
            var collider=part.GetComponent<Collider>();
            if(collider==null || !collider.enabled) { _claimRefused[0]++; return false; }
            var seen=new Vector3(c.WX,c.WY,c.WZ);
            if(Vector3.Distance(origin,seen)>range+.5f) { _claimRefused[1]++; return false; }
            if(Vector3.Distance(collider.bounds.center,seen)>ClaimSlack) { _claimRefused[2]++; return false; }
            if(Walled(origin,seen,mask)) { _claimRefused[3]++; return false; }
            var t=part.transform;
            toward=t.TransformVector(new Vector3(c.DX,c.DY,c.DZ));
            if(toward.sqrMagnitude<1e-8f || float.IsNaN(toward.x)) return false;
            toward.Normalize();
            bool aimed;
            if(!Entry(collider,t.TransformPoint(new Vector3(c.LX,c.LY,c.LZ)),ref toward,origin,out hit,out aimed)) { _claimRefused[4]++; return false; }
            if(aimed) _claimAimed++;
            from=hit.point-toward*.1f;
            return true;
        }

        // Host (LanWorldWork): the carcass of animal `id` that can be cut now, or null.
        internal static CollectedResource HostCarcass(int id)
        {
            var a=Active;
            if(a==null || !a._host || id<1 || id>a._animals.Count) return null;
            var h=a._animals[id-1];
            return h.AI!=null && h.AI.IsDead && Butcherable(h) ? h.Resource : null;
        }
        // Host (LanWorldWork): the guest at `guest` catches live animal `id` by hand, as the game's own catch (Inventory.Add of its
        // TakableAnimal: what it gives, then TakeAmount switches it off); a guest the animal ran from by more than a few metres
        // since it saw it misses.
        internal static byte HostCatch(int id,Vector3 guest,out int item,out int amount)
        {
            item=-1; amount=0; var a=Active;
            if(a==null || !a._host || id<1 || id>a._animals.Count) return LanStorage.NotFound;
            var ai=a._animals[id-1].AI;
            if(ai==null || !ai.gameObject.activeInHierarchy || ai.IsDead) return LanStorage.NotFound;
            var takable=ai.TakableComponent;
            if(takable==null || !takable.enabled || takable.amount<1) return LanStorage.NotAllowed;
            if(Vector3.Distance(ai.transform.position,guest)>5f) return LanStorage.TooFar;
            item=takable.itemID; amount=takable.amount;
            takable.TakeAmount(amount);
            return LanStorage.Ok;
        }
        // Whose resource this is: a copy's carcass (its host id), an animal's own (-1: not to gather as a flower), or none (0).
        internal static int AnimalOfResource(CollectedResource resource)
        {
            if(resource==null) return 0;
            var mark=resource.GetComponentInParent<LanAnimalCarcass>();
            if(mark!=null) return (int)mark.Id;
            return resource.GetComponentInParent<AnimalAIController>()!=null ? -1 : 0;
        }

        // ---- Guest ----
        // The prefabs the host's animals come from: what this scene's spawners make (switched off here), and any loaded.
        private void BuildAnimalCatalog()
        {
            float now=Time.unscaledTime;
            if(now<_animalCatalogAt || AnimalFailure!=null) return;
            _animalCatalogAt=now+5f;
            try {
                foreach(var spawner in Resources.FindObjectsOfTypeAll<AnimalSpawner>()) {
                    var prefab=spawner==null?null:_spawnerPrefab(spawner);
                    if(prefab!=null && prefab.GetComponent<AnimalAIController>()!=null && !_animalPrefabs.ContainsKey(prefab.name) && _animalPrefabs.Count<64) _animalPrefabs.Add(prefab.name,prefab);
                }
            }
            catch(Exception ex) { AnimalReport("Animal prefabs not found: "+ex.GetType().Name+": "+ex.Message); }
        }
        private void ReceiveAnimals(Packet p)
        {
            if(AnimalFailure!=null) return;
            BuildAnimalCatalog();
            Clock(p.HostTime);
            foreach(var f in p.Animals) ApplyAnimal(f,p.Sequence,p.HostTime);
        }
        private readonly HashSet<string> _unknownAnimals=new HashSet<string>(StringComparer.Ordinal);
        private readonly HashSet<string> _failedAnimals=new HashSet<string>(StringComparer.Ordinal);
        private void ApplyAnimal(AnimalFrame f,uint sequence,float hostTime)
        {
            if(f.Id==0 || f.Id>LanProtocol.MaxAnimalIds || _animalGone[f.Id] || (_animalSeen[f.Id]!=0 && !Newer(sequence,_animalSeen[f.Id]))) return;
            _animalSeen[f.Id]=sequence; _receivedAnimals++;
            Replica r; _animalReplicas.TryGetValue(f.Id,out r);
            int state=f.Flags&LanProtocol.AnimalStateBits;
            if(state==2) { _animalGone[f.Id]=true; if(r!=null) { if(r.Root!=null) Object.Destroy(r.Root); _animalReplicas.Remove(f.Id); } return; }
            if(r==null) {
                GameObject prefab;
                if(_animalReplicas.Count>=LanProtocol.MaxAnimalReplicas || _failedAnimals.Contains(f.Prefab)) return;
                if(!_animalPrefabs.TryGetValue(f.Prefab,out prefab) || prefab==null) {
                    if(_unknownAnimals.Count<64 && _unknownAnimals.Add(f.Prefab)) AnimalReport("Unknown animal model "+f.Prefab+"; catalog="+_animalPrefabs.Count);
                    return;
                }
                try { r=CreateAnimalVisual(prefab,f.Id); }
                catch(Exception ex) { _failedAnimals.Add(f.Prefab); AnimalReport("Animal model "+f.Prefab+" not made: "+ex.GetType().Name+": "+ex.Message); return; }
                r.Prefab=f.Prefab; _animalReplicas.Add(f.Id,r); _createdAnimals++;
                r.Root.transform.SetPositionAndRotation(new Vector3(f.X,f.Y,f.Z),Quaternion.Euler(0,f.Yaw,0));
            }
            if(r.Prefab!=f.Prefab) return;
            r.Position=new Vector3(f.X,f.Y,f.Z); r.Rotation=Quaternion.Euler(0,f.Yaw,0); r.Seen=Time.unscaledTime;
            r.Root.SetActive(true);
            bool dead=state==1;
            if(!dead) r.SeenAlive=true;
            else if(!r.Dead) AnimalKilled(r);
            r.Dead=dead;
            var b=r.Beast;
            b.Bleeding=!dead && (f.Flags&LanProtocol.AnimalBleeding)!=0;
            b.Catch=!dead && (f.Flags&LanProtocol.AnimalCatch)!=0 && b.Item>=0;
            ShowCarcass(b,dead && (f.Flags&LanProtocol.AnimalButcher)!=0,f.Left);
            AnimalSounds(b,f);
            if(r.SnapCount!=0) {
                float gap=hostTime-r.Snaps[r.SnapCount-1].T;
                if(gap<=0) return;
                if(gap<1) r.Interval+=(gap-r.Interval)*.2f;
                else r.SnapCount=0;
            }
            if(r.SnapCount==r.Snaps.Length) { Array.Copy(r.Snaps,1,r.Snaps,0,r.Snaps.Length-1); r.SnapCount--; }
            r.Snaps[r.SnapCount++]=new Snap {T=hostTime,P=r.Position,Yaw=f.Yaw,Animation=f.Animation,AnimationTime=f.AnimationTime,Flags=f.Bools,Speed=f.Speed,Idle=f.Idle};
        }
        // 1.4.11's experience of a zombie, for an animal: the game gives its own player an animal's experience when it dies
        // (AnimalAIController.SetState(Die)); a guest takes it when one it saw alive dies at the host (LanGuestCredits credits it).
        private void AnimalKilled(Replica r)
        {
            if(_host || !r.SeenAlive || !_playerReady || r.Beast==null || r.Beast.Settings==null) return;
            var player=LocalPlayer();
            if(player==null || player.zFLevelController==null) return;
            float xp=r.Beast.Settings.ExperienceReward;
            if(!(xp>0) || float.IsInfinity(xp)) return;
            try { player.zFLevelController.AddExperience(xp); _experience+=xp; }
            catch(Exception ex) { AnimalReport("Animal experience not given: "+ex.GetType().Name+": "+ex.Message); }
        }
        // The carcass stand-in is there while the host's carcass can be cut, with what it still gives (the game's hint lists it).
        private static void ShowCarcass(AnimalVisual b,bool show,byte[] left)
        {
            b.Butcher=show;
            if(b.Carcass==null) return;
            var holder=b.Carcass.transform.parent==null?b.Carcass:b.Carcass.transform.parent.gameObject;
            if(holder.activeSelf!=show) holder.SetActive(show);
            if(!show || left==null || b.Resource==null) return;
            try {
                if(!b.Resource.UseNewSystem) { b.Resource.resourceQuantity=left[0]; return; }
                var list=_takables(b.Resource);
                if(list!=null) for(int i=0;i<list.Length && i<left.Length;i++) list[i].resourceQuantity=left[i];
            }
            catch(Exception) { }
        }
        // Its voice and steps as at the host: a looping clip plays while the host's does, each new one-shot once.
        private static void AnimalSounds(AnimalVisual b,AnimalFrame f)
        {
            Sound(b.Voice,b.Clips,f.Voice,(f.Loops&LanProtocol.AnimalVoiceLoop)!=0,b.CountsSeen && f.VoiceCount!=b.VoiceCount);
            Sound(b.Steps,b.Clips,f.Steps,(f.Loops&LanProtocol.AnimalStepsLoop)!=0,b.CountsSeen && f.StepsCount!=b.StepsCount);
            b.VoiceCount=f.VoiceCount; b.StepsCount=f.StepsCount; b.CountsSeen=true;
        }
        private static void Sound(AudioSource source,AudioClip[] clips,byte index,bool loop,bool fresh)
        {
            if(source==null) return;
            var clip=index>=1 && clips!=null && index<=clips.Length ? clips[index-1] : null;
            if(loop) {
                if(clip!=null && (source.clip!=clip || !source.isPlaying || !source.loop)) { source.loop=true; source.clip=clip; source.Play(); }
                return;
            }
            if(source.loop && source.isPlaying) source.Stop();
            source.loop=false;
            if(fresh && clip!=null) source.PlayOneShot(clip);
        }

        // Guest, every frame: the copies move between the host's frames as the zombies' do; a carcass lies frozen as its death ended
        // (its frames still move it: a blast throws a carcass at the host); a bleeding animal leaves its trail.
        private void TickAnimalReplicas(float now,float hostNow,float smooth)
        {
            if(_animalReplicas.Count==0) return;
            List<uint> remove=null;
            foreach(var pair in _animalReplicas) {
                var r=pair.Value;
                if(r.Root==null || now-r.Seen>12) { if(r.Root!=null) Object.Destroy(r.Root); (remove??(remove=new List<uint>())).Add(pair.Key); continue; }
                if(r.SnapCount==0) continue;
                float at=hostNow-Mathf.Clamp(r.Interval+_jitter*2+.03f,.08f,.6f);
                Vector3 position; float yaw; Sample(r,at,out position,out yaw);
                var t=r.Root.transform;
                if((t.position-position).sqrMagnitude>25) t.SetPositionAndRotation(position,Quaternion.Euler(0,yaw,0));
                else { t.position=Vector3.Lerp(t.position,position,smooth); t.rotation=Quaternion.Slerp(t.rotation,Quaternion.Euler(0,yaw,0),smooth); }
                for(int i=r.SnapCount-1;i>=0;i--) if(r.Snaps[i].T<=at) { if(r.Snaps[i].T>r.AnimAt) { r.AnimAt=r.Snaps[i].T; ApplyAnimalAnimation(r,r.Snaps[i]); } break; }
                if(r.ForcePlay && r.AnimAt<0) ApplyAnimalAnimation(r,r.Snaps[r.SnapCount-1]);
                if(r.Beast.Bleeding && now>=r.Beast.BloodAt) Bleed(r.Beast,t,now);
            }
            if(remove!=null) foreach(uint id in remove) _animalReplicas.Remove(id);
        }
        // Its own state machine runs on the host's parameters; a state the host's is in that it is not (a bite, a death: the game's
        // triggers, which the frames do not carry) is crossed over to after a moment, at once on a new copy or a carcass.
        private static void ApplyAnimalAnimation(Replica r,Snap s)
        {
            var anim=r.Animator; var b=r.Beast;
            if(anim==null || !anim.enabled || !anim.isInitialized || b.Frozen) return;
            if(!b.ParamsKnown) { var p=AnimalParameters(anim); b.HasSpeed=p.Speed; b.HasIdle=p.Idle; b.Bools=p.Bools; b.ParamsKnown=true; }
            if(b.HasSpeed) anim.SetFloat(AnimalBaseSO.SPEED,s.Speed);
            if(b.HasIdle) anim.SetInteger(AnimalBaseSO.IDLE_INDEX,s.Idle);
            for(int i=0;i<b.Bools.Length;i++) anim.SetBool(b.Bools[i],(s.Flags&(1u<<i))!=0);
            if(s.Animation!=0 && anim.HasState(0,s.Animation) && !InState(anim,s.Animation)) {
                float now=Time.unscaledTime;
                if(r.ForcePlay || r.Dead) anim.Play(s.Animation,0,s.AnimationTime);
                else if(r.MismatchSince<0) { r.MismatchSince=now; return; }
                else if(now-r.MismatchSince>=.15f) { anim.CrossFade(s.Animation,.15f,0,s.AnimationTime); r.MismatchSince=-1f; }
                else return;
            }
            else r.MismatchSince=-1f;
            r.ForcePlay=false;
            // A carcass: the game stops its animator where its death ends (DieEnd).
            if(r.Dead && s.AnimationTime>=.99f) { anim.Update(0f); anim.enabled=false; b.Frozen=true; }
        }
        private static void Bleed(AnimalVisual b,Transform root,float now)
        {
            b.BloodAt=now+UnityEngine.Random.Range(.6f,1.6f);
            try {
                var from=b.BloodPoint!=null?b.BloodPoint.position:root.position+Vector3.up*.5f;
                RaycastHit ground;
                if(b.Settings==null || !Physics.Raycast(from,Vector3.down,out ground,1.5f,b.BloodMask,QueryTriggerInteraction.Ignore)) return;
                var decal=b.Settings.GetTrailBloodDecal(); if(decal==null) return;
                var copy=Object.Instantiate(decal,ground.point,Quaternion.FromToRotation(Vector3.up,ground.normal));
                float scale=b.Settings.TrailBloodScale; copy.transform.localScale=new Vector3(scale,1f,scale);
            }
            catch(Exception) { b.Bleeding=false; }
        }

        // Transforms, meshes, a trusted animator and the two sound sources of the prefab, as the zombies' copies (CreateVisual);
        // its parts' hitboxes for hit claims; its carcass stand-in (switched off until the host's carcass can be cut).
        private static Replica CreateAnimalVisual(GameObject prefab,uint id)
        {
            var ai=prefab.GetComponent<AnimalAIController>();
            var root=new GameObject("LAN animal visual"); root.SetActive(false);
            try {
                var map=new Dictionary<Transform,Transform>();
                CopyHierarchy(prefab.transform,root.transform,map,0);
                foreach(var source in prefab.GetComponentsInChildren<SkinnedMeshRenderer>(true)) {
                    Transform t; if(!map.TryGetValue(source.transform,out t)) continue;
                    var dest=t.gameObject.AddComponent<SkinnedMeshRenderer>(); dest.sharedMesh=source.sharedMesh; dest.sharedMaterials=source.sharedMaterials;
                    var bones=source.bones; var copied=new Transform[bones.Length];
                    for(int i=0;i<bones.Length;i++) if(bones[i]!=null) map.TryGetValue(bones[i],out copied[i]);
                    dest.bones=copied; Transform bone;
                    if(source.rootBone!=null && map.TryGetValue(source.rootBone,out bone)) dest.rootBone=bone;
                    dest.localBounds=source.localBounds; dest.enabled=source.enabled; dest.updateWhenOffscreen=true;
                }
                Animator animator=null; var sourceAnimator=VisualAnimator(ai);
                Transform animatorTransform;
                if(sourceAnimator!=null && map.TryGetValue(sourceAnimator.transform,out animatorTransform)) {
                    animator=animatorTransform.gameObject.AddComponent<Animator>(); animator.avatar=sourceAnimator.avatar;
                    animator.runtimeAnimatorController=sourceAnimator.runtimeAnimatorController; animator.applyRootMotion=false;
                    animator.cullingMode=AnimatorCullingMode.AlwaysAnimate;
                    animator.fireEvents=false; // its bites, steps and death events are the host's
                }
                var b=new AnimalVisual {Settings=ai.AnimalBaseSo,Clips=AnimalClips(ai.AnimalBaseSo)};
                b.Voice=CopyAudio(_animalVoice(ai),map); b.Steps=CopyAudio(_animalSteps(ai),map);
                var trail=_animalTrail(ai);
                if(trail!=null) { Transform point; if(map.TryGetValue(trail.transform,out point)) b.BloodPoint=point; b.BloodMask=_trailMask(trail).value; }
                if(b.BloodMask==0) b.BloodMask=~0;
                var takable=ai.TakableComponent;
                if(takable!=null && takable.amount>0) { b.Item=takable.itemID; b.ItemAmount=takable.amount; }
                b.Carcass=CarcassStandIn(ai,map,id,out b.Resource);
                return new Replica {Root=root,Animator=animator,Bones=new Transform[0],BoneOrder=new int[0],Limbs=AnimalLimbs(ai,map),Beast=b};
            }
            catch { Object.Destroy(root); throw; }
        }
        private static AudioSource CopyAudio(AudioSource source,Dictionary<Transform,Transform> map)
        {
            Transform at; if(source==null || !map.TryGetValue(source.transform,out at)) return null;
            var audio=at.gameObject.AddComponent<AudioSource>();
            audio.playOnAwake=false; audio.loop=false; audio.outputAudioMixerGroup=source.outputAudioMixerGroup; audio.volume=source.volume; audio.pitch=source.pitch;
            audio.spatialBlend=source.spatialBlend; audio.minDistance=source.minDistance; audio.maxDistance=source.maxDistance; audio.rolloffMode=source.rolloffMode;
            audio.dopplerLevel=source.dopplerLevel; audio.spread=source.spread; audio.priority=source.priority;
            if(source.rolloffMode==AudioRolloffMode.Custom) audio.SetCustomCurve(AudioSourceCurveType.CustomRolloff,source.GetCustomCurve(AudioSourceCurveType.CustomRolloff));
            return audio;
        }
        // The parts' hitboxes (AnimalPartDetector colliders in prefab order: the host's animal has the same) on the copy's bones.
        private static LimbShape[] AnimalLimbs(AnimalAIController prefab,Dictionary<Transform,Transform> map)
        {
            var shapes=new List<LimbShape>(); var parts=prefab.GetComponentsInChildren<AnimalPartDetector>(true);
            for(int i=0;i<parts.Length && i<LanProtocol.MaxClaimLimbs;i++) {
                Transform copy;
                if(parts[i]==null || !map.TryGetValue(parts[i].transform,out copy)) continue;
                var s=Shape(parts[i].GetComponent<Collider>()); if(s==null) continue;
                s.T=copy; s.Index=(byte)i; shapes.Add(s);
            }
            return shapes.ToArray();
        }
        // The prefab's resource object (its CollectedResource and colliders, no meshes, scripts or bodies) where the copy has it,
        // switched off; the game's knife and hint meet it as the host's own carcass (LanWorldWork sends the cut).
        private static GameObject CarcassStandIn(AnimalAIController ai,Dictionary<Transform,Transform> map,uint id,out CollectedResource resource)
        {
            resource=null;
            var source=ai.ResourceObject; Transform at;
            if(source==null || source.GetComponent<CollectedResource>()==null || !map.TryGetValue(source.transform,out at)) return null;
            at.gameObject.SetActive(false);
            for(int i=at.childCount-1;i>=0;i--) Object.Destroy(at.GetChild(i).gameObject); // its meshes come with the stand-in's own
            var staging=new GameObject("LAN staging"); staging.SetActive(false);
            try {
                var copy=Object.Instantiate(source,staging.transform,false);
                foreach(var script in copy.GetComponentsInChildren<MonoBehaviour>(true)) if(!(script is CollectedResource)) Object.DestroyImmediate(script);
                foreach(var body in copy.GetComponentsInChildren<Rigidbody>(true)) Object.DestroyImmediate(body);
                foreach(var audio in copy.GetComponentsInChildren<AudioSource>(true)) Object.DestroyImmediate(audio);
                copy.SetActive(true);
                copy.transform.SetParent(at,false);
                copy.transform.localPosition=Vector3.zero; copy.transform.localRotation=Quaternion.identity; copy.transform.localScale=Vector3.one;
                copy.AddComponent<LanAnimalCarcass>().Id=id;
                resource=copy.GetComponent<CollectedResource>();
                return copy;
            }
            finally { Object.Destroy(staging); }
        }

        // Guest, LanPlugin's look at the host's world: a live animal copy that can be caught (a chicken) under the crosshair within
        // the game's reach of the player's hands: the game's "pick up" hint, and its use or take key asks the host (WorkCatch); the
        // game's own weight check first (Inventory.HowMuchCanFit of a TakableAnimal).
        internal bool LookAtAnimals(bool take)
        {
            if(_host || !_playerReady || _animalReplicas.Count==0) return false;
            var player=LocalPlayer(); var camera=Camera.main; var work=LanWorldWork.GuestWork;
            if(player==null || camera==null || work==null) return false;
            var origin=camera.transform.position; var aim=camera.transform.forward;
            Replica found=null; uint id=0; float along=3f;
            foreach(var pair in _animalReplicas) {
                var r=pair.Value;
                if(r.Root==null || !r.Root.activeInHierarchy || r.Dead || r.Beast==null || !r.Beast.Catch || r.Limbs==null) continue;
                if((r.Root.transform.position-origin).sqrMagnitude>36f) continue;
                foreach(var s in r.Limbs) { float t; if(s.T!=null && Intersect(s,origin,aim,along,out t)) { along=t; found=r; id=pair.Key; } }
            }
            if(found==null) return false;
            var inventories=InventoryController.global;
            var grab=player.zFScriptConnector!=null && player.zFScriptConnector.playerGrabPosition!=null ? player.zFScriptConnector.playerGrabPosition.position : origin;
            float contact=inventories==null || !(inventories.contactDistance>0) ? 2f : inventories.contactDistance;
            if(Vector3.Distance(found.Root.transform.position,grab)>contact+.5f) return false;
            LanStorageGame.HintPickUp(found.Beast.Item,found.Beast.ItemAmount,true);
            if(!take || Time.unscaledTime<_catchAt) return true;
            _catchAt=Time.unscaledTime+1f;
            try {
                var prefabs=ItemsDataBase.Global==null?null:ItemsDataBase.Global.itemPrefab; var bag=player.inventory;
                var item=prefabs!=null && found.Beast.Item<prefabs.Length?prefabs[found.Beast.Item]:null;
                if(item!=null && bag!=null && bag.currentWeight+item.GetWeight()*found.Beast.ItemAmount>bag.maxWeight) {
                    if(GlobalWarningMessageController.global!=null) GlobalWarningMessageController.global.WarningMassage(0);
                    return true;
                }
            }
            catch(Exception) { }
            work(LanStorage.WorkCatch,found.Root.transform.position,-1,(int)id,null);
            return true;
        }

        // ---- Both ----
        private void ResetAnimals()
        {
            foreach(var seat in _animalSeats.Values) { ReleaseAnimals(seat); seat.Sequence=0; seat.Cursor=0; }
            foreach(var r in _animalReplicas.Values) if(r.Root!=null) Object.Destroy(r.Root);
            _animalReplicas.Clear(); _animalIds.Clear(); _animals.Clear(); _failedAnimals.Clear(); _unknownAnimals.Clear();
            Array.Clear(_animalSeen,0,_animalSeen.Length); Array.Clear(_animalGone,0,_animalGone.Length);
            _animalScanAt=0; _animalSendAt=0; _animalSenseAt=0; _sentAnimals=0; _receivedAnimals=0; _createdAnimals=0;
        }
        private void FreezeAnimals()
        {
            foreach(var seat in _animalSeats.Values) ReleaseAnimals(seat);
            foreach(var r in _animalReplicas.Values) if(r.Root!=null) r.Root.SetActive(false);
        }
        private void DisposeAnimals()
        {
            foreach(var seat in _animalSeats.Values) if(seat.Target!=null) Object.Destroy(seat.Target);
            _animalSeats.Clear();
        }
        private string _animalReported;
        private float _animalReportAt;
        private void AnimalReport(string text)
        {
            float now=Time.unscaledTime;
            if(text==_animalReported && now<_animalReportAt) return;
            _animalReported=text; _animalReportAt=now+30f;
            _report(text);
        }
    }

    // 2.8.0, host: a guest as the host's animals see it (ZombieSync.AddAnimalSeat): the game's animal AI chases this object
    // (AnimalAIController.Target, FlockController's target) and asks whether it lives; its bites land through ZombieSync
    // (AnimalBite), never through the game's IHasHealth.CauseDamage, which this leaves without effect.
    internal sealed class LanAnimalTarget : MonoBehaviour, IHasHealth
    {
        internal int Slot;
        internal ZombieSync Owner;
        public bool GetIsAlive() { var owner=Owner; return owner!=null && owner.GuestAlive(Slot); }
        public void CauseDamage(float damage,bool damageEffect) { }
        public void CauseDamage(float damage,GameObject target) { }
    }
    // 2.8.0, guest: the carcass stand-in of the host's animal Id (LanWorldWork sends a cut on it as WorkButcher).
    internal sealed class LanAnimalCarcass : MonoBehaviour
    {
        internal uint Id;
    }
}
