using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Reflection;
using System.Net;
using System.Net.Sockets;
using BepInEx;
using BepInEx.Configuration;
using UnityEngine;
using Zompiercer.Train;
using Object = UnityEngine.Object;

namespace ZompiercerLAN
{
    [BepInPlugin("local.zompiercer.lan", "Zompiercer LAN", LanPlugin.PluginVersion)]
    [DefaultExecutionOrder(10000)]
    public sealed class LanPlugin : BaseUnityPlugin
    {
        // 2.0.0: the line for up to four players (built from 1.4.8); "LAN4P" keeps it apart from 1.4.x. 2.1.0: up to eight.
        internal const string PluginVersion = "2.8.4";
        private static string NetworkGameVersion { get { return Application.version + "/LAN4P-2.8.4"; } }
        // 2.8.0: made for the game 22.0 (its animals, its save folders); on an older game the mod says so and stays off.
        private static string _oldGame;
        private const float SendInterval = 0.10f;
        // 1.4.6: the player's state goes more often than the rest, stamped with this clock: 20 a second, 25 since 2.6.2
        // (also the host's Players packets, sent with it).
        private const float StateInterval = 0.04f;
        private static readonly System.Diagnostics.Stopwatch StateClock = System.Diagnostics.Stopwatch.StartNew();
        private float _nextStateAt;
        // 2.0.0: the secure sessions (LanLink): a guest's one link to its host (slot 0), a host's link per
        // guest (slots 1..LanSeats.MaxGuests), each with its own worker; this player's slot (a guest
        // learns it from the host's Welcome).
        private readonly Dictionary<int, LanLink> _links = new Dictionary<int, LanLink>();
        private int _mySlot;
        // Guest: the host's other guests (their states come in the host's Players packets), by slot.
        private readonly Dictionary<int, RemotePlayer> _others = new Dictionary<int, RemotePlayer>();
        private readonly LanPlayerRoster _roster = new LanPlayerRoster();
        // Host: how its seats open: the room name, the relay and the room password of every new room
        // (null: the local network), whether a new seat opens by itself (a relay room with the host's own
        // password, listed or not) and when; a guest to send away (from the panel, done in Update).
        private string _seatName = "Комната", _seatSecret = "";
        private LanRelayOptions _seatRelay;
        private bool _seatsOpenThemselves;
        private float _openSeatAt = -1f;
        private int _kick;
        private LanIsolatedSession _roomBrowser;
        // Relay public room list (0.13.0): the host lists its room; a guest reads the list.
        private LanIsolatedSession _relayRooms;
        private bool _relayPublic, _hostedPublic;
        private float _relayRoomsAt = -10f;
        private Vector2 _relayRoomsScroll;
        private bool _roomSearchReported;
        private string _roomName = "Комната", _manualAddress = "";
        // Internet relay mode. The server comes from this build (RelayDefaults, masked)
        // or, for advanced players, from the Custom* config entries; never from the network.
        private ConfigEntry<bool> _useRelayEntry;
        private ConfigEntry<string> _customServerEntry, _customFingerprintEntry, _customKeyEntry;
        private bool _relayMode, _showJoinSecret;
        // Room secrets stay in memory only: never written to config or logs.
        private string _relayHostSecret = "", _relayJoinSecret = "", _relayRoomInput = "";
        private Vector2 _roomScroll, _panelScroll;
        private ZombieFighterController _lanHeldPlayer;
        private bool _lanPreviousControl, _lanPreviousCursor;
        private CursorLockMode _lanPreviousLock;
        private ZombieSync _zombies;
        // Guest profile persistence (0.5.0): the host stores (LanLink.GuestHost), the guest restores and uploads.
        private LanPlayerIdentity _identity;
        private bool _identityFailed;
        private float _lostAt = -1f; // 1.4.5: guest: when the host was lost (-1: connected or never)
        // 1.2.0: the host's quests, shared with the guests: their places, ledgers and profiles (1.4.5).
        private Func<IList<Vector3>> _questPositions;
        private Func<int, long> _questCount;
        private Func<IList<string>> _questProfiles;
        private Func<int, uint, string, bool> _questRequest;
        // 1.2.1: the host's avatar holds what the host carries (guest).
        private Func<Transform> _hostAvatar;
        private ConfigEntry<bool> _askBelongingsEntry, _friendDrivesEntry, _showPartnerEntry, _chatEnabledEntry, _chatHideEntry, _notifySoundEntry, _partnerHealthEntry;
        private ConfigEntry<string> _skinEntry;
        // When the host was last reminded of a friend waiting for permission.
        private bool _approvalNotified;
        private float _approvalRemindAt;
        private ConfigEntry<string> _markKeyEntry, _chatKeyEntry;
        private LanMarks _marks;
        private LanChat _chat;
        private LanPlayerList _playerList;
        private Func<LatencySeat[]> _latencyReport;
        // Guest death (0.12.0): the death request is queued (the host keeps its guests' deaths in LanLink).
        private bool _deathSent, _deathLeftItems, _respawning;
        private float _deathRetryAt;
        // 1.4.7: a hit takes this much health at once.
        private const int FlinchHealth = 4;
        private bool _hosting;
        private bool _panelOpen;
        private float _panelContentHeight; // measured height of the panel's lines (1.0.4)
        private bool _joinStartedGame;
        private bool _startedLocalNewGame;
        // 1.1.6: the game's own end of a world load (character HUD on, cursor locked) is still due.
        private bool _nativeHudPending;
        private bool _clientPlacedNearHost;
        private float _lastSend;
        private string _joinCode = "";
        private float _nextNetworkWarning;
        private string _status = "Не подключено";
        // 1.2.2 (2.0.0: for every player): sleeping together, explosions for the guests, the others on the map.
        private Func<IList<int>> _sleepHere;
        private Action<byte, int, uint> _sleepSend;
        private Action<byte, string, Vector3> _explosionSend;
        private Func<IList<Vector3>> _mapPartners;
        // 1.3.0: the guests' checked stats and which of them play in this world.
        private Func<int, LanGuestStats> _creditStats;
        private Func<IList<int>> _creditHere;
        private ConfigEntry<string> _nameEntry;
        private ConfigEntry<float> _coopHealthEntry, _coopLootEntry; // 1.4.4
        private ConfigEntry<float> _coopHealthMaxEntry, _coopLootMaxEntry; // 2.4.1: the factors for eight players
        private ConfigEntry<bool> _extraWeaponsEntry; // 2.4.1
        private Func<int> _extraWeaponsPlayers;
        private int _coopGuests = 1; // 2.0.0: how many guests the zombies' health is set for
        private float _readySince = -1f;
        private string _clientSavePath;
        private uint _stateSequence;
        private float _nextWeaponCheck;
        private string _lastWeaponState;
        private bool _inventoryReadyCaptured;
        private uint _worldEpoch, _worldSequence, _receivedWorldSequence, _clientLoadEpoch;
        private string _hostWorldScene;
        private bool _hostSawLoading, _hostWorldReady;
        private float _hostReadySince = -1f, _nextTravelAttempt;
        private Packet _clientWorld;
        private ClientSceneTravel _travel;
        private readonly WorldClockSync _clock = new WorldClockSync();
        private static readonly FieldInfo LastGround = typeof(ZombieFighterController).GetField("LastKnownPositionOnGround", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
        private static readonly FieldInfo UndergroundTimer = typeof(ZombieFighterController).GetField("FallUndergroundTimer", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);

        // ---- 2.0.0: links and players ----

        // Guest: the link to the host (null: none, or hosting).
        private LanLink HostLink { get { LanLink link; return !_hosting && _links.TryGetValue(0, out link) ? link : null; } }
        private LanGuestClient GuestClient { get { var link = HostLink; return link == null ? null : link.GuestClient; } }
        private LanStorageClient StorageClient { get { var link = HostLink; return link == null ? null : link.StorageClient; } }
        // Some session is up (a guest: with its host; a host: with any of its guests).
        private bool Connected { get { foreach (var link in _links.Values) if (link.Connected) return true; return false; } }
        private bool AnyNetwork() { foreach (var link in _links.Values) if (link.Network != null) return true; return false; }
        // The links as they are now (a loop over them may close one).
        private List<LanLink> LinkList() { return new List<LanLink>(_links.Values); }
        // Every other player this game sees: the guests (host), or the host and its other guests (guest).
        private List<RemotePlayer> RemotePlayers()
        {
            var players = new List<RemotePlayer>();
            foreach (var link in _links.Values) if (link.Connected) players.Add(link.Player);
            if (!_hosting) players.AddRange(_others.Values);
            return players;
        }
        private static string CurrentScene() { var scenes = GlobalSceneManager.global; return scenes == null ? null : scenes.CurrentSceneName; }
        private static bool Newer(uint a, uint b) { return a != 0 && unchecked((int)(a - b)) > 0; }

        private void Awake()
        {
            // 2.4.5: no Windows user name in this log (folders under the profile become %LOCALAPPDATA% and the like).
            bool cleanLog = LanLogPrivacy.Install(Logger);
            LanLanguage.Initialize(Config.Bind("Interface", "Language", "ru",
                "Mod interface language: ru or en. Switch below the links in the main menu."));
            Logger.LogInfo("Zompiercer LAN " + PluginVersion + " (up to 8 players) loaded; AppContainer network worker, bounded IPC, J-PAKE and DTLS");
            if (!cleanLog) Logger.LogWarning("Log path cleaning unavailable in this BepInEx: file errors may show the Windows user folder");
            _useRelayEntry = Config.Bind("Relay", "UseRelay", false, "Play through the internet relay instead of the local network");
            _askBelongingsEntry = Config.Bind("Guests", "AskBeforeAcceptingBelongings", false,
                "Host: ask before taking a new friend's belongings onto the ledger (false: accept them at once)");
            _friendDrivesEntry = Config.Bind("Guests", "FriendMayDrive", true,
                "Host: the friend may use the train's controls (engine, throttle, brake, reverse, lights, horn), repair broken levers and switch lights of built parts");
            LanTrainControl.HostAllows = _friendDrivesEntry.Value;
            _markKeyEntry = Config.Bind("Marks", "Key", "Mouse2",
                "Key that marks what is under the crosshair: Mouse2 (middle mouse button) or a keyboard key name such as T or V");
            _showPartnerEntry = Config.Bind("Marks", "ShowPartner", true, "Show where the other players are (name, distance, arrow at the screen edge)");
            KeyCode markKey;
            LanMarks.Key = Enum.TryParse(_markKeyEntry.Value, true, out markKey) ? markKey : KeyCode.Mouse2;
            LanMarks.ShowPartner = _showPartnerEntry.Value;
            _chatEnabledEntry = Config.Bind("Chat", "Enabled", true, "Text chat with the other players (plain text only, at most 200 characters)");
            _chatKeyEntry = Config.Bind("Chat", "Key", "Return", "Key that opens the chat line: Return (Enter) or a keyboard key name such as Y");
            _chatHideEntry = Config.Bind("Chat", "HidePartner", false, "Do not show the other players' chat messages");
            KeyCode chatKey;
            LanChat.Key = Enum.TryParse(_chatKeyEntry.Value, true, out chatKey) && chatKey != KeyCode.None && chatKey != KeyCode.Escape && chatKey < KeyCode.Mouse0 ? chatKey : KeyCode.Return;
            LanChat.Enabled = _chatEnabledEntry.Value;
            LanChat.HidePartner = _chatHideEntry.Value;
            _notifySoundEntry = Config.Bind("Notifications", "Sound", true,
                "Play a short sound when the other player connects or the connection is lost, when the other player writes in chat, and (host) when a friend waits for your permission to join");
            LanNotify.Sound = _notifySoundEntry.Value;
            _partnerHealthEntry = Config.Bind("Partner", "HealthBar", true, "Show another player's health above them when you look at them from close by");
            _skinEntry = Config.Bind("Player", "Look", "", "How the other player sees you: a game NPC model name such as RegularWomanNPC_01 (empty: the default); chosen in the main menu");
            _nameEntry = Config.Bind("Player", "Name", "", "Your nickname for the other player (up to 16 characters, typed in the main menu next to the look; empty: Хост/Друг)");
            LanSkinPicker.Initialize(_skinEntry, _nameEntry, Logger.LogWarning);
            _coopHealthEntry = Config.Bind("Coop", "ZombieHealth", 1.3f, new ConfigDescription(
                "Host: zombie health multiplier while one friend is in your world; it grows evenly up to ZombieHealthMax for seven friends (1 = off: as in your difficulty settings; never saved into the world)",
                new AcceptableValueRange<float>(LanDifficulty.MinFactor, LanDifficulty.MaxFactor)));
            _coopHealthMaxEntry = Config.Bind("Coop", "ZombieHealthMax", 2.2f, new ConfigDescription(
                "Host: zombie health multiplier while seven friends (eight players) are in your world",
                new AcceptableValueRange<float>(LanDifficulty.MinFactor, LanDifficulty.MaxFactor)));
            _coopLootEntry = Config.Bind("Coop", "Loot", 1.5f, new ConfigDescription(
                "Host: how many items a container or a zombie's bag gets while one friend is connected; it grows evenly up to LootMax for seven friends (1 = off: as in your difficulty settings)",
                new AcceptableValueRange<float>(LanDifficulty.MinFactor, LanDifficulty.MaxFactor)));
            _coopLootMaxEntry = Config.Bind("Coop", "LootMax", 2.5f, new ConfigDescription(
                "Host: how many items a container or a zombie's bag gets while seven friends (eight players) are connected",
                new AcceptableValueRange<float>(LanDifficulty.MinFactor, LanDifficulty.MaxFactor)));
            _extraWeaponsEntry = Config.Bind("Coop", "ExtraWeapons", true,
                "Host: a location the train arrives at while there are 4 or more players (you and your connected friends) gets two of each firearm placed in it (false: one, as in the game)");
            _customServerEntry = Config.Bind("Relay", "CustomServer", "",
                "Advanced: your own ZompiercerRelay as IPv4 or IPv4:port. Leave empty to use the server built into this mod build. Requires CustomFingerprint.");
            _customFingerprintEntry = Config.Bind("Relay", "CustomFingerprint", "",
                "Advanced: SHA-256 certificate fingerprint of your own relay, as printed by its installer (AB:CD:...).");
            _customKeyEntry = Config.Bind("Relay", "CustomAccessKey", "",
                "Advanced: access key of your own relay, if it has one. Stored here as plain text.");
            Logger.LogInfo("LAN startup: configuration read; migrating relay settings");
            MigrateLegacyRelaySettings();
            _relayMode = _useRelayEntry.Value;
            _travel = new ClientSceneTravel(Logger);
            // Keep the newest few backups, checkpoints and client session folders.
            LanRetention.Run(Paths.BepInExRootPath, null, Logger.LogInfo, Logger.LogWarning);
            if (Type.GetType("Zompiercer.Animals.AnimalAIController, Assembly-CSharp") == null)
            {
                _oldGame = Application.version;
                Logger.LogError("This ZompiercerLAN " + PluginVersion + " needs Zompiercer 22.0 or newer; this game is " + _oldGame + ". The mod stays off.");
                return;
            }
            Logger.LogInfo("LAN startup: installing game hooks");
            LanSaveIsolation.Initialize(Logger);
            LanGuestPersistence.Initialize(Logger);
            LanBeaverSave.Initialize(Logger);
            LanBeaverItem.Initialize(Logger.LogInfo);
            LanStorageGame.Initialize(Logger.LogWarning);
            LanWorldDoors.Initialize(Logger.LogWarning);
            LanQuests.Initialize(Logger.LogWarning);
            LanTakables.Initialize(Logger.LogWarning);
            LanRobotWindow.Initialize(Logger.LogWarning);
            LanExplosions.Initialize(Logger.LogWarning);
            LanThrows.Initialize(Logger.LogWarning);
            LanTrainDecor.Initialize(Logger.LogWarning);
            LanFuelStation.Initialize(Logger.LogWarning);
            LanSceneStates.Initialize(Logger.LogWarning);
            LanFarm.Initialize(Logger.LogWarning);
            LanDifficulty.Initialize(Logger.LogInfo);
            LanWeather.Initialize(Logger.LogInfo);
            LanBossReward.Initialize(Logger.LogInfo);
            LanExtraWeapons.Initialize(Logger.LogInfo);
            LanStarterLoot.Initialize(Logger.LogInfo);
            LanLeave.Initialize(Logger.LogWarning);
            LanLeave.Leaving = LeaveToMenu;
            LanSleep.Initialize(Logger.LogInfo);
            LanSleep.GuestSleeps = (slot, hours) => LanGuestCredits.Sleep(slot, hours);
            LanGuestCredits.Initialize(Logger.LogWarning);
            LanMapMarker.Initialize(Logger.LogWarning);
            LanWorldItems.Initialize(Logger.LogWarning);
            LanWorldWork.Initialize(Logger.LogWarning);
            LanTrainBuild.Initialize(Logger.LogWarning);
            LanTrainControl.Initialize(Logger.LogWarning);
            LanBossArena.Initialize(Logger.LogInfo, Logger.LogWarning, text => _marks?.Toast(text));
            LanGuestDeath.Initialize(Logger.LogWarning);
            LanDowned.Initialize(Logger.LogWarning);
            LanDowned.PartnerCanHelp = OthersCanHelp;
            LanDowned.DownedPartners = DownedPlayers;
            LanDowned.PlayerAt = PlayerAt;
            LanDowned.Send = SendRevive;
            // 2.2.0: also while it comes back after a respawn (not placed yet): dying then showed the game's own end screen.
            LanGuestDeath.Attached = () => !_hosting && Connected && (_clientPlacedNearHost || _respawning) && StorageClient != null && LanSaveIsolation.Active;
            Logger.LogInfo("LAN startup: game hooks installed; starting background asset verification");
            LanWorldCatalog.Initialize(Application.dataPath);
            try { ClientTravelHooks.Init(); }
            catch (Exception ex) { Logger.LogError("LAN scene hooks unavailable: " + ex); }
            try { RemoteEquipment.Init(); }
            catch (Exception ex) { Logger.LogWarning("Remote weapon events unavailable: " + ex.Message); }
            Logger.LogInfo("LAN startup completed; network worker starts only on a LAN action");
        }

        private void OnDestroy() { _panelOpen = false; ReleaseLanInput(); StopNetwork(); _roomBrowser?.Dispose(); _relayRooms?.Dispose(); RemoteEquipment.Shutdown(); ClientTravelHooks.Shutdown(); LanSaveIsolation.Shutdown(); LanGuestPersistence.Shutdown(); LanStorageGame.Shutdown(); LanWorldDoors.Shutdown(); LanQuests.Shutdown(); LanTakables.Shutdown(); LanRobotWindow.Shutdown(); LanExplosions.Shutdown(); LanThrows.Shutdown(); LanTrainDecor.Shutdown(); LanFuelStation.Shutdown(); LanSceneStates.Shutdown(); LanFarm.Shutdown(); LanDifficulty.Shutdown(); LanBossReward.Shutdown(); LanExtraWeapons.Shutdown(); LanStarterLoot.Shutdown(); LanWeather.Shutdown(); LanLeave.Shutdown(); LanSleep.Shutdown(); LanMapMarker.Shutdown(); LanGuestCredits.Shutdown(); LanWorldItems.Shutdown(); LanWorldWork.Shutdown(); LanTrainBuild.Shutdown(); LanTrainControl.Shutdown(); LanGuestDeath.Shutdown(); LanBeaverItem.Shutdown(); LanBeaverSave.Shutdown(); LanNotify.Shutdown(); LanSkinPicker.Shutdown(); LanBossArena.Shutdown(); LanDowned.Shutdown(); _identity?.Dispose(); LanInventoryGuard.Shutdown(Logger); }

        // 0.4.0-0.4.1 kept the relay address, fingerprint and key as plain text in
        // [Relay] Server/Fingerprint/AccessKey. A genuinely custom server moves to the
        // Custom* entries; the built-in values are dropped. The old keys are deleted.
        private void MigrateLegacyRelaySettings()
        {
            var server = Config.Bind("Relay", "Server", "", "Obsolete; removed on start");
            var fingerprint = Config.Bind("Relay", "Fingerprint", "", "Obsolete; removed on start");
            var key = Config.Bind("Relay", "AccessKey", "", "Obsolete; removed on start");
            try
            {
                string text = (server.Value ?? "").Trim();
                int colon = text.LastIndexOf(':');
                IPAddress address;
                bool builtIn = text.Length == 0 || IPAddress.TryParse(colon > 0 ? text.Substring(0, colon) : text, out address) && RelayDefaults.Available && address.Equals(RelayDefaults.Server);
                if (!builtIn && (_customServerEntry.Value ?? "").Trim().Length == 0)
                {
                    _customServerEntry.Value = text;
                    _customFingerprintEntry.Value = (fingerprint.Value ?? "").Trim();
                    _customKeyEntry.Value = key.Value ?? "";
                    Logger.LogInfo("Custom relay settings moved to [Relay] CustomServer/CustomFingerprint/CustomAccessKey");
                }
            }
            finally
            {
                Config.Remove(server.Definition); Config.Remove(fingerprint.Definition); Config.Remove(key.Definition);
                Config.Save();
            }
        }

        private bool CustomRelayConfigured { get { return (_customServerEntry.Value ?? "").Trim().Length != 0; } }

        // 2.4.0: the host's load (LanHostTiming): its log line and the count of zombies awake in it.
        private Action<string> _timingLog;
        private Func<int> _timingZombies;
        private Func<TrainCar> _hostGuestCar;

        private void Update()
        {
            if (_oldGame != null) return;
            long callbackStarted = LanHostTiming.Now;
            try
            {
            // 2.4.0: the frame that ended goes into the host's load figures first.
            if (_timingLog == null) { _timingLog = message => Logger.LogInfo(message); _timingZombies = () => _zombies == null ? 0 : _zombies.AwakeZombies(); }
            LanHostTiming.EndFrame(_hosting, _hosting ? ConnectedGuests() : 0, _timingZombies, Time.unscaledTime, Time.unscaledDeltaTime, _timingLog);
            long timing = LanHostTiming.Now;
            LanChat.RestoreControl();
            LanTrainDevices.RestoreControl();
            UpdateLanInput();
            LanSkinPicker.Tick();
            // 2.4.2: a guest in the host's world has the host's weather, not its own random one.
            LanWeather.GuestHeld = !_hosting && Connected && _clientWorld != null;
            // Every frame, with or without a session: a held arena trap settles after one ends.
            BossArenaTick();
            // 1.2.0: quests are the host's while a session is attached.
            QuestsTick();
            // 1.2.1: what the guests carry follows their avatars; a guest's robot dog follows the guest.
            TakablesTick();
            // 1.2.2: sleeping together, explosions for the guests, the others on the map.
            CoopTick();
            // 1.1.9: a downed player, or another player lying downed next to this one.
            LanDowned.Tick();
            LanHostTiming.Add(LanHostTiming.Coop, timing);
            // Keep the disposable client's world out of the player's solo saves,
            // including after disconnection. A restart restores normal save paths.
            if (LanSaveIsolation.Active && !LanSaveIsolation.Enforce() && LanSaveIsolation.Failure != null)
                ClientTravelHooks.Fail("SaveIsolation");
            ClientTravelHooks.Tick();
            if (_roomBrowser != null && _roomBrowser.Finished && !_roomSearchReported)
            {
                _roomSearchReported = true;
                string error = _roomBrowser.SecurityFailure;
                Logger.LogInfo("LAN room search finished: " + _roomBrowser.Rooms.Length + (error == null ? "" : "; " + error));
            }
            _travel?.Hold();
            // Never attach host state to a solo world started while pairing or
            // authentication was pending, including before a DTLS socket exists.
            if (_links.Count != 0 && !_hosting && _clientSavePath == null &&
                GlobalManager.global != null && GlobalManager.global.controlledChar != null)
            {
                StopNetwork(); _status = LanText.T("Подключение отменено: уже начата одиночная игра"); return;
            }
            MenuWhenReady(); // 1.4.5: a guest whose host left goes to the main menu
            PollPairing();
            NotifyApproval();
            if (_hosting) HostSeatsTick();
            if (!AnyNetwork()) return;
            if (!_hosting && ClientTravelHooks.LoadFailure != null)
            {
                HostLink?.Train?.Freeze(); _clock.Freeze(); HideAvatars(); StopSocketOnly();
                _status = LanText.T("Ошибка загрузки клиента. Перезапустите игру; сохранения изолированы");
                Logger.LogError("Client loader failed: " + ClientTravelHooks.LoadFailure);
                return;
            }
            foreach (var link in LinkList())
                if (link.Connected && link.Network.Session != link.Session)
                {
                    LinkDown(link);
                    _status = _hosting ? LanText.T("Ожидание защищённого подключения: ") + LanSkinPicker.Label(link.Slot) : LanText.T("Повторное защищённое подключение");
                }
            timing = LanHostTiming.Now;
            if (_hosting) ObserveHostWorld();
            ReceivePackets();
            timing = LanHostTiming.Add(LanHostTiming.Network, timing);
            foreach (var link in LinkList())
            {
                if (link.Limits.Failure == null) continue;
                string reason = link.Limits.Failure;
                if (!_hosting) { StopNetwork(); _status = reason + LanText.T("; соединение закрыто"); Logger.LogWarning(_status); return; }
                _status = reason + "; " + LanSkinPicker.Label(link.Slot) + LanText.T(" отключён"); Logger.LogWarning(_status);
                DropLink(link, null);
            }
            float now = Time.unscaledTime;
            foreach (var link in LinkList())
            {
                if (!link.Up || _worldEpoch == 0) continue;
                link.Sleep?.Tick(now);
                if (link.Sleep == null || !link.Sleep.Failed) continue;
                string reason = LanText.T("Не удалось подтвердить состояние общего сна; соединение закрыто");
                if (_hosting) { DropLink(link, reason); }
                else { HostLeft(reason); return; }
            }
            foreach (var link in LinkList())
                if (link.Connected && link.Peer != null && now - link.LastReceive > 30f)
                    PeerLost(link, _hosting ? LanSkinPicker.Label(link.Slot) + LanText.T(": связь потеряна") : LanText.T("Связь с хостом потеряна; повторное подключение"));
            // 2.0.0: a guest that does not come back in time (as a guest waits for its host) frees its seat.
            if (_hosting)
                foreach (var link in LinkList())
                    if (!link.Connected && link.Network != null && link.LostAt >= 0f && now - link.LostAt > GuestWaitForHost)
                        DropLink(link, LanSkinPicker.Label(link.Slot) + LanText.T(" не вернулся: место свободно"));
            bool connected = Connected;
            // 1.4.5: a guest waits for its host three minutes, then leaves the frozen world.
            if (!_hosting && !connected && _lostAt >= 0f && now - _lostAt > GuestWaitForHost) { HostLeft(LanText.T("Хост не вернулся за 3 минуты")); return; }
            if (connected)
            {
                var me = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
                RemoteEquipment.ObserveDash(me); RemoteEquipment.ObserveMotion(me);
            }
            timing = LanHostTiming.Now;
            if (connected && now >= _nextStateAt)
            {
                SendState();
                if (_hosting) foreach (var link in _links.Values) if (link.Up) SendPlayers(link);
                _nextStateAt = Mathf.Max(_nextStateAt + StateInterval, now - StateInterval);
            }
            if (connected && now - _lastSend >= SendInterval)
            {
                foreach (var link in _links.Values)
                {
                    if (!link.Up) continue;
                    if (_hosting && _hostWorldReady && now >= link.NextWorldSend) SendWorld(link);
                    Send(link, PacketKind.Heartbeat);
                }
                _lastSend = now;
            }
            timing = LanHostTiming.Add(LanHostTiming.Network, timing);
            var host = HostLink;
            if (connected && !_hosting) UpdateClientWorld();
            timing = LanHostTiming.Now;
            if (_hosting)
                foreach (var link in LinkList())
                {
                    if (!link.Connected) continue;
                    link.GuestHost?.Tick(now);
                    // Friends: a new friend's belongings go onto the ledger as they are (configurable).
                    if (link.GuestHost != null && link.GuestHost.PendingKit != null && !_askBelongingsEntry.Value) link.GuestHost.AcceptKit(true);
                    link.StorageHost?.Tick(now);
                    if (!link.PanelClosed && link.GuestHost != null && link.GuestHost.Confirmed && GuestPosition(link) != null) { link.PanelClosed = true; CloseConnectedPanel(); }
                }
            timing = LanHostTiming.Add(LanHostTiming.Guests, timing);
            int starterGuests = 0;
            if (_hosting) foreach (var link in _links.Values)
                if (link.Connected && link.GuestHost != null && link.GuestHost.Confirmed) starterGuests++;
            LanStarterLoot.Tick(_hosting, starterGuests);
            if (connected && !_hosting && host.GuestClient != null)
                host.GuestClient.Tick(now, _clientPlacedNearHost && !_travel.Active && LocalWorldReady() && LanWorldItems.Dropped.Count == 0 && (host.StorageClient == null || !host.StorageClient.Busy),
                    () => LanGuestCharacter.Capture(new[] { host.StorageClient == null ? 0u : host.StorageClient.AppliedTx, _zombies == null ? 0u : _zombies.Combat.AppliedState }));
            if (connected && !_hosting && host.GuestClient != null && host.GuestClient.CorrectionPending && _clientPlacedNearHost && !_travel.Active &&
                LocalWorldReady() && !LanDowned.Down && !LanSleep.Waiting && (host.StorageClient == null || !host.StorageClient.Busy))
            {
                // The host's ledger replaces belongings it could not account for.
                LanStorageGame.CloseWindow(host.StorageClient);
                RestoreGuestCharacter(host.GuestClient.TakePending());
                Logger.LogInfo("Guest belongings corrected to the host's ledger");
            }
            if (!_hosting) UpdateGuestStorage();
            if (!_hosting) UpdateGuestDeath();
            timing = LanHostTiming.Now;
            bool trainReady = TrainWorldAvailable() && (_hosting ? _hostWorldReady : _clientLoadEpoch == _worldEpoch);
            foreach (var link in _links.Values)
                if (link.Connected && link.Train != null) link.Train.Tick(_hosting, trainReady);
            timing = LanHostTiming.Add(LanHostTiming.Train, timing);
            if (connected && _zombies != null)
            {
                bool ready = TrainWorldAvailable() && (_hosting ? _hostWorldReady :
                    _clientWorld != null && _clientLoadEpoch == _worldEpoch &&
                    GlobalSceneManager.global.CurrentSceneName == _clientWorld.Scene);
                string scene = _hosting ? _hostWorldScene : _clientWorld?.Scene;
                if (_hosting)
                    foreach (var link in _links.Values)
                    {
                        var p = link.Player;
                        // 1.4.13: how the guest moves and its stealth level, for the host's zombies.
                        var book = Ledger(link);
                        _zombies.UpdateRemote(link.Slot, p.WorldPosition(), link.Connected && ready && p.HaveState && now - p.StateAt < 2f && p.Scene == scene,
                            p.EquippedItem, p.Yaw, p.Downed || p.Dead, p.Crouch, (p.MotionFlags & LanProtocol.MotionRun) != 0, (p.MotionFlags & LanProtocol.MotionAir) != 0,
                            p.Speed, book == null ? 1f : book.StealthFactor, p.HandMods);
                    }
                _zombies.Tick(scene, _worldEpoch, ready, _hosting || _clientPlacedNearHost);
            }
            timing = LanHostTiming.Add(LanHostTiming.Zombies, timing);
            if (!connected || !_hosting && host.Doors == null) { LanWorldDoors.GuestToggle = null; LanWorldDoors.GuestUnlock = null; LanWorldItems.GuestActive = false; LanTrainBuild.GuestAttached = false; LanTrainControl.GuestAttached = false; }
            else
            {
                bool ready = TrainWorldAvailable() && (_hosting ? _hostWorldReady :
                    _clientWorld != null && _clientLoadEpoch == _worldEpoch && _clientPlacedNearHost &&
                    GlobalSceneManager.global.CurrentSceneName == _clientWorld.Scene);
                string scene = _hosting ? _hostWorldScene : _clientWorld?.Scene;
                foreach (var link in _links.Values)
                {
                    if (!link.Connected || link.Doors == null) continue;
                    var guest = _hosting ? GuestPosition(link) : null;
                    link.Doors.Tick(scene, _worldEpoch, ready, guest);
                    link.SceneStates?.Tick(scene, _worldEpoch, ready, guest);
                    link.Farm?.Tick(ready);
                    link.WorldItems?.Tick(scene, _worldEpoch, ready, guest);
                    link.Quests?.Tick(scene, _worldEpoch, ready);
                }
                var doors = host == null ? null : host.Doors;
                LanWorldDoors.GuestToggle = !_hosting && ready ? (Action<DoorController>)(door => doors.RequestToggle(door)) : null;
                LanWorldDoors.GuestUnlock = !_hosting && ready ? (Action<DoorController, int>)((door, key) => doors.RequestUnlock(door, key)) : null;
                LanWorldItems.GuestActive = !_hosting && ready;
                LanTrainBuild.GuestAttached = !_hosting && ready;
                LanTrainControl.GuestAttached = !_hosting && ready;
                _marks?.Tick(scene, _worldEpoch, ready && !_panelOpen);
            }
            foreach (var link in _links.Values) if (link.Connected) link.Chat?.Tick(now);
            double latencyNow = StateClock.Elapsed.TotalSeconds;
            foreach (var link in _links.Values)
                if (link.Up) link.Latency?.Tick(latencyNow, _hosting ? _latencyReport : null);
            _chat?.Tick(connected && !_panelOpen);
            timing = LanHostTiming.Add(LanHostTiming.World, timing);
            FinishNativeLoad();
            UpdateAvatar();
            LanHostTiming.Add(LanHostTiming.Avatars, timing);
            LogLocalEquipment();
            }
            finally { LanHostTiming.EndCallback(callbackStarted); }
        }

        private void LateUpdate()
        {
            if (_oldGame != null) return;
            long callbackStarted = LanHostTiming.Now;
            try
            {
            BookDroppedItems();
            if (!Connected) return;
            long timing = LanHostTiming.Now;
            var host = HostLink;
            if (host != null && host.Train != null) host.Train.Render();
            if (host != null) TrainLayout.ShowBlueprints(LanTrainBuild.BlueprintsShownNow()); // 1.4.11
            if (!_hosting && !_panelOpen && _clientPlacedNearHost) LanTrainBuild.DrawProgress();
            if (!_hosting) _clock.Render(_clientPlacedNearHost && _clientWorld != null &&
                GlobalSceneManager.global != null && !ClientTravelHooks.Loading &&
                !GlobalSceneManager.global.SceneCurrentlyLoading && GlobalSceneManager.global.CurrentSceneName == _clientWorld.Scene);
            // Car-relative avatars must follow the same final train pose.
            foreach (var p in RemotePlayers()) if (p.Avatar != null) UpdateRemoteAvatarPose(p);
            LanHostTiming.Add(LanHostTiming.Avatars, timing);
            }
            finally { LanHostTiming.EndCallback(callbackStarted); }
        }

        private void OnGUI()
        {
            if (_oldGame != null)
            {
                GUI.Box(new Rect(Math.Max(12f, Screen.width - 432f), 12f, 420f, 48f),
                    string.Format(LanText.T("LAN {0} нужна игра версии 22.0 или новее (у вас {1}). Обновите игру или поставьте прежнюю версию мода."), PluginVersion, _oldGame));
                return;
            }
            long callbackStarted = LanHostTiming.Now;
            try
            {
            var inputEvent = Event.current;
            if (inputEvent.type == EventType.KeyDown && inputEvent.keyCode == KeyCode.F8)
            {
                _chat?.Close(); _playerList?.Close(); LanTrainDevices.Close(); ToggleLanPanel(); inputEvent.Use();
            }
            bool connected = Connected;
            if (connected && _chat != null && !_panelOpen)
            {
                _chat.KeyEvent(inputEvent);
                _chat.Draw();
            }
            if (_playerList == null) _playerList = new LanPlayerList(PlayerListRows);
            _playerList.Tick((connected || _hosting) && !_panelOpen && (_chat == null || !_chat.Open));
            _playerList.KeyEvent(inputEvent);
            _playerList.Draw();
            LanTakables.DrawWindow();
            LanRobotWindow.Draw();
            LanSleep.Draw();
            if (connected && _marks != null && !_panelOpen)
            {
                _marks.KeyEvent(inputEvent);
                _marks.Draw(PartnerPointers());
            }
            // 1.0.2: further from the right edge, and every line wraps to the panel's width (long
            // labels and the tab bar used to run past the right edge of the screen).
            float width = Math.Min(420f, Screen.width - 24f);
            float x = Math.Max(12f, Screen.width - width - Math.Max(24f, Screen.width * .08f));
            // Labels, check boxes and text fields all wrap: one long unwrapped check box widened
            // the whole column past the panel (1.0.3).
            bool labelWrap = GUI.skin.label.wordWrap, toggleWrap = GUI.skin.toggle.wordWrap, fieldWrap = GUI.skin.textField.wordWrap, buttonWrap = GUI.skin.button.wordWrap;
            GUI.skin.label.wordWrap = true; GUI.skin.toggle.wordWrap = true; GUI.skin.textField.wordWrap = true; GUI.skin.button.wordWrap = true;
            float height = _panelOpen ? Math.Min(680f, Screen.height - 24f) : 44f;
            GUILayout.BeginArea(new Rect(x, 12f, width, height), GUI.skin.box);
            if (GUILayout.Button(_panelOpen ? "LAN ▲ · F8" : LanText.T("LAN: играть вместе ▼ · F8"))) ToggleLanPanel();
            if (_panelOpen)
            {
                // 1.0.4: a plain scroll view around an area of fixed width. In a layout scroll view the
                // widest control that cannot wrap set the width of every line, so lines ran off the panel.
                var view = new Rect(6f, 36f, width - 12f, height - 42f);
                float contentWidth = view.width - 18f, contentHeight = Math.Max(_panelContentHeight, view.height);
                _panelScroll = GUI.BeginScrollView(view, _panelScroll, new Rect(0f, 0f, contentWidth, contentHeight));
                GUILayout.BeginArea(new Rect(0f, 0f, contentWidth, contentHeight));
                GUILayout.Label("LAN " + PluginVersion + LanText.T(" · до 8 игроков") + (_relayMode ? LanText.T(" · Через интернет-сервер") : LanText.T(" · Одна локальная сеть")));
                bool wasEnabled = GUI.enabled;
                GUI.enabled = wasEnabled && _links.Count == 0 && !_hosting; // switch only while idle
                int tab = GUILayout.Toolbar(_relayMode ? 1 : 0, new[] { LanText.T("Локальная сеть"), LanText.T("Через интернет-сервер") });
                GUI.enabled = wasEnabled;
                if ((tab == 1) != _relayMode) { _relayMode = tab == 1; _useRelayEntry.Value = _relayMode; _status = LanText.T("Не подключено"); }
                if (_relayMode) DrawRelayPanel(); else DrawLanPanel();
                var train = HostLink?.Train;
                if (train != null) { GUILayout.Label(train.Status); GUILayout.Label(train.StairHint); }
                GUILayout.Space(2f);
                if (Event.current.type == EventType.Repaint) _panelContentHeight = GUILayoutUtility.GetLastRect().yMax + 6f;
                GUILayout.EndArea();
                GUI.EndScrollView();
            }
            GUILayout.EndArea();
            GUI.skin.label.wordWrap = labelWrap; GUI.skin.toggle.wordWrap = toggleWrap; GUI.skin.textField.wordWrap = fieldWrap; GUI.skin.button.wordWrap = buttonWrap;
            if (!_hosting) LanStorageGame.DrawNotice();
            if (!_hosting) LanGuestDeath.Draw();
            if (!_hosting && connected && LanTrainControl.HostDead && !LanGuestDeath.Dead)
                GUI.Box(new Rect(Screen.width / 2f - 260f, 70f, 520f, 46f), LanText.T("Хост погиб. Когда он загрузит сохранение, вы перенесётесь к нему."));
            if (_hosting && !_panelOpen && KitPending())
                GUI.Box(new Rect(x, 124f, width, 56f), LanText.T("Новый друг пришёл с вещами. Откройте LAN (F8) и решите, принять ли их."));
            if (ApprovalPending() != null && !_panelOpen)
            {
                GUI.Box(new Rect(x, 64f, width, 56f), LanText.T("Друг подтвердил код. Откройте LAN (F8), чтобы разрешить."));
            }
            if (_partnerHealthEntry.Value && connected && Event.current.type == EventType.Repaint)
                foreach (var p in RemotePlayers()) DrawHealth(p);
            LanDowned.Draw();
            LanNotify.Draw();
            LanSkinPicker.Draw();
            }
            finally { LanHostTiming.EndCallback(callbackStarted); }
        }

        // 1.0.8: the host hears and sees a friend waiting for permission, and is reminded every
        // 20 seconds while the LAN panel stays closed.
        private void NotifyApproval()
        {
            if (ApprovalPending() == null) { _approvalNotified = false; _approvalRemindAt = 0f; return; }
            if (Time.unscaledTime < _approvalRemindAt || _approvalNotified && _panelOpen) return;
            LanNotify.Alert(LanText.T("Друг просит подключиться: откройте LAN (F8) и разрешите"));
            _approvalNotified = true; _approvalRemindAt = Time.unscaledTime + 20f;
        }

        // Host: the seat whose invitation is open now (one at a time), and the one whose friend waits
        // for permission; whether a new friend's belongings wait for the host's answer.
        private LanLink InvitingSeat() { foreach (var link in _links.Values) if (link.Pairing != null) return link; return null; }
        private LanLink ApprovalPending() { var seat = InvitingSeat(); return seat != null && seat.Pairing.PendingApproval ? seat : null; }
        private bool KitPending()
        {
            foreach (var link in _links.Values) if (link.Connected && link.GuestHost != null && link.GuestHost.PendingKit != null) return true;
            return false;
        }

        // OnGUI: the other players whose avatars are shown, by name, for the pointers.
        private LatencySeat[] LatencyReport()
        {
            double now = StateClock.Elapsed.TotalSeconds;
            var seats = new List<LatencySeat>();
            foreach (var link in _links.Values)
                if (link.Up && link.Session != 0 && link.Slot > 0 && link.Slot < LanProtocol.MaxPlayers)
                    seats.Add(new LatencySeat { Slot = (byte)link.Slot, Session = link.Session,
                        Milliseconds = link.Latency == null ? -1 : link.Latency.Milliseconds(now) });
            return seats.ToArray();
        }

        private IList<LanPlayerList.Row> PlayerListRows()
        {
            double now = StateClock.Elapsed.TotalSeconds;
            var rows = new List<LanPlayerList.Row>();
            var host = HostLink;
            rows.Add(new LanPlayerList.Row { Slot = _mySlot, Own = true,
                Name = string.IsNullOrEmpty(LanSkinPicker.NickName) ? LanSkinPicker.Label(_mySlot) : LanSkinPicker.NickName,
                Ping = _hosting ? 0 : host == null || host.Latency == null ? -1 : host.Latency.Milliseconds(now) });
            if (_hosting)
            {
                foreach (var link in _links.Values)
                    if (link.Up)
                        rows.Add(new LanPlayerList.Row { Slot = link.Slot, Name = LanSkinPicker.Label(link.Slot),
                            Ping = link.Latency == null ? -1 : link.Latency.Milliseconds(now) });
            }
            else if (host != null && host.Connected)
            {
                rows.Add(new LanPlayerList.Row { Slot = 0, Name = LanSkinPicker.Label(0), Ping = 0 });
                var roster = _roster.Snapshot();
                var report = host.Latency == null ? new LatencySeat[0] : host.Latency.ReportedSeats(now);
                if (report.Length != 0)
                {
                    foreach (var seat in report)
                    {
                        if (seat.Slot == _mySlot) continue;
                        bool knownOccupant = roster.Any(r => r.Player == seat.Slot && r.Session == seat.Session);
                        rows.Add(new LanPlayerList.Row { Slot = seat.Slot,
                            Name = knownOccupant ? LanSkinPicker.Label(seat.Slot) : LanText.T("Друг ") + seat.Slot,
                            Ping = host.Latency.ReportedMilliseconds(seat.Slot, seat.Session, now) });
                    }
                }
                else
                    foreach (var seat in roster)
                        rows.Add(new LanPlayerList.Row { Slot = seat.Player, Name = LanSkinPicker.Label(seat.Player), Ping = -1 });
            }
            rows.Sort((left, right) => left.Slot.CompareTo(right.Slot));
            return rows;
        }

        private List<KeyValuePair<string, Vector3>> PartnerPointers()
        {
            var list = new List<KeyValuePair<string, Vector3>>();
            foreach (var p in RemotePlayers())
                if (p.Avatar != null && p.Avatar.activeSelf) list.Add(new KeyValuePair<string, Vector3>(LanSkinPicker.Label(p.Slot), p.WorldPosition()));
            return list;
        }

        // 1.0.8: another player's health; 1.1.6: only while the player looks at it from close by, above
        // its head, in the game's own numbers (current / maximum), dimmed while its states are late.
        internal const float HealthLookRange = 12f;
        private GUIStyle _healthStyle, _healthShadow;
        private void DrawHealth(RemotePlayer p)
        {
            if (!p.HaveState) return;
            if (p.Avatar == null || !p.Avatar.activeInHierarchy || p.HealthMax == 0 && p.Health == LanProtocol.NoHealth) return;
            var manager = GlobalManager.global;
            var player = manager == null ? null : manager.controlledChar;
            var camera = manager == null || manager.MainCamera == null ? Camera.main : manager.MainCamera;
            var input = LanGame.Input;
            if (player == null || camera == null || input == null || (int)input.CurrentState != 1) return;
            Vector3 eye = camera.transform.position, root = p.Avatar.transform.position - Vector3.up * p.AvatarYOffset;
            Vector3 chest = root + Vector3.up * 1.2f, head = root + Vector3.up * 2.05f;
            float distance = Vector3.Distance(eye, chest);
            if (distance > HealthLookRange || distance < .3f) return;
            // On that player: within its half width (and a little more) of the view's centre.
            if (Vector3.Angle(camera.transform.forward, chest - eye) > Mathf.Atan2(.55f, distance) * Mathf.Rad2Deg + 2f) return;
            foreach (var hit in Physics.RaycastAll(eye, (chest - eye) / distance, distance - .4f, ~0, QueryTriggerInteraction.Ignore))
                if (hit.collider != null && !hit.collider.transform.IsChildOf(player.transform)) return; // behind a wall
            var screen = camera.WorldToScreenPoint(head);
            if (screen.z <= 0f) return;
            float share = p.HealthMax > 0 ? (float)p.HealthNow / p.HealthMax : p.Health / 100f;
            float alpha = Time.unscaledTime - p.StateAt > 3f ? .5f : 1f;
            if (_healthStyle == null)
            {
                _healthStyle = new GUIStyle(GUI.skin.label) { richText = false, wordWrap = false, fontSize = 13, fontStyle = FontStyle.Bold, alignment = TextAnchor.MiddleCenter };
                _healthStyle.normal.textColor = Color.white;
                _healthShadow = new GUIStyle(_healthStyle); _healthShadow.normal.textColor = Color.black;
            }
            var frame = new Rect(screen.x - 85f, Screen.height - screen.y - 22f, 170f, 22f);
            var fill = new Rect(frame.x + 3f, frame.y + 3f, (frame.width - 6f) * Mathf.Clamp01(share), frame.height - 6f);
            var previous = GUI.color;
            GUI.color = new Color(0f, 0f, 0f, .6f * alpha);
            GUI.DrawTexture(frame, Texture2D.whiteTexture);
            GUI.color = share > .5f ? new Color(.35f, .8f, .35f, alpha) : share > .25f ? new Color(.95f, .75f, .2f, alpha) : new Color(.9f, .25f, .2f, alpha);
            GUI.DrawTexture(fill, Texture2D.whiteTexture);
            GUI.color = new Color(1f, 1f, 1f, alpha);
            string text = LanSkinPicker.Label(p.Slot) + " · " + (p.Downed ? LanText.T("ранен") : p.HealthMax > 0 ? p.HealthNow + " / " + p.HealthMax : p.Health + "%");
            GUI.Label(new Rect(frame.x + 1f, frame.y + 1f, frame.width, frame.height), text, _healthShadow);
            GUI.Label(frame, text, _healthStyle);
            GUI.color = previous;
        }

        // 1.1.9: downed or dead, the helmet and weapon flashlights, a reload of the weapon in hand.
        private static byte LocalPoseExtras(ZombieFighterController player)
        {
            int pose = 0;
            try
            {
                if (LanDowned.Down) pose |= LanProtocol.PoseDowned;
                else if (LanGuestDeath.Dead || LanGuestDeath.LocalDead()) pose |= LanProtocol.PoseDead;
                var weapons = player.zombieFighterFireArmWeapon;
                if (weapons != null)
                {
                    if (weapons.HelmetFlashlightEnabled) pose |= LanProtocol.PoseHelmetLight;
                    var gun = weapons.GetSelectedGun();
                    if (gun != null)
                    {
                        if (gun.reloading) pose |= LanProtocol.PoseReload;
                        var lamp = weapons.FlashlightEnabled ? gun.GetComponentInChildren<WeaponFlashlight>(true) : null;
                        if (lamp != null && lamp.flashlight != null && lamp.flashlight.activeSelf) pose |= LanProtocol.PoseGunLight;
                    }
                }
            }
            catch (Exception) { }
            return (byte)pose;
        }

        // Aiming down the sights (the game's own aim state of the weapon in hand).
        private static bool LocalAiming(ZombieFighterController player)
        {
            var weapons = player == null ? null : player.weaponAnimator;
            return weapons != null && weapons.InputAim && RemoteEquipment.CaptureLocalItemId() >= 0;
        }

        // Where the player looks up (+) or down, from the view the shots leave from.
        private static float LocalPitch(ZombieFighterController player)
        {
            var rays = player == null ? null : player.zombieFighterRays;
            var view = rays == null ? null : rays.cameraPoint;
            if (view == null) return 0f;
            float pitch = Mathf.Asin(Mathf.Clamp(view.forward.y, -1f, 1f)) * Mathf.Rad2Deg;
            return float.IsNaN(pitch) ? 0f : Mathf.Clamp(pitch, -LanProtocol.MaxPitch, LanProtocol.MaxPitch);
        }

        // 1.1.6: health points as the game's own bar shows them (SetCurrentValue/SetMaxValue).
        private static void LocalHealthPoints(out ushort now, out ushort max)
        {
            now = max = 0;
            try
            {
                var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
                var bar = player == null ? null : player.zombieFighterIndicatorsBar;
                if (bar == null) return;
                float top = bar.MaxHealth, current = bar.deathRegister ? 0f : bar.currentHealth;
                if (float.IsNaN(top) || float.IsInfinity(top) || float.IsNaN(current) || float.IsInfinity(current) || top < 1f) return;
                max = (ushort)Mathf.Clamp(Mathf.RoundToInt(top), 1, 65535);
                now = (ushort)Mathf.Clamp(Mathf.RoundToInt(current), 0, max);
            }
            catch (Exception) { now = max = 0; }
        }

        private static byte LocalHealth()
        {
            try
            {
                var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
                var bar = player == null ? null : player.zombieFighterIndicatorsBar;
                if (bar == null) return LanProtocol.NoHealth;
                if (bar.deathRegister || bar.currentHealth <= 0f) return 0;
                float max = bar.MaxHealth, share = bar.currentHealth / max;
                if (!(max > 0f) || float.IsNaN(share) || float.IsInfinity(share)) return LanProtocol.NoHealth;
                return (byte)Mathf.Clamp(Mathf.RoundToInt(share * 100f), 1, 100); // alive: never 0
            }
            catch (Exception) { return LanProtocol.NoHealth; }
        }

        // 1.0.5: the panel has a framed area for creating a room and another for joining one,
        // each with its own fields and button; the shared status and "disconnect" come below.
        private GUIStyle _sectionTitle;
        private void BeginSection(string title)
        {
            if (_sectionTitle == null) _sectionTitle = new GUIStyle(GUI.skin.label) { fontStyle = FontStyle.Bold };
            _sectionTitle.wordWrap = true;
            GUILayout.BeginVertical(GUI.skin.box);
            GUILayout.Label(title, _sectionTitle);
        }
        private static void EndSection() { GUILayout.EndVertical(); GUILayout.Space(6); }

        private void DrawSessionFooter()
        {
            GUILayout.Label(LanText.T("Состояние: ") + LanText.T(_status));
            if (GUILayout.Button(LanText.T("Отключиться / закрыть комнату"))) StopNetwork();
            DrawCombat();
            DrawGuestProfile();
        }

        private void DrawLanPanel()
        {
            BeginSection(LanText.T("1. Создать свою комнату (вы — хост)"));
            GUILayout.Label(LanText.T("Имя вашей комнаты:"));
            _roomName = GUILayout.TextField(_roomName, 20);
            if (GUILayout.Button(LanText.T("Создать комнату"))) StartHosting();
            if (_hosting)
            {
                var seat = InvitingSeat();
                if (seat != null && seat.Pairing.PendingApproval)
                {
                    GUILayout.Label(LanText.T("Код подтверждён с адреса ") + seat.Pairing.PendingPeer + LanText.T(". Разрешить подключение?"));
                    GUILayout.Label(LanText.T("IP — адрес соединения, а не подтверждение личности. Сверьте запрос с другом."));
                    GUILayout.BeginHorizontal();
                    if (GUILayout.Button(LanText.T("Разрешить"))) seat.Pairing.Approve();
                    if (GUILayout.Button(LanText.T("Отклонить"))) seat.Pairing.Reject();
                    GUILayout.EndHorizontal();
                }
                else if (seat == null && FreeSlot() != 0)
                {
                    if (GUILayout.Button(GuestCount() == 0 ? LanText.T("Новый код") : LanText.T("Пригласить ещё одного друга (новый код)"))) OpenSeat();
                }
                else if (seat != null && seat.Pairing.Code.Length != 0)
                {
                    GUILayout.Label(LanText.T("Код для друга: ") + seat.Pairing.Code + LanText.T(" · осталось ") + seat.Pairing.SecondsLeft + LanText.T(" с"));
                    if (GUILayout.Button(LanText.T("Скопировать код"))) GUIUtility.systemCopyBuffer = seat.Pairing.Code;
                }
                DrawSeats();
            }
            else GUILayout.Label(LanText.T("После создания здесь появится код из шести цифр — передайте его другу. Играть можно до восьми человек: каждому другу — свой код."));
            GUILayout.Label(LanText.T("Все компьютеры должны быть в одной локальной сети."));
            EndSection();

            BeginSection(LanText.T("2. Войти в комнату друга"));
            if (GUILayout.Button(_roomBrowser != null && !_roomBrowser.Finished ? LanText.T("Поиск…") : LanText.T("Найти комнаты в сети"))) RefreshRooms();
            if (_roomBrowser != null)
            {
                GUILayout.Label(_roomBrowser.Status);
                if (_roomBrowser.Finished && _roomBrowser.Rooms.Length == 0)
                    GUILayout.Label(LanText.T("Для разрешения LAN в Windows запустите «Настроить LAN.cmd» из папки игры на обоих ПК."));
                if (_roomBrowser.Rooms.Length != 0)
                {
                    _roomScroll = GUILayout.BeginScrollView(_roomScroll, GUILayout.Height(Math.Min(155f, 30f * _roomBrowser.Rooms.Length + 8f)));
                    foreach (var room in _roomBrowser.Rooms)
                    {
                        GUILayout.BeginHorizontal();
                        GUILayout.Label(room.Name + " · " + room.Address + (room.Busy ? LanText.T(" · занято") : room.PinActive ? LanText.T(" · код активен") : LanText.T(" · нужен новый код")));
                        bool previousEnabled = GUI.enabled;
                        GUI.enabled = previousEnabled && room.PinActive && !_hosting && _links.Count == 0;
                        if (GUILayout.Button(LanText.T("Войти"), GUILayout.Width(62f))) StartJoining(room.Address);
                        GUI.enabled = previousEnabled; GUILayout.EndHorizontal();
                    }
                    GUILayout.EndScrollView();
                }
            }
            GUILayout.Label(LanText.T("Шесть цифр от хоста:"));
            _joinCode = GUILayout.TextField(_joinCode, 6);
            GUILayout.Label(LanText.T("Резервный IPv4 адрес хоста (необязательно):"));
            _manualAddress = GUILayout.TextField(_manualAddress, 15);
            if (GUILayout.Button(LanText.T("Подключиться"))) StartJoining();
            GUILayout.Label(LanText.T("Код действует ") + LanLocalText.PinSeconds + LanText.T(" секунд, потом хост разрешает подключение. Список комнат не подтверждает личность хоста: всё равно нужен его код."));
            EndSection();

            DrawSessionFooter();
        }

        private void DrawRelayPanel()
        {
            bool wasEnabled = GUI.enabled;
            bool idle = _links.Count == 0 && !_hosting; // settings are fixed for a running session
            GUILayout.Label(CustomRelayConfigured ? LanText.T("Сервер: свой, из конфига BepInEx ([Relay] CustomServer)") : RelayDefaults.Available ? LanText.T("Сервер: встроенный в эту сборку мода") :
                LanText.T("В этой сборке нет интернет-сервера: играйте по локальной сети или скачайте готовую сборку мода (GitHub, Releases)"));

            BeginSection(LanText.T("1. Создать свою комнату (вы — хост)"));
            GUI.enabled = wasEnabled && idle;
            GUILayout.Label(LanText.T("Название комнаты (друг увидит его после проверки пароля):"));
            _roomName = GUILayout.TextField(_roomName, 20);
            _relayPublic = GUILayout.Toggle(_relayPublic, LanText.T(" Показать комнату в общем списке (на сервере её увидят другие игроки)"));
            GUILayout.Label(_relayPublic ? LanText.T("Пароль комнаты (обязательно для общего списка; придумайте сами, от 8 символов):") :
                LanText.T("Свой пароль комнаты (необязательно; пусто — случайный PIN):"));
            _relayHostSecret = GUILayout.PasswordField(_relayHostSecret, '*', LanRelayText.MaxSecret);
            string warning = _relayPublic ? LanRelayText.PublicSecretProblem(_relayHostSecret) : LanRelayText.SecretWarning(_relayHostSecret);
            if (warning != null) GUILayout.Label((_relayPublic ? "" : LanText.T("Внимание: ")) + warning);
            if (_relayPublic) GUILayout.Label(LanText.T("В списке видно только название «") + LanRelayText.PublicName(_roomName) + LanText.T("». Пароль на сервер не уходит; каждого игрока вы всё равно разрешаете сами."));
            GUI.enabled = wasEnabled;
            if (GUILayout.Button(LanText.T("Создать комнату"))) StartHosting();
            if (_hosting)
            {
                var seat = InvitingSeat();
                if (seat != null && seat.Pairing.PendingApproval)
                {
                    GUILayout.Label(LanText.T("Друг подтвердил пароль комнаты через сервер. Разрешить подключение?"));
                    GUILayout.Label(LanText.T("Сервер не показывает адрес друга. Убедитесь, что пароль вводил именно он."));
                    GUILayout.BeginHorizontal();
                    if (GUILayout.Button(LanText.T("Разрешить"))) seat.Pairing.Approve();
                    if (GUILayout.Button(LanText.T("Отклонить"))) seat.Pairing.Reject();
                    GUILayout.EndHorizontal();
                }
                else if (seat == null && FreeSlot() != 0)
                {
                    if (GUILayout.Button(GuestCount() == 0 ? LanText.T("Новая комната") : LanText.T("Пригласить ещё одного друга (новая комната)"))) OpenSeat();
                }
                else if (seat != null && seat.Pairing.InvitationOpen && seat.Pairing.RelayRoom.Length != 0)
                {
                    string room = LanRelayText.FormatRoom(seat.Pairing.RelayRoom);
                    bool custom = seat.Pairing.CustomSecret;
                    if (_hostedPublic) GUILayout.Label(LanText.T("«") + LanRelayText.PublicName(_seatName) + LanText.T("» в общем списке · код ") + room + LanText.T(" · пароль задан вами"));
                    else GUILayout.Label(LanText.T("«") + _seatName + LanText.T("» · код ") + room + (custom ? LanText.T(" · пароль задан вами") : " · PIN " + seat.Pairing.Code) +
                        LanText.T(" · осталось ") + seat.Pairing.SecondsLeft + LanText.T(" с"));
                    if (GUILayout.Button(LanText.T("Скопировать для друга")))
                        GUIUtility.systemCopyBuffer = custom ? LanText.T("Комната ") + room + LanText.T(" (пароль сообщу отдельно)") : LanText.T("Комната ") + room + ", PIN " + seat.Pairing.Code;
                }
                GUILayout.Label(GuestCount() == 0 ? LanText.T("Передайте другу код комнаты и PIN или пароль, например в мессенджере.") :
                    LanText.T("Каждому другу — своя комната на сервере: передайте следующему её код") + (_seatsOpenThemselves ? LanText.T(" (пароль тот же).") : LanText.T(" и PIN.")));
                DrawSeats();
            }
            else GUILayout.Label(LanText.T("После создания здесь появятся код комнаты и PIN — передайте их другу."));
            GUILayout.Label(_hostedPublic && _hosting ? LanText.T("Пароль на сервер не передаётся; комната в списке около 28 минут, до 10 попыток входа.") :
                LanText.T("Пароль на сервер не передаётся; три попытки входа на комнату."));
            EndSection();

            BeginSection(LanText.T("2. Войти в комнату друга"));
            bool listing = _relayRooms != null && !_relayRooms.Finished;
            GUI.enabled = wasEnabled && idle && !listing && Time.unscaledTime - _relayRoomsAt >= 3f;
            if (GUILayout.Button(listing ? LanText.T("Загрузка списка…") : LanText.T("Открытые комнаты на сервере"))) RefreshRelayRooms();
            GUI.enabled = wasEnabled && idle;
            if (_relayRooms != null)
            {
                GUILayout.Label(_relayRooms.Status);
                var rooms = _relayRooms.Finished ? _relayRooms.Rooms : new LanRoomInfo[0];
                if (rooms.Length != 0)
                {
                    _relayRoomsScroll = GUILayout.BeginScrollView(_relayRoomsScroll, GUILayout.Height(Math.Min(155f, 30f * rooms.Length + 8f)));
                    foreach (var room in rooms)
                    {
                        GUILayout.BeginHorizontal();
                        GUILayout.Label(room.Name + LanText.T(" · есть место · по паролю"));
                        if (GUILayout.Button(LanText.T("Выбрать"), GUILayout.Width(80f)))
                        {
                            _relayRoomInput = LanRelayText.FormatRoom(room.RelayRoom);
                            _status = LanText.T("Комната «") + room.Name + LanText.T("» выбрана. Введите пароль, который сообщил хост, и нажмите «Подключиться»");
                        }
                        GUILayout.EndHorizontal();
                    }
                    GUILayout.EndScrollView();
                }
            }
            GUILayout.Label(LanText.T("Код комнаты от хоста (8 символов, например 7Q2M-XK4D):"));
            _relayRoomInput = GUILayout.TextField(_relayRoomInput, 9);
            GUILayout.Label(LanText.T("PIN или пароль комнаты от хоста:"));
            GUILayout.BeginHorizontal();
            _relayJoinSecret = _showJoinSecret ? GUILayout.TextField(_relayJoinSecret, LanRelayText.MaxSecret) :
                GUILayout.PasswordField(_relayJoinSecret, '*', LanRelayText.MaxSecret);
            _showJoinSecret = GUILayout.Toggle(_showJoinSecret, LanText.T("показать"), GUILayout.Width(80f));
            GUILayout.EndHorizontal();
            GUI.enabled = wasEnabled;
            if (GUILayout.Button(LanText.T("Подключиться"))) StartJoining();
            GUILayout.Label(LanText.T("Хост создаёт комнату, сообщает её код и PIN или пароль, а потом разрешает подключение."));
            EndSection();

            DrawSessionFooter();
        }

        private void DrawCombat()
        {
            if (!Connected || _zombies == null) return;
            if (!_hosting) { GUILayout.Label(_zombies.Combat.Description); return; }
            foreach (var link in LinkList())
            {
                var combat = link.Connected ? _zombies.CombatOf(link.Slot) : null;
                if (combat == null) continue;
                string who = LanSkinPicker.Label(link.Slot);
                GUILayout.Label(who + ": " + combat.Description);
                if (combat.Approved && GUILayout.Button(LanText.T("Запретить бой до новой комнаты: ") + who)) combat.DenyOrRevoke();
            }
        }

        // Host (2.0.0): the guests of this room, each with a button that sends it away (done in Update).
        private void DrawSeats()
        {
            GUILayout.Label(LanText.T("Друзей в комнате: ") + GuestCount() + LanText.T(" из ") + LanSeats.MaxGuests);
            foreach (var link in LinkList())
            {
                if (link.Network == null) continue;
                GUILayout.BeginHorizontal();
                GUILayout.Label(LanSkinPicker.Label(link.Slot) + (link.Connected ? "" : LanText.T(" · нет связи")));
                if (GUILayout.Button(LanText.T("Отключить"), GUILayout.Width(96f))) _kick = link.Slot;
                GUILayout.EndHorizontal();
            }
        }

        // Built-in relay of this build, or the advanced Custom* config entries.
        // Returns null with _status set on error. Nothing here is written back to config.
        private LanRelayOptions RelayOptions(bool join)
        {
            string room = "";
            if (join && (room = LanRelayText.NormalizeRoom(_relayRoomInput)) == null) { _status = LanText.T("Введите код комнаты сервера: 8 символов, например 7Q2M-XK4D"); return null; }
            if (!CustomRelayConfigured)
            {
                if (RelayDefaults.Available) return RelayDefaults.Create(room);
                _status = LanText.T("В этой сборке нет интернет-сервера: играйте по локальной сети или скачайте готовую сборку мода (GitHub, Releases)"); return null;
            }
            string text = _customServerEntry.Value.Trim();
            int port = LanRelayText.DefaultPort, colon = text.LastIndexOf(':');
            if (colon > 0 && (!int.TryParse(text.Substring(colon + 1), System.Globalization.NumberStyles.None, System.Globalization.CultureInfo.InvariantCulture, out port) || port < 1 || port > 65535))
            { _status = LanText.T("Свой сервер в конфиге: неверный порт"); return null; }
            IPAddress server;
            if (!IPAddress.TryParse(colon > 0 ? text.Substring(0, colon) : text, out server) || !LanRelayText.ValidServer(server))
            { _status = LanText.T("Свой сервер в конфиге: нужен публичный IPv4-адрес"); return null; }
            byte[] fingerprint = LanRelayText.ParseFingerprint(_customFingerprintEntry.Value);
            if (fingerprint == null) { _status = LanText.T("Свой сервер в конфиге: укажите CustomFingerprint (64 шестнадцатеричных символа)"); return null; }
            string key = _customKeyEntry.Value ?? "";
            if (System.Text.Encoding.UTF8.GetByteCount(key) > 64) { _status = LanText.T("Свой сервер в конфиге: ключ длиннее 64 байт"); return null; }
            return new LanRelayOptions { Server = server, Port = port, Fingerprint = fingerprint, AccessKey = key, Room = room };
        }

        private static bool GameMenusVisible()
        {
            var manager = GlobalManager.global;
            var menus = manager == null ? null : manager.canvas;
            if (menus == null) menus = Object.FindObjectOfType<Zompiercer.GUI.GUIManager>();
            return Time.timeScale == 0f || (menus != null && ((menus.mainGameMenu != null && menus.mainGameMenu.activeInHierarchy) ||
                (menus.startGameMenu != null && menus.startGameMenu.activeInHierarchy) ||
                (menus.inGameMenu != null && menus.inGameMenu.activeInHierarchy)));
        }
        private void ToggleLanPanel()
        {
            _panelOpen = !_panelOpen;
            if (_panelOpen && _roomBrowser == null && !_relayMode) RefreshRooms();
            UpdateLanInput();
        }
        private void CloseConnectedPanel()
        {
            _panelOpen = false;
            ReleaseLanInput();
        }
        private void UpdateLanInput()
        {
            var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
            var scenes = GlobalSceneManager.global;
            var saves = Zompiercer.SaveLoad.SaveLoadCore.global;
            var input = LanGame.Input;
            // The host's storages use the game's own windows, which manage the cursor themselves.
            // Never capture the loader's disabled control state as the state to restore.
            if (!_panelOpen || GameMenusVisible() || player == null ||
                scenes != null && scenes.SceneCurrentlyLoading || saves != null && saves.LoadingNow ||
                input == null || (int)input.CurrentState != 1 || ClientTravelHooks.Loading ||
                ClientTravelHooks.LoadFailure != null || _travel != null && _travel.Active ||
                _lanHeldPlayer != player && !player.controlEnabled)
            { ReleaseLanInput(); return; }
            if (_lanHeldPlayer != player)
            {
                ReleaseLanInput(); _lanHeldPlayer = player;
                _lanPreviousControl = player.controlEnabled; _lanPreviousCursor = Cursor.visible; _lanPreviousLock = Cursor.lockState;
            }
            player.controlEnabled = false; Cursor.lockState = CursorLockMode.None; Cursor.visible = true;
        }
        private void ReleaseLanInput()
        {
            var player = _lanHeldPlayer;
            if (player == null || GlobalManager.global == null || GlobalManager.global.controlledChar != player)
            { _lanHeldPlayer = null; return; }
            if (GameMenusVisible()) return;
            bool gameplay = LanGame.Input != null && (int)LanGame.Input.CurrentState == 1;
            var saves = Zompiercer.SaveLoad.SaveLoadCore.global;
            if (gameplay && (GlobalSceneManager.global == null || !GlobalSceneManager.global.SceneCurrentlyLoading) &&
                (saves == null || !saves.LoadingNow) && !ClientTravelHooks.Loading && ClientTravelHooks.LoadFailure == null)
            { _lanHeldPlayer = null; player.controlEnabled = _lanPreviousControl; Cursor.lockState = _lanPreviousLock; Cursor.visible = _lanPreviousCursor; }
        }
        // 1.1.6: the game ends its own load of a saved world with CharGuiOn and CursorLock
        // (SaveLoadCore.LoadWorldFromDataCoroutine); a guest's world comes through the scene loader,
        // which skips both for a location other than the first. Without them the quick-access belt
        // ignored its keys until Escape -> "back to the game" did the same. Done once the player
        // stands in the host's world with no window, menu or LAN panel open.
        private void FinishNativeLoad()
        {
            if (!_nativeHudPending) return;
            if (!Connected || _hosting) { _nativeHudPending = false; return; }
            var manager = GlobalManager.global;
            var player = manager == null ? null : manager.controlledChar;
            var gui = manager == null ? null : manager.canvas;
            var input = LanGame.Input;
            if (!_clientPlacedNearHost || player == null || gui == null || input == null || (int)input.CurrentState != 1 || _panelOpen ||
                _lanHeldPlayer != null || LanGuestDeath.Dead || GameMenusVisible() || GameWindowOpen() ||
                GlobalSceneManager.global == null || GlobalSceneManager.global.SceneCurrentlyLoading || ClientTravelHooks.Loading) return;
            _nativeHudPending = false;
            try { gui.CharGuiOn(); gui.CursorLock(); Logger.LogInfo("Guest world ready: character HUD on, cursor locked"); }
            catch (Exception ex) { Logger.LogWarning("Guest HUD not finished: " + ex.GetType().Name + ": " + ex.Message); }
        }

        private void RefreshRooms()
        {
            if (_roomBrowser != null && !_roomBrowser.Finished) return;
            _roomBrowser?.Dispose();
            try { _roomSearchReported = false; _roomBrowser = LanIsolatedSession.Browse(); }
            catch (Exception ex) { _roomBrowser = null; _status = LanText.T("Поиск комнат недоступен; можно использовать IP"); Logger.LogWarning(ex.GetType().Name); }
        }

        private void StartHosting()
        {
            if (LanSaveIsolation.Active) { _status = LanText.T("После игры клиентом перезапустите игру для создания хоста"); return; }
            if (_hosting && GuestCount() != 0) { _status = LanText.T("Комната уже открыта: пригласите ещё друга кнопкой ниже или отключитесь"); return; }
            if (ApprovalPending() != null) { _status = LanText.T("Сначала разрешите или отклоните запрос друга"); return; }
            if (ClientTravelHooks.Loading || (GlobalSceneManager.global != null && GlobalSceneManager.global.SceneCurrentlyLoading))
            { _status = LanText.T("Дождитесь окончания загрузки мира"); return; }
            LanRelayOptions relay = null;
            string secret = "";
            if (_relayMode)
            {
                // Empty: random six-digit PIN. Otherwise the host's own password (6..64 characters).
                secret = LanRelayText.NormalizeSecret(_relayHostSecret);
                if (secret.Length != 0 && !LanRelayText.ValidSecret(secret)) { _status = LanText.T("Пароль комнаты: от 6 до 64 символов, без управляющих символов"); return; }
                string problem = _relayPublic ? LanRelayText.PublicSecretProblem(secret) : null;
                if (problem != null) { _status = problem; return; }
                if ((relay = RelayOptions(false)) == null) return;
                if (_relayPublic) relay.PublicName = LanRelayText.PublicName(_roomName);
            }
            try
            {
                LanInventoryGuard.BackupSavesBeforeSession(Logger);
                LanInventoryGuard.CaptureCheckpoint("before-host-session", Logger);
                StopNetwork();
                _hosting = true;
                _hostedPublic = relay != null && relay.PublicName.Length != 0;
                // 2.0.0: every seat has its own invitation: a LAN code on the seat's own port, or a relay
                // room of its own with the same password (each with a new PIN, without one). With the
                // host's own password the next seat opens by itself once one is taken.
                _seatName = LanLocalText.CleanName(_roomName); _seatRelay = relay; _seatSecret = secret;
                _seatsOpenThemselves = relay != null && secret.Length != 0;
                OpenSeat();
                Logger.LogInfo(relay != null ? "Relay invitation requested from the " + (CustomRelayConfigured ? "custom" : "built-in") + " relay; room code and secret omitted from logs"
                    : "LAN invitation opened for " + LanLocalText.PinSeconds + " seconds; PIN omitted from logs");
            }
            catch (Exception ex)
            {
                _status = LanText.T("Не удалось создать LAN-сессию: ") + ex.Message;
                Logger.LogError(ex);
                StopSocketOnly();
            }
        }

        // Host (2.0.0): the lowest free seat (1..LanSeats.MaxGuests; 0: all taken), and how many are taken.
        private int FreeSlot() { for (int slot = 1; slot <= LanSeats.MaxGuests; slot++) if (!_links.ContainsKey(slot)) return slot; return 0; }
        private int GuestCount() { int taken = 0; foreach (var link in _links.Values) if (link.Network != null) taken++; return taken; }
        private int ConnectedGuests() { int up = 0; foreach (var link in _links.Values) if (link.Connected) up++; return up; }

        // Host (2.0.0): a new seat with its own worker and invitation, while a seat is free and no other
        // invitation is open (the LAN pairing and discovery ports serve one seat at a time).
        private void OpenSeat()
        {
            int slot = FreeSlot();
            if (!_hosting || slot == 0 || InvitingSeat() != null) return;
            var link = new LanLink(slot);
            try
            {
                link.Isolated = _seatRelay != null ? LanIsolatedSession.RelayHost(_seatRelay, NetworkGameVersion, _seatName, _seatSecret)
                    : LanIsolatedSession.Host(_seatName, NetworkGameVersion, slot - 1);
            }
            catch (Exception ex) { _status = LanText.T("Не удалось открыть место для друга: ") + ex.Message; Logger.LogError(ex); return; }
            link.Pairing = link.Isolated; link.OpenedAt = Time.unscaledTime;
            _links[slot] = link;
            LanSkinPicker.Names[slot] = "";
            _status = link.Pairing.Status;
            Logger.LogInfo("Seat " + slot + " invites a friend; room code, PIN and password omitted from logs");
        }

        // Host: a guest the panel sends away, and a seat that opens by itself once it is due.
        private void HostSeatsTick()
        {
            if (_kick != 0)
            {
                int slot = _kick; _kick = 0;
                LanLink link;
                if (_links.TryGetValue(slot, out link))
                {
                    string who = LanSkinPicker.Label(slot);
                    Logger.LogInfo("The host disconnected guest " + slot);
                    DropLink(link, null);
                    _status = who + LanText.T(" отключён");
                }
            }
            if (_openSeatAt >= 0f && Time.unscaledTime >= _openSeatAt)
            {
                _openSeatAt = -1f;
                if (_seatsOpenThemselves) OpenSeat();
            }
        }

        // The relay's public room list (0.13.0), read by a short-lived worker of its own.
        private void RefreshRelayRooms()
        {
            if (_relayRooms != null && !_relayRooms.Finished) return;
            _relayRooms?.Dispose(); _relayRooms = null;
            _relayRoomsAt = Time.unscaledTime;
            var relay = RelayOptions(false);
            if (relay == null) return;
            try { _relayRooms = LanIsolatedSession.RelayBrowse(relay); }
            catch (Exception ex) { _status = LanText.T("Список комнат недоступен"); Logger.LogWarning("Relay room list: " + ex.GetType().Name); }
        }

        private void StartJoining(IPAddress selectedAddress = null)
        {
            if (!ClientTravelHooks.Ready) { _status = LanText.T("Переход между локациями недоступен; смотрите журнал LAN"); return; }
            if (!LanSaveIsolation.Ready || ClientTravelHooks.LoadFailure != null)
            { _status = LanText.T("Защита сохранений гостя отключилась после ошибки; перезапустите игру и подключитесь снова"); return; }
            if (LanStorageGame.Failure != null || LanWorldItems.Failure != null || LanWorldWork.Failure != null || LanTrainBuild.Failure != null)
            { _status = LanText.T("Общие хранилища и предметы недоступны в этой версии игры; смотрите журнал LAN"); return; }
            if (!LanWorldCatalog.Ready)
            { _status = LanWorldCatalog.Failure == null ? LanText.T("Проверка ресурсов игры; повторите подключение чуть позже") : LanText.T("Ресурсы игры изменились; нужен обновлённый каталог LAN"); return; }
            if (GlobalManager.global != null && GlobalManager.global.controlledChar != null)
            { _status = LanText.T("Для подключения перезапустите игру и войдите из главного меню"); return; }
            // LAN: the six-digit 10-second PIN. Relay: the host's PIN or room password.
            string joinCode = _relayMode ? LanRelayText.NormalizeSecret(_relayJoinSecret) : (_joinCode ?? "").Trim();
            if (_relayMode ? !LanRelayText.ValidSecret(joinCode) : !LanLocalText.ValidPin(joinCode))
            { _status = _relayMode ? LanText.T("Введите PIN или пароль комнаты от хоста (от 6 символов)") : LanText.T("Введите шесть цифр свежего кода от хоста"); return; }
            IPAddress address = selectedAddress;
            LanRelayOptions relay = null;
            if (_relayMode) { if ((relay = RelayOptions(true)) == null) return; }
            else if (address == null && !string.IsNullOrWhiteSpace(_manualAddress) &&
                (!IPAddress.TryParse(_manualAddress.Trim(), out address) || address.AddressFamily != AddressFamily.InterNetwork))
            { _status = LanText.T("Резервный адрес должен быть IPv4 адресом хоста"); return; }
            try
            {
                // 2.8.4: a guest's later session: the player's own saves are out of reach since the first one (backed
                // up then). A copy now would be of the previous session folder and push real backups out of the newest five.
                if (!LanSaveIsolation.Active) LanInventoryGuard.BackupSavesBeforeSession(Logger);
                StopNetwork();
                _hosting = false;
                var link = new LanLink(0);
                link.Isolated = relay != null ? LanIsolatedSession.RelayJoin(joinCode, relay, NetworkGameVersion)
                    : LanIsolatedSession.Join(joinCode, address, NetworkGameVersion);
                link.Pairing = link.Isolated;
                _links[0] = link;
                _status = link.Pairing.Status;
                Logger.LogInfo(relay != null ? "Joining a relay room via the " + (CustomRelayConfigured ? "custom" : "built-in") + " relay; room code and secret omitted from logs"
                    : "Searching LAN for invitation; PIN omitted from logs");
            }
            catch (Exception ex)
            {
                _status = LanText.T("Ошибка подключения: ") + ex.Message;
                Logger.LogError(ex);
                StopSocketOnly();
            }
        }

        private void StopNetwork()
        {
            // 1.4.5 (2.0.0: over every link): the others learn at once that this player leaves.
            var leaving = new List<LanLink>();
            foreach (var link in _links.Values) if (SendLeave(link)) leaving.Add(link);
            var flush = System.Diagnostics.Stopwatch.StartNew();
            foreach (var link in leaving) link.Isolated?.Flush(Math.Max(0, 400 - (int)flush.ElapsedMilliseconds));
            _lostAt = -1f;
            _zombies?.Dispose(); _zombies = null;
            LanStorageGame.CloseWindow(StorageClient);
            foreach (var link in _links.Values) EndLink(link);
            _clock.Reset();
            if (!ClientTravelHooks.Loading && ClientTravelHooks.LoadFailure == null && LanSaveIsolation.Failure == null)
                _travel?.Complete();
            StopSocketOnly();
            LanStorageGame.GuestOpenScene = null;
            LanWorldDoors.GuestToggle = null; LanWorldDoors.GuestUnlock = null; LanQuests.Request = null;
            LanQuests.ResetSession();
            LanDifficulty.LootActive = false; LanDifficulty.HostRestore(); LanDifficulty.GuestRestore(); LanExtraWeapons.Players = null; LanWeather.GuestRestore();
            LanTakables.GuestAbort(); LanWorldItems.PartnerAvatar = null;
            LanSleep.Reset(); LanExplosions.Clear(); LanThrows.Clear(); LanThrows.GuestThrow = null; LanTrainDecor.GuestRequest = null; LanFuelStation.Clear();
            LanWorldItems.Dropped.Clear(); LanWorldItems.Placed.Clear(); LanWorldItems.GuestActive = false; LanWorldWork.GuestWork = null;
            LanTrainBuild.GuestAttached = false; LanTrainBuild.GuestBuild = null; LanTrainBuild.GuestPlace = null; LanTrainBuild.GuestFurniture = null; LanTrainBuild.GuestDismantle = null;
            LanTrainControl.GuestAttached = false; LanTrainControl.GuestRequest = null; LanTrainControl.ReleaseGuest(); _marks = null;
            LanTrainControl.HostGuestCar = null;
            _chat?.Close(); _chat = null;
            _playerList?.Close();
            if (LanGuestDeath.Dead) LanGuestDeath.Respawn(); // never left dead without a session
            _deathSent = false; _deathLeftItems = false; _respawning = false;
            HideOthers(); _others.Clear(); _roster.Reset();
            RemoteNativeGrip.Clear();
            _hosting = false;
            _mySlot = 0; LanMarks.LocalSlot = 0; Array.Clear(LanSkinPicker.Names, 0, LanSkinPicker.Names.Length);
            _seatRelay = null; _seatSecret = ""; _seatsOpenThemselves = false; _openSeatAt = -1f; _kick = 0;
            _joinCode = ""; _relayJoinSecret = "";
            _joinStartedGame = false;
            _startedLocalNewGame = false;
            _clientPlacedNearHost = false;
            _stateSequence = 0;
            _inventoryReadyCaptured = false;
            _worldEpoch = 0; _worldSequence = 0; _receivedWorldSequence = 0; _clientLoadEpoch = 0;
            _hostWorldScene = null; _hostSawLoading = false; _hostWorldReady = false; _hostReadySince = -1f;
            _clientWorld = null; _nextTravelAttempt = 0;
            _readySince = -1f;
            _status = LanText.T("Не подключено");
        }

        // A link's own parts end with it: its train frames, profile keeper, storage views, what its guest
        // carries and its avatar.
        private void EndLink(LanLink link)
        {
            link.Train?.Freeze();
            link.GuestHost?.End(); link.StorageHost?.End(); link.StorageClient?.End();
            link.SceneStates?.Clear(); link.WorldItems?.ClearShown();
            if (!_hosting) LanFarm.ClearGuest();
            if (_hosting)
            {
                _zombies?.RemoveRemote(link.Slot);
                LanTakables.Untrack(link.Slot); LanSleep.Forget(link.Slot); LanStorageGame.GuestWorking.Remove(link.Slot);
            }
            HideAvatar(link.Player);
        }

        // Host (2.0.0): a guest's seat closes (it left, the host sent it away, it did not come back, or the
        // invitation ended unused): its worker stops and the seat is free for another guest.
        private void DropLink(LanLink link, string alert)
        {
            if (SendLeave(link)) link.Isolated?.Flush(200);
            EndLink(link);
            link.Isolated?.Dispose();
            link.Isolated = link.Network = link.Pairing = null;
            link.Connected = false; link.Peer = null;
            _links.Remove(link.Slot);
            LanSkinPicker.Names[link.Slot] = "";
            if (alert != null) LanNotify.Alert(alert);
            if (_seatsOpenThemselves && link.ConnectedAt >= 0f) _openSeatAt = Time.unscaledTime + 2f;
        }

        // 1.4.5: the other player learns at once that this player leaves (not after 30 s of silence).
        private bool SendLeave(LanLink link)
        {
            if (link.Network == null || !link.Connected || link.Session == 0) return false;
            try
            {
                for (int i = 0; i < 2; i++) SendPacket(link, new Packet { Kind = PacketKind.Leave });
                return true;
            }
            catch (Exception ex) { Logger.LogWarning("Leave not sent: " + ex.GetType().Name + ": " + ex.Message); return false; }
        }

        // The local player exits to the main menu: its session ends (the host's room closes with it).
        private void LeaveToMenu()
        {
            if (_links.Count == 0) return;
            Logger.LogInfo(_hosting ? "Host left for the main menu; the session ends" : "Guest left for the main menu; the session ends");
            StopNetwork();
        }

        // The other end is silent: the host waits for that guest (at most GuestWaitForHost, then its seat
        // is free), a guest waits for its host (at most GuestWaitForHost, then it leaves too).
        private void PeerLost(LanLink link, string alert)
        {
            LinkDown(link);
            link.Network.Restart();
            link.Player.Scene = null;
            _status = _hosting ? LanText.T("Ожидание: ") + LanSkinPicker.Label(link.Slot) : LanText.T("Связь потеряна; повторное подключение");
            LanNotify.Alert(alert);
        }

        // A link's session ended (silence, or its worker restarted it): its player's avatar and train
        // frames stop; a host stops that guest's zombie combat, a guest everything of its host's world.
        private void LinkDown(LanLink link)
        {
            link.Connected = false;
            link.Train?.Freeze();
            link.Player.Poses.Clear(); HideAvatar(link.Player);
            if (_hosting)
            {
                link.Peer = null; link.LastState = null; link.SentStates.Clear();
                if (link.LostAt < 0f) link.LostAt = Time.unscaledTime;
                _zombies?.RemoveRemote(link.Slot); LanSleep.Forget(link.Slot);
                return;
            }
            _zombies?.Freeze(); _clock.Freeze(); HideOthers();
            if (_lostAt < 0f) _lostAt = Time.unscaledTime;
        }

        // Guest: the host left (or did not come back in time): back to the main menu.
        private const float GuestWaitForHost = 180f;
        private bool _menuPending;
        private void HostLeft(string reason)
        {
            bool inWorld = _clientSavePath != null && GlobalManager.global != null && GlobalManager.global.controlledChar != null;
            Logger.LogInfo(reason + "; the guest leaves the host's world");
            var host = HostLink;
            if (host != null) host.Connected = false; // nothing to tell a host that is gone
            StopNetwork();
            _status = reason + LanText.T(". Чтобы играть дальше, перезапустите игру");
            LanNotify.Alert(reason);
            _menuPending = inWorld;
        }
        private void MenuWhenReady()
        {
            if (!_menuPending) return;
            var scenes = GlobalSceneManager.global;
            if (scenes == null || scenes.SceneCurrentlyLoading || ClientTravelHooks.Loading) return;
            _menuPending = false;
            try { if (!LanLeave.ToMainMenu()) Logger.LogWarning("Main menu not opened: the game's menu is not ready"); }
            catch (Exception ex) { Logger.LogWarning("Main menu not opened: " + ex.GetType().Name + ": " + ex.Message); }
        }

        private void StopSocketOnly()
        {
            LanTrainDevices.Close();
            LanWorldWork.ResetWater();
            _zombies?.Freeze();
            foreach (var link in _links.Values)
            {
                link.Isolated?.Dispose();
                link.Isolated = link.Network = link.Pairing = null; link.Connected = false;
            }
            _links.Clear();
        }

        private void PollPairing()
        {
            foreach (var link in LinkList())
            {
                if (link.Isolated == null) continue;
                if (link.Isolated.SecurityFailure != null)
                {
                    string reason = link.Isolated.SecurityFailure;
                    if (!_hosting) { StopNetwork(); _status = reason + LanText.T("; нужны новый код и разрешение хоста"); Logger.LogWarning(_status); return; }
                    bool taken = link.Network != null;
                    _status = reason + (taken ? "; " + LanSkinPicker.Label(link.Slot) + LanText.T(" отключён") : LanText.T("; нужен новый код"));
                    Logger.LogWarning(_status);
                    DropLink(link, taken ? LanSkinPicker.Label(link.Slot) + LanText.T(": связь закрыта") : null);
                    continue;
                }
                var pairing = link.Pairing;
                if (pairing == null) continue;
                _status = pairing.Status;
                IPAddress peer;
                if (pairing.TryTakeReady(out peer))
                {
                    try
                    {
                        LinkReady(link);
                        link.Pairing = null;
                        Logger.LogInfo("Approved isolated network worker ready" + (_hosting ? " for seat " + link.Slot : "") + "; transport keys remain inside AppContainer");
                    }
                    catch (Exception ex)
                    {
                        if (_hosting) DropLink(link, null); else StopSocketOnly();
                        _status = LanText.T("Не удалось открыть защищённое соединение; создайте новый код");
                        Logger.LogError(ex);
                        continue;
                    }
                }
                if (link.Pairing != null && link.Pairing.Finished)
                {
                    // 2.0.0: an invitation that ended unused (expired, refused, failed) closes its worker;
                    // a host's seat is free again (one that lasted reopens by itself when seats do).
                    _status = link.Pairing.Status; link.Pairing = null;
                    if (link.Network != null) continue;
                    if (!_hosting) { link.Isolated?.Dispose(); link.Isolated = null; _links.Remove(link.Slot); continue; }
                    DropLink(link, null);
                    if (_seatsOpenThemselves && Time.unscaledTime - link.OpenedAt > 60f) _openSeatAt = Time.unscaledTime + 2f;
                }
            }
        }

        // A link's worker is paired and approved: its senders, keepers and views of the host's world.
        private void LinkReady(LanLink link)
        {
            link.Network = link.Isolated;
            Action<Packet> send = packet => SendPacket(link, packet);
            link.Train = new TrainSync(send, Logger, link.Limits, link.Slot);
            if (!_hosting) { _zombies?.Dispose(); _zombies = new ZombieSync(false, send, text => Logger.LogWarning("Zombies: " + text), link.CombatInventory); }
            else if (_zombies == null) _zombies = new ZombieSync(true, null, text => Logger.LogWarning("Zombies: " + text), null);
            link.Doors = new LanWorldDoors(_hosting, send, Logger.LogWarning);
            if (_hosting) link.Doors.Ledger = () => Ledger(link);
            link.SceneStates?.Clear();
            link.SceneStates = new LanSceneStates(_hosting, send, Logger.LogWarning);
            link.Farm = _hosting ? new LanFarm(send) : null; // 2.4.4
            Func<string> profile = () => ProfileOf(link);
            link.Quests = new LanQuests(_hosting, send, link.Slot, _hosting ? profile : null);
            link.WorldItems = new LanWorldItems(_hosting, send, Logger.LogWarning, _hosting ? link.Slot : -1, _hosting ? profile : null);
            if (_marks == null) _marks = new LanMarks(SendMark);
            if (_chat == null) _chat = new LanChat(BroadcastChat);
            link.Chat = new LanChatChannel(send);
            link.Latency = new LanLatencyChannel(_hosting, send);
            if (_hosting && _latencyReport == null) _latencyReport = LatencyReport;
            link.Sleep = new LanSleepChannel(packet => SendWorldEvent(link, packet));
            // A guest's host answers on its seat's own port (the worker knows it once the session is up).
            link.Peer = _hosting ? null : link.Network.Peer;
            if (_hosting)
            {
                link.GuestHost = new LanGuestHost(LanGuestPersistence.Store, send, Logger.LogInfo, new LanLedgerRules(), LanLedgerRules.HostBackpackIndex,
                    () => LanBeaverItem.Ready && LanBeaverSave.Ready ? new object[] { LanBeaverItem.ItemId, 1, new object[4] } : null);
                var hostWorld = new LanStorageHostWorld(() => GuestPosition(link), link.WorldItems, link.Slot, profile);
                hostWorld.GuestDied = (car, point) => GuestDied(link, car, point);
                var storage = link.StorageHost = new LanStorageHost(hostWorld, send, Logger.LogInfo, () => link.Connected && link.GuestHost != null && link.GuestHost.Confirmed);
                storage.Ledger = () => Ledger(link);
                storage.TrainRevision = () => link.Train == null ? 0 : link.Train.HostRevision;
                storage.TrainChanged = () =>
                {
                    foreach (var other in _links.Values)
                        if (other.Connected) other.Train?.InvalidateLayout();
                };
                if (LanQuests.Failure == null)
                {
                    storage.Quests = link.Quests;
                    storage.QuestChanged = (kind, key) => { foreach (var other in _links.Values) other.Quests?.SendSoon(); };
                }
                if (LanTakables.Failure == null) storage.Takables = new LanTakables(link.Slot);
                TrackGuest(link);
            }
            else
            {
                link.GuestClient = new LanGuestClient(GuestToken, send, Logger.LogInfo);
                var client = link.StorageClient = new LanStorageClient(new LanStorageGuestWorld(), send, Logger.LogInfo, () => link.GuestClient?.CaptureSoon());
                client.PickedUp = (id, amount) => { link.WorldItems?.HidePickedItem(id); TrainLayout.HidePickedItem(id); };
                client.BuildDone = (car, kind, identity, progress, maximum, completed, revision) =>
                {
                    if (maximum > 0f) TrainLayout.ApplyBuildFeedback(car, kind, identity, progress, maximum, revision);
                };
                client.DeathDone = DeathAnswered;
                client.WorkDone = (kind, detail) =>
                {
                    if (kind == LanStorage.WorkRefuel) LanWorldWork.Refuelled(detail);
                    else if (LanStorage.WaterWork(kind)) { } // Applied below with the confirmed request's tank identity.
                    else if (LanStorage.FarmWork(kind)) LanFarm.Worked(kind); // 2.4.4: the host's garden beds
                    else LanWorldWork.Worked(kind, detail); // 2.4.4: gathering, taking apart a barrel
                };
                client.WorkRefused = LanWorldWork.Refused;
                client.WorkConfirmed = (kind, detail, tool, extra, revision) =>
                {
                    if (LanStorage.WaterWork(kind)) LanWorldWork.Watered(kind, detail, tool, extra, revision);
                };
                client.DoorDone = LanTrainControl.DoorDone;
                client.QuestDone = LanQuests.Answered;
            }
            link.LastReceive = Time.unscaledTime;
        }

        // Host (1.2.1, 2.0.0 for each guest): how LanTakables sees this guest.
        private void TrackGuest(LanLink link)
        {
            var guest = LanTakables.Track(link.Slot);
            var p = link.Player;
            guest.Profile = () => ProfileOf(link);
            guest.Avatar = () => p.Avatar != null && p.Avatar.activeSelf && !p.Lying ? p.Avatar.transform : null;
            guest.Position = () => GuestPosition(link);
            guest.Crouch = () => p.Crouch;
            guest.Able = () => GuestPosition(link) != null && !p.Downed && !p.Dead && link.GuestDeadAt < 0f;
        }

        private void ReceivePackets()
        {
            foreach (var link in LinkList())
            {
                if (!_hosting && link.Network != null && link.Network.Peer != null) link.Peer = link.Network.Peer;
                var budget = System.Diagnostics.Stopwatch.StartNew();
                for (int i = 0; i < 64 && link.Network != null && budget.Elapsed.TotalMilliseconds < 2; i++)
                {
                    try
                    {
                        if (!link.Network.Available) break;
                        IPEndPoint from;
                        Packet packet;
                        if (!link.Network.TryReceive(out from, out packet)) continue;
                        if (!_hosting && packet.Kind == PacketKind.VersionMismatch && link.Peer != null && SameEndpoint(link.Peer, from))
                        {
                            StopNetwork(); _status = LanText.T("Версии игры не совпадают");
                            return;
                        }
                        if (packet.GameVersion != NetworkGameVersion)
                        {
                            if (_hosting && packet.Kind == PacketKind.Hello) SendPacket(link, new Packet { Kind = PacketKind.VersionMismatch }, from);
                            continue;
                        }
                        if (_hosting) ReceiveAsHost(link, from, packet);
                        else ReceiveAsClient(link, from, packet);
                    }
                    catch (SocketException ex) { NetworkWarning(ex); break; }
                    catch (ObjectDisposedException) { break; }
                    catch (Exception ex) { NetworkWarning(ex); break; }
                }
            }
        }

        private void ReceiveAsHost(LanLink link, IPEndPoint from, Packet packet)
        {
            var p = link.Player;
            float now = Time.unscaledTime;
            if (packet.Kind == PacketKind.Hello)
            {
                if (packet.Session == 0 || packet.Session != link.Network.Session) return;
                if (!link.Connected || link.Peer == null || link.Session != packet.Session)
                {
                    bool first = link.ConnectedAt < 0f;
                    p.HaveState = false;
                    ClearExtras(p);
                    p.Poses.Clear();
                    link.LastState = null; link.SentStates.Clear();
                    link.Train?.Freeze();
                    link.Train = new TrainSync(value => SendPacket(link, value), Logger, link.Limits, link.Slot);
                    var combat = _zombies?.AddRemote(link.Slot, value => SendPacket(link, value), link.CombatInventory);
                    if (combat != null) combat.Ledger = () => Ledger(link);
                    HideAvatar(p);
                    link.GuestHost?.Begin();
                    link.PanelClosed = false;
                    link.StorageHost?.Begin();
                    link.Chat?.Reset();
                    if (link.Session != packet.Session)
                        link.Latency = new LanLatencyChannel(true, value => SendPacket(link, value));
                    link.Sleep?.Reset(link.Session != packet.Session); LanSleep.Forget(link.Slot);
                    link.GuestDeadAt = -1f; link.LostAt = -1f; link.ConnectedAt = now;
                    LanNotify.Alert(LanSkinPicker.Label(link.Slot) + (first ? LanText.T(" подключился") : LanText.T(" снова на связи")));
                    if (first && _seatsOpenThemselves) _openSeatAt = now + 2f;
                }
                link.Peer = from;
                link.Session = packet.Session;
                link.Connected = true;
                link.LastReceive = now;
                _status = (link.Network.Relay ? LanText.T("Защищённое соединение через сервер") : LanText.T("Защищённое соединение: ") + from.Address) + LanText.T(" · друзей: ") + ConnectedGuests();
                link.NextWorldSend = 0;
                SendPacket(link, new Packet { Kind = PacketKind.Welcome, Player = (byte)link.Slot }, from);
                return;
            }
            if (link.Peer == null || !SameEndpoint(link.Peer, from)) return;
            if (packet.Session != link.Session) return;
            if (packet.Kind == PacketKind.Leave) // 1.4.5
            {
                Logger.LogInfo("Guest " + link.Slot + " left the game");
                link.Connected = false;
                DropLink(link, LanSkinPicker.Label(link.Slot) + LanText.T(" вышел из игры"));
                return;
            }
            if (packet.Kind == PacketKind.Latency)
            {
                if (link.Connected) { link.LastReceive = now; link.Latency?.Receive(packet, StateClock.Elapsed.TotalSeconds); }
                return;
            }
            if (packet.Kind == PacketKind.Heartbeat) { link.LastReceive = now; return; }
            if (packet.Kind == PacketKind.Chat) { link.LastReceive = now; ReceiveChat(link, packet); return; }
            if (packet.Kind >= PacketKind.StorageRequest && packet.Kind <= PacketKind.StorageViewAck) { link.LastReceive = now; link.StorageHost?.Receive(packet, now); return; }
            if (packet.Kind >= PacketKind.IdentityRequest && packet.Kind <= PacketKind.GuestRestoreAck)
            {
                link.LastReceive = now; link.GuestHost?.Receive(packet, now);
                if (link.GuestHost != null && link.GuestHost.IdentityRejected)
                {
                    string reason = link.GuestHost.Status;
                    Logger.LogWarning(reason); _status = reason; DropLink(link, reason);
                }
                return;
            }
            if (packet.WorldEpoch != _worldEpoch || _worldEpoch == 0) return;
            if (packet.Kind == PacketKind.TrainLayoutAck)
            { link.LastReceive = now; link.Train?.Receive(packet, true); return; }
            if (packet.Kind == PacketKind.DoorToggle) { link.LastReceive = now; link.Doors?.Receive(packet, GuestPosition(link)); return; }
            if (packet.Kind == PacketKind.SceneUse) { link.LastReceive = now; link.SceneStates?.Receive(packet, GuestPosition(link)); return; }
            if (packet.Kind == PacketKind.Revive) { link.LastReceive = now; ReceiveRevive(link, packet); return; }
            if (packet.Kind == PacketKind.Sleep || packet.Kind == PacketKind.SleepAck) { link.LastReceive = now; ReceiveSleep(link, packet); return; }
            if (packet.Kind == PacketKind.Mark) { link.LastReceive = now; ReceiveMark(link, packet); return; }
            if (packet.Kind == PacketKind.ZombieAction || packet.Kind == PacketKind.ZombieHurtAck || packet.Kind == PacketKind.CombatProposal || packet.Kind == PacketKind.CombatReload)
            {
                link.LastReceive = now;
                if (packet.Kind == PacketKind.ZombieAction)
                {
                    if (!p.HaveState) return;
                    if (packet.CarIndex >= 0)
                    {
                        // 1.0.7: a shot from a train car is placed with the host's own car, as the guest
                        // is: a world origin was a state period (0.1 s) of train travel off and refused.
                        var car = TrainSync.GetCar(packet.CarIndex);
                        if (car == null) return;
                        var origin = car.transform.TransformPoint(new Vector3(packet.X, packet.Y, packet.Z));
                        var aim = car.transform.TransformDirection(new Vector3(packet.AimX, packet.AimY, packet.AimZ)).normalized;
                        packet.X = origin.x; packet.Y = origin.y; packet.Z = origin.z; packet.AimX = aim.x; packet.AimY = aim.y; packet.AimZ = aim.z;
                        packet.CarIndex = -1;
                    }
                    else { packet.X += p.CombatOffset.x; packet.Y += p.CombatOffset.y; packet.Z += p.CombatOffset.z; }
                }
                _zombies?.Receive(link.Slot, packet); return;
            }
            if (packet.Kind != PacketKind.State) return;
            link.LastReceive = now;
            if (p.HaveState && packet.Sequence <= p.Sequence) return;
            if (!ValidateClientPose(link, packet)) return;
            // The guest stops its states while dead: the first one well after its death means it is back.
            if (link.GuestDeadAt >= 0f && now - link.GuestDeadAt > 3f) link.GuestDeadAt = -1f;
            SetRemoteState(p, packet);
            // 2.0.0: as accepted (the host's place for it), for the other guests' Players.
            packet.Player = (byte)link.Slot; link.LastState = packet;
        }

        private void ReceiveAsClient(LanLink link, IPEndPoint from, Packet packet)
        {
            var host = link.Player;
            float now = Time.unscaledTime;
            if (link.Peer == null || !SameEndpoint(link.Peer, from)) return;
            if (packet.Kind == PacketKind.Busy)
            {
                if (!link.Connected) { _status = LanText.T("Хост уже занят; ожидание свободной комнаты"); link.Network.RetryAfterBusy(); }
                return;
            }
            if (packet.Kind == PacketKind.VersionMismatch) { _status = LanText.T("Версии игры не совпадают"); return; }
            if (packet.Kind == PacketKind.Welcome)
            {
                // 2.0.0: the host's Welcome gives this guest its slot (never the host's own).
                if (packet.Session == 0 || packet.Session != link.Network.Session || packet.Player == 0) return;
                if (link.Session != packet.Session)
                {
                    link.Latency = new LanLatencyChannel(false, value => SendPacket(link, value));
                    LanWorldWork.ResetWater();
                    link.Session = packet.Session;
                    _mySlot = packet.Player; LanMarks.LocalSlot = _mySlot;
                    host.HaveState = false;
                    ClearExtras(host);
                    host.Poses.Clear();
                    HideOthers(); _others.Clear(); _roster.Reset();
                    _worldEpoch = 0; _receivedWorldSequence = 0; _clientLoadEpoch = 0;
                    _clientWorld = null; _clock.Reset();
                    link.Train?.Freeze();
                    link.Train = new TrainSync(value => SendPacket(link, value), Logger, link.Limits);
                    ResetZombieConnection(link);
                    link.GuestClient?.Begin(now);
                    LanStorageGame.CloseWindow(link.StorageClient);
                    link.StorageClient?.Begin();
                    link.Chat?.Reset();
                    link.Sleep?.Reset(true); LanSleep.Reset();
                    LanNotify.Alert(LanText.T("Хост разрешил подключение"));
                    Logger.LogInfo("Joined the host as guest " + _mySlot);
                }
                link.Connected = true;
                _lostAt = -1f;
                link.LastReceive = now;
                _status = link.Network.RoomName.Length != 0 ? LanText.T("Защищённое соединение с комнатой «") + link.Network.RoomName + LanText.T("»; ожидание уровня хоста") : LanText.T("Защищённое соединение; ожидание уровня хоста");
                return;
            }
            if (!link.Connected || packet.Session != link.Session) return;
            if (packet.Kind == PacketKind.Leave) { HostLeft(LanText.T("Хост отключил вас или вышел из игры")); return; } // 1.4.5
            if (packet.Kind == PacketKind.Latency) { link.LastReceive = now; link.Latency?.Receive(packet, StateClock.Elapsed.TotalSeconds); return; }
            if (packet.Kind == PacketKind.Heartbeat) { link.LastReceive = now; return; }
            if (packet.Kind == PacketKind.Chat) { link.LastReceive = now; ReceiveChat(link, packet); return; }
            if (packet.Kind >= PacketKind.StorageRequest && packet.Kind <= PacketKind.StorageViewAck) { link.LastReceive = now; link.StorageClient?.Receive(packet); return; }
            if (packet.Kind >= PacketKind.IdentityRequest && packet.Kind <= PacketKind.GuestRestoreAck) { link.LastReceive = now; link.GuestClient?.Receive(packet, now); return; }
            if (packet.Kind == PacketKind.WorldState) { ReceiveWorld(link, packet); return; }
            if (packet.WorldEpoch != _worldEpoch || _worldEpoch == 0) return;
            if (packet.Kind == PacketKind.TrainMotion || packet.Kind == PacketKind.TrainLayoutChunk)
            {
                if(packet.Kind==PacketKind.TrainMotion && (_clientWorld==null || packet.Train.Scene!=_clientWorld.Scene)) return;
                link.LastReceive = now; link.Train?.Receive(packet, false); return;
            }
            if (packet.Kind == PacketKind.DoorStates) { link.LastReceive = now; link.Doors?.Receive(packet, null); return; }
            if (packet.Kind == PacketKind.SceneStates) { link.LastReceive = now; link.SceneStates?.Receive(packet, null); return; }
            if (packet.Kind == PacketKind.FarmStates) { link.LastReceive = now; LanFarm.Receive(packet); return; }
            if (packet.Kind == PacketKind.QuestStates) { link.LastReceive = now; link.Quests?.Receive(packet); return; }
            if (packet.Kind == PacketKind.Revive) { link.LastReceive = now; ReceiveRevive(link, packet); return; }
            if (packet.Kind == PacketKind.Sleep || packet.Kind == PacketKind.SleepAck) { link.LastReceive = now; ReceiveSleep(link, packet); return; }
            if (packet.Kind == PacketKind.Explosion)
            {
                link.LastReceive = now;
                var scenes = GlobalSceneManager.global;
                if (scenes != null && packet.Scene == scenes.CurrentSceneName && _clientPlacedNearHost) LanExplosions.Receive(packet.Action, packet.Text, new Vector3(packet.X, packet.Y, packet.Z));
                return;
            }
            if (packet.Kind == PacketKind.WorldItems) { link.LastReceive = now; link.WorldItems?.Receive(packet); return; }
            if (packet.Kind == PacketKind.Mark) { link.LastReceive = now; ReceiveMark(link, packet); return; }
            if (packet.Kind == PacketKind.ZombieState || packet.Kind == PacketKind.ZombieHurt || packet.Kind == PacketKind.CombatState || packet.Kind == PacketKind.ZombieCorpse || packet.Kind == PacketKind.ZombieEffect ||
                packet.Kind == PacketKind.AnimalState)
            { link.LastReceive = now; _zombies?.Receive(packet); return; }
            if (packet.Kind == PacketKind.Players) { link.LastReceive = now; ReceivePlayers(packet); return; }
            if (packet.Kind != PacketKind.State) return;
            link.LastReceive = now;
            if (host.HaveState && packet.Sequence <= host.Sequence) return;
            SetRemoteState(host, packet);
        }

        // Guest (2.0.0): the host's other guests, as the host accepted their states.
        private void ReceivePlayers(Packet packet)
        {
            _roster.Apply(packet, _mySlot, slot =>
            {
                RemotePlayer p;
                if (_others.TryGetValue(slot, out p)) HideAvatar(p);
                _others.Remove(slot); LanSkinPicker.Names[slot] = "";
            }, (state, replaced) =>
            {
                RemotePlayer p;
                if (!_others.TryGetValue(state.Player, out p) || replaced)
                {
                    if (p != null) HideAvatar(p);
                    _others[state.Player] = p = new RemotePlayer(state.Player);
                }
                if (p.HaveState && !LanPlayerRoster.Newer(state.Sequence, p.Sequence)) return;
                SetRemoteState(p, state);
            });
        }

        // 1.0.8: a sound for another player's message; while the LAN panel hides the chat, the message
        // is shown at the top of the screen as well. 2.0.0: the host passes its guests' lines on to the
        // other guests (each line under the slot of the link it came over).
        private void ReceiveChat(LanLink link, Packet packet)
        {
            byte from = 0;
            string text = link.Chat == null ? null : link.Chat.Receive(packet, out from);
            if (text == null) return;
            int slot = _hosting ? link.Slot : from;
            if (!_hosting && slot == _mySlot) return;
            if (_hosting)
                foreach (var other in _links.Values)
                    if (other != link && other.Up) other.Chat?.Relay(text, (byte)slot, Time.unscaledTime);
            string shown = _chat?.Receive(text, slot);
            if (shown == null) return;
            LanNotify.Message(_panelOpen ? LanSkinPicker.Label(slot) + ": " + (shown.Length > 120 ? shown.Substring(0, 120) + "…" : shown) : null);
        }

        // This player's chat line to every other player (a guest's goes to its host, which passes it on).
        private LanChatChannel.Submit BroadcastChat(string raw, double now, out string text, out Func<bool> pending)
        {
            text = LanChatChannel.Clean(raw); pending = null;
            var result = LanChatChannel.Submit.Empty;
            var sent = new List<KeyValuePair<LanChatChannel, int>>();
            foreach (var link in _links.Values)
            {
                if (!link.Up || link.Chat == null) continue;
                string cleaned; int id;
                var outcome = link.Chat.Send(raw, now, out cleaned, out id);
                if (outcome == LanChatChannel.Submit.Sent) { sent.Add(new KeyValuePair<LanChatChannel, int>(link.Chat, id)); text = cleaned; result = outcome; }
                else if (result != LanChatChannel.Submit.Sent) result = outcome;
            }
            if (sent.Count != 0) pending = () => { foreach (var line in sent) if (line.Key.IsPending(line.Value)) return true; return false; };
            return result;
        }

        // This player's mark to every other player (each link numbers its own marks).
        private void SendMark(Packet packet)
        {
            foreach (var link in _links.Values)
            {
                if (!link.Up) continue;
                packet.Sequence = ++link.MarkSequence;
                SendPacket(link, packet);
            }
        }

        // Another player's mark (newer than the last over this link): shown, and passed on by the host.
        private void ReceiveMark(LanLink link, Packet packet)
        {
            if (!Newer(packet.Sequence, link.MarkReceived)) return;
            link.MarkReceived = packet.Sequence;
            int from = _hosting ? link.Slot : packet.Player;
            if (_marks == null || !_marks.Receive(packet, from) || !_hosting) return;
            packet.Player = (byte)from;
            foreach (var other in _links.Values)
            {
                if (other == link || !other.Up) continue;
                packet.Sequence = ++other.MarkSequence;
                SendPacket(other, packet);
            }
        }

        private void SetRemoteState(RemotePlayer p, Packet packet)
        {
            // 1.4.7: a new count of throws is a throw; health dropping by a blow's worth at once (not a
            // bleeding tick) is a hit.
            if (p.HaveState)
            {
                if (packet.Throws != p.Throws) p.ThrowPending = true;
                if (packet.Interacts != p.Interacts) p.InteractPending = true;
                if (packet.HealthMax > 0 && p.HealthNow - packet.HealthNow >= Math.Max(FlinchHealth, packet.HealthMax / 25)) p.FlinchPending = true;
            }
            p.Throws = packet.Throws; p.MotionFlags = packet.Motion; p.Interacts = packet.Interacts;
            // 1.4.6: the walk and its pace come from the shown motion (UpdateRemoteAvatarPose).
            p.Poses.Push(packet);
            var nextLocal = new Vector3(packet.LocalX, packet.LocalY, packet.LocalZ);
            p.Sequence = packet.Sequence;
            p.HaveState = true;
            p.StateAt = Time.unscaledTime;
            p.CarIndex = packet.CarIndex;
            p.LocalPosition = nextLocal;
            p.LocalYaw = packet.LocalYaw;
            p.Scene = packet.Scene;
            p.Position = new Vector3(packet.X, packet.Y, packet.Z);
            p.Yaw = packet.Yaw;
            p.TrainPosition = packet.TrainPosition;
            p.EquippedItem = packet.EquippedItemId;
            p.ShotSequence = packet.ShotSequence;
            p.ShotItem = packet.ShotItemId;
            p.Health = packet.Health;
            p.HealthNow = packet.HealthNow; p.HealthMax = packet.HealthMax; p.Skin = packet.Skin;
            p.Outfit = packet.Outfit; // 2.3.0
            p.HandMods = packet.HandMods; // 2.4.0
            p.Pitch = packet.Pitch;
            p.Crouch = (packet.Pose & LanProtocol.PoseCrouch) != 0;
            p.Aim = (packet.Pose & LanProtocol.PoseAim) != 0;
            bool wasDowned = p.Downed;
            p.Downed = (packet.Pose & LanProtocol.PoseDowned) != 0;
            p.Dead = (packet.Pose & LanProtocol.PoseDead) != 0;
            p.HelmetLight = (packet.Pose & LanProtocol.PoseHelmetLight) != 0;
            p.GunLight = (packet.Pose & LanProtocol.PoseGunLight) != 0;
            p.Reload = (packet.Pose & LanProtocol.PoseReload) != 0;
            LanSkinPicker.Names[p.Slot] = packet.Name ?? "";
            if (p.Downed && !wasDowned && !LanDowned.Down)
                LanNotify.Alert(LanSkinPicker.Label(p.Slot) + LanText.T(" тяжело ранен: подойдите и удерживайте E, чтобы поднять"));
        }

        // 1.1.9: another player's Revive packet, for this player when it lies downed. 2.0.0: a guest's
        // Revive names the player it is for (the host passes one for another guest on, naming the guest
        // it came from); the host's names it as the one it comes from.
        private void ReceiveRevive(LanLink link, Packet packet)
        {
            var scenes = GlobalSceneManager.global;
            if (!_hosting)
            {
                if (scenes == null || packet.Scene != scenes.CurrentSceneName) return;
                LanDowned.Receive(packet.Action, packet.Player);
                return;
            }
            int target = packet.Player;
            if (target == 0)
            {
                if (scenes != null && packet.Scene == scenes.CurrentSceneName) LanDowned.Receive(packet.Action, link.Slot);
                return;
            }
            LanLink to;
            if (target == link.Slot || !_links.TryGetValue(target, out to) || !to.Up) return;
            if (packet.Action == LanProtocol.ReviveDone) LanGuestCredits.Revive(target); // 1.3.0: it gets up with some health
            SendPacket(to, new Packet { Kind = PacketKind.Revive, Scene = packet.Scene, Sequence = ++to.ReviveSequence, Action = packet.Action, Player = (byte)link.Slot });
        }

        private void SendRevive(byte action, int target)
        {
            string scene = CurrentScene();
            if (_worldEpoch == 0 || string.IsNullOrEmpty(scene)) return;
            if (_hosting)
            {
                LanLink to;
                if (!_links.TryGetValue(target, out to) || !to.Up) return;
                SendPacket(to, new Packet { Kind = PacketKind.Revive, WorldEpoch = _worldEpoch, Scene = scene, Sequence = ++to.ReviveSequence, Action = action, Player = 0 });
                if (action == LanProtocol.ReviveDone) LanGuestCredits.Revive(target); // 1.3.0: the guest gets up with some health
                return;
            }
            var host = HostLink;
            if (host == null || !host.Up || !LanProtocol.ValidPlayer((byte)target)) return;
            SendPacket(host, new Packet { Kind = PacketKind.Revive, WorldEpoch = _worldEpoch, Scene = scene, Sequence = ++host.ReviveSequence, Action = action, Player = (byte)target });
        }

        // 1.2.2: another player's Sleep packet, in this world. 2.0.0: the host passes a guest's lying
        // down and getting up on to the other guests (naming that guest).
        private void ReceiveSleep(LanLink link, Packet packet)
        {
            string scene = CurrentScene();
            if (scene == null || packet.Scene != scene) return;
            if (link.Sleep == null) return;
            if (_hosting && packet.Kind == PacketKind.Sleep)
            {
                if (packet.Action == LanProtocol.SleepStart) return;
                packet.Player = (byte)link.Slot;
            }
            if (!link.Sleep.Receive(packet)) return;
            if (!_hosting) { LanSleep.Receive(packet.Action, packet.Revision, packet.Player, packet.SleepAttempt); return; }
            LanSleep.Receive(packet.Action, packet.Revision, link.Slot, packet.SleepAttempt);
            if (packet.Action != LanProtocol.SleepWait && packet.Action != LanProtocol.SleepCancel) return;
            foreach (var other in _links.Values)
                if (other != link && other.Up && other.Player.Scene == scene)
                    other.Sleep?.Send(packet.Action, packet.Revision, (byte)link.Slot, packet.SleepAttempt, Time.unscaledTime);
        }

        // 1.2.2: a world packet of a link (Sleep, Explosion) in this scene.
        private void SendWorldEvent(LanLink link, Packet packet)
        {
            string scene = CurrentScene();
            if (!link.Up || _worldEpoch == 0 || string.IsNullOrEmpty(scene)) return;
            packet.WorldEpoch = _worldEpoch; packet.Scene = scene;
            SendPacket(link, packet);
        }

        private void CoopTick()
        {
            if (_hostGuestCar == null) _hostGuestCar = HostGuestTrainCar;
            LanTrainControl.HostGuestCar = _hosting ? _hostGuestCar : null;
            string scene = CurrentScene();
            bool attached = Connected && _worldEpoch != 0 && !string.IsNullOrEmpty(scene) && (_hosting ? _hostWorldReady : _clientPlacedNearHost);
            if (_sleepHere == null) _sleepHere = PlayersHere;
            if (_sleepSend == null) _sleepSend = (action, hours, attempt) =>
            {
                // Sleep belongs to this scene; remote scenes must not create unacknowledged work.
                foreach (var link in _links.Values)
                    if (link.Up && link.Player.Scene == CurrentScene()) link.Sleep?.Send(action, hours, (byte)_mySlot,
                        _hosting && action == LanProtocol.SleepStart ? LanSleep.AttemptFor(link.Slot) : attempt, Time.unscaledTime);
            };
            if (_explosionSend == null) _explosionSend = (action, name, at) =>
            {
                foreach (var link in _links.Values)
                    if (link.Up) SendWorldEvent(link, new Packet { Kind = PacketKind.Explosion, Sequence = ++link.ExplosionSequence, Action = action, Text = name, X = at.x, Y = at.y, Z = at.z });
            };
            if (_mapPartners == null) _mapPartners = () =>
            {
                var list = new List<Vector3>();
                string here = CurrentScene();
                foreach (var p in RemotePlayers()) if (Here(p, here, 3f)) list.Add(p.WorldPosition());
                return list;
            };
            LanSleep.Hosting = _hosting;
            LanSleep.PlayersHere = attached ? _sleepHere : null;
            LanSleep.Send = attached ? _sleepSend : null;
            LanExplosions.Send = _hosting && attached ? _explosionSend : null;
            LanMapMarker.Partners = attached ? _mapPartners : null;
            LanSleep.Tick();
            LanExplosions.Tick();
            LanThrows.Tick();
            // 1.3.0: what the host's world gives a guest counts toward its checked stats.
            if (_creditStats == null) _creditStats = slot => { LanLink link; var book = _links.TryGetValue(slot, out link) ? Ledger(link) : null; return book == null ? null : book.Stats; };
            if (_creditHere == null) _creditHere = () =>
            {
                var list = new List<int>();
                foreach (var link in _links.Values) if (GuestPosition(link) != null) list.Add(link.Slot);
                return list;
            };
            bool hosting = _hosting && Connected;
            LanGuestCredits.Stats = hosting ? _creditStats : null;
            LanGuestCredits.GuestsHere = hosting ? _creditHere : null;
        }

        // A player's state is from this scene and fresh.
        private static bool Here(RemotePlayer p, string scene, float fresh)
        {
            return p.HaveState && !string.IsNullOrEmpty(scene) && p.Scene == scene && Time.unscaledTime - p.StateAt < fresh;
        }
        // Host: this guest died and has not come back yet.
        private bool DeadGuest(RemotePlayer p) { LanLink link; return _hosting && _links.TryGetValue(p.Slot, out link) && link.GuestDeadAt >= 0f; }

        // 1.2.2 (2.0.0: every player): the other players up in this world now, by slot.
        private IList<int> PlayersHere()
        {
            var list = new List<int>();
            string scene = CurrentScene();
            foreach (var p in RemotePlayers())
                if (Here(p, scene, 3f) && !p.Downed && !p.Dead && !DeadGuest(p) && !(p.Slot == 0 && LanTrainControl.HostDead)) list.Add(p.Slot);
            return list;
        }

        // 1.1.9: another player can still revive this player: in this world and up, or (seen by the
        // host) a guest that died and comes back next to the host.
        private bool OthersCanHelp()
        {
            if (!Connected || (_hosting ? !_hostWorldReady : !_clientPlacedNearHost)) return false;
            string scene = CurrentScene();
            if (string.IsNullOrEmpty(scene)) return false;
            float now = Time.unscaledTime;
            foreach (var p in RemotePlayers())
            {
                if (!p.HaveState || p.Downed || p.Scene != scene) continue;
                LanLink link;
                if (_hosting && _links.TryGetValue(p.Slot, out link) && link.GuestDeadAt >= 0f)
                {
                    if (now - link.GuestDeadAt < LanDowned.DownedSeconds + 15f) return true;
                    continue;
                }
                if (p.Dead || p.Slot == 0 && LanTrainControl.HostDead) continue;
                if (now - p.StateAt < 5f) return true;
            }
            return false;
        }

        // 1.1.9 (2.0.0: every player): the other players lying downed in this world, and where a player is.
        private IList<KeyValuePair<int, Vector3>> DownedPlayers()
        {
            var list = new List<KeyValuePair<int, Vector3>>();
            string scene = CurrentScene();
            foreach (var p in RemotePlayers())
                if (p.HaveState && p.Downed && p.Scene == scene) list.Add(new KeyValuePair<int, Vector3>(p.Slot, p.WorldPosition()));
            return list;
        }
        private Vector3? PlayerAt(int slot)
        {
            foreach (var p in RemotePlayers()) if (p.Slot == slot && p.HaveState) return p.WorldPosition();
            return null;
        }

        private static void ClearExtras(RemotePlayer p)
        {
            p.Downed = p.Dead = p.HelmetLight = p.GunLight = p.Reload = false;
            LanSkinPicker.Names[p.Slot] = "";
        }

        private void ResetZombieConnection(LanLink link)
        {
            _zombies?.Dispose();
            _zombies = new ZombieSync(false, packet => SendPacket(link, packet), text => Logger.LogWarning("Zombies: " + text), link.CombatInventory);
        }

        // Host: the ledger of a link's guest while it is usable, and its profile id.
        private static LanGuestLedger Ledger(LanLink link) { return link.Connected && link.GuestHost != null && link.GuestHost.Confirmed ? link.GuestHost.Ledger : null; }
        private static string ProfileOf(LanLink link) { return Ledger(link) != null ? link.GuestHost.ProfileId : null; }
        private bool ValidateClientPose(LanLink link, Packet packet)
        {
            var p = link.Player;
            if (!_hostWorldReady || packet.Scene != _hostWorldScene) return false;
            var manager = GlobalManager.global;
            if (manager == null || manager.controlledChar == null) return false;
            var position = new Vector3(packet.X, packet.Y, packet.Z);
            var reportedPosition = position;
            if (packet.CarIndex >= 0)
            {
                var car = TrainSync.GetCar(packet.CarIndex);
                if (car == null) return false;
                var local = new Vector3(packet.LocalX, packet.LocalY, packet.LocalZ);
                var projected = car.transform.TransformPoint(local);
                float speed = manager.controlledTrain == null ? 0 : Mathf.Abs(manager.controlledTrain.Speed);
                // Account for delayed rendering of a moving train, then use the
                // host's car transform as the position for combat validation.
                float apart = Vector3.Distance(position, projected);
                if (apart > 12f + Math.Min(speed, 500f) * .75f && !Persistent(link, "car position " + apart.ToString("0.0") + " m off")) return false;
                position = projected;
            }
            if (!p.HaveState)
            {
                if (Vector3.Distance(position, manager.controlledChar.transform.position) > 200f) return false;
                p.MoveBudget = 6f;
            }
            else
            {
                var previous = p.Position;
                if (p.CarIndex >= 0)
                {
                    var previousCar = TrainSync.GetCar(p.CarIndex);
                    if (previousCar != null) previous = previousCar.transform.TransformPoint(p.LocalPosition);
                }
                float elapsed = Mathf.Clamp(Time.unscaledTime - p.MoveBudgetAt, 0, 2);
                float available = Mathf.Min(6f, p.MoveBudget + 20f * elapsed);
                float distance = Vector3.Distance(previous, position);
                if (distance > available)
                {
                    // A fall, a jump off a moving train: one late state must not lock the guest
                    // at its last accepted place for good (everything near it would be "too far").
                    if (!Persistent(link, "jump " + distance.ToString("0.0") + " m")) return false;
                    available = distance;
                }
                p.MoveBudget = available - distance;
            }
            p.MoveBudgetAt = Time.unscaledTime;
            p.RejectedSince = -1f;
            p.CombatOffset = position - reportedPosition;
            packet.X = position.x; packet.Y = position.y; packet.Z = position.z;
            return true;
        }

        // True once a guest's states have been refused for 1.5 s in a row: its new place is taken as is.
        private bool Persistent(LanLink link, string why)
        {
            var p = link.Player;
            float now = Time.unscaledTime;
            if (p.RejectedSince < 0f) p.RejectedSince = now;
            if (now - p.RejectedSince >= 1.5f)
            {
                Logger.LogInfo("Guest " + link.Slot + " position resynchronised (" + why + ")");
                return true;
            }
            if (now - p.RejectLogAt > 5f) { p.RejectLogAt = now; Logger.LogInfo("Guest " + link.Slot + " state refused for now: " + why); }
            return false;
        }

        private void ObserveHostWorld()
        {
            var scenes = GlobalSceneManager.global;
            bool loading = scenes != null && (scenes.SceneCurrentlyLoading || ClientTravelHooks.Loading);
            if (loading) _hostSawLoading = true;
            if (loading || !TrainWorldAvailable())
            { _hostWorldReady = false; _hostReadySince = -1f; _zombies?.Freeze(); return; }
            if (_hostReadySince < 0f) _hostReadySince = Time.unscaledTime;
            if (Time.unscaledTime - _hostReadySince < 0.5f) { _hostWorldReady = false; return; }
            if (_worldEpoch == 0 || _hostSawLoading || _hostWorldScene != scenes.CurrentSceneName)
            {
                unchecked { ++_worldEpoch; if (_worldEpoch == 0) ++_worldEpoch; }
                _hostWorldScene = scenes.CurrentSceneName;
                _hostSawLoading = false;
                LanSleep.Reset();
                foreach (var link in _links.Values)
                {
                    if (link.Network == null) continue;
                    link.Train?.Freeze();
                    link.Train = new TrainSync(packet => SendPacket(link, packet), Logger, link.Limits, link.Slot);
                    link.NextWorldSend = 0;
                    link.Sleep?.Reset();
                    link.Player.HaveState = false;
                    link.Player.Poses.Clear(); HideAvatar(link.Player);
                    link.LastState = null; link.SentStates.Clear();
                }
                Logger.LogInfo("Host world ready: epoch=" + _worldEpoch + " scene=" + _hostWorldScene);
            }
            _hostWorldReady = true;
        }

        private void SendWorld(LanLink link)
        {
            var manager = GlobalManager.global;
            var train = manager == null ? null : manager.controlledTrain;
            var saves = Zompiercer.SaveLoad.SaveLoadCore.global;
            if (train == null || train.Cars == null || train.Cars.Length == 0 || train.Cars[0].FrontAxis == null || saves == null) return;
            var rails = train.Spline == null ? null : train.Spline.GetComponent<ObjectID>();
            ClockSnapshot clock;
            if (!WorldClockSync.Capture(out clock)) clock = null;
            SendPacket(link, new Packet { Kind = PacketKind.WorldState, Sequence = ++_worldSequence, Scene = _hostWorldScene,
                Location = saves.currentLocation, RailsId = rails == null ? -1 : rails.ID,
                TrainPosition = train.Cars[0].FrontAxis.Position, Clock = clock, Difficulty = LanDifficulty.Capture(), Weather = LanWeather.Capture() });
            link.NextWorldSend = Time.unscaledTime + 0.25f;
        }

        private void ReceiveWorld(LanLink link, Packet packet)
        {
            if (packet.Sequence <= _receivedWorldSequence || packet.WorldEpoch < _worldEpoch) return;
            if (!ClientWorldValidation.Valid(packet)) return;
            if (_clientWorld != null && packet.WorldEpoch == _worldEpoch &&
                (packet.Scene != _clientWorld.Scene || packet.Location != _clientWorld.Location)) return;
            link.LastReceive = Time.unscaledTime;
            _receivedWorldSequence = packet.Sequence;
            if (_worldEpoch != packet.WorldEpoch)
            {
                if(!link.Limits.WorldChange(Time.unscaledTime)) return;
                _zombies?.Freeze();
                link.Train?.Freeze();
                _worldEpoch = packet.WorldEpoch;
                link.Sleep?.Reset(); LanSleep.Reset(); _roster.Reset();
                link.Train = new TrainSync(value => SendPacket(link, value), Logger, link.Limits);
                _clock.Reset();
                link.Player.HaveState = false; link.Player.Poses.Clear(); HideAvatar(link.Player);
                foreach (var other in _others.Values) { other.HaveState = false; other.Poses.Clear(); HideAvatar(other); }
                _others.Clear();
                _clientPlacedNearHost = false; _readySince = -1f;
                link.Player.Scene = packet.Scene;
                link.Player.CarIndex = -1;
                _nextTravelAttempt = 0;
                Logger.LogInfo("Received host world: epoch=" + _worldEpoch + " scene=" + packet.Scene);
                // 1.0.3: the panel folds away as soon as the guest heads into the host's world.
                if (_panelOpen) CloseConnectedPanel();
            }
            _clientWorld = packet;
            link.Player.TrainPosition = packet.TrainPosition;
            if (packet.Clock != null) _clock.Receive(packet.Clock, Time.unscaledTime);
            if (packet.Difficulty != null) LanDifficulty.GuestApply(packet.Difficulty); // 1.4.4
            LanWeather.GuestApply(packet.Weather); // 2.4.2
        }

        private void UpdateClientWorld()
        {
            if (_clientWorld == null || _clientLoadEpoch == _worldEpoch || Time.unscaledTime < _nextTravelAttempt) return;
            var scenes = GlobalSceneManager.global;
            var manager = GlobalManager.global;
            var saves = Zompiercer.SaveLoad.SaveLoadCore.global;
            if (scenes == null || manager == null || saves == null || scenes.SceneCurrentlyLoading || ClientTravelHooks.Loading || saves.LoadingNow) return;
            if (_travel.Active && !_travel.LoadFinished()) return;
            _nextTravelAttempt = Time.unscaledTime + 1f;
            try
            {
                if (manager.controlledChar == null)
                {
                    StartLocalGame();
                    if (_joinStartedGame) _clientLoadEpoch = _worldEpoch;
                }
                else if (_clientSavePath == null || !ClientTravelHooks.ClientSession)
                {
                    StopNetwork(); _status = LanText.T("Переход отменён: сохранения клиента не изолированы");
                }
                else if (BeginClientTravel())
                {
                    _clientLoadEpoch = _worldEpoch;
                    _status = _travel.Status;
                }
                else if (!string.IsNullOrEmpty(_travel.Status)) _status = _travel.Status;
            }
            catch (Exception ex)
            {
                _nextTravelAttempt = Time.unscaledTime + 5f;
                _status = LanText.T("Ошибка перехода за хостом: ") + ex.Message;
                Logger.LogError(ex);
            }
        }

        private bool BeginClientTravel()
        {
            // Scene travel must retain the actual gameplay state, not the LAN panel's hold.
            ReleaseLanInput();
            return _travel.Begin(_clientWorld);
        }

        private void StartLocalGame()
        {
            var manager = GlobalManager.global;
            var scenes = GlobalSceneManager.global;
            var gui = manager == null ? null : manager.canvas;
            if (gui == null) gui = Object.FindObjectOfType<Zompiercer.GUI.GUIManager>();
            var host = HostLink == null ? null : HostLink.Player;
            if (manager == null || gui == null || scenes == null || host == null || string.IsNullOrEmpty(host.Scene)) return;
            if (manager.controlledChar != null) { _joinStartedGame = true; return; }
            if (gui.mainGameMenu == null || !gui.mainGameMenu.activeInHierarchy) return;
            if (!ClientWorldValidation.Valid(_clientWorld))
            {
                _status = LanText.T("Сцена хоста отсутствует: ") + host.Scene;
                return;
            }
            try
            {
                var saves = Zompiercer.SaveLoad.SaveLoadCore.global;
                if (saves == null) return;
                string clientSavePath = Path.Combine(Paths.BepInExRootPath, "LAN-sessions", DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fff") + "-" + Guid.NewGuid().ToString("N"));
                if (!LanSaveIsolation.Activate(clientSavePath))
                    throw new IOException(LanText.T("Не удалось подготовить отдельную папку для сохранений гостя; перезапустите игру и подключитесь снова"));
                _clientSavePath = clientSavePath;
                ClientTravelHooks.ClientSession = true;
                saves.currentLocation = _clientWorld.Location;
                saves.TrainPositionAfterLoad = -1f;
                saves.TrainRailsIDAfterLoad = -1;
                manager.GameStarted = true;
                manager.GameStartedTime = Time.time;
                GlobalSceneManager.SaveLocationStartFileAfterSceneLoaded = false;
                ClientTravelHooks.AuthorizeLoad(_clientWorld);
                scenes.LoadLevel(_clientWorld.Scene, _clientWorld.TrainPosition, _clientWorld.RailsId);
                _joinStartedGame = true;
                _startedLocalNewGame = true;
                _status = LanText.T("Загрузка сцены хоста: ") + host.Scene;
                Logger.LogInfo("Loading host scene " + host.Scene + " at train position " + host.TrainPosition);
            }
            catch (Exception ex)
            {
                if (LanSaveIsolation.Active) ClientTravelHooks.Fail(ex.GetType().Name);
                _status = LanText.T("Не удалось запустить игру: ") + ex.Message;
                Logger.LogError(ex);
            }
        }

        private void SendState()
        {
            if (!_hosting && !_clientPlacedNearHost) return;
            var manager = GlobalManager.global;
            var scenes = GlobalSceneManager.global;
            if (_hosting ? !_hostWorldReady : !LocalWorldReady()) return;
            string scene = scenes.CurrentSceneName;
            if (string.IsNullOrEmpty(scene)) return;
            var transform = manager.controlledChar.transform;
            var position = transform.position;
            var train = manager.controlledTrain;
            float trainPosition = train == null || train.Cars == null || train.Cars.Length == 0 ? 0f : train.Cars[0].FrontAxis.Position;
            var packet = new Packet
            {
                Kind = PacketKind.State, GameVersion = NetworkGameVersion, Scene = scene, Sequence = ++_stateSequence,
                X = position.x, Y = position.y, Z = position.z, Yaw = transform.eulerAngles.y,
                TrainPosition = trainPosition,
                EquippedItemId = RemoteEquipment.CaptureLocalItemId(),
                ShotSequence = RemoteEquipment.LocalShotSequence, ShotItemId = RemoteEquipment.StateShotItemId,
                Health = LocalHealth(), Skin = LanSkinPicker.Chosen,
                Pitch = LocalPitch(manager.controlledChar),
                Pose = (byte)((manager.controlledChar.crouch ? LanProtocol.PoseCrouch : 0) | (LocalAiming(manager.controlledChar) ? LanProtocol.PoseAim : 0) | LocalPoseExtras(manager.controlledChar)),
                Name = LanSkinPicker.NickName,
                SentAt = unchecked((uint)StateClock.ElapsedMilliseconds), Dash = RemoteEquipment.LocalDash,
                Motion = RemoteEquipment.LocalMotion, Throws = RemoteEquipment.LocalThrows, Interacts = RemoteEquipment.LocalInteracts,
                Outfit = RemoteOutfit.CaptureLocal(manager.controlledChar), // 2.3.0
                HandMods = RemoteEquipment.CaptureLocalHandMods() // 2.4.0
            };
            ushort healthNow, healthMax; LocalHealthPoints(out healthNow, out healthMax);
            packet.HealthNow = healthNow; packet.HealthMax = healthMax;
            var car = manager.controlledChar.OnTrainCar;
            if (car != null && train != null && car.transform.IsChildOf(train.transform))
            {
                int index = car.GetCarIndex();
                if (index >= 0 && index < LanProtocol.MaxCars)
                {
                    var local = car.transform.InverseTransformPoint(position);
                    packet.CarIndex = index; packet.LocalX = local.x; packet.LocalY = local.y; packet.LocalZ = local.z;
                    packet.LocalYaw = (Quaternion.Inverse(car.transform.rotation) * transform.rotation).eulerAngles.y;
                }
            }
            foreach (var link in _links.Values) if (link.Up) SendPacket(link, packet);
        }

        // Full snapshots repeat even when empty: losing one datagram cannot retain a departed guest.
        private void SendPlayers(LanLink to)
        {
            var states = new List<Packet>();
            foreach (var other in _links.Values)
            {
                if (other == to || !other.Connected || other.LastState == null || Time.unscaledTime - other.Player.StateAt > 2f) continue;
                states.Add(other.LastState);
            }
            // 2.1.0: every packet names all of them; their states go in as many packets as they need (up to six
            // others may not fit one datagram).
            var roster = new PlayerSeat[states.Count];
            for (int i = 0; i < roster.Length; i++) roster[i] = new PlayerSeat { Player = states[i].Player, Session = states[i].Session };
            var part = new List<Packet>();
            foreach (var state in states)
            {
                part.Add(state);
                if (part.Count > 1 && LanProtocol.Size(new Packet { Kind = PacketKind.Players, GameVersion = NetworkGameVersion, Roster = roster, Players = part.ToArray() }) > LanProtocol.MaxBytes)
                {
                    part.RemoveAt(part.Count - 1);
                    SendPacket(to, new Packet { Kind = PacketKind.Players, Sequence = ++to.PlayersSequence, Roster = roster, Players = part.ToArray() });
                    part = new List<Packet> { state };
                }
            }
            SendPacket(to, new Packet { Kind = PacketKind.Players, Sequence = ++to.PlayersSequence, Roster = roster, Players = part.ToArray() });
        }

        private void Send(LanLink link, PacketKind kind) { SendPacket(link, new Packet { Kind = kind, GameVersion = NetworkGameVersion }); }

        private void SendPacket(LanLink link, Packet packet) { SendPacket(link, packet, link == null ? null : link.Peer); }

        private void SendPacket(LanLink link, Packet packet, IPEndPoint endpoint)
        {
            var network = link == null ? null : link.Network;
            if (network == null || endpoint == null || !SameEndpoint(endpoint, network.Peer)) return;
            if (packet.WorldEpoch != 0 && packet.WorldEpoch != _worldEpoch) return;
            try
            {
                packet.Session = packet.Kind == PacketKind.VersionMismatch ? network.Session : link.Session;
                packet.GameVersion = NetworkGameVersion;
                packet.WorldEpoch = _worldEpoch;
                network.Send(packet);
            }
            catch (Exception ex) { NetworkWarning(ex); }
        }

        private void NetworkWarning(Exception ex)
        {
            if (Time.unscaledTime < _nextNetworkWarning) return;
            _nextNetworkWarning = Time.unscaledTime + 5f;
            Logger.LogWarning("LAN network: " + ex.GetType().Name + ": " + ex.Message);
        }

        private void UpdateAvatar()
        {
            if (!Connected) { HideAvatars(); return; }
            var manager = GlobalManager.global;
            var scenes = GlobalSceneManager.global;
            if (manager == null || manager.controlledChar == null || scenes == null || scenes.SceneCurrentlyLoading || ClientTravelHooks.Loading) { HideAvatars(); return; }
            if (_hosting)
            {
                foreach (var link in _links.Values)
                {
                    var p = link.Player;
                    if (!link.Connected || string.IsNullOrEmpty(p.Scene) || !string.Equals(scenes.CurrentSceneName, p.Scene, StringComparison.Ordinal) || link.GuestDeadAt >= 0f) HideAvatar(p);
                    else ShowRemotePlayer(p);
                }
                return;
            }
            var hostLink = HostLink;
            var host = hostLink.Player;
            if (string.IsNullOrEmpty(host.Scene)) { HideAvatars(); return; }
            if (_startedLocalNewGame)
            {
                var gui = manager.canvas;
                if (gui == null) gui = Object.FindObjectOfType<Zompiercer.GUI.GUIManager>();
                var introButton = gui == null ? null : gui.playAfterIntroductionButton;
                var introText = gui == null ? null : gui.introductionText;
                // 2.5.0: as soon as the introduction shows (GlobalSceneManager.IntroductionText), not only once its play button
                // appears: a joining player who pressed the game's own key first (Q) skipped it themselves until now.
                if (introButton != null && introButton.activeSelf || introText != null && introText.activeSelf)
                {
                    // The game's introduction pauses time and deliberately leaves the mouse unlocked.
                    // Use its own completion path before restoring control and moving the player.
                    scenes.PlayAfterIntroductionButton();
                    if (_clientWorld != null) Zompiercer.SaveLoad.SaveLoadCore.global.currentLocation = _clientWorld.Location;
                    Logger.LogInfo("Completed the new-game introduction for the joining player");
                }
            }
            if (!string.Equals(scenes.CurrentSceneName, host.Scene, StringComparison.Ordinal))
            {
                _status = LanText.T("Разные сцены: ") + scenes.CurrentSceneName + " / " + host.Scene;
                HideAvatars();
                return;
            }
            if (!_clientPlacedNearHost)
            {
                if (LanGuestDeath.Dead) return; // placed next to the host when it respawns
                if (_clientLoadEpoch != _worldEpoch || !host.HaveState) return;
                if (_travel.Active ? !_travel.LoadFinished() : !LocalWorldReady()) return;
                if (hostLink.Train == null || !hostLink.Train.Ready) { _status = LanText.T("Получение поезда хоста"); return; }
                if (_startedLocalNewGame &&
                    (Zompiercer.SaveLoad.SaveLoadCore.global == null ||
                     Zompiercer.SaveLoad.SaveLoadCore.global.currentLocation == 0))
                {
                    _status = LanText.T("Ожидание завершения загрузки");
                    return;
                }
                // A stored profile from the host decides the first placement.
                var guestClient = hostLink.GuestClient;
                if (guestClient != null && guestClient.Waiting(Time.unscaledTime)) { _status = LanText.T("Получение профиля игрока от хоста"); return; }
                var character = manager.controlledChar;
                Vector3 target = Vector3.zero;
                float passengerYaw = 0f;
                var profile = guestClient == null ? null : guestClient.Pending;
                bool passenger = _travel.Active && _travel.PassengerPosition(out target, out passengerYaw);
                // After a death: next to the host, never at a place saved in a profile.
                bool restoredPlace = !passenger && !_respawning && profile != null && SavedPlace(profile, character, out target, out passengerYaw);
                if (!passenger && !restoredPlace && !TryFindSpawn(character, out target)) { _status = LanText.T("Ожидание свободного места рядом с хостом"); return; }
                foreach (var delayed in character.GetComponents<DelayedMoveToTrain>())
                { delayed.StopAllCoroutines(); Object.Destroy(delayed); }
                if (profile != null) RestoreGuestCharacter(guestClient.TakePending());
                if (character.controller != null) character.controller.enabled = false;
                TrainSync.DetachPlayer();
                character.transform.position = target;
                if (passenger || restoredPlace)
                {
                    character.transform.rotation = Quaternion.Euler(0f, passengerYaw, 0f);
                    var camera = character.GetComponentInChildren<CameraController>();
                    if (camera != null) camera.charRotation = passengerYaw;
                }
                LastGround?.SetValue(character, target);
                UndergroundTimer?.SetValue(character, 0f);
                character.GravityVector = 0f;
                character.IgnoreNextFallDamage = true;
                if (character.controller != null) character.controller.enabled = true;
                _travel.Complete();
                _clientPlacedNearHost = true; _respawning = false;
                CloseConnectedPanel();
                _nativeHudPending = true;
                _status = restoredPlace ? LanText.T("На сохранённом месте") : LanText.T("Рядом с хостом");
                Logger.LogInfo((restoredPlace ? "Placed joining player at the saved place " : "Placed joining player next to host at ") + target);
            }
            ShowRemotePlayer(host);
            // 2.0.0: the host's other guests in this scene; ones the host stopped showing go.
            foreach (var other in new List<RemotePlayer>(_others.Values))
            {
                if (Time.unscaledTime - other.StateAt > 10f) { HideAvatar(other); _others.Remove(other.Slot); continue; }
                if (Here(other, scenes.CurrentSceneName, 5f)) ShowRemotePlayer(other); else HideAvatar(other);
            }
        }

        // 2.0.0: one other player's avatar: made (again, for a new look), its held item, motion and pose.
        private void ShowRemotePlayer(RemotePlayer p)
        {
            // 1.1.6: the partner chose another look (a new avatar at most every 3 seconds).
            if (p.Avatar != null && p.AvatarSkin != p.Skin && Time.unscaledTime - p.AvatarCreatedAt > 3f) HideAvatar(p);
            if (p.Avatar == null) CreateAvatar(p);
            if (p.Avatar == null) return;
            p.Avatar.SetActive(true);
            if (p.Equipment == null) p.Equipment = p.Avatar.AddComponent<RemoteEquipmentVisual>();
            p.Lying = p.Downed || p.Dead || p.Slot == 0 && !_hosting && LanTrainControl.HostDead;
            p.Equipment.Apply(p.EquippedItem, p.ShotSequence, p.ShotItem, p.HandMods); // 2.4.0: with its mods
            // 1.4.7: how it moves; eating, drinking, bandaging or swimming it puts its weapon away;
            // swimming or climbing it does not walk, in the air or in water its steps are not heard.
            byte use = LanProtocol.MotionUse(p.MotionFlags);
            bool swim = (p.MotionFlags & LanProtocol.MotionSwim) != 0, air = (p.MotionFlags & LanProtocol.MotionAir) != 0;
            bool climbing = p.Motion != null && p.Motion.IsClimbing;
            // A delayed consumption flag must not put food back into a downed,
            // swimming or climbing partner's hand.
            if (p.Lying || swim || climbing) use = LanProtocol.UseNone;
            p.Equipment.Hidden = use != LanProtocol.UseNone || swim || climbing;
            p.Equipment.ShowUse(use, p.ShotItem); // 1.5.0: what it eats or drinks
            if (p.Wear != null) p.Wear.Apply(p.Outfit); // 2.3.0: what it wears
            bool walking = p.Speed > WalkingSpeed && !swim && !climbing;
            if (p.Motion != null)
            {
                p.Motion.Moves((p.MotionFlags & LanProtocol.MotionRun) != 0, air, swim, (p.MotionFlags & LanProtocol.MotionCock) != 0,
                    use, (p.MotionFlags & LanProtocol.MotionTired) != 0, p.ShotItem);
                if (p.ThrowPending && !p.Lying) p.Motion.Throw();
                if (p.FlinchPending && !p.Lying) p.Motion.Flinch();
                // 1.4.8: the held melee weapon's kind of strike, jabs with bare fists, the use key.
                p.Motion.StrikeKind = RemoteAvatarMotion.StrikeOf(p.EquippedItem);
                if (p.Equipment.Punches > p.ShownPunches && !p.Lying) p.Motion.Jab();
                if (p.InteractPending && !p.Lying) p.Motion.Interact();
            }
            p.ShownPunches = p.Equipment.Punches;
            p.ThrowPending = p.FlinchPending = p.InteractPending = false;
            // 1.0.9: a firearm in hand gives the armed pose (aiming for a while after a shot), and the
            // walk keeps pace with the partner. 1.1.0: crouching, the view's pitch, melee swings.
            // 1.1.9: a downed or dead partner lies on its back; a reload; flashlights and steps.
            if (p.Motion != null)
                p.Motion.Apply(p.Equipment.TwoHanded, walking, p.Speed, p.Aim || Time.unscaledTime - p.Equipment.LastShotAt < 1.5f,
                    p.Crouch, p.Pitch, p.Equipment.Swings ? p.Equipment.LastShotAt : -100f,
                    p.Equipment.TwoHanded ? p.Equipment.LastShotAt : -100f, p.Reload, p.Lying);
            else if (p.Animator != null) p.Animator.SetBool("Walk", walking && !p.Lying);
            if (p.Extras != null) p.Extras.Apply(p.HelmetLight, p.GunLight, p.Pitch, walking && !air, p.Speed, p.Crouch, p.Lying);
        }


        // 1.4.6: above this shown ground speed (m/s) the avatar walks; once a minute the log tells
        // how far behind the partner's fastest delivered state it is shown (one send interval plus jitter).
        private const float WalkingSpeed = .3f;

        private void UpdateRemoteAvatarPose(RemotePlayer p)
        {
            Vector3 position; float yaw, speed; byte dash;
            if (!p.Poses.Get(out position, out yaw, out speed)) { p.Speed = 0f; return; }
            p.Speed = Mathf.Lerp(p.Speed, Mathf.Min(speed, 15f), 1f - Mathf.Exp(-10f * Time.unscaledDeltaTime));
            if (p.Poses.TakeDash(out dash) && p.Motion != null && !p.Lying) p.Motion.Dash(dash);
            // 1.4.7: a ladder (the game moves the player to its top at once) is climbed from where the
            // partner stood, in the space of its car when it is on the train.
            var climbCar = p.Poses.ShownCar < 0 ? null : TrainSync.GetCar(p.Poses.ShownCar);
            if (p.Poses.TakeClimb() && p.Motion != null && !p.Lying)
            {
                p.Motion.Climb();
                p.ClimbCar = p.Poses.ShownCar;
                p.ClimbFrom = climbCar != null ? climbCar.transform.InverseTransformPoint(p.Avatar.transform.position - Vector3.up * p.AvatarYOffset) : p.Avatar.transform.position - Vector3.up * p.AvatarYOffset;
            }
            if (p.Motion != null && p.Motion.IsClimbing && p.ClimbCar == p.Poses.ShownCar)
            {
                var from = climbCar != null ? climbCar.transform.TransformPoint(p.ClimbFrom) : p.ClimbFrom;
                position = Vector3.Lerp(from, position, Mathf.SmoothStep(0f, 1f, p.Motion.ClimbShare));
            }
            if (Time.unscaledTime >= p.NextDelayLog)
            {
                p.NextDelayLog = Time.unscaledTime + 60f;
                Logger.LogInfo("Player " + p.Slot + " shown " + Mathf.RoundToInt(p.Poses.Delay * 1000f) + " ms behind its fastest state");
            }
            // 1.1.9: lying on its back, feet where it stands, a little above the ground.
            var rotation = p.Lying ? Quaternion.Euler(0f, yaw, 0f) * Quaternion.Euler(-90f, 0f, 0f) : Quaternion.Euler(0f, yaw, 0f);
            p.Avatar.transform.SetPositionAndRotation(position + Vector3.up * (p.AvatarYOffset + (p.Lying ? .15f : 0f)), rotation);
            if (p.Extras != null) p.Extras.Yaw = yaw;
        }

        // The first model whose ID equals one of the names; a name ending without a number also
        // matches as a prefix (any model of that kind).
        private static CharacterModel PickModel(System.Collections.Generic.List<CharacterModel> models, params string[] names)
        {
            foreach (var name in names)
                foreach (var model in models)
                    if (model.ID == name) return model;
            string prefix = names[names.Length - 1];
            foreach (var model in models)
                if (model.ID != null && model.ID.StartsWith(prefix, StringComparison.Ordinal)) return model;
            return null;
        }

        private void CreateAvatar(RemotePlayer p)
        {
            GameObject staging = null;
            LanInventoryGuard.CaptureCheckpoint("before-remote-avatar", Logger);
            try
            {
                var npc = NPCManager.Global;
                var models = npc == null || npc.NPCModels == null ? new System.Collections.Generic.List<CharacterModel>() : npc.NPCModels.Where(item => item != null).ToList();
                // 1.0.2: the host is shown as a man and the guest as a woman (the game's own NPC
                // models). Without such a model: another model than the host's, or a tint. 2.0.0: each
                // guest by default in its own clothes (the second a soldier, the third a farmer).
                // 1.1.6: the look the player chose in its main menu, when this game has that model.
                // 2.5.1: only a look this version offers.
                p.AvatarSkin = p.Skin; p.AvatarCreatedAt = Time.unscaledTime;
                string chosen = LanSkinPicker.IsAllowed(p.Skin) ? LanSkinPicker.ModelId(p.Skin) : null;
                var model = chosen != null ? PickModel(models, chosen) : null;
                bool guest = p.Slot != 0;
                // 1.1.6: by default models whose clothes are whole (LanSkinPicker).
                if (model == null) model = !guest
                    ? PickModel(models, LanSkinPicker.ManDefault, "RegularMenNPC_Farmer_01", "RegularMenNPC_Worker_01", "RegularMenNPC")
                    : p.Slot == 2 ? PickModel(models, "RegularWomanNPC_Military_04", LanSkinPicker.WomanDefault, "RegularWomanNPC_01", "RegularWomanNPC")
                    : p.Slot == 3 ? PickModel(models, "RegularMenNPC_Farmer_01", "RegularMenNPC_Worker_01", "RegularMenNPC")
                    : PickModel(models, LanSkinPicker.WomanDefault, "RegularWomanNPC_Military_04", "RegularWomanNPC_01", "RegularWomanNPC");
                if (model == null && models.Count != 0) model = models[guest && models.Count > 1 ? 1 : 0];
                bool tint = guest && models.Count == 1;
                if (model != null)
                {
                    staging = new GameObject("LAN avatar staging");
                    staging.SetActive(false);
                    p.Avatar = DisplayCopy(model, staging.transform, "LAN Remote Player");
                    p.AvatarYOffset = 0f;
                    if (tint)
                        foreach (var renderer in p.Avatar.GetComponentsInChildren<Renderer>(true))
                            foreach (var material in renderer.materials) if (material.HasProperty("_Color")) material.color *= new Color(.65f, .8f, 1.15f, 1f);
                    Logger.LogInfo("Player " + p.Slot + " shown as NPC model " + (string.IsNullOrEmpty(model.ID) ? model.name : model.ID) + (tint ? " (tinted)" : ""));
                    p.Animator = p.Avatar.GetComponentInChildren<Animator>(true);
                    if (p.Animator != null)
                    {
                        p.Animator.runtimeAnimatorController = model.AnimationControllerNormal;
                        p.Animator.enabled = true; p.Animator.applyRootMotion = false;
                    }
                    // 1.0.9: the armed pose comes from an invisible military NPC playing the game's
                    // "NPC with AK" controller (RemoteAvatarMotion).
                    var soldier = PickModel(models.Where(item => item != model).ToList(), "MilitaryRegularNPC_01", "MilitaryRegularNPC");
                    GameObject driver = null;
                    if (soldier != null && soldier != model && npc.AnimatorControllerNPCWithAK != null)
                    {
                        try { driver = DisplayCopy(soldier, staging.transform, "LAN Remote Player pose"); }
                        catch (Exception ex) { Logger.LogWarning("Armed pose unavailable: " + ex.Message); }
                    }
                    RemoteAvatarMotion.Log = message => Logger.LogInfo(message);
                    p.Motion = p.Avatar.AddComponent<RemoteAvatarMotion>();
                    string poseProblem = p.Motion.Initialize(p.Animator, driver, npc.AnimatorControllerNPCWithAK);
                    if (poseProblem != null) Logger.LogWarning("Armed pose unavailable: " + poseProblem);
                    // 1.1.9: its flashlights and steps.
                    try
                    {
                        string rig;
                        p.Extras = p.Avatar.AddComponent<RemoteAvatarExtras>();
                        p.Extras.Initialize(RemoteAvatarMotion.FindBone(p.Avatar.transform, "Hub003", out rig), p.Motion.RightPalm);
                    }
                    catch (Exception ex) { Logger.LogWarning("Partner flashlights and steps unavailable: " + ex.Message); p.Extras = null; }
                    // 2.3.0: what it wears, placed by the prefab pose it still has here.
                    try
                    {
                        p.Wear = p.Avatar.AddComponent<RemoteOutfitVisual>();
                        string problem = p.Wear.Initialize();
                        if (problem != null) { Logger.LogWarning("Partner's worn items unavailable: " + problem); Object.Destroy(p.Wear); p.Wear = null; }
                    }
                    catch (Exception ex) { Logger.LogWarning("Partner's worn items unavailable: " + ex.Message); p.Wear = null; }
                    p.Avatar.transform.SetParent(null, false);
                    p.Avatar.transform.position = p.WorldPosition();
                    p.Avatar.SetActive(true);
                    return;
                }
            }
            catch (Exception ex)
            {
                Logger.LogWarning("NPC avatar unavailable: " + ex.Message);
                if (p.Avatar != null) Object.Destroy(p.Avatar);
                p.Animator = null; p.Motion = null; p.Extras = null;
            }
            finally
            {
                if (staging != null) Object.Destroy(staging);
                LanInventoryGuard.CaptureCheckpoint("after-remote-avatar", Logger);
            }
            p.Avatar = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            p.Avatar.name = "LAN Remote Player (placeholder)";
            p.AvatarYOffset = 1f;
            var capsuleCollider = p.Avatar.GetComponent<Collider>();
            if (capsuleCollider != null) capsuleCollider.enabled = false;
        }

        // A display-only copy of an NPC model under the inactive staging object (so Awake/OnEnable
        // wait until every gameplay script is gone): no scripts, colliders, physics, sounds or
        // cameras, and without the rifles baked into the model. Left inactive.
        internal static GameObject DisplayCopy(CharacterModel model, Transform staging, string name)
        {
            var copy = Object.Instantiate(model.gameObject, staging, false);
            copy.SetActive(false);
            copy.name = name;
            foreach (var behaviour in copy.GetComponentsInChildren<MonoBehaviour>(true)) Object.DestroyImmediate(behaviour);
            if (copy.GetComponentsInChildren<MonoBehaviour>(true).Length != 0)
            {
                Object.Destroy(copy);
                throw new InvalidOperationException("Avatar still contains gameplay scripts");
            }
            foreach (var collider in copy.GetComponentsInChildren<Collider>(true)) collider.enabled = false;
            foreach (var body in copy.GetComponentsInChildren<Rigidbody>(true)) { body.isKinematic = true; body.detectCollisions = false; }
            foreach (var audio in copy.GetComponentsInChildren<AudioSource>(true)) audio.enabled = false;
            foreach (var camera in copy.GetComponentsInChildren<Camera>(true)) camera.enabled = false;
            foreach (var child in copy.GetComponentsInChildren<Transform>(true))
                if (child.name == "Pickup_AKM_LOD0" || child.name == "Pickup_HuntingRifle_LOD0") child.gameObject.SetActive(false);
            return copy;
        }

        private void HideAvatars() { foreach (var link in _links.Values) HideAvatar(link.Player); HideOthers(); }
        private void HideOthers() { foreach (var other in _others.Values) HideAvatar(other); }

        private static void HideAvatar(RemotePlayer p)
        {
            if (p.Avatar != null) { Object.Destroy(p.Avatar); p.Avatar = null; }
            p.Animator = null;
            p.Motion = null;
            p.Extras = null;
            p.Equipment = null;
            p.Wear = null;
        }

        private bool LocalWorldReady()
        {
            var manager = GlobalManager.global;
            var scenes = GlobalSceneManager.global;
            var character = manager == null ? null : manager.controlledChar;
            // Control held by this mod's panel or by an open game window (inventory, a host
            // storage, construction) still counts as ready: the character is where it is, and
            // the host must keep seeing it (an open host storage closes without its position).
            if (character == null || scenes == null || scenes.SceneCurrentlyLoading || ClientTravelHooks.Loading ||
                !character.controlEnabled && _lanHeldPlayer != character && !GameWindowOpen() && !LanHoldsPlayer() || character.GetComponent<DelayedMoveToTrain>() != null ||
                character.transform.position == Vector3.zero)
            { _readySince = -1f; return false; }
            if (_readySince < 0f) _readySince = Time.unscaledTime;
            return Time.unscaledTime - _readySince > 3f;
        }

        // 1.4.1: control held by a LAN feature that keeps the player where it is (downed, waiting in bed
        // for the partner, the robot dog window). The host must keep seeing it: its pose says it is
        // downed (the partner's revive prompt), and its place keeps the host's requests answered.
        private static bool LanHoldsPlayer() { return LanDowned.Down || LanSleep.Waiting || LanTakables.WindowOpen; }

        private static bool GameWindowOpen()
        {
            var inventory = Zompiercer.Inventory.InventoryController.global;
            if (inventory != null && !inventory.IsAllInventoryClosed()) return true;
            var input = LanGame.Input;
            return input != null && (int)input.CurrentState != 1; // a UI state of the game
        }

        private static bool TrainWorldAvailable()
        {
            var manager = GlobalManager.global;
            var scenes = GlobalSceneManager.global;
            var save = Zompiercer.SaveLoad.SaveLoadCore.global;
            return manager != null && manager.controlledChar != null && scenes != null &&
                !scenes.SceneCurrentlyLoading && !ClientTravelHooks.Loading && save != null && !save.LoadingNow && save.currentLocation > 0 &&
                manager.controlledChar.GetComponent<DelayedMoveToTrain>() == null;
        }

        private bool TryFindSpawn(ZombieFighterController character, out Vector3 target)
        {
            var host = HostLink.Player;
            for (int ring = 0; ring < 3; ring++)
            for (int i = 0; i < 8; i++)
            {
                var candidate = host.WorldPosition() + Quaternion.Euler(0f, host.Yaw + i * 45f, 0f) * Vector3.right * (2f + ring * 1.5f);
                if (GroundSpot(character, candidate, 3f, 8f, out target)) return true;
            }
            target = Vector3.zero;
            return false;
        }

        // Walkable ground below `candidate` (searched from `above` metres higher,
        // `depth` metres down) with room for the character's capsule.
        private static bool GroundSpot(ZombieFighterController character, Vector3 candidate, float above, float depth, out Vector3 target)
        {
            var controller = character.controller;
            float radius = controller == null ? 0.4f : controller.radius;
            float height = controller == null ? 1.8f : Mathf.Max(controller.height, radius * 2f);
            Vector3 center = controller == null ? Vector3.up * height * 0.5f : controller.center;
            var hits = Physics.RaycastAll(candidate + Vector3.up * above, Vector3.down, depth, ~0, QueryTriggerInteraction.Ignore).OrderBy(h => h.distance);
            foreach (var hit in hits)
            {
                if (hit.normal.y < 0.65f || hit.collider.transform.IsChildOf(character.transform)) continue;
                target = hit.point + Vector3.up * (height * 0.5f - center.y + 0.12f);
                var middle = target + center;
                var upper = middle + Vector3.up * (height * 0.5f - radius);
                var lower = middle - Vector3.up * (height * 0.5f - radius);
                if (Physics.OverlapCapsule(lower, upper, radius, ~0, QueryTriggerInteraction.Ignore)
                    .Any(c => !c.transform.IsChildOf(character.transform))) continue;
                return true;
            }
            target = Vector3.zero;
            return false;
        }

        // The place stored in the guest profile, if it is in the current scene and
        // location and still walkable. Train passengers return to the same car.
        private static bool SavedPlace(object[] profile, ZombieFighterController character, out Vector3 target, out float yaw)
        {
            target = Vector3.zero; yaw = 0f;
            var scenes = GlobalSceneManager.global; var saves = Zompiercer.SaveLoad.SaveLoadCore.global;
            if (scenes == null || saves == null || (string)profile[1] != scenes.CurrentSceneName || (int)profile[2] != saves.currentLocation) return false;
            Vector3 place;
            int carIndex = (int)profile[3];
            if (carIndex >= 0)
            {
                var car = TrainSync.GetCar(carIndex);
                if (car == null) return false;
                place = car.transform.TransformPoint(new Vector3((float)profile[8], (float)profile[9], (float)profile[10]));
                yaw = (car.transform.rotation * Quaternion.Euler(0f, (float)profile[11], 0f)).eulerAngles.y;
            }
            else { place = new Vector3((float)profile[4], (float)profile[5], (float)profile[6]); yaw = (float)profile[7]; }
            return GroundSpot(character, place, 1.5f, 4f, out target);
        }

        private void RestoreGuestCharacter(object[] profile)
        {
            LanInventoryGuard.CaptureCheckpoint("before-guest-restore", Logger);
            try
            {
                LanGuestCharacter.Apply(profile);
                GuestClient.Applied(true, LanText.T("Персонаж восстановлен из профиля у хоста; прогресс сохраняется у хоста"));
                Logger.LogInfo("Guest character restored from the host's profile");
            }
            catch (Exception ex)
            {
                GuestClient.Applied(false, ex.GetType().Name);
                Logger.LogError("Guest character restore failed: " + ex);
            }
            LanInventoryGuard.CaptureCheckpoint("after-guest-restore", Logger);
        }

        private byte[] GuestToken(Guid world)
        {
            if (_identity == null)
            {
                if (_identityFailed) return null;
                try { _identity = LanPlayerIdentity.LoadOrCreate(LanPlayerIdentity.DefaultDirectory); }
                catch (Exception ex)
                {
                    _identityFailed = true;
                    Logger.LogWarning("Guest identity unavailable (" + LanLogPrivacy.Clean(LanPlayerIdentity.DefaultDirectory) + "): " +
                        ex.GetType().Name + ": " + LanLogPrivacy.Clean(ex.Message));
                    return null;
                }
            }
            return _identity.WorldToken(world);
        }

        // Guest (0.12.0): tell the host where it fell, then come back next to the host.
        private void UpdateGuestDeath()
        {
            if (!LanGuestDeath.Dead) { _deathSent = false; return; }
            var client = StorageClient;
            if (!_deathSent && client != null && Connected && Time.unscaledTime >= _deathRetryAt)
            {
                _deathSent = client.Death(LanGuestDeath.Point.x, LanGuestDeath.Point.y, LanGuestDeath.Point.z, LanGuestDeath.Car);
                if (!_deathSent) { _deathRetryAt = float.MaxValue; LanGuestDeath.Answer(LanStorage.Invalid, 0); }
            }
            if (!LanGuestDeath.ReadyToRespawn) return;
            LanGuestDeath.Respawn();
            _clientPlacedNearHost = false; _readySince = -1f; _deathSent = false; _deathRetryAt = 0f; _respawning = true;
            if (_deathLeftItems) _marks?.Stash(LanGuestDeath.Car, LanGuestDeath.Point, LanText.T("Ваши вещи"));
            _deathLeftItems = false;
        }
        private void DeathAnswered(byte status, int stacks)
        {
            if (status == LanStorage.Busy) { _deathSent = false; _deathRetryAt = Time.unscaledTime + 3f; return; }
            LanGuestDeath.Answer(status, stacks);
            _deathLeftItems = status == LanStorage.Ok && stacks > 0;
            // No more states while dead: the host hides the body; placement waits for the respawn.
            _clientPlacedNearHost = false;
            Logger.LogInfo("Guest death answered: status " + status + ", " + stacks + " item stack(s) left");
        }
        // Host (0.12.0): a guest died; its belongings lie in bags there.
        private void GuestDied(LanLink link, int car, Vector3 point)
        {
            link.GuestDeadAt = Time.unscaledTime;
            LanGuestCredits.Respawn(link.Slot); // 1.3.0: it comes back with fresh health and needs
            link.Player.Downed = false; link.Player.Dead = true; // until its first state after the respawn
            HideAvatar(link.Player);
            string who = LanSkinPicker.Label(link.Slot);
            _marks?.Stash(car, point, LanText.T("Вещи: ") + who);
            _marks?.Toast(who + LanText.T(" погиб. Его вещи остались в сумке на месте гибели"));
        }

        // Host (1.1.7): the boss arena waits for the guests while they play in this world, dead or alive.
        private void BossArenaTick()
        {
            bool hosting = _hosting && Connected;
            var guests = new List<LanBossArena.Player>();
            if (hosting && _hostWorldReady)
                foreach (var link in _links.Values)
                {
                    var p = link.Player;
                    if (!link.Connected || !p.HaveState || p.Scene != _hostWorldScene || Time.unscaledTime - p.StateAt >= 60f) continue;
                    bool dead = link.GuestDeadAt >= 0f;
                    guests.Add(new LanBossArena.Player { Slot = link.Slot, Position = dead ? null : GuestPosition(link), Dead = dead });
                }
            LanBossArena.Tick(hosting, guests);
        }

        // 1.2.0: while a session is attached the guests' quests show the host's, and on the host a
        // quest goal counts for the guests too (their places, their ledgers).
        private void QuestsTick()
        {
            bool hosting = _hosting && Connected;
            LanQuests.Guest = !_hosting && Connected && LanQuests.Failure == null;
            if (!LanQuests.Guest) LanQuests.Request = null;
            if (_questPositions == null) _questPositions = () =>
            {
                var list = new List<Vector3>();
                foreach (var link in _links.Values) { var at = GuestPosition(link); if (at != null) list.Add(at.Value); }
                return list;
            };
            if (_questCount == null) _questCount = id =>
            {
                long most = 0;
                foreach (var link in _links.Values) { var book = Ledger(link); if (book != null) most = Math.Max(most, book.Count(id)); }
                return most;
            };
            if (_questProfiles == null) _questProfiles = () =>
            {
                var list = new List<string>();
                foreach (var link in _links.Values) { string id = ProfileOf(link); if (id != null && GuestPosition(link) != null && Ledger(link) != null) list.Add(id); }
                return list;
            };
            LanQuests.GuestPositions = hosting ? _questPositions : null;
            LanQuests.GuestCount = hosting ? _questCount : null;
            LanQuests.GuestProfilesHere = hosting ? _questProfiles : null; // 1.4.5
        }

        // 1.2.1: a guest's avatar holds what the guest carries (LanLink: TrackGuest); a guest sees what
        // the host carries in the host avatar's hands.
        private void TakablesTick()
        {
            if (_hostAvatar == null) _hostAvatar = () =>
            {
                var link = HostLink;
                var p = link == null ? null : link.Player;
                return p != null && p.Avatar != null && p.Avatar.activeSelf && !p.Lying ? p.Avatar.transform : null;
            };
            LanTakables.Hosting = _hosting && Connected && LanTakables.Failure == null;
            LanWorldItems.PartnerAvatar = !_hosting && Connected ? _hostAvatar : null;
            LanTakables.HostTick();
            LanFuelStation.HostTick();
            // 1.4.4: zombie health and loot for the players (2.4.1: from the one-guest factor evenly up to the seven-guest one).
            int connected = 0, here = 0;
            if (_hosting)
                foreach (var link in _links.Values)
                {
                    if (!link.Connected) continue;
                    connected++;
                    if (GuestPosition(link) != null) here++;
                }
            if (here != 0) _coopGuests = here;
            LanDifficulty.ZombieHealth = LanDifficulty.ForGuests(_coopHealthEntry.Value, _coopHealthMaxEntry.Value, _coopGuests);
            LanDifficulty.Loot = LanDifficulty.ForGuests(_coopLootEntry.Value, _coopLootMaxEntry.Value, connected);
            LanDifficulty.LootActive = connected != 0;
            LanDifficulty.HostTick(connected != 0, here != 0);
            // 2.4.1: two of each firearm in a location reached with 4 or more players.
            if (_extraWeaponsPlayers == null) _extraWeaponsPlayers = () => 1 + ConnectedGuests();
            LanExtraWeapons.Players = _hosting && _extraWeaponsEntry.Value ? _extraWeaponsPlayers : null;
        }


        // Native train presence includes a living guest whose latest position the host accepted.
        private TrainCar HostGuestTrainCar()
        {
            if (!_hosting || !_hostWorldReady) return null;
            foreach (var link in _links.Values)
            {
                var p = link.Player;
                if (p.CarIndex < 0 || p.Downed || p.Dead || link.GuestDeadAt >= 0f || GuestPosition(link) == null) continue;
                var car = TrainSync.GetCar(p.CarIndex);
                if (car != null) return car;
            }
            return null;
        }

        // Host: where a guest stands (validated pose, car-relative while aboard).
        private Vector3? GuestPosition(LanLink link)
        {
            var p = link.Player;
            if (!link.Connected || !_hostWorldReady || !p.HaveState || Time.unscaledTime - p.StateAt > 2f || p.Scene != _hostWorldScene) return null;
            return p.WorldPosition();
        }

        // Guest: requests keep flowing while connected; opening needs the host's
        // world, a placed character and a profile the host keeps.
        private void UpdateGuestStorage()
        {
            var client = StorageClient;
            var guestClient = GuestClient;
            if (client != null && Connected) client.Tick(Time.unscaledTime);
            if (client != null) LanStorageGame.TickWindow(client);
            var scenes = GlobalSceneManager.global;
            bool usable = client != null && Connected && _clientPlacedNearHost && !LanGuestDeath.Dead && !_travel.Active && guestClient != null && guestClient.Saving &&
                LanStorageGame.Failure == null && TrainWorldAvailable() && _clientWorld != null && scenes != null && scenes.CurrentSceneName == _clientWorld.Scene;
            // 1.2.0: quests go to the host on the same terms as its storages.
            if (usable && _questRequest == null) _questRequest = (kind, key, scene) => { var asker = StorageClient; return asker != null && asker.Quest(kind, key, scene); };
            LanQuests.Request = usable ? _questRequest : null;
            LanQuests.Unavailable = usable ? "" : guestClient != null && guestClient.Blocked ? LanText.T("Квесты недоступны: ваш профиль у хоста не сохраняется")
                : LanText.T("Квесты станут доступны, когда вы будете в мире хоста");
            if (!usable)
            {
                LanStorageGame.CloseWindow(client);
                LanTakables.GuestAbort();
                string reason = guestClient != null && guestClient.Blocked ? LanText.T("Хранилища хоста недоступны: ваш профиль у хоста не сохраняется")
                    : LanText.T("Хранилища хоста откроются, когда вы будете в его мире");
                LanStorageGame.GuestOpenScene = inventory => LanStorageGame.Notice(reason);
                // Work on the host's world is refused too (the guest's own copy is not used).
                LanWorldWork.GuestWork = client == null ? null : (Func<int, Vector3, int, int, object[], bool>)((kind, at, tool, extra, escrow) => { LanStorageGame.Notice(reason); return false; });
                LanTrainBuild.GuestBuild = null; LanTrainBuild.GuestPlace = null;
                LanTrainBuild.GuestFurniture = null; LanTrainBuild.GuestDismantle = null;
                LanTrainControl.GuestRequest = null;
                LanThrows.GuestThrow = null; LanTrainDecor.GuestRequest = null; LanFuelStation.GuestRequest = null;
                return;
            }
            LanStorageGame.GuestOpenScene = inventory => LanStorageGame.OpenWindow(client, LanStorageGame.SceneTarget(inventory), null, inventory);
            LanWorldWork.GuestWork = (kind, at, tool, extra, escrow) => client.Work(kind, at.x, at.y, at.z, tool, extra, escrow);
            LanTrainBuild.GuestBuild = (car, kind, identity, tool, needs) => client.Build(car, kind, identity, tool, needs);
            LanTrainBuild.GuestPlace = (part, car, type, point, pose) => client.Place(part, car, type, point, pose);
            // 1.4.2: furniture kits and taking the host's train apart.
            LanTrainBuild.GuestFurniture = (kit, car, pose, answer, giveBack) => client.Furniture(kit, car, pose, answer, giveBack);
            LanTrainBuild.GuestDismantle = (mode, car, owner, identity, tool, answer) => client.Dismantle(mode, car, owner, identity, tool, answer);
            LanTrainControl.GuestRequest = (kind, index, check, value, escrow) => client.Control(kind, index, check, value, escrow);
            // 1.4.0: the guest's explosives fly in the host's world; paint, wires and signs of the host's train.
            LanThrows.GuestThrow = (escrow, car, at, turn, type, answer, giveBack) => client.Throw(escrow, car, at, turn, type, answer, giveBack);
            LanTrainDecor.GuestRequest = (request, answer) => client.Decor(request, answer);
            // 1.4.3: the fuel stations of the host's scene.
            LanFuelStation.GuestRequest = (payload, answer) => client.Takable(payload, answer);
            LanTrainControl.Tick();
            // 1.2.1: a host object in the guest's hands, the guest's robot window.
            LanTakables.GuestTick(client);
            if (GameMenusVisible()) { LanStorageGame.CloseWindow(client); LanTakables.CloseWindow(); }
            if (LanTakables.Carrying || LanTakables.WindowOpen) return;
            if (LanStorageGame.WindowOpen || LanStorageGame.RecentlyClosed || _panelOpen) return;
            var input = LanGame.Input;
            var inventories = Zompiercer.Inventory.InventoryController.global;
            if (input == null || (int)input.CurrentState != 1 || inventories == null || !inventories.IsAllInventoryClosed()) return;
            bool use = input.isKbMouseDevice ? input.isUseKeyDown : input.gp_isUseOpenTalkDown;
            // The game picks loose items up with its use key or its own take key.
            bool take = use || input.isTakeItemAccept_Down;
            // 1.2.1: a host barrel or robot dog in front of the guest.
            var near = LanWorldItems.InViewAny();
            if (near != null && near.Kind == LanWorldItems.TakableKind)
            {
                bool looked = LanTakables.GuestLook(near, use, input.isKbMouseDevice && input.isReloadDown, client);
                LanWorldWork.HintHeld(near); // 2.4.4: a barrel to take apart with the tool in hand
                if (looked) return;
            }
            var shown = near != null && near.Kind != LanWorldItems.TakableKind ? near : null;
            if (shown != null)
            {
                if (shown.Kind == LanWorldItems.BagKind)
                {
                    LanStorageGame.HintOpen(LanStorageGame.BagName());
                    if (use) LanStorageGame.OpenWindow(client, LanStorage.BagPayload(shown.HostId));
                }
                else
                {
                    // 2.4.3: a host sleeping bag also takes the guest to sleep (LanSleep), as the game's own.
                    // 2.5.0: forced, as on the host's train (2.3.0): the look ray (LanWorldItems.LookAt) found nothing on the
                    // game's selection layers before the item, so what the game calls hovered is behind it: the location's
                    // shelf it lies on took its "pick up" away.
                    if (LanStorageGame.HintPickUp(shown.ItemId, shown.Amount, true)) LanSleep.LookAtSleepingBag(shown.ItemId, input);
                    if (take && !client.Busy) client.Pickup(shown.HostId, shown.ItemId, shown.Amount);
                }
                return;
            }
            // 2.8.0: a host chicken to catch by hand.
            if (_zombies != null && !client.Busy && _zombies.LookAtAnimals(take)) return;
            // Host blueprints to build and host fuel tanks to fill.
            if (LanTrainBuild.Tick(client)) return;
            // 1.1.6: doors of the host's train, through the host.
            if (LanTrainControl.TickDoor(use)) return;
            // Light switches of parts the host built (when the host lets the guest drive).
            if (LanTrainControl.TickLook(use)) return;
            // 1.4.11: an item on a shelf before the shelf's own storage.
            int hostId, itemId, itemAmount;
            if (TrainItemInView(out hostId, out itemId, out itemAmount))
            {
                LanStorageGame.HintPickUp(itemId, itemAmount, true); // 2.3.0: above the shelf it stands on
                LanSleep.LookAtSleepingBag(itemId, input); // 2.4.3: a sleeping bag on the host's train
                if (take && !client.Busy) client.Pickup(hostId, itemId, itemAmount);
                return;
            }
            Workbench bench;
            byte[] target = LanStorageGame.TrainTargetInView(out bench);
            if (target != null)
            {
                LanStorageGame.HintOpen(null);
                if (use) LanStorageGame.OpenWindow(client, target, bench);
            }
        }

        // 1.4.11: an item the host placed on its train, also one on a shelf whose copy is one box (LookAt).
        private static bool TrainItemInView(out int hostId, out int itemId, out int amount)
        {
            hostId = itemId = amount = 0;
            var seen = LanWorldItems.LookAt(LanWorldItems.Look, collider => { int id, item, count; return TrainLayout.TryIdentifyItem(collider, out id, out item, out count); });
            return seen != null && TrainLayout.TryIdentifyItem(seen, out hostId, out itemId, out amount);
        }

        // Guest: items its player dropped or placed this frame go to the host's world.
        private void BookDroppedItems()
        {
            var dropped = LanWorldItems.Dropped;
            if (dropped.Count == 0) return;
            var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
            var client = StorageClient;
            var guestClient = GuestClient;
            bool usable = !_hosting && Connected && client != null && player != null && _clientPlacedNearHost && guestClient != null && guestClient.Saving;
            for (int i = dropped.Count - 1; i >= 0; i--)
            {
                var item = dropped[i];
                if (item == null || item.inInventory != null) { dropped.RemoveAt(i); LanWorldItems.Placed.Remove(item); continue; } // picked back or destroyed
                if (!usable) { dropped.RemoveAt(i); LanWorldItems.Placed.Remove(item); continue; } // solo or unsaved: a local item like any other
                if (client.Busy) return; // one escrow at a time; it waits where it lies
                var at = item.transform.position;
                Vector3 grabbed;
                if (LanWorldItems.TakeStolen(item, out grabbed)) at = grabbed; // 2.2.0: a frog's tongue took it: by the frog
                else if ((at - player.transform.position).sqrMagnitude > 9f) at = player.transform.position + player.transform.forward * .8f + Vector3.up * .3f;
                object[] entry = null;
                try { entry = LanStorage.Normalize(new object[] { item.itemID, item.amount, item.Save() }); LanGuestCharacter.ValidateItems(new object[] { entry }, 0); }
                catch (Exception ex) { Logger.LogWarning("Dropped item cannot travel: " + ex.Message); entry = null; }
                dropped.RemoveAt(i);
                bool placed = LanWorldItems.Placed.Remove(item);
                var car = item.ParentedToTraincCar;
                int carIndex = TrainLayout.CarIndex(GlobalManager.global.controlledTrain, car);
                var position = carIndex < 0 ? at : car.transform.InverseTransformPoint(at);
                var rotation = carIndex < 0 ? item.transform.rotation : Quaternion.Inverse(car.transform.rotation) * item.transform.rotation;
                var pose = new[] { position.x, position.y, position.z, rotation.x, rotation.y, rotation.z, rotation.w };
                if (entry != null && (placed ? client.Drop(entry, carIndex, pose) : client.Drop(entry, at.x, at.y, at.z)))
                { item.amount = 0; item.gameObject.SetActive(false); Object.Destroy(item.gameObject); continue; }
                // Not sent: back into the backpack rather than a local-only item.
                if (player.inventory == null || !player.inventory.Add(item, true)) Logger.LogWarning("Dropped item kept locally");
                LanStorageGame.Notice(LanText.T("Этот предмет нельзя выбросить по сети"));
            }
        }

        private void DrawGuestProfile()
        {
            bool connected = Connected;
            if (_hosting)
                foreach (var link in LinkList())
                {
                    var kit = link.Connected && link.GuestHost != null ? link.GuestHost.PendingKit : null;
                    if (kit == null) continue;
                    GUILayout.Label(LanSkinPicker.Label(link.Slot) + LanText.T(" пришёл с вещами (их источник хост не видит):"));
                    GUILayout.Label(LanLedgerRules.Describe(kit));
                    GUILayout.BeginHorizontal();
                    if (GUILayout.Button(LanText.T("Принять вещи"))) link.GuestHost.AcceptKit(true);
                    if (GUILayout.Button(LanText.T("Без вещей"))) link.GuestHost.AcceptKit(false);
                    GUILayout.EndHorizontal();
                }
            if (_hosting)
                foreach (var link in LinkList())
                    if (link.StorageHost != null && link.StorageHost.Open) GUILayout.Label(LanSkinPicker.Label(link.Slot) + LanText.T(" смотрит в хранилище"));
            if (_hosting)
            {
                bool drive = GUILayout.Toggle(LanTrainControl.HostAllows, LanText.T(" Друзья могут управлять поездом (тяга, тормоз, двигатель, свет, ремонт рычагов)"));
                if (drive != LanTrainControl.HostAllows) { LanTrainControl.HostAllows = drive; _friendDrivesEntry.Value = drive; }
            }
            else if (connected) GUILayout.Label(LanTrainControl.GuestAllowed ? LanText.T("Хост разрешил вам управлять поездом") : LanText.T("Управлять поездом может только хост"));
            if (connected && _chat != null)
            {
                GUILayout.Label(_chat.Hint);
                GUILayout.Label(LanText.T("Игроки и пинг до хоста: Ъ / ]"));
                bool hide = GUILayout.Toggle(LanChat.HidePartner, LanText.T(" Скрыть сообщения других игроков"));
                if (hide != LanChat.HidePartner) { LanChat.HidePartner = hide; _chatHideEntry.Value = hide; }
            }
            if (connected) GUILayout.Label(LanText.T("Метка: ") + (LanMarks.Key == KeyCode.Mouse2 ? LanText.T("средняя кнопка мыши") : LanMarks.Key.ToString()) + LanText.T(" (враг, находка или «сюда»); повторно по своей метке — убрать"));
            if (_hosting)
                foreach (var link in LinkList())
                    if (link.Connected && link.GuestHost != null) GUILayout.Label(LanSkinPicker.Label(link.Slot) + ": " + link.GuestHost.Status);
            if (!_hosting && GuestClient != null && connected) GUILayout.Label(GuestClient.Status);
            // 2.0.0: a guest sees who else plays (the host, and the other guests the host shows it).
            if (!_hosting && connected)
            {
                var names = new List<string> { LanSkinPicker.Label(0) };
                foreach (var other in _others.Values) if (other.HaveState && Time.unscaledTime - other.StateAt < 10f) names.Add(LanSkinPicker.Label(other.Slot));
                GUILayout.Label(LanText.T("В комнате: вы, ") + string.Join(", ", names.ToArray()));
            }
            if (_hosting && LanGuestPersistence.LastResult != null) GUILayout.Label(LanGuestPersistence.LastResult);
        }

        private void LogLocalEquipment()
        {
            if (!Connected || Time.unscaledTime < _nextWeaponCheck) return;
            _nextWeaponCheck = Time.unscaledTime + 1f;
            var character = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
            var inventory = Zompiercer.Inventory.InventoryController.global;
            if (character == null || inventory == null || character.zombieFighterFireArmWeapon == null) return;
            if (!_inventoryReadyCaptured && LocalWorldReady())
            {
                _inventoryReadyCaptured = true;
                LanInventoryGuard.CaptureCheckpoint("local-world-ready", Logger);
            }
            var firearm = character.zombieFighterFireArmWeapon;
            string belt = character.beltInventory == null ? "missing" : string.Join("|", character.beltInventory.Select(slot =>
                slot == null ? "null" : string.Join(",", slot.content.Select(item => item == null ? "null" : item.itemID.ToString()).ToArray())).ToArray());
            var gun = firearm.gunList.FirstOrDefault(g => g != null && g.ID == firearm.SelectedWeaponID);
            string state = "slot=" + inventory.selectedBeltIcon + " belt=" + belt + " selected=" + firearm.SelectedWeaponID +
                " active=" + (gun != null && gun.gameObject.activeInHierarchy) + " control=" + character.controlEnabled +
                " lowered=" + (character.weaponAnimator != null && character.weaponAnimator.Down);
            if (state == _lastWeaponState) return;
            _lastWeaponState = state;
            Logger.LogInfo("Local equipment: " + state);
            LanInventoryGuard.CaptureCheckpoint("local-equipment-changed", Logger);
        }

        private static bool SameEndpoint(IPEndPoint left, IPEndPoint right)
        {
            return left != null && right != null && left.Port == right.Port && left.Address.Equals(right.Address);
        }

    }
}

