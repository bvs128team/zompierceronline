using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
using Zompiercer.Inventory;
using Object = UnityEngine.Object;

namespace ZompiercerLAN
{
    // Work on the world through the host (0.7.0): melee hits on resource objects,
    // gathering with a knife, digging with a shovel, filling a canister at a gas
    // station; 0.8.0: pouring a full canister into a fuel tank of the host's train. The guest's own copy of these objects is never used; the host acts on
    // its objects with its own copy of the guest's tool and hands out the result. 1.2.2: filling
    // empty bottles at, and pouring dirty water into, the rainwater tank of the host's train.
    // 2.4.4: chopping a fallen tree (the game's melee blow on its HitPoints, not a take-apart hit: the guest's copy
    // fell and its logs were hidden as the guest's own, while the host's tree stood); taking apart a host barrel
    // (a carryable copy here); a flower is the one at that very place (the nearest within 30 cm was another of the
    // patch while the guest's picked one stayed), and the guest's copy goes once the host has none left.
    internal static class LanWorldWork
    {
        internal const int EmptyCanister = 92, FullCanister = 8, Sand = 89, Soil = 296;
        // The game's empty plastic bottle and bottle of dirty water (InventoryController); 0.5 l each.
        internal const int EmptyBottle = 10, DirtyBottle = 61;
        internal const float BottleVolume = .5f;
        private const int Flower = 2;
        private static Harmony _harmony;
        private static Action<string> _log;
        internal static string Failure { get; private set; }
        // Guest: sends a work request; null when no usable session is attached.
        internal static Func<int, Vector3, int, int, object[], bool> GuestWork;

        private static readonly FieldInfo GunResource = AccessTools.Field(typeof(Gun), "resourceContent");
        private static readonly FieldInfo GunCollected = AccessTools.Field(typeof(Gun), "collectedResource");
        private static readonly FieldInfo GunFurniture = AccessTools.Field(typeof(Gun), "HitFurniture");
        private static readonly FieldInfo GunPart = AccessTools.Field(typeof(Gun), "HitTrainPart");
        private static readonly FieldInfo GunHit = AccessTools.Field(typeof(Gun), "raycastHit");
        internal static readonly MethodInfo GunWear = AccessTools.Method(typeof(Gun), "SubtractWeaponDurability");
        private static readonly FieldInfo SpawnedItem = AccessTools.Field(typeof(CollectedResource), "spawnedItemID");
        // 2.8.0 (game 22.0): a CollectedResource gives a cut while IsCanUse holds (GettingResource sets it off), animals' carcasses
        // and newer flowers list several resources (takableResources), and picked clean the game hides it (HideResource).
        private static readonly FieldInfo CanUse = AccessTools.Field(typeof(CollectedResource), "_isCanUse");
        private static readonly FieldInfo Takables = AccessTools.Field(typeof(CollectedResource), "takableResources");
        private static readonly MethodInfo HideResource = AccessTools.Method(typeof(CollectedResource), "HideResource");
        private static readonly FieldInfo FillingTank = AccessTools.Field(typeof(InventoryController), "CurrentlyFillingFuelTank");
        private static int _reportedGatherTool = -1;
        private static float _missingResourceLogAt = -100f;

        internal static void Initialize(Action<string> log)
        {
            _log = log;
            if (_harmony != null) return;
            _harmony = new Harmony("local.zompiercer.lan.world-work");
            try
            {
                if (GunResource == null || GunCollected == null || GunFurniture == null || GunPart == null || GunHit == null || GunWear == null || SpawnedItem == null || FillingTank == null)
                    throw new MissingMemberException("Gun/CollectedResource members changed");
                _harmony.Patch(AccessTools.Method(typeof(Gun), "MeleeDisassemblyTarget"), prefix: new HarmonyMethod(typeof(LanWorldWork), nameof(MeleePrefix)));
                _harmony.Patch(AccessTools.Method(typeof(InventoryController), "CheckGasStationAndFillGasoline"), prefix: new HarmonyMethod(typeof(LanWorldWork), nameof(FuelPrefix)));
                // The game's own "refuel from a canister" ends in these two calls.
                _harmony.Patch(AccessTools.Method(typeof(InventoryController), "GetResourcesFromItem"), prefix: new HarmonyMethod(typeof(LanWorldWork), nameof(PourPrefix)));
                _harmony.Patch(AccessTools.Method(typeof(TrainFuelTank), "Fill"), prefix: new HarmonyMethod(typeof(LanWorldWork), nameof(TankFillPrefix)));
                // 1.2.2: bottles at the host's rainwater tank, before the game uses the bottle in hand.
                _harmony.Patch(AccessTools.Method(typeof(InventoryController), "Update"), prefix: new HarmonyMethod(typeof(LanWorldWork), nameof(WaterPrefix)));
                // 2.4.5: the take-apart swing at a host barrel's copy (the game starts it only at an object it knows).
                _harmony.Patch(AccessTools.Method(typeof(ZombieFighterFireArmWeapon), "GunShot"), prefix: new HarmonyMethod(typeof(LanWorldWork), nameof(SwingPrefix)));
                // 2.4.4: a blow landing (Gun.MeleeHitTarget) and what it does to an object with hit points (a fallen tree).
                _harmony.Patch(AccessTools.Method(typeof(Gun), "MeleeHitTarget"), prefix: new HarmonyMethod(typeof(LanWorldWork), nameof(BlowPrefix)), postfix: new HarmonyMethod(typeof(LanWorldWork), nameof(BlowPostfix)));
                _harmony.Patch(AccessTools.Method(typeof(HitPoints), "CauseDamage"), prefix: new HarmonyMethod(typeof(LanWorldWork), nameof(HitPointsPrefix)));
                // 2.2.0: where each object to take apart stood when its location loaded (the same for every player).
                try { _harmony.Patch(AccessTools.Method(typeof(ResourceContent), "Start"), postfix: new HarmonyMethod(typeof(LanWorldWork), nameof(ResourceStarted))); }
                catch (Exception ex) { log("Objects taken apart are found by their place now (no load place): " + ex.GetType().Name + ": " + ex.Message); }
            }
            catch (Exception ex)
            {
                _harmony.UnpatchSelf();
                Failure = ex.GetType().Name + ": " + ex.Message;
                log("World work hooks unavailable: " + Failure);
            }
        }
        internal static void Shutdown() { _harmony?.UnpatchSelf(); _harmony = null; GuestWork = null; _pouring = null; _blowGun = null; _reportedGatherTool = -1; Gathers.Clear(); HeldAsks.Clear(); HeldWear.Clear(); }

        // A suppressed native melee blow needs its immediate local sound and chips.
        // Play only after a validated request is queued, exactly once at the hit, not
        // at every prefix (which also ran for refused and unrelated targets).
        private static bool _effectsFailed;
        internal static void PlaySuppressedHitEffects(Gun gun, bool assembly, int requiredTool = 0)
        {
            if (gun == null) return;
            try
            {
                gun.DoRaycast();
                var hit = (RaycastHit)GunHit.GetValue(gun);
                if (hit.collider == null) return;
                var effects = GlobalEffects.Global; var sounds = GlobalSoundEffects.global;
                var tool = InventoryController.global == null ? null : InventoryController.global.GetActiveIntenvoryItem();
                string tag = hit.collider.tag;
                ParticleSystem dust = effects == null ? null : effects.bulletHitDust;
                if (tag == "WallWood" || tag == "ObjectWood" || requiredTool == 1)
                { dust = effects == null ? null : effects.meleeWoodHit; gun.AudioPlay(assembly ? gun.meleeHitWoodSound : gun.disassemblyWoodSound, 1f); }
                if (tag == "WallMetal" || tag == "ObjectMetal" || requiredTool == 2)
                { dust = effects == null ? null : effects.meleeMetalHit; gun.AudioPlay(gun.disassemblyMetalSound, 1f); }
                if (tool != null && tool.toolShovel)
                {
                    var detector = LanGame.Detector;
                    int type = detector == null ? -1 : (int)detector.ResourceType;
                    if (type != 1 && type != 2) return; // the game: nothing more where nothing can be dug
                    dust = effects == null ? null : type == 1 ? effects.diggingSandHit : effects.diggingSoilHit;
                    var clip = sounds == null ? null : type == 1 ? sounds.GetDiggingSand() : sounds.GetDiggingSoil();
                    if (clip != null) gun.AudioPlay(clip, 1f);
                    if (dust != null) Object.Instantiate(dust, hit.point, Quaternion.FromToRotation(Vector3.up, hit.normal));
                    return;
                }
                if (tool != null && tool.toolKnife)
                {
                    dust = effects == null ? null : effects.cutGrassEffect;
                    var clip = sounds == null ? null : sounds.GetPlantCut();
                    if (clip != null) gun.AudioPlay(clip, 1f);
                }
                if (dust == null) return;
                var shown = Object.Instantiate(dust, hit.point, Quaternion.identity);
                shown.transform.LookAt(shown.transform.position + hit.normal);
            }
            catch (Exception ex)
            {
                if (_effectsFailed) return;
                _effectsFailed = true; _log?.Invoke("Take-apart blow effects failed: " + ex.GetType().Name + ": " + ex.Message);
            }
        }

        private static bool MeleePrefix(Gun __instance)
        {
            if (!LanSaveIsolation.Active) return true;
            var work = GuestWork;
            if (work == null) return true; // solo or not attached: the guest's own world
            try
            {
                __instance.DoRaycast();
                var tool = InventoryController.global == null ? null : InventoryController.global.GetActiveIntenvoryItem();
                if (tool == null) return false;
                // The host's train and furniture are never taken apart from here.
                if (GunFurniture.GetValue(__instance) != null || GunPart.GetValue(__instance) != null) return false;
                var resource = GunResource.GetValue(__instance) as ResourceContent;
                var collected = GunCollected.GetValue(__instance) as CollectedResource;
                bool sent = false; int requiredTool = 0;
                // 2.2.0: by where it stood when the location loaded: a chair knocked about stands elsewhere on each side.
                LanWorldReplica held;
                if (resource != null) { requiredTool = tool.GetToolType(); sent = work(LanStorage.WorkHit, LoadPlace(resource), tool.itemID, 0, null); }
                // 2.4.4: a host barrel (a carryable copy here, without its scripts): taken apart at the host.
                else if (HeldInView(out held))
                {
                    requiredTool = tool.GetToolType();
                    sent = work(LanStorage.WorkHitHeld, held.transform.position, tool.itemID, held.HostId, null);
                    if (sent) HeldAsks.Enqueue(held.HostId);
                }
                else if (tool.toolShovel)
                {
                    var detector = LanGame.Detector;
                    int type = detector == null ? 0 : (int)detector.ResourceType;
                    var hit = (RaycastHit)GunHit.GetValue(__instance);
                    if ((type == 1 || type == 2) && hit.collider != null) sent = work(LanStorage.WorkDig, hit.point, tool.itemID, type, null);
                }
                else if (tool.toolKnife && collected != null)
                {
                    // 2.8.0: the carcass of a host animal (its copy here carries a stand-in resource): cut at the host.
                    int animal = ZombieSync.AnimalOfResource(collected);
                    if (animal > 0) sent = work(LanStorage.WorkButcher, collected.transform.position, tool.itemID, animal, null);
                    else
                    {
                        sent = work(LanStorage.WorkGather, collected.transform.position, tool.itemID, 0, null);
                        if (sent) Gathers.Enqueue(collected);
                    }
                }
                // The tool wears as natively; the host wears its ledger copy alike.
                if (sent)
                {
                    PlaySuppressedHitEffects(__instance, false, requiredTool);
                    GunWear.Invoke(__instance, new object[] { -1f });
                }
            }
            catch (Exception ex) { _log?.Invoke("Melee work hook failed: " + ex.Message); }
            return false;
        }

        // ---- 2.4.4, guest: chopping, barrels, flowers ----
        // The weapon whose blow is landing now (Gun.MeleeHitTarget), for HitPoints.CauseDamage.
        private static Gun _blowGun;
        private static void BlowPrefix(Gun __instance) { _blowGun = __instance; }
        private static void BlowPostfix() { _blowGun = null; }
        // Hit points of an object of the location that falls apart into resources (a fallen tree): the guest's copy never
        // takes the damage; the guest's own blow goes to the host, whose tree's hit points come back (LanSceneStates).
        // Anything else with hit points (a zombie's stomach) is the game's.
        private static bool HitPointsPrefix(HitPoints __instance)
        {
            if (!LanSaveIsolation.Active || __instance == null) return true;
            var work = GuestWork;
            if (work == null) return true;
            var resource = ResourceOf(__instance);
            if (resource == null) return true;
            try
            {
                var gun = _blowGun;
                var tool = InventoryController.global == null ? null : InventoryController.global.GetActiveIntenvoryItem();
                if (gun != null && !gun.Hands && tool != null) work(LanStorage.WorkChop, LoadPlace(resource), tool.itemID, 0, null);
            }
            catch (Exception ex) { _log?.Invoke("Chop hook failed: " + ex.Message); }
            return false;
        }
        internal static HitPoints HitPointsOf(ResourceContent resource)
        {
            if (resource == null) return null;
            var points = resource.GetComponent<HitPoints>();
            if (points == null) points = resource.GetComponentInParent<HitPoints>();
            return points;
        }
        private static ResourceContent ResourceOf(HitPoints points)
        {
            var resource = points.GetComponent<ResourceContent>();
            return resource != null ? resource : points.GetComponentInParent<ResourceContent>();
        }

        // 2.4.5: ZombieFighterFireArmWeapon.GunShot starts the take-apart swing (Gun.MeleeRightMouseButton) only at an object
        // SelectionManager knows (HoveredResourceContent, a furniture, a part, a flower); a host barrel here is a copy without
        // scripts, so 2.4.4's request at its blow (MeleePrefix) never went: no swing, no blow. The same keys and checks start
        // the game's swing at the copy; its blow (Gun.OnHit -> MeleeDisassemblyTarget) becomes the request.
        private static bool SwingPrefix(ZombieFighterFireArmWeapon __instance)
        {
            if (!LanSaveIsolation.Active || GuestWork == null || __instance == null) return true;
            try
            {
                var input = LanGame.Input;
                if (input == null || (int)input.CurrentState != 1) return true; // EStateInput.Game: no window, build, paint or wire mode
                if (!(input.isKbMouseDevice ? input.isAimPressed : input.isDisassemblePressed)) return true;
                // The rest of GunShot's own conditions for the aim branch: no paint mode, no inventory or equipment open,
                // not eating or drinking, running, swimming, knocked back or bouncing, no train constructor or wire mode.
                var paint = Zompiercer.Paint.PaintManager.Global;
                if (paint != null && paint.PaintMode) return true;
                var inventory = InventoryController.global;
                if (inventory != null && (inventory.inventoryOpened || inventory.eqipmentInventoryOpened || inventory.consumeSomething)) return true;
                var player = __instance.zombieFighterController;
                if (player == null || !player.controlEnabled || player.runing || player.swimming || player.flightAfterHit || player.IsBouncing()) return true;
                var gui = LanGame.Gui;
                if (gui != null && gui.trainConstructor != null && gui.trainConstructor.activeSelf) return true;
                var wires = Zompiercer.Electricity.WireEditor.Global;
                if (wires != null && wires.IconWireModeActive != null && wires.IconWireModeActive.activeSelf) return true;
                var selection = SelectionManager.Global;
                if (selection != null && (selection.HoveredResourceContent != null || selection.HoveredFurniture != null ||
                    selection.HoveredTrainPartInfRange != null || selection.HoveredCollectedResource != null)) return true;
                var gun = __instance.GetSelectedGun();
                var tool = InventoryController.global == null ? null : InventoryController.global.GetActiveIntenvoryItem();
                if (gun == null || tool == null || gun.weaponType != 2 || gun.meleeDisassembly) return true;
                LanWorldReplica held;
                if (!HeldInView(out held)) return true;
                var resource = HeldResource(held.ItemId);
                if (!(resource.wood && tool.toolWood || resource.scrapMetal && tool.toolMetal)) return true;
                gun.MeleeRightMouseButton(); // the game's own checks: cooldown, stamina, a broken tool
                return false;
            }
            catch (Exception ex) { _log?.Invoke("Barrel swing hook failed: " + ex.Message); return true; }
        }

        // 2.8.0 (game 22.0): the game's own end of a cut on this copy (IsCanUse off), the host's flower having given its cut.
        internal static void Spent(CollectedResource resource)
        {
            try { if (CanUse != null && resource != null) CanUse.SetValue(resource, false); }
            catch (Exception) { }
        }

        // 2.8.0 (game 22.0): what a resource still gives (each listed resource's sum, or the one resource's count).
        internal static int Remaining(CollectedResource resource)
        {
            if (resource == null) return 0;
            if (!resource.UseNewSystem) return Math.Max(0, resource.resourceQuantity);
            var list = Takables == null ? null : Takables.GetValue(resource) as CollectedResource.TakableResource[];
            int left = 0;
            if (list != null) foreach (var item in list) left += Math.Max(0, item.resourceQuantity);
            return left;
        }
        // Guest: the host's resource was cut: this copy is spent as the game leaves it, hidden when picked clean.
        internal static void Picked(CollectedResource resource, bool clean)
        {
            if (resource == null) return;
            try
            {
                if (!clean) { Spent(resource); return; }
                if (!resource.UseNewSystem) { resource.Load(new object[] { 0 }); return; }
                Spent(resource);
                if (HideResource != null) HideResource.Invoke(resource, null);
            }
            catch (Exception ex) { _log?.Invoke("Resource state not applied: " + ex.GetType().Name + ": " + ex.Message); }
        }

        // 2.8.0 (game 22.0), host: what one cut of `amount` takes from a resource, as the game's GettingResource gives it to its
        // own player: each listed resource up to `amount` (a carcass: meat and skin; CollectedResources), or the one resource
        // up to its item's own stack (older flowers); the base class gives one cut only. Picked clean it is hidden the game's
        // way (an animal's carcass then goes, HideResource). Items whose prefab is missing here are not given.
        internal static List<object[]> Extract(CollectedResource resource, int amount, out int left)
        {
            var given = new List<object[]>(); left = 0;
            var prefabs = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.itemPrefab;
            if (resource == null || prefabs == null || CanUse == null || Takables == null || HideResource == null || !resource.IsCanUse) return given;
            amount = Math.Max(1, amount);
            bool clean = true;
            if (resource.UseNewSystem)
            {
                var list = Takables.GetValue(resource) as CollectedResource.TakableResource[];
                if (list == null) return given;
                for (int i = 0; i < list.Length; i++)
                {
                    if (list[i].resourceQuantity <= 0) continue;
                    int cut = Math.Min(list[i].resourceQuantity, amount);
                    list[i].resourceQuantity -= cut;
                    int id = list[i].spawnedItemID;
                    if (id >= 0 && id < prefabs.Length && prefabs[id] != null) given.Add(new object[] { id, cut, new object[4] });
                    if (list[i].resourceQuantity > 0) { clean = false; left += list[i].resourceQuantity; }
                }
                if (!(resource is CollectedResources)) CanUse.SetValue(resource, false);
            }
            else
            {
                CanUse.SetValue(resource, false);
                int id = (int)SpawnedItem.GetValue(resource);
                if (id < 0 || id >= prefabs.Length || prefabs[id] == null) return given;
                int cut = Math.Min(Math.Max(1, prefabs[id].amount), amount);
                given.Add(new object[] { id, cut, new object[4] });
                resource.resourceQuantity -= cut;
                left = Math.Max(0, resource.resourceQuantity);
                clean = resource.resourceQuantity <= 0;
            }
            if (clean) { CanUse.SetValue(resource, false); HideResource.Invoke(resource, null); }
            return given;
        }

        // A host carryable object that can be taken apart (a barrel) in front of the guest.
        private static bool HeldInView(out LanWorldReplica held)
        {
            held = LanWorldItems.InViewAny();
            if (held == null || held.Kind != LanWorldItems.TakableKind || HeldResource(held.ItemId) == null) { held = null; return false; }
            return true;
        }
        private static ResourceContent HeldResource(int prefab)
        {
            var misc = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.MiscPrefabs;
            if (misc == null || prefab < 0 || prefab >= misc.Count || misc[prefab] == null) return null;
            return misc[prefab].GetComponentInChildren<ResourceContent>(true);
        }
        // The flowers asked for and the barrels hit, oldest first (the host answers in order); how much of each barrel
        // is left at the host (host id -> share of its durability).
        private static readonly Queue<CollectedResource> Gathers = new Queue<CollectedResource>();
        private static readonly Queue<int> HeldAsks = new Queue<int>();
        private static readonly Dictionary<int, float> HeldWear = new Dictionary<int, float>();
        internal static void Worked(int kind, int detail)
        {
            if (kind == LanStorage.WorkGather && Gathers.Count > 0)
            {
                var flower = Gathers.Dequeue();
                if (detail <= 0 && flower != null) flower.Load(new object[] { 0 }); // the host has none left: hidden, as the game hides it
                else if (flower != null) Spent(flower); // 2.8.0: one cut a flower, as the game's GettingResource
            }
            else if (kind == LanStorage.WorkHitHeld && HeldAsks.Count > 0)
            {
                int id = HeldAsks.Dequeue();
                if (HeldWear.Count > 64) HeldWear.Clear();
                HeldWear[id] = Mathf.Clamp01(detail / 1000f);
            }
        }
        internal static void Refused(int kind, byte status)
        {
            if (kind == LanStorage.WorkGather && Gathers.Count > 0)
            {
                var flower = Gathers.Dequeue();
                if (status == LanStorage.NotFound && flower != null) flower.Load(new object[] { 0 }); // picked at the host already
            }
            else if (kind == LanStorage.WorkHitHeld && HeldAsks.Count > 0) HeldAsks.Dequeue();
        }
        // The look at a host barrel with a tool in hand: the game's take-apart hint and, once hit, how much is left.
        internal static void HintHeld(LanWorldReplica near)
        {
            try
            {
                if (near == null || near.Kind != LanWorldItems.TakableKind || HeldResource(near.ItemId) == null) return;
                var tool = InventoryController.global == null ? null : InventoryController.global.GetActiveIntenvoryItem();
                var info = InventoryController.global == null ? null : InventoryController.global.simpleInfoDisplayer;
                if (tool == null || info == null || !tool.toolWood && !tool.toolMetal) return;
                info.SetIconText("Disassemble", (Zompiercer.Inputs.Actions)54, (Zompiercer.Inputs.Actions)0, true);
                float left;
                var manager = GlobalManager.global;
                if (manager == null || !HeldWear.TryGetValue(near.HostId, out left) || left >= 1f) return;
                manager.buildProgressInfoDisplayer.SetActive(true);
                manager.buildProgressInfoBar.localScale = new Vector3(left, 1f, 1f);
                manager.buildProgressInfoText.text = Mathf.Round(left * 100f) + "%";
            }
            catch (Exception) { }
        }

        // Guest: filling a canister at a gas station is the host's fuel.
        private static bool FuelPrefix(InventoryController __instance)
        {
            if (!LanSaveIsolation.Active) return true;
            var work = GuestWork;
            if (work == null) return true;
            try
            {
                var station = SelectionManager.Global == null ? null : SelectionManager.Global.HoveredGasStation;
                var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
                if (station == null || player == null || player.beltInventory == null) return false;
                var slot = player.beltInventory[__instance.selectedBeltIcon];
                var can = slot == null || slot.content == null || slot.content.Count == 0 ? null : slot.content[0];
                if (can == null || can.itemID != EmptyCanister) return false;
                var escrow = LanStorage.Normalize(new object[] { can.itemID, 1, can.Save() });
                slot.Extract(can, 1);
                if (!work(LanStorage.WorkFuel, station.transform.position, -1, 0, escrow))
                    new LanStorageGuestWorld().Give(escrow);
            }
            catch (Exception ex) { _log?.Invoke("Fuel hook failed: " + ex.Message); }
            return false;
        }

        // ---- Guest: refuelling the host's train ----
        private static TrainFuelTank _pouring;

        // The game has taken the full canister and now wants to give back the empty one:
        // the canister goes to the host instead, which fills its own tank and hands back the empty one.
        private static bool PourPrefix(InventoryController __instance, InventoryItem fromItem)
        {
            var tank = FillingTank.GetValue(__instance) as TrainFuelTank;
            if (!LanSaveIsolation.Active || GuestWork == null || tank == null || fromItem == null || fromItem.itemID != FullCanister) return true;
            object[] escrow = null;
            try
            {
                escrow = LanStorage.Normalize(new object[] { fromItem.itemID, 1, fromItem.Save() });
                if (!Pour(tank, tank.transform.position, escrow)) new LanStorageGuestWorld().Give(escrow);
            }
            catch (Exception ex)
            {
                _log?.Invoke("Refuel hook failed: " + ex.Message);
                if (escrow != null) { try { new LanStorageGuestWorld().Give(escrow); } catch (Exception) { } }
            }
            return false;
        }
        // The guest's own copy of a tank on the host's train never fills by itself.
        private static bool TankFillPrefix(TrainFuelTank __instance, float value)
        {
            if (!LanSaveIsolation.Active || GuestWork == null || value <= 0f) return true;
            var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrain;
            return train == null || !__instance.transform.IsChildOf(train.transform);
        }

        // Sends a full canister (already out of the inventory) to the tank at `point` of the host's train.
        internal static bool Pour(TrainFuelTank shown, Vector3 point, object[] escrow)
        {
            var work = GuestWork;
            var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrain;
            var car = shown != null ? shown.GetComponentInParent<Zompiercer.Train.TrainCar>() : null;
            if (car == null && train != null)
                foreach (var hit in Physics.OverlapSphere(point, .1f, ~0, QueryTriggerInteraction.Ignore))
                    if ((car = hit.GetComponentInParent<Zompiercer.Train.TrainCar>()) != null) break;
            int index = TrainLayout.CarIndex(train, car);
            if (work == null || index < 0) { LanStorageGame.Notice(LanText.T("Заправлять можно только поезд хоста")); return false; }
            var local = car.transform.InverseTransformPoint(point);
            if (!work(LanStorage.WorkRefuel, local, -1, index, escrow)) return false;
            _pouring = shown;
            return true;
        }
        internal static bool Pour(Zompiercer.Train.TrainCar car, Vector3 point, object[] escrow)
        {
            var work = GuestWork;
            var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrain;
            int index = TrainLayout.CarIndex(train, car);
            if (work == null || index < 0) return false;
            _pouring = null;
            return work(LanStorage.WorkRefuel, car.transform.InverseTransformPoint(point), -1, index, escrow);
        }

        // Guest: the host's answer to a refuel, its tank's level x100; shown on the guest's own copy.
        internal static void Refuelled(int level)
        {
            var tank = _pouring; _pouring = null;
            if (tank != null) tank.currentFuelAmount = Mathf.Clamp(level / 100f, 0f, tank.maxFuelAmount);
            LanStorageGame.Notice(LanText.T("Бак поезда хоста: ") + Mathf.RoundToInt(level / 100f));
        }

        // ---- Guest: the rainwater tank of the host's train (1.2.2) ----
        // The guest's copy of the tank has no script: with an empty bottle (or one of dirty water) in
        // hand and the copy in sight, the game's own keys fill one or every bottle (pour one or all);
        // the host does it at its own tank. The level comes from the host (a read every 1.5 s in sight).
        private static float _waterLevel = -1f, _waterReadAt = -100f;
        private static int _waterCar = -1, _waterIdentity;
        internal static void ResetWater()
        { _waterCar = -1; _waterIdentity = 0; _waterLevel = -1f; _waterReadAt = -100f; _waterRevision = 0; }
        private static uint _waterRevision;
        private static void WaterPrefix(InventoryController __instance)
        {
            if (!LanSaveIsolation.Active) return;
            var work = GuestWork;
            if (work == null) return;
            try
            {
                var input = LanGame.Input;
                var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
                if (input == null || player == null || (int)input.CurrentState != 1 || __instance.consumeSomething || player.beltInventory == null) return;
                RaycastHit hit; int car, identity; float max;
                if (!LanTrainBuild.LookHit(out hit) || !TrainLayout.TryIdentifyWaterTank(hit.collider, out car, out identity, out max)) return;
                var train = GlobalManager.global.controlledTrain;
                var carObject = TrainLayout.GetCar(train, car);
                var local = carObject.transform.InverseTransformPoint(hit.point);
                float now = Time.unscaledTime;
                if (car != _waterCar || identity != _waterIdentity) { _waterCar = car; _waterIdentity = identity; _waterLevel = -1f; _waterReadAt = -100f; _waterRevision = 0; }
                if (now - _waterReadAt > 1.5f && work(LanStorage.WorkWaterLevel, local, identity, car, null)) _waterReadAt = now;
                var info = __instance.simpleInfoDisplayer;
                if (info != null)
                    info.SetText((_waterLevel < 0f ? "…" : Math.Round(_waterLevel, 1).ToString()) + " / " + max + " " + Zompiercer.GUI.LocalizationCore.GetTextByKey("DirtyWater").ToUpper());
                var slot = player.beltInventory[__instance.selectedBeltIcon];
                var bottle = slot == null || slot.content == null || slot.content.Count == 0 ? null : slot.content[0];
                if (bottle == null || bottle.itemID != EmptyBottle && bottle.itemID != DirtyBottle) return;
                bool fill = bottle.itemID == EmptyBottle;
                if (info != null)
                {
                    info.color = GlobalSoundEffects.global.colorGreen;
                    info.SetIconText(fill ? "TakeWater" : "Pour out the water", (Zompiercer.Inputs.Actions)2, (Zompiercer.Inputs.Actions)0, true);
                    if (bottle.amount > 1) info.SetIconText(fill ? "Fill everything with water" : "Pour out all the water", (Zompiercer.Inputs.Actions)3, (Zompiercer.Inputs.Actions)0, true);
                }
                bool one = input.isKbMouseDevice ? input.isUiMainActionDown : input.gp_isAttackDown;
                bool all = input.isKbMouseDevice ? input.isUiSecondDown : input.gp_isAimDown;
                if (!one && !all) return;
                // The game would use (or take apart) the bottle in hand: this press is the tank's.
                input.isUiMainActionDown = false; input.isUiSecondDown = false; input.gp_isAttackDown = false; input.gp_isAimDown = false;
                int count = all ? bottle.amount : 1;
                if (fill)
                {
                    count = Math.Min(count, Mathf.FloorToInt(player.inventory.GetFreeMass() / BottleVolume));
                    if (_waterLevel >= 0f) count = Math.Min(count, Mathf.FloorToInt(_waterLevel / BottleVolume + .001f));
                    if (count < 1) { LanStorageGame.Notice(_waterLevel >= 0f && _waterLevel < BottleVolume ? Zompiercer.GUI.LocalizationCore.GetTextByKey("NotEnoughWater") : LanText.T("Не хватает места в рюкзаке")); return; }
                }
                else if (_waterLevel >= 0f) count = Math.Min(count, Mathf.FloorToInt((max - _waterLevel) / BottleVolume + .001f));
                if (count < 1) { LanStorageGame.Notice(Zompiercer.GUI.LocalizationCore.GetTextByKey("The tank is full")); return; }
                count = Math.Min(count, LanStorage.MaxWaterBottles);
                var escrow = LanStorage.Normalize(new object[] { bottle.itemID, count, bottle.Save() });
                slot.Extract(bottle, count);
                if (work(fill ? LanStorage.WorkWater : LanStorage.WorkPourWater, local, identity, car, escrow))
                {
                    _waterReadAt = now;
                    if (player.zombieFighterEffects != null) player.zombieFighterEffects.RandomFillingBottleSound();
                }
                else new LanStorageGuestWorld().Give(escrow);
            }
            catch (Exception ex) { _log?.Invoke("Water hook failed: " + ex.Message); }
        }

        // Guest: the host's answer about its rainwater tank, its level x100.
        internal static void Watered(int kind, int level, int identity, int car, uint revision)
        {
            if (identity != _waterIdentity || car != _waterCar || revision == 0 || (_waterRevision != 0 && unchecked((int)(revision - _waterRevision)) <= 0)) return;
            _waterRevision = revision;
            _waterLevel = level / 100f;
            if (kind != LanStorage.WorkWaterLevel) LanStorageGame.Notice(LanText.T("Бак с водой хоста: ") + Math.Round(_waterLevel, 1));
        }

        // ---- Host ----
        internal static byte HostWork(int kind, Vector3 at, int tool, int extra, object[] escrow, Vector3? guest, out object[] given, out int detail)
        {
            given = null; detail = 0;
            if (kind == LanStorage.WorkRefuel) return HostRefuel(at, extra, escrow, guest, out given, out detail);
            if (LanStorage.WaterWork(kind)) return HostWater(kind, at, tool, extra, escrow, guest, out given, out detail);
            if (LanStorage.FarmWork(kind)) return LanFarm.HostWork(kind, at, extra, escrow, guest, out given, out detail);
            if (guest == null) return LanStorage.Lost;
            if (kind != LanStorage.WorkHit && kind != LanStorage.WorkChop && kind != LanStorage.WorkHitHeld && Vector3.Distance(at, guest.Value) > 5f) return LanStorage.TooFar;
            var prefabs = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.itemPrefab;
            if (prefabs == null) return LanStorage.Unavailable;
            var toolPrefab = tool >= 0 && tool < prefabs.Length ? prefabs[tool] : null;
            var gun = tool >= 0 ? HostGun(tool) : null;
            switch (kind)
            {
                case LanStorage.WorkHit:
                {
                    if (gun == null || gun.furnitureBuildPower <= 0) return LanStorage.NotAllowed;
                    // 2.2.0: the object that stood there when the location loaded (else one there now); within reach now.
                    var target = AtLoadPlace(at) ?? NearestResource(at, .6f);
                    if (target == null) { ReportMissingResource(at); return LanStorage.NotFound; }
                    if (Reach(target, guest.Value) > 4f) return LanStorage.TooFar;
                    return TakeApart(target, gun.furnitureBuildPower, out detail);
                }
                case LanStorage.WorkChop:
                {
                    // 2.4.4: the game's blow (Gun.MeleeHitTarget: HitPoints.CauseDamage with the gun's melee strength, 5% more a
                    // strength level, over the world's zombie health factor, of the gun's damage type) by the guest's strength.
                    if (gun == null || gun.Hands || gun.weaponType != 2) return LanStorage.NotAllowed;
                    var target = AtLoadPlace(at) ?? NearestResource(at, .6f);
                    var points = HitPointsOf(target);
                    if (points == null) { if (target == null) ReportMissingResource(at); return LanStorage.NotFound; }
                    if (Reach(target, guest.Value) > 4f) return LanStorage.TooFar;
                    var difficulty = DifficultyManager.Global;
                    float factor = difficulty == null ? 1f : Mathf.Max(.05f, difficulty.ZombieHP);
                    float damage = Mathf.Clamp(gun.meleeAttackStrength * (1f + .05f * (Mathf.Clamp(extra, 1, 100) - 1)), 0f, 1000f) / factor;
                    points.CauseDamage(damage, gun.damageType); // at none left its ResourceContent drops the logs in this world
                    detail = Mathf.RoundToInt(Mathf.Max(0f, points.CurrentHP));
                    return LanStorage.Ok;
                }
                case LanStorage.WorkHitHeld:
                {
                    if (gun == null || gun.furnitureBuildPower <= 0) return LanStorage.NotAllowed;
                    TakableItem held = null;
                    foreach (var candidate in Object.FindObjectsOfType<TakableItem>(true))
                        if (candidate != null && candidate.GetInstanceID() == extra) { held = candidate; break; }
                    var target = held == null ? null : held.GetComponentInChildren<ResourceContent>(true);
                    if (target == null) return LanStorage.NotFound;
                    if (Reach(held, guest.Value) > 4f) return LanStorage.TooFar;
                    return TakeApart(target, gun.furnitureBuildPower, out detail);
                }
                case LanStorage.WorkGather:
                {
                    if (!HostKnife(tool, toolPrefab) || gun == null)
                    {
                        // The request is sent only when the guest's live item has toolKnife.
                        // Record the host's actual item and gun mapping if it still disagrees.
                        if (_reportedGatherTool != tool)
                        {
                            _reportedGatherTool = tool;
                            _log?.Invoke("Flower work tool rejected: item " + tool +
                                " hostPrefab=" + (toolPrefab == null ? "missing" : toolPrefab.name) +
                                " hostKnife=" + HostKnife(tool, toolPrefab) +
                                " hostGun=" + (gun == null ? "missing" : gun.name));
                        }
                        return LanStorage.NotAllowed;
                    }
                    // 2.4.4: the flower at that very place (they grow in patches: the nearest within 30 cm was often another
                    // one while the guest's picked copy stayed), also one the host's camera does not see (switched off by
                    // the game's culling); picked clean is the game's own hiding.
                    CollectedResource resource = null; float best = .05f * .05f;
                    foreach (var candidate in Object.FindObjectsOfType<CollectedResource>(true))
                    {
                        if (candidate == null) continue;
                        float d = (candidate.transform.position - at).sqrMagnitude;
                        if (d <= best) { best = d; resource = candidate; }
                    }
                    // 2.8.0 (game 22.0): a flower gives one cut (IsCanUse), of the game's GettingResource.
                    if (resource == null || !resource.gameObject.activeSelf || !resource.IsCanUse || !resource.UseNewSystem && resource.resourceQuantity <= 0) return LanStorage.NotFound;
                    if (!resource.UseForHarvesting() || ZombieSync.AnimalOfResource(resource) != 0) return LanStorage.NotAllowed;
                    int left;
                    var cut = Extract(resource, gun.resourceExtractionPower, out left);
                    if (cut.Count == 0) return LanStorage.Invalid;
                    given = cut[0]; // a flower's one item (a work answer carries one)
                    detail = left;
                    return LanStorage.Ok;
                }
                case LanStorage.WorkButcher:
                {
                    // 2.8.0 (game 22.0): a knife cut on the carcass of the host's animal, as the game's (Gun.MeleeDisassemblyTarget:
                    // GettingResource with the knife's extraction power): what it gives goes to the guest.
                    if (!HostKnife(tool, toolPrefab) || gun == null) return LanStorage.NotAllowed;
                    var resource = ZombieSync.HostCarcass(extra);
                    if (resource == null) return LanStorage.NotFound;
                    if (Reach(resource, guest.Value) > 4f) return LanStorage.TooFar;
                    if (!resource.UseForButchering()) return LanStorage.NotAllowed;
                    int left;
                    var cut = Extract(resource, gun.resourceExtractionPower, out left);
                    if (cut.Count == 0) return LanStorage.Empty;
                    if (cut.Count > LanStorage.MaxRefundItems) cut.RemoveRange(LanStorage.MaxRefundItems, cut.Count - LanStorage.MaxRefundItems);
                    given = cut.ToArray();
                    detail = left;
                    return LanStorage.Ok;
                }
                case LanStorage.WorkCatch:
                {
                    // 2.8.0 (game 22.0): the guest takes a live animal by hand (a chicken: the game's TakableAnimal, Inventory.Add);
                    // it leaves the host's world as the game's own catch does (TakeAmount: the animal is switched off).
                    int item, amount;
                    byte caught = ZombieSync.HostCatch(extra, guest.Value, out item, out amount);
                    if (caught != LanStorage.Ok) return caught;
                    if (item < 0 || item >= prefabs.Length || prefabs[item] == null || amount < 1) return LanStorage.Invalid;
                    given = new object[] { item, amount, new object[4] };
                    return LanStorage.Ok;
                }
                case LanStorage.WorkDig:
                {
                    if (toolPrefab == null || !toolPrefab.toolShovel || gun == null) return LanStorage.NotAllowed;
                    int id = extra == 1 ? Sand : Soil;
                    if (id >= prefabs.Length || prefabs[id] == null) return LanStorage.Invalid;
                    given = new object[] { id, Math.Max(1, gun.resourceExtractionPower), new object[4] };
                    return LanStorage.Ok;
                }
                case LanStorage.WorkFuel:
                {
                    if (escrow == null || (int)escrow[0] != EmptyCanister || (int)escrow[1] != 1) return LanStorage.NotAllowed;
                    var station = Nearest<GasStation>(at, 1f);
                    if (station == null) return LanStorage.NotFound;
                    if (station.FuelQuantityCurrent < 10) return LanStorage.Empty;
                    if (FullCanister >= prefabs.Length || prefabs[FullCanister] == null) return LanStorage.Invalid;
                    station.Fill(-10);
                    given = new object[] { FullCanister, 1, new object[4] };
                    return LanStorage.Ok;
                }
            }
            return LanStorage.Invalid;
        }

        // A full canister into the fuel tank of car `index` nearest to `local` (that car's space).
        private static byte HostRefuel(Vector3 local, int index, object[] escrow, Vector3? guest, out object[] given, out int detail)
        {
            given = null; detail = 0;
            if (escrow == null || (int)escrow[0] != FullCanister || (int)escrow[1] != 1) return LanStorage.NotAllowed;
            var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrain;
            if (train == null) return LanStorage.Unavailable;
            Zompiercer.Train.TrainCar car;
            try { car = TrainLayout.GetCar(train, index); }
            catch (Exception) { return LanStorage.NotFound; }
            var at = car.transform.TransformPoint(local);
            if (guest == null) return LanStorage.Lost;
            if (Vector3.Distance(at, guest.Value) > 5f) return LanStorage.TooFar;
            TrainFuelTank tank = null; float best = 16f; // within 4 m of the point the guest aimed at
            foreach (var candidate in car.GetComponentsInChildren<TrainFuelTank>())
            {
                if (candidate == null || !candidate.isActiveAndEnabled) continue;
                float d = (candidate.transform.position - at).sqrMagnitude;
                foreach (var collider in candidate.GetComponentsInChildren<Collider>())
                    if (collider != null && collider.enabled) d = Math.Min(d, (collider.ClosestPoint(at) - at).sqrMagnitude);
                if (d <= best) { best = d; tank = candidate; }
            }
            if (tank == null) return LanStorage.NotFound;
            if (tank.currentFuelAmount >= tank.maxFuelAmount - .01f) return LanStorage.Full;
            var prefabs = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.itemPrefab;
            var full = prefabs != null && FullCanister < prefabs.Length ? prefabs[FullCanister] : null;
            var value = full == null ? null : full.GetComponent<LootObjectValue>();
            if (value == null || value.FuelValue <= 0f || EmptyCanister >= prefabs.Length || prefabs[EmptyCanister] == null) return LanStorage.Invalid;
            tank.Fill(value.FuelValue);
            given = new object[] { EmptyCanister, 1, new object[4] };
            detail = Mathf.RoundToInt(Mathf.Clamp(tank.currentFuelAmount, 0f, 9999f) * 100f);
            return LanStorage.Ok;
        }

        // 1.2.2: the rainwater tank of car `index` nearest to `local`: read, fill bottles, pour back.
        private static byte HostWater(int kind, Vector3 local, int identity, int index, object[] escrow, Vector3? guest, out object[] given, out int detail)
        {
            given = null; detail = 0;
            var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrain;
            if (train == null) return LanStorage.Unavailable;
            Zompiercer.Train.TrainCar car;
            try { car = TrainLayout.GetCar(train, index); }
            catch (Exception) { return LanStorage.NotFound; }
            var at = car.transform.TransformPoint(local);
            if (guest == null) return LanStorage.Lost;
            if (Vector3.Distance(at, guest.Value) > 5f) return LanStorage.TooFar;
            RainwaterTank tank = null; float best = 16f;
            foreach (var candidate in car.GetComponentsInChildren<RainwaterTank>())
            {
                if (candidate == null || !candidate.isActiveAndEnabled || candidate.trainPart == null || candidate.trainPart.Blueprint || candidate.trainPart.GetInstanceID() != identity) continue;
                float d = (candidate.transform.position - at).sqrMagnitude;
                foreach (var collider in candidate.GetComponentsInChildren<Collider>())
                    if (collider != null && collider.enabled) d = Math.Min(d, (collider.ClosestPoint(at) - at).sqrMagnitude);
                if (d <= best) { best = d; tank = candidate; }
            }
            if (tank == null) return LanStorage.NotFound;
            if (kind == LanStorage.WorkWaterLevel) { detail = WaterLevel(tank); return LanStorage.Ok; }
            int count = (int)escrow[1];
            float volume = count * BottleVolume;
            if (count < 1) return LanStorage.Invalid;
            var prefabs = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.itemPrefab;
            if (prefabs == null || EmptyBottle >= prefabs.Length || DirtyBottle >= prefabs.Length || prefabs[EmptyBottle] == null || prefabs[DirtyBottle] == null) return LanStorage.Invalid;
            if (kind == LanStorage.WorkWater)
            {
                if ((int)escrow[0] != EmptyBottle) return LanStorage.NotAllowed;
                if (tank.VolumeCurrent + .001f < volume) return LanStorage.Empty;
                tank.Fill(-volume);
                given = new object[] { DirtyBottle, count, new object[4] };
            }
            else
            {
                if ((int)escrow[0] != DirtyBottle) return LanStorage.NotAllowed;
                if (tank.VolumeCurrent + volume > tank.VolumeMax + .001f) return LanStorage.Full;
                tank.Fill(volume);
                given = new object[] { EmptyBottle, count, new object[4] }; // what the game's pouring leaves
            }
            detail = WaterLevel(tank);
            return LanStorage.Ok;
        }
        private static int WaterLevel(RainwaterTank tank) { return Mathf.RoundToInt(Mathf.Clamp(tank.VolumeCurrent, 0f, 99999f) * 100f); }

        // 2.4.4: a take-apart hit as the game's (Gun.MeleeDisassemblyTarget): at no more than the tool's power left the object
        // falls apart (what falls out lies in this world); `left` in thousandths of its durability.
        private static byte TakeApart(ResourceContent target, float power, out int left)
        {
            left = 0;
            if (target.durability <= power) { target.ObjectParsed(); return LanStorage.Ok; }
            target.durability -= power;
            left = Mathf.RoundToInt(1000f * Mathf.Clamp01(target.durability / Mathf.Max(1f, target.durabilityMax)));
            return LanStorage.Ok;
        }
        // How far the guest stands from the object's nearest solid part (a fallen tree is long).
        private static float Reach(Component target, Vector3 guest)
        {
            float best = Vector3.Distance(target.transform.position, guest);
            foreach (var collider in target.GetComponentsInChildren<Collider>(true))
                if (collider != null && !collider.isTrigger) best = Mathf.Min(best, Vector3.Distance(collider.bounds.ClosestPoint(guest), guest));
            return best;
        }

        // The host's own Gun for the guest's tool (same prefab, same stats).
        internal static Gun HostGun(int itemId)
        {
            var prefabs = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.itemPrefab;
            var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
            if (prefabs == null || itemId < 0 || itemId >= prefabs.Length || prefabs[itemId] == null || player == null || player.zombieFighterFireArmWeapon == null) return null;
            var data = prefabs[itemId].GetComponent<WeaponData>();
            if (data == null || player.zombieFighterFireArmWeapon.gunList == null) return null;
            foreach (var gun in player.zombieFighterFireArmWeapon.gunList) if (gun != null && gun.ID == data.ID) return gun;
            return null;
        }

        // InventoryItem.Awake sets toolKnife from itemID (56, 187, 188) on a live item.
        // ItemsDataBase.itemPrefab is an asset, so its Awake-derived flag can still be false.
        private static bool HostKnife(int itemId, InventoryItem prefab)
        { return prefab != null && prefab.itemID == itemId && (itemId == 56 || itemId == 187 || itemId == 188); }

        // 2.2.0: load places of the objects to take apart (ResourceContent.Start: the location just loaded, before
        // anything knocked them about). The game loads the same objects at the same places for every player.
        private static readonly Dictionary<ResourceContent, Vector3> LoadPlaces = new Dictionary<ResourceContent, Vector3>();
        private static void ResourceStarted(ResourceContent __instance)
        {
            if (__instance == null) return;
            if (LoadPlaces.Count >= 8192)
            {
                var gone = new List<ResourceContent>();
                foreach (var key in LoadPlaces.Keys) if (key == null) gone.Add(key);
                foreach (var key in gone) LoadPlaces.Remove(key);
                if (LoadPlaces.Count >= 8192) return;
            }
            LoadPlaces[__instance] = __instance.transform.position;
        }
        internal static Vector3 LoadPlace(ResourceContent resource)
        {
            Vector3 place;
            return resource != null && LoadPlaces.TryGetValue(resource, out place) ? place : resource.transform.position;
        }
        private static ResourceContent AtLoadPlace(Vector3 at)
        {
            ResourceContent best = null; float distance = .3f * .3f;
            foreach (var pair in LoadPlaces)
            {
                if (pair.Key == null || !LanWorldItems.Present(pair.Key.gameObject)) continue;
                float d = (pair.Value - at).sqrMagnitude;
                if (d <= distance) { best = pair.Key; distance = d; }
            }
            return best;
        }

        // ResourceContent.Start initializes durability and our postfix records its load place.
        // A started resource can later move or be culled on the host. Include those disabled
        // scene objects, but never a resource still waiting for Start or a hidden copy.
        private static ResourceContent NearestResource(Vector3 at, float within)
        {
            ResourceContent best = null; float distance = within * within;
            foreach (var candidate in Object.FindObjectsOfType<ResourceContent>(true))
            {
                if (candidate == null || !LoadPlaces.ContainsKey(candidate) ||
                    !LanWorldItems.Present(candidate.gameObject) ||
                    candidate.GetComponentInParent<LanWorldReplica>() != null ||
                    candidate.GetComponentInParent<LanTrainReplica>() != null) continue;
                float d = (candidate.transform.position - at).sqrMagnitude;
                if (d <= distance) { best = candidate; distance = d; }
            }
            return best;
        }

        private static void ReportMissingResource(Vector3 at)
        {
            if (Time.unscaledTime < _missingResourceLogAt) return;
            _missingResourceLogAt = Time.unscaledTime + 10f;
            ResourceContent nearest = null; float distance = float.PositiveInfinity;
            foreach (var candidate in Object.FindObjectsOfType<ResourceContent>(true))
            {
                if (candidate == null) continue;
                Vector3 load;
                if (!LoadPlaces.TryGetValue(candidate, out load)) load = candidate.transform.position;
                float d = Vector3.Distance(load, at);
                if (d < distance) { nearest = candidate; distance = d; }
            }
            _log?.Invoke("Guest resource hit has no host target at " + at.ToString("F1") +
                "; nearest=" + (nearest == null ? "none" : nearest.name + " distance=" + distance.ToString("F2") +
                " present=" + LanWorldItems.Present(nearest.gameObject) +
                " started=" + LoadPlaces.ContainsKey(nearest)));
        }

        private static T Nearest<T>(Vector3 at, float within) where T : Component
        {
            T best = null; float distance = within * within;
            foreach (var candidate in Object.FindObjectsOfType<T>())
            {
                float d = (candidate.transform.position - at).sqrMagnitude;
                if (d <= distance) { best = candidate; distance = d; }
            }
            return best;
        }
    }
}

