using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace ZompiercerLAN
{
    // Third-person animation of the other player (1.0.9). The avatar is a game NPC model (man:
    // RigSkuf* bones, woman: RigW*) whose own controller has idle and walk only. With a firearm,
    // an invisible military NPC (RigSlim*, the same 65-bone rig with the same bone axes) plays
    // the game's "NPC with AK" controller (armed idle, walk and aim). Display only: no gameplay scripts.
    // 1.1.0: crouching, looking up or down and melee swings, for which the game's NPCs have no
    // clips, are bone turns about the avatar's own right axis over whichever pose the animators made.
    // 1.1.9: a reload (the rifle dips, the left hand works the magazine) and lying (downed or dead:
    // the plugin lays the whole avatar on its back; here only the armed pose gives way to idle).
    // 1.4.6: the controllers' states are entered directly (the armed idle let the aim in only near
    // the end of its 3.8 s loop); the legs stay the avatar's own (idle or walk, so aiming on the move
    // walks); the dash is a roll.
    // 1.4.7: running (a longer stride, a lean), jumping and falling (legs drawn up), swimming (lying
    // forward, kicking, the breaststroke), a climb (the game moves the player to the top of a ladder
    // at once; here it climbs there hand over hand), a throw (held back, then let go) and a flinch when hit.
    // 1.4.8: strikes by weapon (an overhead blow with a hammer, a chop with an axe or a shovel, a
    // sideways swing with a bat or a wrench, a stab with a knife, jabs with bare fists, hand after
    // hand) and the use key: a reach where it looks (the left hand with a firearm), or bending down
    // for an item when it looks down.
    // 2.7.0: what it holds and uses is posed by RemoteHoldPose (worked out offline on these very
    // meshes, men and women, with armour): with a long gun the military NPC's aiming torso (spine,
    // neck, head and collarbones) over the avatar's legs, the butt in the shoulder, aimed or at the
    // low ready; a handgun in both hands; the bow; a shovel; a one-hand item at the hip; eating,
    // drinking, a medkit, a bandage and pills with the item in hand. The arms reach their grips with
    // an anatomical elbow and a forearm twist; the fingers are the game's own first-person grip.
    internal sealed class RemoteAvatarMotion : MonoBehaviour
    {
        // The pace (m/s) at which the NPC walk cycles keep up with the ground (an estimate):
        // a faster partner walks the same clip faster, within PaceMin..PaceMax.
        internal const float WalkClipSpeed = 1.4f, PaceMin = .8f, PaceMax = 2.2f;
        // Crouch: knee bend and forward lean in degrees; how fast pose changes follow (per second).
        internal const float CrouchKnee = 60f, CrouchLean = 15f, Follow = 12f, MaxBodyPitch = 70f;
        // A swing: the arm rises forward over the head, strikes down past the body, comes back.
        internal const float SwingRise = .22f, SwingStrike = .12f, SwingReturn = .3f, SwingHigh = -130f, SwingLow = 15f;
        // A shot (1.1.1): the chest and arms kick back and settle.
        internal const float RecoilKick = 7f, RecoilSettle = .07f;
        // A reload (1.1.9): how far the chest bends and the weapon dips, the support hand's pace at the magazine.
        internal const float ReloadLean = 10f, ReloadPace = 6f;
        // 1.4.6: a state change blends this long (s).
        internal const float Blend = .15f;
        internal const float RunSpeed = 3.2f;
        // 1.4.6: a roll (the dash): its length (s), knee bend, back curl and head tuck at its middle
        // (degrees), how far the pelvis sinks (share of its height); the share of it spent turning
        // towards the dash at either end.
        internal const float RollTime = .6f, RollKnee = 95f, RollCurl = 60f, RollHead = 40f, RollSink = .35f, RollFace = .15f;
        // 1.4.7: running: the stride's growth and the lean (degrees); in the air: how far the knees come up;
        // swimming: the body's tilt, kick and stroke (degrees) and their pace; a climb (s); a throw:
        // the arm held back (degrees), how it comes over and settles (s); a flinch (s). 2.7.0: a bandage goes
        // round the forearm this many turns a second; a medkit's dip and dab take this long (s).
        internal const float RunStride = .35f, RunLean = 12f, AirKnee = 45f, SwimTilt = 75f, SwimKick = 22f, SwimStroke = 45f, SwimPace = 3.5f;
        internal const float ClimbTime = .7f, ThrowBack = -150f, ThrowRise = .15f, ThrowStrike = .12f, ThrowReturn = .33f, ThrowFollow = 30f;
        internal const float FlinchTime = .45f, WrapTurns = 1.1f, MedkitCycle = 2.4f;
        // 1.4.8: a chop (rise, strike, return in s; arm high and low, chest turn in degrees); a sideways
        // swing (wind-up, strike, return; how far back and across, the arm raised); a stab (pull, thrust,
        // hold, return); a jab (thrust, hold, return); a reach or bending down (rise, hold, return; below
        // this pitch it bends; back curl and knee bend in degrees).
        internal const float ChopRise = .26f, ChopStrike = .13f, ChopReturn = .35f, ChopHigh = -165f, ChopLow = 35f, ChopTwist = 20f;
        internal const float SideWind = .22f, SideStrike = .14f, SideReturn = .32f, SideBack = 75f, SideAcross = -85f, SideRaise = -85f;
        internal const float StabPull = .08f, StabThrust = .08f, StabHold = .05f, StabReturn = .22f;
        internal const float JabThrust = .08f, JabHold = .04f, JabReturn = .2f;
        internal const float ReachRise = .15f, ReachHold = .12f, ReachReturn = .25f, BendPitch = 35f, BendCurl = 45f, BendKnee = 40f;
        // 1.4.8: how a held melee weapon strikes, by item (ItemsDataBase ids): knives and the dagger stab,
        // bats and wrenches swing sideways, axes and shovels chop, the rest (hammers) strike overhead.
        internal enum Strike : byte { Overhead, Chop, Sideways, Stab }
        internal static Strike StrikeOf(int itemId)
        {
            switch (itemId)
            {
                case 56: case 187: case 188: return Strike.Stab;
                case 27: case 54: case 184: case 55: case 94: case 186: return Strike.Sideways;
                case 93: case 189: case 191: case 192: case 193: return Strike.Chop;
                default: return Strike.Overhead;
            }
        }
        internal static readonly int IdleState = Animator.StringToHash("NPCMarkStandIdle"), WalkState = Animator.StringToHash("NPCMarkWalk"),
            AimState = Animator.StringToHash("MRAKMAimingIdle");
        private const string Palm = "RArmPalm";
        // 2.7.0: what the armed NPC lends a long gun's holder: its aiming spine, neck, head and collarbones.
        private static readonly string[] Torso = { "Spine1", "Spine2", "Spine3", "Hub002", "Spine1 1", "Spine2 1", "Spine3 1", "Hub003", "RArmCollarbone", "LArmCollarbone" };
        private Driven _own, _driver;
        private GameObject _driverObject;
        private Transform[] _from = new Transform[0], _to = new Transform[0];
        private int _torsoRoot = -1;
        // The avatar's finger bones (by name after the rig prefix) and their skin bind turns.
        private Transform[] _toDigits = new Transform[0];
        private string[] _digitSuffixes = new string[0];
        private Quaternion[] _toDigitBind = new Quaternion[0];
        // 1.4.6: where the plugin's log goes (which way each animator is switched, once).
        internal static Action<string> Log;
        private bool _armed, _long, _lying, _driverActive, _supportHeld;
        private RemoteEquipmentVisual _equipment;
        private RemoteOutfitVisual _wear;

        // An animator of the avatar (its own, or the armed driver's) and what it was checked for.
        private sealed class Driven
        {
            internal Animator Animator;
            internal string Role;
            private bool _checked, _walk, _aim, _direct;
            // Known once the animator was active: whether it has the aim state and is switched directly.
            internal bool CanAim { get { Check(); return _aim && _direct; } }

            private void Check()
            {
                if (_checked || Animator == null || !Animator.isActiveAndEnabled) return;
                _checked = true; _walk = Has(Animator, "Walk"); _aim = Has(Animator, "Aim");
                try { _direct = Animator.HasState(0, IdleState) && Animator.HasState(0, WalkState) && (!_aim || Animator.HasState(0, AimState)); }
                catch (Exception) { _direct = false; }
                var controller = Animator.runtimeAnimatorController;
                Log?.Invoke("Partner " + Role + " animator " + (controller == null ? "?" : controller.name) +
                    (_direct ? ": states entered directly" : ": switched by its parameters") + (_aim ? ", with aim" : ""));
            }

            // Puts it into a state (IdleState, WalkState, AimState). The parameters follow, so the
            // controller's own transitions keep it there; a controller without these states is
            // switched by the parameters alone, as before 1.4.6.
            internal void Set(int state, float speed)
            {
                if (Animator == null || !Animator.isActiveAndEnabled) return;
                Check();
                if (state == AimState && !_aim) state = IdleState;
                if (_walk) Animator.SetBool("Walk", state == WalkState);
                if (_aim) Animator.SetBool("Aim", state == AimState);
                Animator.speed = speed;
                if (!_direct) return;
                if (Animator.IsInTransition(0) ? Animator.GetNextAnimatorStateInfo(0).shortNameHash == state
                    : Animator.GetCurrentAnimatorStateInfo(0).shortNameHash == state) return;
                Animator.CrossFadeInFixedTime(state, Blend, 0);
            }
        }

        // A bone turned by the procedural layer. Each frame starts from the animated pose; a bone
        // the animators did not write this frame (culled, or not in the clip) starts from its last
        // animated rotation instead of piling the turns up.
        private sealed class Turned
        {
            internal Transform Bone;
            internal Quaternion Base, Written, Rest;
            internal bool Seen;
        }
        private Turned _lThigh, _lShin, _lFoot, _rThigh, _rShin, _rFoot, _spine2, _spine3, _neck, _head, _arm, _lArm, _hub;
        private Turned[] _turned = new Turned[0];
        private Transform _pelvis;
        private Vector3 _pelvisBase, _pelvisWritten;
        private bool _pelvisSeen;
        private float _legLength, _crouch, _crouchTarget, _pitch, _pitchTarget, _swingAt = -100f, _shotAt = -100f, _reload, _reloadTarget;
        // 1.4.6: the arms (upper arm, forearm, palm) and chest of the avatar, the pelvis height at rest; the roll.
        // 2.7.0: the forearms' twist bones and the collarbones, both arms as RemoteHoldPose solves them, the palms'
        // anatomical frames, the lips and the head's ahead (head space); how far aimed (1) and lowered (degrees).
        private Transform _rUpper, _rLower, _rPalm, _lUpper, _lLower, _lPalm, _chest;
        private Transform _rTwist2, _rTwist3, _lTwist2, _lTwist3, _lCollar;
        private RemoteHoldPose.Arm _armR, _armL;
        private RemoteHoldPose.Palm _palmR, _palmL;
        private Vector3 _mouthLocal, _mouthAhead;
        private Vector3 _torsoRightLocal, _torsoUpLocal, _torsoForwardLocal;
        private float _hubHeight = .8f, _rollAt = -100f, _lower, _lowerTarget, _aim, _aimTarget;
        private byte _rollDirection;
        private bool _armsReady, _walking;
        // 1.4.7: how much each motion shows (followed towards its target) and when the last events began.
        private float _run, _runTarget, _air, _airTarget, _swim, _swimTarget, _cock, _cockTarget, _use, _useTarget;
        private float _tired, _tiredTarget;
        private int _useItem = -1;
        private float _throwAt = -100f, _throwRise = ThrowRise, _flinchAt = -100f, _climbAt = -100f, _useAt = -100f;
        private byte _useKind;
        // 1.4.8: the held melee weapon's strike, the last jab (and which hand), the last use key press
        // (and whether it bent down for it).
        internal Strike StrikeKind { get; set; }
        private float _jabAt = -100f, _reachAt = -100f;
        private bool _jabLeft = true, _reachDown;

        // The avatar's right palm bone (not the driver's), for the held weapon.
        internal Transform RightPalm { get; private set; }
        internal Transform LeftPalm { get; private set; }

        // A bone whose name ends with the suffix; prefix: the rest of its name (the rig's prefix).
        internal static Transform FindBone(Transform root, string suffix, out string prefix)
        {
            foreach (var bone in root.GetComponentsInChildren<Transform>(true))
                if (bone.name.EndsWith(suffix, StringComparison.Ordinal) && bone.name.StartsWith("Rig", StringComparison.Ordinal))
                { prefix = bone.name.Substring(0, bone.name.Length - suffix.Length); return bone; }
            prefix = null;
            return null;
        }

        // own: the avatar's animator (idle and walk). driver: a display copy of a military NPC,
        // or null; it is destroyed when it cannot drive this avatar. Called before the avatar
        // is first shown, so both rigs are still in their prefab poses.
        internal string Initialize(Animator own, GameObject driver, RuntimeAnimatorController armed)
        {
            _own = new Driven { Animator = own, Role = "own" };
            string prefix, driverPrefix;
            RightPalm = FindBone(transform, Palm, out prefix);
            if (RightPalm != null)
            {
                string leftPrefix;
                LeftPalm = FindBone(transform, "LArmPalm", out leftPrefix);
                if (leftPrefix != prefix) LeftPalm = null;
            }
            var avatarBones = new Dictionary<string, Transform>(StringComparer.Ordinal);
            if (RightPalm != null)
                foreach (var bone in GetComponentsInChildren<Transform>(true))
                    if (bone.name.StartsWith(prefix, StringComparison.Ordinal)) avatarBones[bone.name.Substring(prefix.Length)] = bone;
            PrepareTurns(avatarBones);
            PrepareArms(avatarBones);
            LogHead();
            if (driver == null) return "no military NPC model";
            if (armed == null || RightPalm == null || FindBone(driver.transform, Palm, out driverPrefix) == null)
            { Destroy(driver); return "no armed controller or no palm bone"; }
            var from = new List<Transform>(); var to = new List<Transform>();
            foreach (var name in Torso)
            {
                Transform match, source = null;
                if (!avatarBones.TryGetValue(name, out match)) continue;
                foreach (var bone in driver.GetComponentsInChildren<Transform>(true))
                    if (bone.name == driverPrefix + name) { source = bone; break; }
                if (source == null) continue;
                if (name == "Spine1") _torsoRoot = from.Count;
                from.Add(source); to.Add(match);
            }
            if (from.Count < 8 || _torsoRoot < 0) { Destroy(driver); _torsoRoot = -1; return "the rigs differ (" + from.Count + " shared torso bones)"; }
            _from = from.ToArray(); _to = to.ToArray();
            foreach (var renderer in driver.GetComponentsInChildren<Renderer>(true)) renderer.enabled = false;
            var animator = driver.GetComponentInChildren<Animator>(true);
            if (animator == null) { Destroy(driver); _from = _to = new Transform[0]; _torsoRoot = -1; return "no animator on the military NPC"; }
            animator.runtimeAnimatorController = armed;
            animator.applyRootMotion = false;
            animator.cullingMode = AnimatorCullingMode.AlwaysAnimate; // its renderers are off
            animator.enabled = true;
            _driver = new Driven { Animator = animator, Role = "armed" };
            _driverObject = driver;
            driver.SetActive(false);
            driver.transform.SetParent(transform, false);
            driver.transform.localPosition = Vector3.zero; driver.transform.localRotation = Quaternion.identity;
            return null;
        }

        // In a skinned mesh, bindposes map each bone from renderer space. Multiplying the parent's
        // bind matrix by the inverse child's gives the digit's true local bind rotation. Prefab
        // Transform.localRotation is already a posed fist on some of the game's models.
        private static Quaternion BindLocalRotation(SkinnedMeshRenderer[] skins, Transform digit)
        {
            if (digit == null || digit.parent == null) return digit == null ? Quaternion.identity : digit.localRotation;
            foreach (var skin in skins)
            {
                var mesh = skin.sharedMesh;
                if (mesh == null) continue;
                var bones = skin.bones; var bindposes = mesh.bindposes;
                if (bones == null || bindposes == null || bones.Length != bindposes.Length) continue;
                int child = Array.IndexOf(bones, digit), parent = Array.IndexOf(bones, digit.parent);
                if (child < 0 || parent < 0) continue;
                return (bindposes[parent] * bindposes[child].inverse).rotation;
            }
            return digit.localRotation;
        }

        // 1.4.14: what hangs on the model's head, once, to the log (for its eyes and hair).
        private void LogHead()
        {
            if (_head == null || Log == null) return;
            var names = new List<string>();
            foreach (var bone in _head.Bone.GetComponentsInChildren<Transform>(true))
                if (bone != _head.Bone && names.Count < 40) names.Add(bone.name + (bone.childCount > 0 ? "(" + bone.childCount + ")" : ""));
            Log("Partner head bones: " + (names.Count == 0 ? "none" : string.Join(", ", names.ToArray())));
        }

        // The rig's legs ("LLeg1" thigh, "LLeg2" shin, "LLegAnkle" foot), spine, neck ("Spine1 1"),
        // head ("Hub003"), right upper arm and (1.4.6) pelvis; a missing bone only drops its part.
        private void PrepareTurns(Dictionary<string, Transform> bones)
        {
            Func<string, Turned> find = name => { Transform bone; return bones.TryGetValue(name, out bone) ? new Turned { Bone = bone, Rest = bone.localRotation } : null; };
            _lThigh = find("LLeg1"); _lShin = find("LLeg2"); _lFoot = find("LLegAnkle");
            _rThigh = find("RLeg1"); _rShin = find("RLeg2"); _rFoot = find("RLegAnkle");
            _spine2 = find("Spine2"); _spine3 = find("Spine3"); _neck = find("Spine1 1"); _head = find("Hub003");
            if (_head != null)
            {
                // The lips 12 cm ahead and 7 cm below the head bone (2.7.0: and a worn mask's depth further ahead).
                _mouthLocal = _head.Bone.InverseTransformPoint(_head.Bone.position + transform.forward * .12f - transform.up * .07f);
                _mouthAhead = _head.Bone.InverseTransformDirection(transform.forward);
            }
            _arm = find("RArm1"); _lArm = find("LArm1"); _hub = find("Hub001");
            Transform pelvis;
            if (bones.TryGetValue("Hub001", out pelvis)) { _pelvis = pelvis; _hubHeight = Mathf.Clamp(pelvis.position.y - transform.position.y, .5f, 1.2f); }
            var list = new List<Turned>();
            foreach (var turned in new[] { _lThigh, _lShin, _lFoot, _rThigh, _rShin, _rFoot, _spine2, _spine3, _neck, _head, _arm, _lArm, _hub })
                if (turned != null) list.Add(turned);
            _turned = list.ToArray();
            if (_lThigh != null && _lShin != null && _lFoot != null)
                _legLength = Vector3.Distance(_lThigh.Bone.position, _lShin.Bone.position) + Vector3.Distance(_lShin.Bone.position, _lFoot.Bone.position);
            // Both arms ("RArm1" upper arm, "RArm21" forearm, "RArmPalm"; the twist bones "RArm22/23"
            // lie along the forearm) and the chest ("Hub002"), for the hands' reach.
            Func<string, Transform> get = name => { Transform found; return bones.TryGetValue(name, out found) ? found : null; };
            _rUpper = get("RArm1"); _rLower = get("RArm21"); _rPalm = get("RArmPalm");
            _lUpper = get("LArm1"); _lLower = get("LArm21"); _lPalm = get("LArmPalm");
            _rTwist2 = get("RArm22"); _rTwist3 = get("RArm23"); _lTwist2 = get("LArm22"); _lTwist3 = get("LArm23");
            _lCollar = get("LArmCollarbone");
            _chest = get("Hub002");
            // NPC chest bone axes differ from anatomical body axes. Store the
            // avatar frame in the rest chest so the proxy follows later body turns.
            if (_chest != null)
            {
                _torsoRightLocal = _chest.InverseTransformDirection(transform.right);
                _torsoUpLocal = _chest.InverseTransformDirection(transform.up);
                _torsoForwardLocal = _chest.InverseTransformDirection(transform.forward);
            }
            _armsReady = _head != null && !new[] { _rUpper, _rLower, _rPalm, _lUpper, _lLower, _lPalm, _chest }.Any(b => b == null);
            // 1.4.8: the forearms and palms the hands' reach turns start each frame from their animated
            // pose too (a clip that does not write them must not keep a reach for good); 2.7.0: the twist
            // bones and collarbones, which the held poses turn, too.
            var reached = new List<Turned>(_turned);
            foreach (var bone in new[] { _rLower, _rPalm, _lLower, _lPalm, _rTwist2, _rTwist3, _lTwist2, _lTwist3, _lCollar, get("RArmCollarbone") })
                if (bone != null) reached.Add(new Turned { Bone = bone, Rest = bone.localRotation });
            _turned = reached.ToArray();
        }

        // 2.7.0: both arms as RemoteHoldPose solves them, the palms' anatomical frames and the avatar's own fingers
        // (by name, with their skin bind turns), measured in the prefab pose.
        private void PrepareArms(Dictionary<string, Transform> bones)
        {
            _armR = MeasureArm(_rUpper, _rLower, _rTwist2, _rTwist3, _rPalm);
            _armL = MeasureArm(_lUpper, _lLower, _lTwist2, _lTwist3, _lPalm);
            RemoteNativeGrip.PalmFrame frame;
            if (RemoteNativeGrip.CaptureTargetFrame(_rPalm, out frame)) _palmR = new RemoteHoldPose.Palm { Center = frame.Center, Rotation = frame.Rotation, Valid = true };
            if (RemoteNativeGrip.CaptureTargetFrame(_lPalm, out frame)) _palmL = new RemoteHoldPose.Palm { Center = frame.Center, Rotation = frame.Rotation, Valid = true };
            var skins = GetComponentsInChildren<SkinnedMeshRenderer>(true);
            var digits = new List<Transform>(); var suffixes = new List<string>(); var binds = new List<Quaternion>();
            foreach (var pair in bones)
            {
                if (!pair.Key.StartsWith("RArmDigit", StringComparison.Ordinal) && !pair.Key.StartsWith("LArmDigit", StringComparison.Ordinal)) continue;
                digits.Add(pair.Value); suffixes.Add(pair.Key); binds.Add(BindLocalRotation(skins, pair.Value));
            }
            _toDigits = digits.ToArray(); _digitSuffixes = suffixes.ToArray(); _toDigitBind = binds.ToArray();
            // The own idle clip leaves the fingers as they were; restore them each frame before a grip curls them.
            var tracked = new List<Turned>(_turned);
            foreach (var finger in _toDigits) tracked.Add(new Turned { Bone = finger, Rest = finger.localRotation });
            _turned = tracked.ToArray();
            _armsReady &= _armR.Valid && _armL.Valid;
        }

        private static RemoteHoldPose.Arm MeasureArm(Transform upper, Transform lower, Transform twist2, Transform twist3, Transform palm)
        {
            var arm = new RemoteHoldPose.Arm();
            if (upper == null || lower == null || twist2 == null || twist3 == null || palm == null) return arm;
            var elbow = upper.InverseTransformPoint(lower.position);
            arm.UpperAxis = elbow.normalized;
            var forearm = upper.InverseTransformPoint(palm.position) - elbow;
            arm.Bend = RemoteHoldPose.Flat(forearm, arm.UpperAxis);
            if (arm.Bend.sqrMagnitude < .5f) arm.Bend = RemoteHoldPose.Flat(Vector3.up, arm.UpperAxis);
            arm.ForearmAxis = lower.InverseTransformPoint(twist2.position).normalized;
            arm.Twist2Axis = twist2.InverseTransformPoint(twist3.position).normalized;
            arm.Twist3Axis = twist3.InverseTransformPoint(palm.position).normalized;
            arm.Twist2Rest = twist2.localRotation; arm.Twist3Rest = twist3.localRotation;
            arm.Upper = Vector3.Distance(upper.position, lower.position);
            arm.Lower = Vector3.Distance(lower.position, palm.position);
            arm.Valid = arm.Upper > .05f && arm.Lower > .05f && arm.Bend.sqrMagnitude > .5f &&
                RemoteHoldPose.Finite(arm.UpperAxis) && RemoteHoldPose.Finite(arm.ForearmAxis);
            return arm;
        }

        // Read once each animator is active (an inactive animator lists no parameters).
        private static bool Has(Animator animator, string parameter)
        {
            try { foreach (var p in animator.parameters) if (p.name == parameter) return true; }
            catch (Exception) { }
            return false;
        }

        // Every frame: armed (a firearm in hand), walking, the partner's pace (m/s), aiming (down the sights,
        // or a recent shot), crouching, the view's pitch (degrees, up positive) and the times
        // (Time.unscaledTime; long ago when none) of the last melee swing and the last shot; 1.1.9:
        // reloading, and lying (downed or dead: no armed pose, no walk, no crouch).
        internal void Apply(bool armed, bool walking, float speed, bool aiming, bool crouching, float pitch, float swingAt, float shotAt, bool reloading, bool lying)
        {
            if (lying)
            {
                armed = false; walking = false; crouching = false; reloading = false; aiming = false; pitch = 0f; _rollAt = -100f;
                _use = _useTarget = 0f;
                _run = _runTarget = _tired = _tiredTarget = 0f;
            }
            _reloadTarget = reloading ? 1f : 0f;
            _crouchTarget = crouching ? 1f : 0f;
            _pitchTarget = Mathf.Clamp(pitch, -LanProtocol.MaxPitch, LanProtocol.MaxPitch);
            _swingAt = swingAt; _shotAt = shotAt;
            _walking = walking;
            _lying = lying;
            if (_equipment == null) _equipment = GetComponent<RemoteEquipmentVisual>();
            _armed = armed;
            // 2.7.0: a long gun's holder takes the armed NPC's aiming torso; nothing else needs that NPC.
            _long = !lying && _equipment != null && _equipment.Kind == RemoteHoldPose.Kind.Long;
            bool driverActive = _driverObject != null && _long;
            if (driverActive != _driverActive)
            {
                _driverActive = driverActive;
                _driverObject.SetActive(driverActive);
            }
            _aimTarget = aiming ? 1f : 0f;
            bool running = walking && (speed >= RunSpeed || _runTarget > 0f);
            _lowerTarget = aiming ? 0f : running ? RemoteHoldPose.LongRun : RemoteHoldPose.LongLow;
            float pace = walking ? Mathf.Clamp(speed / WalkClipSpeed, PaceMin, PaceMax) : 1f;
            _own?.Set(walking ? WalkState : IdleState, pace);
            if (_driverActive) _driver.Set(AimState, 1f);
        }

        // 1.4.7: every frame before Apply: running, in the air, swimming, a throw held back, and what
        // it uses (LanProtocol.UseNone .. UseMedicine) with which item.
        internal void Moves(bool run, bool air, bool swim, bool cock, byte use, bool tired, int useItem)
        {
            _runTarget = run ? 1f : 0f; _airTarget = air ? 1f : 0f; _swimTarget = swim ? 1f : 0f; _cockTarget = cock ? 1f : 0f;
            _tiredTarget = tired ? 1f : 0f;
            if (use != LanProtocol.UseNone && (_useTarget == 0f || use != _useKind || useItem != _useItem)) _useAt = Time.unscaledTime;
            if (use != LanProtocol.UseNone) _useKind = use;
            _useItem = useItem;
            _useTarget = use != LanProtocol.UseNone ? 1f : 0f;
        }

        // 1.4.7: the partner let a throw go, was hit, climbed a ladder (shown climbing for ClimbTime).
        internal void Throw() { _throwRise = ThrowRise * (1f - _cock); _throwAt = Time.unscaledTime; }
        // 1.4.8: a jab with bare fists (hand after hand); a press of the use key.
        internal void Jab() { _jabLeft = !_jabLeft; _jabAt = Time.unscaledTime; }
        internal void Interact() { _reachDown = _pitchTarget < -BendPitch; _reachAt = Time.unscaledTime; }
        internal void Flinch() { _flinchAt = Time.unscaledTime; }
        internal void Climb() { _climbAt = Time.unscaledTime; }
        internal bool IsClimbing { get { float age = Time.unscaledTime - _climbAt; return age >= 0f && age < ClimbTime; } }
        internal float ClimbShare { get { return Mathf.Clamp01((Time.unscaledTime - _climbAt) / ClimbTime); } }

        // 1.4.6: the partner dashed (direction in eighths of a turn clockwise from its facing).
        internal void Dash(byte direction)
        {
            _rollAt = Time.unscaledTime;
            _rollDirection = (byte)(direction % LanProtocol.DashDirections);
        }

        // After the animators: the armed NPC's torso onto the avatar, the procedural layer, then what it holds or uses.
        private void LateUpdate()
        {
            if (_driverActive && _long && _torsoRoot >= 0)
            {
                // The spine takes the driver's turn relative to the body as a whole (its aiming stance turns the
                // chest to the right, the left shoulder forward), the rest of the torso its turns relative to the spine.
                for (int i = 0; i < _from.Length; i++)
                    if (i == _torsoRoot) _to[i].rotation = _from[i].rotation;
                    else _to[i].localRotation = _from[i].localRotation;
            }
            float follow = 1f - Mathf.Exp(-Follow * Time.unscaledDeltaTime);
            _crouch = Mathf.Lerp(_crouch, _crouchTarget, follow);
            _pitch = Mathf.Lerp(_pitch, _pitchTarget, follow);
            _reload = Mathf.Lerp(_reload, _reloadTarget, follow);
            _lower = Mathf.Lerp(_lower, _lowerTarget, follow);
            _aim = Mathf.Lerp(_aim, _aimTarget, follow);
            float quick = 1f - Mathf.Exp(-15f * Time.unscaledDeltaTime);
            _run = Mathf.Lerp(_run, _runTarget, follow); _air = Mathf.Lerp(_air, _airTarget, quick);
            _tired = Mathf.Lerp(_tired, _tiredTarget, 1f - Mathf.Exp(-4f * Time.unscaledDeltaTime));
            _swim = Mathf.Lerp(_swim, _swimTarget, follow); _cock = Mathf.Lerp(_cock, _cockTarget, quick);
            _use = Mathf.Lerp(_use, _useTarget, follow);
            // A climb, swim or downed transition interrupts the use instead of letting an
            // empty hand linger at the mouth through the new full-body motion. Once the held
            // weapon reappears, do not swing that weapon up during the ordinary use exit fade.
            float rollAge = Time.unscaledTime - _rollAt;
            bool rolling = rollAge >= 0f && rollAge < RollTime;
            if (_swimTarget > 0f || IsClimbing || rolling ||
                _useTarget == 0f && _equipment != null && _equipment.HasHeldItem)
                _use = _useTarget = 0f;
            foreach (var turned in _turned) Restore(turned);
            RestorePelvis();
            var right = transform.right;
            Stride(right);
            if (_crouch > .001f)
            {
                // Knees forward, shins back, feet flat; the pelvis drops by what the legs lost in height.
                float knee = _crouch * CrouchKnee;
                Turn(_lThigh, -knee, right); Turn(_lShin, 2f * knee, right); Turn(_lFoot, -knee, right);
                Turn(_rThigh, -knee, right); Turn(_rShin, 2f * knee, right); Turn(_rFoot, -knee, right);
                if (_pelvis != null) _pelvis.position += Vector3.down * (_legLength * (1f - Mathf.Cos(knee * Mathf.Deg2Rad)));
            }
            // Looking up or down: the body bends with it, the more so with a rifle (the arms hang
            // from the chest, so the weapon follows the spine's share). 1.4.13: looking up unarmed, the upper
            // back takes more and the head and neck less (a head tilted 40 degrees back pulled a long hairdo,
            // skinned to the neck and the upper back too, through the body). 1.4.14: less still (the hair has no
            // physics on this copy: it stays as the head turns it): at 90 degrees up the head and neck tilt ~18.
            float body = Mathf.Clamp(_pitch, -MaxBodyPitch, MaxBodyPitch);
            float lean = _crouch * CrouchLean;
            bool up = !_armed && _pitch > 0f;
            Turn(_spine2, (_armed ? .4f : up ? .25f : .1f) * -body + lean * .5f, right);
            Turn(_spine3, (_armed ? .4f : up ? .35f : .15f) * -body + lean * .5f, right);
            Turn(_neck, (_armed ? .1f : up ? .08f : .3f) * -_pitch, right);
            Turn(_head, (_armed ? .1f : up ? .12f : .45f) * -_pitch, right);
            if (_armed)
            {
                float age = Time.unscaledTime - _shotAt;
                if (age >= 0f && age < 6f * RecoilSettle) Turn(_spine3, -RecoilKick * Mathf.Exp(-age / RecoilSettle), right);
                if (_reload > .01f) Turn(_spine3, ReloadLean * _reload, right);
            }
            float now = Time.unscaledTime;
            Airborne(right); Climbing(right, now); Flinching(right, now);
            Swimming(right, now);
            Roll();
            // 2.7.0: what it holds, from the final body pose; strikes, throws, jabs and a reach go over it.
            bool free = _swim < .01f && !IsClimbing && !rolling;
            _supportHeld = false;
            if (free && _use < .01f) Holding(now);
            if (!_armed) { Striking(right); Throwing(right); Jabbing(right); }
            Reaching(right, now);
            // The mouth is on the head and must be measured after every body/head transform.
            if (free) Using(now);
            Fingers(now);
            foreach (var turned in _turned) turned.Written = turned.Bone.localRotation;
            if (_pelvis != null) _pelvisWritten = _pelvis.localPosition;
        }

        // 2.7.0: the held item's stance (RemoteHoldPose) and both arms to its grips.
        private void Holding(float now)
        {
            // Downed or dead (laid on its back by the plugin) it holds nothing up.
            if (!_armsReady || _lying || _equipment == null || !_equipment.HasHeldItem) return;
            var kind = _equipment.Kind;
            if (kind == RemoteHoldPose.Kind.None) return;
            var body = BodyNow();
            if (kind == RemoteHoldPose.Kind.OneHand) { ArmTo(false, RemoteHoldPose.OneHand(body, _palmR), 1f); return; }
            RemoteHoldPose.Weapon w;
            if (!_equipment.TryGetWeapon(out w)) return;
            RemoteHoldPose.Frame f;
            RemoteHoldPose.Hand primary, support;
            float work = Mathf.Sin(now * ReloadPace) * .5f + .5f;
            switch (kind)
            {
                case RemoteHoldPose.Kind.Long:
                    // 2.8.1: a reload brings the gun up before the chest and turned in (it went 18 degrees lower, the muzzle
                    // near the feet), and the left hand takes the magazine instead of hanging under the gun as on the fore-end.
                    RemoteHoldPose.LongGun(body, w, Mathf.Lerp(_lower, RemoteHoldPose.ReloadLow, _reload), RemoteHoldPose.ReloadInward * _reload,
                        out f, out primary, out support);
                    if (support.Valid && _lCollar != null)
                    {
                        // A shorter arm: the left shoulder comes forward, then the hand slides back along the fore-end.
                        float angle = RemoteHoldPose.Protract(_lCollar.position, _lUpper.position, body.ReachL, support.Wrist, body.Up, true);
                        if (Mathf.Abs(angle) > .01f) _lCollar.rotation = Quaternion.AngleAxis(angle, body.Up) * _lCollar.rotation;
                        var bore = f.Rotation * w.Bore;
                        float span = (support.Wrist - primary.Wrist).magnitude;
                        float slide = RemoteHoldPose.Slide(_lUpper.position, body.ReachL, support.Wrist, bore, RemoteHoldPose.SlideShare * span);
                        support = RemoteHoldPose.SupportPalm(w, primary, bore * slide, support.Pole);
                        if (_reload > .01f) support = RemoteHoldPose.Blend(support, RemoteHoldPose.Reload(body, w, f, _palmL, true, work), _reload);
                    }
                    break;
                case RemoteHoldPose.Kind.Handgun:
                    RemoteHoldPose.Handgun(body, w, _aim, out f, out primary, out support);
                    if (_reload > .01f && support.Valid)
                        support.Wrist = Vector3.Lerp(support.Wrist, primary.Wrist - f.Rotation * (w.Aim * Vector3.up) * (.08f + .03f * work), _reload);
                    break;
                case RemoteHoldPose.Kind.Bow:
                    RemoteHoldPose.Bow(body, w, _aim, out f, out primary, out support);
                    break;
                default:
                    RemoteHoldPose.TwoHand(body, w, out f, out primary, out support);
                    break;
            }
            bool left = _equipment.PrimaryLeft;
            ArmTo(left, primary, 1f);
            float weight = 1f;
            if (kind == RemoteHoldPose.Kind.Bow)
            {
                // The draw hand releases the string briefly as the bow fires.
                float shotAge = now - _equipment.LastShotAt;
                if (shotAge >= 0f && shotAge < .18f) weight = Mathf.SmoothStep(0f, 1f, shotAge / .18f);
            }
            ArmTo(!left, support, weight);
            _supportHeld = support.Valid;
        }

        // The body as RemoteHoldPose reads it: the avatar's axes, chest, shoulders and lips now, the torso's (or
        // armour's) front, the arms' reach and the view's pitch.
        private RemoteHoldPose.Body BodyNow()
        {
            if (_wear == null) _wear = GetComponent<RemoteOutfitVisual>();
            float mask = _wear == null ? 0f : _wear.MaskDepth;
            return new RemoteHoldPose.Body
            {
                Right = transform.right, Up = transform.up, Forward = transform.forward,
                Chest = _chest.position, ShoulderR = _rUpper.position, ShoulderL = _lUpper.position,
                Mouth = _head.Bone.TransformPoint(_mouthLocal + _mouthAhead * mask),
                Front = _wear == null ? .25f : _wear.FrontDepth,
                ReachR = _armR.Upper + _armR.Lower, ReachL = _armL.Upper + _armL.Lower,
                Pitch = Mathf.Clamp(_pitch, -MaxBodyPitch, MaxBodyPitch)
            };
        }

        // One arm to a hand target (RemoteHoldPose.Solve), blended over the animated pose by weight.
        private void ArmTo(bool left, RemoteHoldPose.Hand hand, float weight)
        {
            if (weight <= .001f || !hand.Valid || !_armsReady) return;
            Transform upper = left ? _lUpper : _rUpper, lower = left ? _lLower : _rLower, palm = left ? _lPalm : _rPalm;
            Transform twist2 = left ? _lTwist2 : _rTwist2, twist3 = left ? _lTwist3 : _rTwist3;
            var pose = RemoteHoldPose.Solve(left ? _armL : _armR, upper.position, transform.up, lower.localRotation, hand);
            if (!pose.Valid) return;
            Quaternion u = upper.localRotation, l = lower.localRotation, a = twist2.localRotation, b = twist3.localRotation, p = palm.localRotation;
            upper.rotation = pose.Upper;
            lower.rotation = pose.Lower;
            twist2.localRotation = pose.Twist2;
            twist3.localRotation = pose.Twist3;
            palm.rotation = pose.Palm;
            if (weight >= .999f) return;
            upper.localRotation = Quaternion.Slerp(u, upper.localRotation, weight);
            lower.localRotation = Quaternion.Slerp(l, lower.localRotation, weight);
            twist2.localRotation = Quaternion.Slerp(a, twist2.localRotation, weight);
            twist3.localRotation = Quaternion.Slerp(b, twist3.localRotation, weight);
            palm.localRotation = Quaternion.Slerp(p, palm.localRotation, weight);
        }

        // The fingers: the item's own first-person grip on the hands that hold it; a fist round what is eaten,
        // drunk or used.
        private void Fingers(float now)
        {
            if (_use > .01f && _equipment != null)
            {
                bool medkit = _useKind == LanProtocol.UseMedicine && _equipment.UseItemId != RemoteEquipment.PillsItem;
                Fist(_use * (medkit ? .4f : 1f));
                return;
            }
            if (_equipment == null || !_equipment.HasHeldItem || _equipment.Kind == RemoteHoldPose.Kind.None) return;
            bool primaryLeft = _equipment.PrimaryLeft;
            for (int i = 0; i < _toDigits.Length; i++)
            {
                bool left = _digitSuffixes[i][0] == 'L';
                bool primary = left == primaryLeft;
                if (!primary && !_supportHeld) continue;
                // This item's native hand pose: its CAT fingers are transferred as a curl relative to skin bind; the
                // avatar's bind supplies its own axes (a raw local quaternion twists Skuf/W digits).
                Quaternion sourcePose, sourceBind;
                if (!_equipment.TryGetGripFinger(_digitSuffixes[i], out sourcePose, out sourceBind)) continue;
                var grip = _toDigitBind[i] * (Quaternion.Inverse(sourceBind) * sourcePose);
                float release = 0f;
                if (!primary && _armed)
                    release = Mathf.Max(_reload, Envelope(now - _reachAt, ReachRise, ReachHold, ReachReturn));
                else if (!primary && _equipment.Kind == RemoteHoldPose.Kind.Bow)
                {
                    float shotAge = now - _equipment.LastShotAt;
                    if (shotAge >= 0f && shotAge < .18f) release = 1f - Mathf.SmoothStep(0f, 1f, shotAge / .18f);
                }
                _toDigits[i].localRotation = Quaternion.Slerp(grip, _toDigits[i].localRotation, release);
            }
        }

        // The right hand closed round a held consumable: the game's own hammer grip (RemoteNativeGrip.TryFist).
        private void Fist(float amount)
        {
            RemoteNativeGrip.FingerPose[] fist;
            if (amount <= .01f || !RemoteNativeGrip.TryFist(out fist)) return;
            for (int i = 0; i < _toDigits.Length; i++)
            {
                if (_digitSuffixes[i][0] != 'R') continue;
                foreach (var finger in fist)
                {
                    if (finger.Suffix != _digitSuffixes[i]) continue;
                    var grip = _toDigitBind[i] * (Quaternion.Inverse(finger.LocalRest) * finger.LocalPose);
                    _toDigits[i].localRotation = Quaternion.Slerp(_toDigits[i].localRotation, grip, amount);
                    break;
                }
            }
        }

        // 1.4.8: the held melee weapon's strike since the last swing began.
        private void Striking(Vector3 right)
        {
            float age = Time.unscaledTime - _swingAt;
            var up = transform.up;
            switch (StrikeKind)
            {
                case Strike.Chop:
                {
                    // Both arms over the right shoulder, the chest turned back, then down across.
                    float arm = Curve(age, ChopRise, ChopStrike, ChopReturn, ChopHigh, ChopLow);
                    if (arm == 0f) return;
                    Turn(_arm, arm, right); Turn(_lArm, arm * .85f, right);
                    Turn(_spine3, arm / ChopHigh * ChopTwist, up);
                    return;
                }
                case Strike.Sideways:
                {
                    // The arms raised level and swung back to the right, then across to the left; the chest follows.
                    if (age < 0f || age >= SideWind + SideStrike + SideReturn) return;
                    float raise, yaw;
                    if (age < SideWind) { raise = Mathf.SmoothStep(0f, 1f, age / SideWind); yaw = SideBack * raise; }
                    else if (age < SideWind + SideStrike) { raise = 1f; yaw = Mathf.Lerp(SideBack, SideAcross, Mathf.SmoothStep(0f, 1f, (age - SideWind) / SideStrike)); }
                    else { float t = Mathf.SmoothStep(0f, 1f, (age - SideWind - SideStrike) / SideReturn); raise = 1f - t; yaw = Mathf.Lerp(SideAcross, 0f, t); }
                    Turn(_arm, SideRaise * raise, right); Turn(_arm, yaw, up);
                    Turn(_lArm, SideRaise * .85f * raise, right); Turn(_lArm, yaw, up);
                    Turn(_spine3, yaw * .3f, up); Turn(_spine2, yaw * .15f, up);
                    return;
                }
                case Strike.Stab:
                {
                    // Drawn back, then thrust straight ahead at full reach, the chest leaning in.
                    if (age < 0f || age >= StabPull + StabThrust + StabHold + StabReturn) return;
                    if (age < StabPull) { Turn(_arm, 25f * Mathf.SmoothStep(0f, 1f, age / StabPull), right); return; }
                    float w = Envelope(age - StabPull, StabThrust, StabHold, StabReturn);
                    Turn(_spine3, 8f * w, right);
                    if (_armsReady) Reach(_rUpper, _rLower, _rPalm, Ahead(_rUpper, _rLower, _rPalm, transform.forward - up * .08f), _rPalm.rotation, w);
                    return;
                }
                default:
                    Turn(_arm, SwingAngle(age), right);
                    return;
            }
        }

        // 1.4.8: a jab: one hand straight at head height towards the middle, the chest turning behind it.
        private void Jabbing(Vector3 right)
        {
            float age = Time.unscaledTime - _jabAt;
            if (!_armsReady || age < 0f || age >= JabThrust + JabHold + JabReturn) return;
            float w = Envelope(age, JabThrust, JabHold, JabReturn);
            Turn(_spine3, (_jabLeft ? 12f : -12f) * w, transform.up);
            var direction = transform.forward + transform.up * .12f + (_jabLeft ? right : -right) * .12f;
            if (_jabLeft) Reach(_lUpper, _lLower, _lPalm, Ahead(_lUpper, _lLower, _lPalm, direction), _lPalm.rotation, w);
            else Reach(_rUpper, _rLower, _rPalm, Ahead(_rUpper, _rLower, _rPalm, direction), _rPalm.rotation, w);
        }

        // 1.4.8: the use key: a hand out where the partner looks (the left one when it holds a
        // firearm); looking down it bends (back and knees) and reaches to the ground before it.
        private void Reaching(Vector3 right, float now)
        {
            float age = now - _reachAt;
            if (!_armsReady || age < 0f || age >= ReachRise + ReachHold + ReachReturn) return;
            float w = Envelope(age, ReachRise, ReachHold, ReachReturn);
            var up = transform.up; var forward = transform.forward;
            Vector3 target;
            float side = _armed ? -.1f : .12f;
            if (_reachDown)
            {
                float knee = BendKnee * w;
                Turn(_lThigh, -knee, right); Turn(_lShin, 2f * knee, right); Turn(_lFoot, -knee, right);
                Turn(_rThigh, -knee, right); Turn(_rShin, 2f * knee, right); Turn(_rFoot, -knee, right);
                if (_pelvis != null) _pelvis.position -= up * (_legLength * (1f - Mathf.Cos(knee * Mathf.Deg2Rad)));
                Turn(_spine2, BendCurl * .5f * w, right); Turn(_spine3, BendCurl * .5f * w, right);
                target = transform.position + forward * .45f + up * .12f + right * side;
            }
            else target = _chest.position + Quaternion.AngleAxis(-Mathf.Clamp(_pitch, -60f, 60f), right) * forward * .6f + right * side;
            if (_armed) Reach(_lUpper, _lLower, _lPalm, target, _lPalm.rotation, w);
            else Reach(_rUpper, _rLower, _rPalm, target, _rPalm.rotation, w);
        }

        // A point a whole arm's length (as the arm is now) from the shoulder along a direction.
        private static Vector3 Ahead(Transform upper, Transform lower, Transform end, Vector3 direction)
        {
            float length = Vector3.Distance(upper.position, lower.position) + Vector3.Distance(lower.position, end.position);
            return upper.position + direction.normalized * (length * .95f);
        }

        // 0..1: up over rise, held, back down over the return (smoothed).
        internal static float Envelope(float age, float rise, float hold, float back)
        {
            if (age < 0f) return 0f;
            if (age < rise) return Mathf.SmoothStep(0f, 1f, age / rise);
            age -= rise;
            if (age < hold) return 1f;
            age -= hold;
            return age < back ? 1f - Mathf.SmoothStep(0f, 1f, age / back) : 0f;
        }

        // A blow's turn (degrees): up to high over rise, through to low over strike, back to 0.
        internal static float Curve(float age, float rise, float strike, float back, float high, float low)
        {
            if (age < 0f) return 0f;
            if (age < rise) return high * Mathf.SmoothStep(0f, 1f, age / rise);
            age -= rise;
            if (age < strike) return Mathf.Lerp(high, low, age / strike);
            age -= strike;
            return age < back ? Mathf.Lerp(low, 0f, Mathf.SmoothStep(0f, 1f, age / back)) : 0f;
        }

        // The same ground-paced clip keeps the feet timed to travel. Fatigue changes only
        // extension, upper-body weight and free arm swing, never root motion or movement speed.
        private void Stride(Vector3 right)
        {
            float rollAge = Time.unscaledTime - _rollAt;
            if (_run < .01f || _airTarget > 0f || _swimTarget > 0f || IsClimbing || _crouchTarget > 0f ||
                rollAge >= 0f && rollAge < RollTime) return;
            float fatigue = _tired * _run;
            if (_walking)
                foreach (var leg in new[] { _lThigh, _rThigh, _lShin, _rShin })
                    if (leg != null) leg.Bone.localRotation = Quaternion.SlerpUnclamped(leg.Rest, leg.Bone.localRotation, 1f + RunStride * _run - .20f * fatigue);
            float breath = Mathf.Sin(Time.unscaledTime * 7f) * fatigue;
            Turn(_spine2, RunLean * .5f * _run + 5f * fatigue + .7f * breath, right);
            Turn(_spine3, RunLean * .5f * _run + 3f * fatigue + .5f * breath, right);
            Turn(_head, 4f * fatigue, right);
            if (_walking) Turn(_spine2, 1.2f * breath, transform.forward);
            bool empty = !_armed && (_equipment == null || !_equipment.HasHeldItem) && _use < .01f && _cock < .01f;
            if (empty && fatigue > .01f)
                foreach (var arm in new[] { _arm, _lArm })
                    if (arm != null)
                    {
                        arm.Bone.localRotation = Quaternion.SlerpUnclamped(arm.Rest, arm.Bone.localRotation, 1f - .35f * fatigue);
                        Turn(arm, 8f * fatigue, right);
                    }
        }

        // 1.4.7: in the air the knees come up (the right a little less), the free arms rise a little.
        private void Airborne(Vector3 right)
        {
            if (_air < .01f) return;
            float knee = AirKnee * _air;
            Turn(_lThigh, -1.2f * knee, right); Turn(_lShin, 1.8f * knee, right); Turn(_lFoot, -.6f * knee, right);
            Turn(_rThigh, -.9f * knee, right); Turn(_rShin, 1.5f * knee, right); Turn(_rFoot, -.5f * knee, right);
            if (!_armed) { Turn(_arm, -20f * _air, right); Turn(_lArm, -20f * _air, right); }
        }

        // 1.4.7: a climb: hand over hand and step over step, strongest mid-way.
        private void Climbing(Vector3 right, float now)
        {
            float age = now - _climbAt;
            if (age < 0f || age >= ClimbTime) return;
            float c = Mathf.Sin(age / ClimbTime * Mathf.PI), beat = Mathf.Sin(age * 14f);
            if (!_armed) { Turn(_arm, (-150f + 25f * beat) * c, right); Turn(_lArm, (-150f - 25f * beat) * c, right); }
            Turn(_lThigh, (-45f + 25f * beat) * c, right); Turn(_lShin, 60f * c, right);
            Turn(_rThigh, (-45f - 25f * beat) * c, right); Turn(_rShin, 60f * c, right);
        }

        // 1.4.7: a throw over the shoulder: the arm held back (the chest turned with it, the other arm
        // forward), then over and down, then back.
        private void Throwing(Vector3 right)
        {
            float age = Time.unscaledTime - _throwAt;
            bool going = age >= 0f && age < _throwRise + ThrowStrike + ThrowReturn;
            float arm = going ? ThrowAngle(age, _throwRise) : ThrowBack * _cock;
            if (Mathf.Abs(arm) < .01f) return;
            Turn(_arm, arm, right);
            float back = Mathf.Clamp01(arm / ThrowBack);
            Turn(_spine3, arm / ThrowBack * 20f, transform.up);
            Turn(_lArm, -50f * back, right);
        }

        // The throwing arm's turn (degrees about the right axis) at a time after the throw began.
        internal static float ThrowAngle(float age, float rise)
        {
            if (age < 0f) return 0f;
            if (age < rise) return ThrowBack * Mathf.SmoothStep(0f, 1f, age / rise);
            age -= rise;
            if (age < ThrowStrike) return Mathf.Lerp(ThrowBack, ThrowFollow, Mathf.SmoothStep(0f, 1f, age / ThrowStrike));
            age -= ThrowStrike;
            return age < ThrowReturn ? Mathf.Lerp(ThrowFollow, 0f, Mathf.SmoothStep(0f, 1f, age / ThrowReturn)) : 0f;
        }

        // 2.7.0: eating, drinking, pills, a medkit or a bandage (RemoteHoldPose), the item in the hand that holds it.
        // Drinking (a bottle, a can; pills too) tips it at the lips with the head back between rests before the chest;
        // eating brings the food's end to the mouth and chews; a medkit lies on the left palm while the right hand dips
        // into it and dabs the chest; a bandage goes round the left forearm. The sip and bite cycles are
        // RemoteMotionStyle's; without the item's model (an older partner) the hands still move with a stand-in size.
        private void Using(float now)
        {
            if (_use < .01f || !_armsReady || _equipment == null) return;
            var right = transform.right;
            RemoteHoldPose.Item item;
            bool shown = _equipment.TryGetUseItem(out item);
            bool pills = _useKind == LanProtocol.UseMedicine && _equipment.UseItemId == RemoteEquipment.PillsItem;
            if (!shown) item = StandIn(_useKind);
            float age = now - _useAt;
            Vector3 position; Quaternion rotation;
            RemoteHoldPose.Hand hand;
            Transform holder;
            if (_useKind == LanProtocol.UseDrink || pills)
            {
                var cycle = RemoteMotionStyle.Sample(age, true);
                Turn(_head, -18f * cycle.Tilt * _use, right); // 2.8.1: the head goes back as the bottle tips, at the lips
                hand = RemoteHoldPose.Drink(BodyNow(), _palmR, item, cycle.Contact, 10f + 100f * cycle.Tilt, out position, out rotation);
                ArmTo(false, hand, _use);
                holder = _rPalm;
            }
            else if (_useKind == LanProtocol.UseEat)
            {
                var cycle = RemoteMotionStyle.Sample(age, false);
                Turn(_head, (cycle.Head + 3f * cycle.Contact) * _use, right);
                hand = RemoteHoldPose.Eat(BodyNow(), _palmR, item, cycle.Contact, out position, out rotation);
                ArmTo(false, hand, _use);
                holder = _rPalm;
            }
            else if (_useKind == LanProtocol.UseBandage)
            {
                Turn(_head, 20f * _use, right);
                var body = BodyNow();
                ArmTo(true, RemoteHoldPose.BandageArm(body, _palmL), _use);
                hand = RemoteHoldPose.BandageWrap(body, _palmR, item, _lLower.position, _lPalm.position, age * WrapTurns, out position, out rotation);
                ArmTo(false, hand, _use);
                holder = _rPalm;
            }
            else
            {
                Turn(_head, 22f * _use, right);
                Turn(_spine3, 6f * _use, right);
                float phase = .5f - .5f * Mathf.Cos(age * 2f * Mathf.PI / MedkitCycle);
                RemoteHoldPose.Hand work;
                RemoteHoldPose.Medkit(BodyNow(), _palmL, _palmR, item, phase, out hand, out work, out position, out rotation);
                ArmTo(true, hand, _use);
                ArmTo(false, work, _use);
                holder = _lPalm;
            }
            if (shown && hand.Valid)
            {
                var inverse = Quaternion.Inverse(hand.Palm);
                _equipment.PlaceUse(holder, inverse * (position - hand.Wrist), inverse * rotation);
            }
        }

        // The size the hands move for when the partner's state names no item (bounds in metres, scale 1).
        private static RemoteHoldPose.Item StandIn(byte use)
        {
            switch (use)
            {
                case LanProtocol.UseEat: return new RemoteHoldPose.Item { Min = new Vector3(-.04f, 0f, -.14f), Max = new Vector3(.04f, .05f, .14f), Scale = 1f };
                case LanProtocol.UseBandage: return new RemoteHoldPose.Item { Min = new Vector3(-.06f, 0f, -.06f), Max = new Vector3(.06f, .14f, .06f), Scale = 1f };
                case LanProtocol.UseMedicine: return new RemoteHoldPose.Item { Min = new Vector3(-.13f, 0f, -.13f), Max = new Vector3(.13f, .09f, .13f), Scale = 1f };
                default: return new RemoteHoldPose.Item { Min = new Vector3(-.035f, 0f, -.035f), Max = new Vector3(.035f, .24f, .035f), Scale = 1f };
            }
        }

        // 1.4.7: hit: the chest and head jerk back and the knees give a little, then settle.
        private void Flinching(Vector3 right, float now)
        {
            float age = now - _flinchAt;
            if (age < 0f || age >= FlinchTime) return;
            float k = age < .06f ? age / .06f : Mathf.Exp(-(age - .06f) / .12f);
            Turn(_spine2, -8f * k, right); Turn(_spine3, -8f * k, right); Turn(_head, -12f * k, right);
            Turn(_lThigh, -10f * k, right); Turn(_lShin, 20f * k, right); Turn(_rThigh, -10f * k, right); Turn(_rShin, 20f * k, right);
            if (_pelvis != null) _pelvis.position -= transform.up * (.03f * k);
        }

        // 1.4.7: swimming: legs kicking in turn and the breaststroke (free arms), then the whole body
        // tilts forward about the chest, as if lying on the water.
        private void Swimming(Vector3 right, float now)
        {
            if (_swim < .01f || _hub == null) return;
            float kick = Mathf.Sin(now * SwimPace * 2f) * SwimKick * _swim;
            Turn(_lThigh, kick, right); Turn(_rThigh, -kick, right);
            if (!_armed)
            {
                float stroke = (-110f + SwimStroke * Mathf.Sin(now * SwimPace)) * _swim;
                Turn(_arm, stroke, right); Turn(_lArm, stroke, right);
            }
            var pivot = _chest != null ? _chest.position : _hub.Bone.position + transform.up * (.6f * _hubHeight);
            _hub.Bone.RotateAround(pivot, right, SwimTilt * _swim);
        }

        // Two-bone reach with an avatar-side/front elbow pole for a free reach (a jab, a stab, the use key): its
        // wrist may be projected off the torso. Held items go through ArmTo (RemoteHoldPose) instead.
        private void Reach(Transform upper, Transform lower, Transform end, Vector3 target,
            Quaternion rotation, float weight)
        {
            if (weight <= .001f || float.IsNaN(target.x) || float.IsNaN(target.y) || float.IsNaN(target.z)) return;
            Vector3 a = upper.position, b = lower.position, c = end.position;
            var solved = RemoteArmSolver.Solve(ReachInput(upper, lower, end, target, weight));
            if (!solved.Valid) return;
            var elbow = Unity(solved.Elbow);
            var wrist = Unity(solved.Wrist);
            upper.rotation = Quaternion.FromToRotation(b - a, elbow - a) * upper.rotation;
            b = lower.position; c = end.position;
            lower.rotation = Quaternion.FromToRotation(c - b, wrist - b) * lower.rotation;
            end.rotation = Quaternion.Slerp(end.rotation, rotation, weight);
        }

        private RemoteArmSolver.Input ReachInput(Transform upper, Transform lower, Transform end,
            Vector3 target, float weight)
        {
            Vector3 a = upper.position, b = lower.position, c = end.position;
            var chest = _chest == null ? transform.position : _chest.position;
            float shoulders = _armsReady ? Vector3.Distance(_rUpper.position, _lUpper.position) : .45f;
            var up = _chest == null ? transform.up : _chest.TransformDirection(_torsoUpLocal);
            return new RemoteArmSolver.Input
            {
                Shoulder = Scalar(a), Elbow = Scalar(b), Wrist = Scalar(c), Target = Scalar(target),
                Chest = Scalar(chest), Right = Scalar(_chest == null ? transform.right : _chest.TransformDirection(_torsoRightLocal)),
                Forward = Scalar(_chest == null ? transform.forward : _chest.TransformDirection(_torsoForwardLocal)), Up = Scalar(up),
                ShoulderWidth = shoulders, TorsoHeight = _pelvis == null ? .45f :
                    Mathf.Abs(Vector3.Dot(chest - _pelvis.position, up)),
                Weight = weight, Left = upper == _lUpper
            };
        }

        private static RemoteArmSolver.Point Scalar(Vector3 v) { return new RemoteArmSolver.Point(v.x, v.y, v.z); }
        private static Vector3 Unity(RemoteArmSolver.Point p) { return new Vector3(p.X, p.Y, p.Z); }

        // 1.4.6: the roll. The body turns to face the dash (the back of it for a dash backwards),
        // tucks (knees in, back curled, head down, the pelvis low) and goes once round over its
        // head (over its back backwards) about its middle, then turns back to the view.
        private void Roll()
        {
            float age = Time.unscaledTime - _rollAt;
            if (_hub == null || age < 0f || age >= RollTime) return;
            float p = age / RollTime, tuck = Mathf.Sin(p * Mathf.PI);
            float heading = Mathf.DeltaAngle(0f, _rollDirection * 45f);
            bool back = Mathf.Abs(heading) > 90f;
            float face = (back ? Mathf.DeltaAngle(180f, heading) : heading) *
                Mathf.SmoothStep(0f, 1f, Mathf.Clamp01(p / RollFace)) * Mathf.SmoothStep(0f, 1f, Mathf.Clamp01((1f - p) / RollFace));
            // The tuck about the body's own right axis; then the whole body turns, then rolls about
            // the turned axis.
            var up = transform.up; var right = transform.right;
            float knee = tuck * RollKnee;
            Turn(_lThigh, -1.4f * knee, right); Turn(_lShin, 2f * knee, right); Turn(_lFoot, -.6f * knee, right);
            Turn(_rThigh, -1.4f * knee, right); Turn(_rShin, 2f * knee, right); Turn(_rFoot, -.6f * knee, right);
            Turn(_spine2, tuck * RollCurl * .5f, right); Turn(_spine3, tuck * RollCurl * .5f, right);
            Turn(_neck, tuck * RollHead * .5f, right); Turn(_head, tuck * RollHead * .5f, right);
            var hub = _hub.Bone;
            hub.position += -up * (tuck * RollSink * _hubHeight);
            var pivot = hub.position + up * (.15f * _hubHeight);
            hub.RotateAround(new Vector3(transform.position.x, pivot.y, transform.position.z), up, face);
            hub.RotateAround(pivot, Quaternion.AngleAxis(face, up) * right, (back ? -360f : 360f) * Mathf.SmoothStep(0f, 1f, p));
        }

        // The upper arm's turn (degrees about the right axis, negative raises it forward) at a
        // time after a swing began.
        internal static float SwingAngle(float age)
        {
            if (age < 0f || age > SwingRise + SwingStrike + SwingReturn) return 0f;
            if (age < SwingRise) return SwingHigh * Mathf.SmoothStep(0f, 1f, age / SwingRise);
            age -= SwingRise;
            if (age < SwingStrike) return Mathf.Lerp(SwingHigh, SwingLow, age / SwingStrike);
            age -= SwingStrike;
            return Mathf.Lerp(SwingLow, 0f, Mathf.SmoothStep(0f, 1f, age / SwingReturn));
        }

        private static void Restore(Turned turned)
        {
            if (turned.Seen && turned.Bone.localRotation == turned.Written) turned.Bone.localRotation = turned.Base;
            else turned.Base = turned.Bone.localRotation;
            turned.Seen = true;
        }

        private void RestorePelvis()
        {
            if (_pelvis == null) return;
            if (_pelvisSeen && _pelvis.localPosition == _pelvisWritten) _pelvis.localPosition = _pelvisBase;
            else _pelvisBase = _pelvis.localPosition;
            _pelvisSeen = true;
        }

        private static void Turn(Turned turned, float degrees, Vector3 axis)
        {
            if (turned == null || Mathf.Abs(degrees) < .01f) return;
            turned.Bone.rotation = Quaternion.AngleAxis(degrees, axis) * turned.Bone.rotation;
        }
    }
}
