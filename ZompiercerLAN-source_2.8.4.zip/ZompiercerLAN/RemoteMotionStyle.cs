using System;

namespace ZompiercerLAN
{
    // Cosmetic curves only. Scalar sampling permits checks without running Unity.
    internal static class RemoteMotionStyle
    {
        internal const float TiredEnter = .25f, TiredExit = .35f;
        internal const float EatPeriod = 2.4f, DrinkPeriod = 2.8f;
        internal struct Consumption
        {
            internal float Contact, Chew, Tilt, Head;
        }

        internal static bool Tired(bool previous, float current, float maximum)
        {
            if (!Finite(current) || !Finite(maximum) || maximum <= 0f || current < 0f) return false;
            float share = current / maximum;
            return previous ? share < TiredExit : share <= TiredEnter;
        }

        // 2.8.1: a sip brings the bottle up to the lips upright (Contact) and tips it only there (Tilt), back upright before
        // it leaves; a bite keeps the food at the mouth most of the time, chewing there, with a short rest between bites.
        // 2.7.0 tipped the bottle on its way up (halfway it lay level beside the cheek) and held the food at the mouth
        // 0.22 s of each 2.4 s (the rest of the time it hung before the chest and the cheek).
        internal static Consumption Sample(float age, bool drink)
        {
            if (!Finite(age) || age < 0f) return new Consumption();
            float phase = age % (drink ? DrinkPeriod : EatPeriod);
            float contact = drink ? Window(phase, .5f, 1.6f, .45f) : Window(phase, .4f, 1.15f, .4f);
            float tilt = drink ? Window(phase - .45f, .35f, 1f, .3f) : contact;
            float chew = drink ? 0f : Window(phase - .55f, .15f, .8f, .2f);
            float beat = (float)Math.Sin(phase * (drink ? 12f : 17f));
            return new Consumption {
                Contact = contact,
                Chew = chew,
                Tilt = drink ? tilt * (1f + .025f * beat) : tilt,
                Head = drink ? -10f * tilt : 3f * contact + .7f * chew * beat
            };
        }

        private static float Window(float age, float rise, float hold, float fall)
        {
            if (age < 0f) return 0f;
            if (age < rise) return Smooth(age / rise);
            age -= rise;
            if (age < hold) return 1f;
            age -= hold;
            return age < fall ? 1f - Smooth(age / fall) : 0f;
        }
        private static float Smooth(float x) { return x * x * (3f - 2f * x); }
        private static bool Finite(float value) { return !float.IsNaN(value) && !float.IsInfinity(value); }
    }
}
