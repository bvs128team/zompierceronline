using System;
using System.IO;

namespace ZompiercerLAN
{
    // Where a guest's saves may go (LanSaveIsolation.Activate). Pure path rules, checked without the game.
    // 2.8.4: a guest's later session in the same run of the game (the host loaded another world, or the guest came back)
    // gets a fresh folder of its own, as the first one did. The game's saves never point back at the player's own folder
    // until a restart, and never at the previous session's folder again.
    internal static class LanIsolationRules
    {
        // The reason the saves may not move to target now, or null. All paths full and without a trailing separator;
        // current: the session folder in use (null before the first session); original: the player's own saves.
        internal static string Refusal(string target, string current, string original, string root, bool worldLoaded, bool loading)
        {
            if (string.IsNullOrEmpty(target) || string.IsNullOrEmpty(original) || string.IsNullOrEmpty(root)) return "Empty save path.";
            if (loading) return "Cannot isolate saves while native loading is active.";
            if (current != null && worldLoaded) return "Client isolation cannot change while a world is loaded.";
            if (!Same(Path.GetDirectoryName(target), root)) return "Client directory must be a fresh direct child of LAN-sessions.";
            if (Within(target, original) || Within(original, target)) return "Client and original save directories overlap.";
            if (current != null && (Within(target, current) || Within(current, target))) return "A later client session needs a new directory.";
            return null;
        }
        internal static bool Same(string a, string b) { return string.Equals(a, b, StringComparison.OrdinalIgnoreCase); }
        internal static bool Within(string path, string root)
        { return Same(path, root) || path.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase); }
    }
}
