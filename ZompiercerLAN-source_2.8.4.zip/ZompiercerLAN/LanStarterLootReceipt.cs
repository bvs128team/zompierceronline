using System;
using System.Collections.Generic;

namespace ZompiercerLAN
{
    // Stored in the SAME native snapshot as loose items. A sidecar written after
    // the native save cannot atomically remember whether those items existed.
    internal sealed class LanStarterLootReceipt
    {
        // 2.8.2: the game's own fields come first, however many: 21 in 21.4, 22 in 22.0 (its animal spawners in [21],
        // where 2.0-2.8.1 kept this receipt). The receipt follows them and is taken out before the game reads the
        // snapshot, so the game never reads it as a field of its own.
        internal const int NativeMinimum = 21;
        internal const string Magic = "ZompiercerLAN.StarterLoot";
        // 2.8.3: the first location, the scene of level2 where the kit's anchors are (2.5.6-2.8.2 named Terrain1, the
        // second location, so the kit never came).
        internal const string Scene = "ZCSBaseTerrain";
        internal const int Backpack = 7, Bat = 27, Knife = 56;
        private int _state = 2; // 0 eligible, 1 granted, 2 unknown/blocked
        internal bool Granted { get { return _state == 1; } }
        internal void NewWorld() { _state = 0; }
        internal void Block() { _state = 2; }
        internal bool Eligible(bool host, bool isolated, int admittedGuests, string scene, bool loading)
        { return _state == 0 && host && !isolated && admittedGuests >= 1 && admittedGuests <= 7 && scene == Scene && !loading; }
        internal bool Commit()
        { if (_state != 0) return false; _state = 1; return true; }
        // The snapshot for the game: the same, without any receipt after the game's first fields.
        internal object[] Load(object[] data)
        {
            _state = 2;
            if (data == null || data.Length < NativeMinimum) return data;
            var native = new List<object>(data.Length);
            object[] receipt = null; int receipts = 0;
            for (int i = 0; i < data.Length; i++)
                if (i >= NativeMinimum && IsReceipt(data[i])) { receipt = (object[])data[i]; receipts++; }
                else native.Add(data[i]);
            // Legacy native saves predate this feature and contain no extra kit.
            if (receipts == 0) { _state = 0; return data; }
            if (receipts == 1 && receipt.Length == 3 && receipt[1] is int && (int)receipt[1] == 1 && receipt[2] is int)
            {
                int state = (int)receipt[2];
                if (state >= 0 && state <= 2) _state = state;
            }
            return native.ToArray();
        }
        internal object[] Save(object[] data)
        {
            if (data == null || data.Length < NativeMinimum)
                throw new InvalidOperationException("Unexpected native starter-loot snapshot shape");
            for (int i = NativeMinimum; i < data.Length; i++)
                if (IsReceipt(data[i])) throw new InvalidOperationException("Native snapshot already holds a starter-loot receipt");
            var copy = new object[data.Length + 1];
            Array.Copy(data, copy, data.Length);
            copy[data.Length] = new object[] { Magic, 1, _state };
            return copy;
        }
        // Ours by its first value; no field of the game starts with this text.
        private static bool IsReceipt(object value)
        {
            var receipt = value as object[];
            return receipt != null && receipt.Length > 0 && Magic.Equals(receipt[0]);
        }
    }
}
