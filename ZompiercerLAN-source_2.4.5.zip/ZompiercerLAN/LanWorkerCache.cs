using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Security;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using Microsoft.Win32.SafeHandles;

namespace ZompiercerLAN
{
    // The installation is read-only. Only this user's pinned copy receives the
    // exact AppContainer read grant in LanSandboxProcess.Start.
    internal sealed class LanWorkerCache : IDisposable
    {
        private static readonly string[] Names = { "ZompiercerLAN.Network.exe", "BouncyCastle.Cryptography.dll", "ZompiercerLAN.Network.exe.config" };
        private const long MaxAssetBytes = 32 * 1024 * 1024;
        private readonly List<IDisposable> locks = new List<IDisposable>();
        internal string DirectoryPath { get; private set; }

        internal static LanWorkerCache Prepare(string source, string executable, string crypto, string configuration)
        {
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            if (String.IsNullOrWhiteSpace(local)) throw new SecurityException("Local application data directory unavailable.");
            return PrepareAt(source, local, executable, crypto, configuration);
        }

        // Explicit root also permits offline tests confined to a disposable workspace.
        internal static LanWorkerCache PrepareAt(string source, string local, string executable, string crypto, string configuration)
        {
            var result = new LanWorkerCache();
            string[] hashes = { executable, crypto, configuration };
            string digest = ContentKey(executable, crypto, configuration);
            try
            {
                source = result.PinChain(source);
                local = result.PinChain(local);
                string root = Path.Combine(local, "ZompiercerLAN");
                result.PrivateDirectory(root);
                string network = Path.Combine(root, "Network");
                result.PrivateDirectory(network);
                string destination = Path.Combine(network, digest);
                // Source is validated even when a cache already exists: a broken
                // installation must never silently use an older cached helper.
                var inputs = result.OpenVerified(source, hashes);
                if (!System.IO.Directory.Exists(destination))
                {
                    string staging = Path.Combine(network, ".stage-" + Guid.NewGuid().ToString("N"));
                    System.IO.Directory.CreateDirectory(staging);
                    using (var stagingLock = PinDirectory(staging))
                    {
                        for (int i = 0; i < Names.Length; i++)
                        {
                            inputs[i].Position = 0;
                            using (var output = new FileStream(Path.Combine(staging, Names[i]), FileMode.CreateNew, FileAccess.Write, FileShare.None))
                            { inputs[i].CopyTo(output); output.Flush(true); }
                        }
                    }
                    // Rename publishes all three complete assets together. A racing
                    // publisher wins harmlessly; never overwrite a running cache.
                    try { System.IO.Directory.Move(staging, destination); }
                    catch (IOException) { if (!System.IO.Directory.Exists(destination)) throw; }
                    if (System.IO.Directory.Exists(staging))
                    {
                        using (var stagingLock = PinDirectory(staging))
                            foreach (string name in Names) File.Delete(Path.Combine(staging, name));
                        System.IO.Directory.Delete(staging, false);
                    }
                }
                result.locks.Add(PinDirectory(destination));
                result.OpenVerified(destination, hashes);
                RequirePrivateAssets(destination);
                result.DirectoryPath = destination;
                return result;
            }
            catch { result.Dispose(); throw; }
        }

        internal static string ContentKey(string executable, string crypto, string configuration)
        {
            string value = "";
            foreach (string hash in new[] { executable, crypto, configuration })
            {
                if (hash == null || hash.Length != 64) throw new SecurityException("Invalid helper pin.");
                foreach (char c in hash) if (!Uri.IsHexDigit(c)) throw new SecurityException("Invalid helper pin.");
                value += hash.ToUpperInvariant();
            }
            using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(Encoding.ASCII.GetBytes(value))).Replace("-", "");
        }

        private FileStream[] OpenVerified(string directory, string[] hashes)
        {
            if (System.IO.Directory.GetFileSystemEntries(directory).Length != Names.Length)
                throw new SecurityException("Helper directory must contain exactly the three pinned runtime assets.");
            var files = new FileStream[Names.Length];
            for (int i = 0; i < Names.Length; i++)
            {
                string path = Path.Combine(directory, Names[i]);
                if ((File.GetAttributes(path) & (FileAttributes.ReparsePoint | FileAttributes.Directory)) != 0)
                    throw new SecurityException("Linked helper asset.");
                var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
                locks.Add(file); files[i] = file;
                if (file.Length == 0 || file.Length > MaxAssetBytes) throw new SecurityException("Invalid helper asset size.");
                using (var sha = SHA256.Create())
                    if (!String.Equals(BitConverter.ToString(sha.ComputeHash(file)).Replace("-", ""), hashes[i], StringComparison.OrdinalIgnoreCase))
                        throw new SecurityException("Helper integrity mismatch: " + Names[i]);
            }
            return files;
        }

        private string PinChain(string path)
        {
            string full = Path.GetFullPath(path).TrimEnd(Path.DirectorySeparatorChar);
            if (full.Length < 4 || full.StartsWith("\\\\", StringComparison.Ordinal) || full.IndexOf('"') >= 0 ||
                new DriveInfo(Path.GetPathRoot(full)).DriveType != DriveType.Fixed)
                throw new SecurityException("Helper cache requires a fixed local drive.");
            var parents = new Stack<string>();
            for (var info = new DirectoryInfo(full); info != null; info = info.Parent) parents.Push(info.FullName);
            while (parents.Count != 0) locks.Add(PinDirectory(parents.Pop()));
            return full;
        }

        private void PrivateDirectory(string path)
        {
            var user = WindowsIdentity.GetCurrent().User;
            var acl = new DirectorySecurity();
            acl.SetOwner(user);
            acl.SetAccessRuleProtection(true, false);
            var inheritance = InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit;
            acl.AddAccessRule(new FileSystemAccessRule(user, FileSystemRights.FullControl, inheritance, PropagationFlags.None, AccessControlType.Allow));
            acl.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null), FileSystemRights.FullControl, inheritance, PropagationFlags.None, AccessControlType.Allow));
            System.IO.Directory.CreateDirectory(path, acl);
            locks.Add(PinDirectory(path));
            var existing = System.IO.Directory.GetAccessControl(path);
            if (!user.Equals(existing.GetOwner(typeof(SecurityIdentifier)))) throw new SecurityException("Helper cache belongs to another user.");
            System.IO.Directory.SetAccessControl(path, acl);
        }

        private static SafeFileHandle PinDirectory(string path)
        {
            // OPEN_REPARSE_POINT prevents following a link raced into this name.
            var handle = CreateFile(path, 0x80, 3, IntPtr.Zero, 3, 0x02000000 | 0x00200000, IntPtr.Zero);
            if (handle.IsInvalid) { int error = Marshal.GetLastWin32Error(); handle.Dispose(); throw new Win32Exception(error, "Lock helper cache directory"); }
            BY_HANDLE_FILE_INFORMATION info;
            if (!GetFileInformationByHandle(handle, out info) || (info.Attributes & 0x400) != 0 || (info.Attributes & 0x10) == 0)
            { handle.Dispose(); throw new SecurityException("Linked or invalid helper cache directory."); }
            return handle;
        }

        private static void RequirePrivateAssets(string directory)
        {
            // Private ancestors do not cancel explicit grants on pre-existing
            // descendants. Reject such caches instead of changing a live worker's
            // ACL. Only the exact worker identity may additionally read its assets.
            string profile;
            using (var sha = SHA256.Create()) profile = "ZompiercerLAN." + BitConverter.ToString(sha.ComputeHash(Encoding.UTF8.GetBytes(directory.ToUpperInvariant()))).Replace("-", "").Substring(0, 40);
            IntPtr sid;
            int hr = DeriveAppContainerSidFromAppContainerName(profile, out sid);
            if (hr < 0) Marshal.ThrowExceptionForHR(hr);
            SecurityIdentifier worker;
            try { worker = new SecurityIdentifier(sid); } finally { FreeSid(sid); }
            var user = WindowsIdentity.GetCurrent().User;
            var system = new SecurityIdentifier(WellKnownSidType.LocalSystemSid, null);
            var paths = new List<string> { directory };
            foreach (string name in Names) paths.Add(Path.Combine(directory, name));
            foreach (string path in paths)
            {
                FileSystemSecurity acl = path == directory ? (FileSystemSecurity)System.IO.Directory.GetAccessControl(path) : File.GetAccessControl(path);
                if (!user.Equals(acl.GetOwner(typeof(SecurityIdentifier)))) throw new SecurityException("Helper cache asset belongs to another user.");
                foreach (FileSystemAccessRule rule in acl.GetAccessRules(true, true, typeof(SecurityIdentifier)))
                {
                    if (rule.AccessControlType != AccessControlType.Allow) continue;
                    if (user.Equals(rule.IdentityReference) || system.Equals(rule.IdentityReference)) continue;
                    if (worker.Equals(rule.IdentityReference) && (rule.FileSystemRights & ~(FileSystemRights.ReadAndExecute | FileSystemRights.Synchronize)) == 0) continue;
                    throw new SecurityException("Helper cache asset has an unsafe access grant.");
                }
            }
        }

        public void Dispose() { for (int i = locks.Count - 1; i >= 0; i--) locks[i].Dispose(); locks.Clear(); }
        [StructLayout(LayoutKind.Sequential)] private struct BY_HANDLE_FILE_INFORMATION
        { public uint Attributes; public System.Runtime.InteropServices.ComTypes.FILETIME Creation, Access, Write; public uint Volume, SizeHigh, SizeLow, Links, IndexHigh, IndexLow; }
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] private static extern SafeFileHandle CreateFile(string path, uint access, uint sharing, IntPtr security, uint disposition, uint flags, IntPtr template);
        [DllImport("kernel32.dll", SetLastError = true)] private static extern bool GetFileInformationByHandle(SafeFileHandle file, out BY_HANDLE_FILE_INFORMATION information);
        [DllImport("userenv.dll", CharSet = CharSet.Unicode)] private static extern int DeriveAppContainerSidFromAppContainerName(string name, out IntPtr sid);
        [DllImport("advapi32.dll")] private static extern IntPtr FreeSid(IntPtr sid);
    }
}
