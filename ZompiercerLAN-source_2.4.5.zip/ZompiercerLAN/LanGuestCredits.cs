using System;
using System.Collections.Generic;
using HarmonyLib;

namespace ZompiercerLAN
{
    // Host (1.3.0): what the host's world gives the guest, credited to the guest's checked stats
    // (LanGuestStats): the experience of every zombie dying here while the guest plays here (the game
    // gives each player that experience on its own copy), quest experience the guest hands in,
    // getting up after being downed, respawning, sleeping together. Main thread only.
    // 2.0.0: each guest by its slot; a zombie's experience goes to every guest playing in this world.
    internal static class LanGuestCredits
    {
        private static Harmony _harmony;
        internal static string Failure { get; private set; }
        // Set by the plugin every frame: a guest's checked stats by slot (null: none), and the slots of
        // the guests playing in this world now (zombie experience counts only for them).
        internal static Func<int, LanGuestStats> Stats;
        internal static Func<IList<int>> GuestsHere;

        internal static void Initialize(Action<string> log)
        {
            if (_harmony != null || Failure != null) return;
            _harmony = new Harmony("local.zompiercer.lan.guest-credits");
            try
            {
                _harmony.Patch(AccessTools.Method(typeof(ZombieDamagDetector), "Dead"), prefix: new HarmonyMethod(typeof(LanGuestCredits), nameof(DeadPrefix)), postfix: new HarmonyMethod(typeof(LanGuestCredits), nameof(DeadPostfix)));
            }
            catch (Exception ex)
            {
                Failure = ex.GetType().Name + ": " + ex.Message;
                _harmony.UnpatchSelf();
                log("Guest experience hook unavailable: " + Failure);
            }
        }
        internal static void Shutdown() { _harmony?.UnpatchSelf(); _harmony = null; Stats = null; GuestsHere = null; }

        private static LanGuestStats Of(int slot) { var stats = Stats; return stats == null ? null : stats(slot); }

        private static void DeadPrefix(ZombieDamagDetector __instance, out bool __state)
        { __state = __instance != null && __instance.zombieAIController != null && __instance.zombieAIController.dead; }
        private static void DeadPostfix(ZombieDamagDetector __instance, bool __state)
        {
            if (__state || __instance == null || __instance.zombieAIController == null || !__instance.zombieAIController.dead) return;
            var here = GuestsHere == null ? null : GuestsHere();
            if (here != null) foreach (int slot in here) Of(slot)?.CreditXp(__instance.XPReward);
        }

        internal static void Xp(int slot, float experience) { Of(slot)?.CreditXp(experience); }
        internal static void Revive(int slot) { Of(slot)?.CreditRevive(); }
        internal static void Health(int slot, float amount) { Of(slot)?.CreditHealth(amount); }
        internal static void Respawn(int slot) { Of(slot)?.CreditRespawn(); }
        internal static void Sleep(int slot, int hours) { Of(slot)?.CreditSleep(hours); }
    }
}
