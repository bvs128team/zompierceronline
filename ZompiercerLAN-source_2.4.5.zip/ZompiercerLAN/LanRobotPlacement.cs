using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
using Zompiercer.Train;
using Zompiercer.Inventory;

namespace ZompiercerLAN
{
    internal sealed partial class LanTakables
    {
        private static bool _placing;
        private static int _carryGeneration;

        private static void InstallRobotPlacement()
        {
            _harmony.Patch(AccessTools.Method(typeof(ZombieFighterRays), "ReloadActionOnStarted"),
                prefix: new HarmonyMethod(typeof(LanTakables), nameof(RobotReloadPrefix)));
            _harmony.Patch(AccessTools.Method(typeof(ZombieFighterRays), "Update"),
                postfix: new HarmonyMethod(typeof(LanTakables), nameof(RobotPlacementHint)));
            _harmony.Patch(AccessTools.Method(typeof(GlobalSceneManager), "LoadLevel"),
                prefix: new HarmonyMethod(typeof(LanTakables), nameof(RobotTravelPrefix)));
        }

        // Native selection intentionally skips synchronized construction. Use its physical
        // surface only for robot placement, without exposing native furniture interactions.
        private static bool RobotAim(out RaycastHit best)
        {
            best = default(RaycastHit);
            var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
            var camera = GlobalManager.global == null ? null : GlobalManager.global.MainCamera;
            if (player == null || camera == null || !player.controlEnabled) return false;
            var input = Zompiercer.Inputs.InputController.Global;
            if (input == null || (int)input.CurrentState != 1) return false;
            bool found = false;
            foreach (var hit in Physics.RaycastAll(new Ray(camera.transform.position, camera.transform.forward), Reach, ~0, QueryTriggerInteraction.Ignore))
            {
                if (hit.collider == null || hit.collider.transform.IsChildOf(player.transform) ||
                    _proxy != null && hit.collider.transform.IsChildOf(_proxy.transform)) continue;
                if (!found || hit.distance < best.distance) { best = hit; found = true; }
            }
            return found && PlacementSurface(best);
        }

        private static bool PlacementSurface(RaycastHit hit)
        {
            return hit.collider != null && Vector3.Dot(Vector3.up, hit.normal) > .9f &&
                hit.collider.GetComponentInParent<TakableItem>() == null &&
                hit.collider.GetComponentInParent<ZombieFighterController>() == null &&
                hit.collider.GetComponentInParent<Stair>() == null &&
                hit.collider.GetComponentInParent<DoorController>() == null;
        }

        private static void RobotPlacementHint(ZombieFighterRays __instance)
        {
            if (!_proxyDog || _proxy == null || __instance.takableItemTaked != _proxy || _placing) return;
            RaycastHit hit;
            if (RobotAim(out hit) && InventoryController.global != null && InventoryController.global.simpleInfoDisplayer != null)
                InventoryController.global.simpleInfoDisplayer.SetIconText("Drop", (Zompiercer.Inputs.Actions)62, (Zompiercer.Inputs.Actions)0, true);
        }

        private static bool RobotReloadPrefix(ZombieFighterRays __instance)
        {
            if (!_proxyDog || _proxy == null || __instance.takableItemTaked != _proxy) return true;
            RaycastHit hit;
            if (_placing || _client == null || !RobotAim(out hit)) return false;
            var car = hit.collider.GetComponentInParent<TrainCar>();
            int host = _proxyHost, generation = _carryGeneration;
            _placing = true;
            if (!SendRelease(host, LanStorage.ReleasePlace, hit.point, _proxy.transform.rotation, Vector3.zero, car,
                status =>
                {
                    if (generation != _carryGeneration || host != _proxyHost) return;
                    _placing = false;
                    if (status != LanStorage.Ok) return; // rejected: keep hands and authoritative ownership
                    if (__instance != null && __instance.takableItemTaked == _proxy) __instance.takableItemTaked = null;
                    DestroyProxy();
                })) _placing = false;
            return false;
        }

        // The proposed coordinates never confer authority over a car or arbitrary world point.
        // Host physics confirms the same nearby, upward-facing surface, including upper decks.
        private static bool CheckedDogPlacement(TakableItem dog, Vector3 proposed, Transform requestedCar, out Vector3 point, out Transform car)
        {
            point = proposed; car = null;
            RaycastHit best = default(RaycastHit); bool found = false;
            foreach (var hit in Physics.RaycastAll(proposed + Vector3.up * .3f, Vector3.down, .65f, ~0, QueryTriggerInteraction.Ignore))
            {
                if (hit.collider == null || hit.collider.transform.IsChildOf(dog.transform)) continue;
                if (!found || hit.distance < best.distance) { best = hit; found = true; }
            }
            if (!found || !PlacementSurface(best)) return false;
            var supported = best.collider.GetComponentInParent<TrainCar>();
            car = supported == null ? null : supported.transform;
            if (car != requestedCar) return false;
            point = best.point;
            return true;
        }

        // A carried dog is one existing host object, never a snapshot to instantiate twice.
        // Park it under the persistent train before scene unload; native train save then also
        // records its owner/devices via the existing Save postfix and OnTrainCar field.
        private static bool RobotTravelPrefix()
        {
            if (LanSaveIsolation.Active)
            {
                // A guest's proxy is disposable and must not send an old-world drop request.
                CloseWindow(); LanRobotWindow.Close();
                var p = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
                if (p != null && p.zombieFighterRays != null && p.zombieFighterRays.takableItemTaked == _proxy)
                    p.zombieFighterRays.takableItemTaked = null;
                DestroyProxy(); _taking = 0;
                return true;
            }
            if (!Hosting) return true;
            var parking = new Dictionary<TakableItem, RaycastHit>();
            foreach (var guest in _guests.Values)
            {
                var item = guest.Carried;
                if (item == null || item.GetComponent<RobotDogAiController>() == null) continue;
                RaycastHit surface;
                TravelSurface(item, out surface);
                parking[item] = surface;
            }
            var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
            var rays = player == null ? null : player.zombieFighterRays;
            var held = rays == null ? null : rays.takableItemTaked;
            if (held != null && held.GetComponent<RobotDogAiController>() != null)
            {
                RaycastHit surface;
                TravelSurface(held, out surface);
                parking[held] = surface;
            }
            // Resolve every destination before detaching hands. Never cancel LoadLevel here:
            // its caller may already have committed its scene-transition flags.
            foreach (var entry in parking)
                ParkForTravel(entry.Key, entry.Value);
            foreach (var guest in _guests.Values)
                if (guest.Carried != null && parking.ContainsKey(guest.Carried)) Detach(guest);
            if (held != null && parking.ContainsKey(held)) rays.takableItemTaked = null;
            return true;
        }

        private static bool TravelSurface(TakableItem item, out RaycastHit best)
        {
            // Prefer the deck immediately beneath the carrier. A guest's position is already
            // checked by the host; only a real host train collider can select the destination.
            best = default(RaycastHit); bool found = false;
            foreach (var hit in Physics.RaycastAll(item.transform.position + Vector3.up * .2f, Vector3.down, 3f, ~0, QueryTriggerInteraction.Ignore))
            {
                if (!PlacementSurface(hit) || hit.collider.transform.IsChildOf(item.transform) ||
                    hit.collider.GetComponentInParent<TrainCar>() == null) continue;
                if (!found || hit.distance < best.distance) { best = hit; found = true; }
            }
            if (found) return true;
            // A carrier can stand beside the train when the host leaves the location.
            // Choose a real deck on the persistent train rather than losing that dog with
            // the outgoing scene. Raycast against each collider so nearby terrain does not
            // hide a perfectly usable train deck.
            var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrain;
            if (train == null) return false;
            float distance = float.PositiveInfinity;
            foreach (var collider in train.GetComponentsInChildren<Collider>())
            {
                if (!collider.enabled || collider.isTrigger || collider.GetComponentInParent<TrainCar>() == null ||
                    collider.transform.IsChildOf(item.transform)) continue;
                var bounds = collider.bounds;
                RaycastHit hit;
                if (!collider.Raycast(new Ray(new Vector3(bounds.center.x, bounds.max.y + .1f, bounds.center.z), Vector3.down),
                    out hit, bounds.size.y + .2f) || !PlacementSurface(hit)) continue;
                float candidate = (hit.point - item.transform.position).sqrMagnitude;
                if (candidate < distance) { best = hit; distance = candidate; found = true; }
            }
            return found;
        }

        private static void ParkForTravel(TakableItem item, RaycastHit best)
        {
            var car = best.collider == null ? TrainSync.GetCar(0) : best.collider.GetComponentInParent<TrainCar>();
            if (car == null)
            {
                // No train is an abnormal teardown state. Preserve the existing object
                // across unload; do not manufacture a saved replacement or cancel travel.
                item.transform.SetParent(null, true);
                UnityEngine.Object.DontDestroyOnLoad(item.gameObject);
                _log?.Invoke("Carried robot preserved across travel without an available train");
                item.SetTaked(false);
                return;
            }
            var point = best.collider == null ? car.transform.position + Vector3.up : best.point;
            if (best.collider == null) _log?.Invoke("Carried robot preserved on train; deck geometry unavailable during travel");
            PlaceDog(item.GetComponent<RobotDogAiController>(), item, point, item.transform.rotation, car.transform);
            item.SetTaked(false);
        }
    }
}

