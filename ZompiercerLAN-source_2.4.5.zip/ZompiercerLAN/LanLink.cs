using System.Collections.Generic;
using System.Net;

namespace ZompiercerLAN
{
    // 2.0.0: one secure session with one other game and what it carries. A guest has one link (to
    // its host); a host has one per guest (slots 1..LanSeats.MaxGuests), each with its own worker,
    // invitation, approval and keys, and its own copies of the host's senders (train, doors, scene
    // objects, quests, world items), the guest's profile keeper and storage requests. The host's
    // world is one: every link's senders read it, and each guest's requests change it.
    internal sealed class LanLink
    {
        // Host: the guest's slot (1..3). Guest: 0 (the link is to the host).
        internal readonly int Slot;
        // The worker of this link (it pairs first, then carries the session); Pairing while it pairs.
        internal LanIsolatedSession Isolated, Pairing, Network;
        internal IPEndPoint Peer;
        internal ulong Session;
        internal bool Connected;
        // When its invitation opened, its session was last heard from, its guest first came (-1: not yet).
        internal float OpenedAt, LastReceive, ConnectedAt = -1f;
        // Host: when the guest went silent (to free its seat after a while), whether it said it leaves.
        internal float LostAt = -1f;
        internal LanPeerWorkLimits Limits = new LanPeerWorkLimits();
        // The other player of this link: the guest (host side), or the host (guest side).
        internal readonly RemotePlayer Player;
        internal TrainSync Train;
        internal LanWorldDoors Doors;
        internal LanSceneStates SceneStates;
        // Host (2.4.4): the garden beds of its train for this guest.
        internal LanFarm Farm;
        internal LanQuests Quests;
        internal LanWorldItems WorldItems;
        internal LanChatChannel Chat;
        internal LanSleepChannel Sleep;
        internal LanGuestHost GuestHost;
        internal LanGuestClient GuestClient;
        internal LanStorageHost StorageHost;
        internal LanStorageClient StorageClient;
        internal HostCombatInventory CombatInventory = new HostCombatInventory();
        // Host: when the next WorldState goes, the Players sequence, whether its panel was folded, when
        // its guest died (-1: alive), and its sequences of marks, revives and sleeps it is sent.
        internal float NextWorldSend;
        internal uint PlayersSequence, MarkSequence, ReviveSequence, ExplosionSequence;
        internal bool PanelClosed;
        internal float GuestDeadAt = -1f;
        // The last mark received over this link (marks are numbered per link by their sender).
        internal uint MarkReceived;
        // Host: its guest's newest accepted state (the host's place for it, its slot set), and the
        // sequence of each other guest's state last sent to it in Players (by slot).
        internal Packet LastState;
        internal readonly Dictionary<int, uint> SentStates = new Dictionary<int, uint>();

        internal LanLink(int slot) { Slot = slot; Player = new RemotePlayer(slot); }

        // Ready to carry application packets.
        internal bool Up { get { return Network != null && Connected && Peer != null; } }
    }
}
