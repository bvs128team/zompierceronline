using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
using Zompiercer.Farm;
using Zompiercer.Inventory;
using Object = UnityEngine.Object;

namespace ZompiercerLAN
{
    // 2.4.4: the garden beds (FarmTray) of the host's train for the guests. A guest's copy of a bed has no script
    // (TrainLayout strips them), so 1.4.2-2.4.3 showed it bare and the game's own keys did nothing on it. Now the host
    // sends how each bed stands (FarmStates: watered, fertilized, what grows at each point and how far), the guest
    // shows it on its copy (the soil's material, a script-free copy of each plant at its growth stage, the planting
    // icons) with the game's own tips, and its keys become work requests: dirty water and fertilizer poured in, a seed
    // planted, a crop harvested. The host runs the game's own methods on its bed (FarmTray.AddWater, AddFertilizer,
    // FarmTrayPlantPoint.Plant, Remove); what the guest pours or plants leaves its ledger, empty bottles and the crop
    // come back to it.
    internal sealed class LanFarm
    {
        internal const int Fertilizer = 297;
        private const int SeedType = 18;
        private static Harmony _harmony;
        private static Action<string> _log;
        internal static string Failure { get; private set; }

        private static readonly AccessTools.FieldRef<FarmTray, bool> _hasWater = AccessTools.FieldRefAccess<FarmTray, bool>("_hasWater");
        private static readonly AccessTools.FieldRef<FarmTray, bool> _hasFertilize = AccessTools.FieldRefAccess<FarmTray, bool>("_hasFertilize");
        private static readonly AccessTools.FieldRef<FarmTray, int> _fertilizeLeft = AccessTools.FieldRefAccess<FarmTray, int>("_amountForFertilizeRemained");
        private static readonly AccessTools.FieldRef<FarmTray, int> _waterPerBed = AccessTools.FieldRefAccess<FarmTray, int>("waterBottleForWet");
        private static readonly AccessTools.FieldRef<FarmTray, MeshRenderer[]> _soil = AccessTools.FieldRefAccess<FarmTray, MeshRenderer[]>("soilMeshes");
        private static readonly AccessTools.FieldRef<FarmTray, Material> _dry = AccessTools.FieldRefAccess<FarmTray, Material>("dryMaterial");
        private static readonly AccessTools.FieldRef<FarmTray, Material> _wet = AccessTools.FieldRefAccess<FarmTray, Material>("wetMaterial");
        private static readonly AccessTools.FieldRef<FarmTray, Material> _fertilized = AccessTools.FieldRefAccess<FarmTray, Material>("fertilizedMaterial");
        private static readonly AccessTools.FieldRef<FarmPlant, GameObject[]> _stages = AccessTools.FieldRefAccess<FarmPlant, GameObject[]>("stagesGrowth");
        private static readonly AccessTools.FieldRef<FarmPlant, float> _growMax = AccessTools.FieldRefAccess<FarmPlant, float>("_currentGrowingTimeMax");

        internal static void Initialize(Action<string> log)
        {
            _log = log;
            if (_harmony != null) return;
            _harmony = new Harmony("local.zompiercer.lan.farm");
            try
            {
                // Before the game uses the item in hand (as the rainwater tank's keys, LanWorldWork).
                _harmony.Patch(AccessTools.Method(typeof(InventoryController), "Update"), prefix: new HarmonyMethod(typeof(LanFarm), nameof(GuestPrefix)));
            }
            catch (Exception ex)
            {
                _harmony.UnpatchSelf();
                Failure = ex.GetType().Name + ": " + ex.Message;
                log("Garden bed hooks unavailable: " + Failure);
            }
        }
        internal static void Shutdown() { _harmony?.UnpatchSelf(); _harmony = null; ClearGuest(); }

        // ---- Host: what its beds look like, for each guest ----
        private sealed class Snapshot { internal FarmFrame[] Frames = new FarmFrame[0]; internal int State, Full; internal float At = -100f; }
        private static Snapshot _snapshot = new Snapshot();
        private static bool _dirty;
        private static readonly Dictionary<string, int> PlantIndex = new Dictionary<string, int>(StringComparer.Ordinal);

        private readonly Action<Packet> _send;
        private uint _sequence;
        private int _sentState, _sentFull;
        private float _sentAt = -100f;
        internal LanFarm(Action<Packet> send) { _send = send; }

        // Host, each frame: the beds go when one changed (at once), when only growth changed (every 2 s), and every 5 s.
        internal void Tick(bool ready)
        {
            if (!ready) return;
            float now = Time.unscaledTime;
            var shot = Current(now);
            if (shot.Frames.Length == 0) return;
            bool state = shot.State != _sentState, full = shot.Full != _sentFull;
            if (!(state && now - _sentAt >= .25f || full && now - _sentAt >= 2f || now - _sentAt >= 5f)) return;
            _sentState = shot.State; _sentFull = shot.Full; _sentAt = now;
            for (int i = 0; i < shot.Frames.Length; i += LanProtocol.MaxFarmBatch)
            {
                var batch = new FarmFrame[Math.Min(LanProtocol.MaxFarmBatch, shot.Frames.Length - i)];
                Array.Copy(shot.Frames, i, batch, 0, batch.Length);
                _send(new Packet { Kind = PacketKind.FarmStates, Sequence = ++_sequence, Farms = batch });
            }
        }

        private static Snapshot Current(float now)
        {
            if (!_dirty && now - _snapshot.At < .5f) return _snapshot;
            _dirty = false;
            var shot = new Snapshot { At = now };
            var frames = new List<FarmFrame>();
            try
            {
                var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrain;
                var scenes = GlobalSceneManager.global;
                var cars = train == null || scenes == null || scenes.SceneCurrentlyLoading ? null : TrainLayout.Cars(train);
                if (cars != null)
                    for (int car = 0; car < cars.Length && car < LanProtocol.MaxCars; car++)
                    {
                        if (cars[car] == null || cars[car].AllFurniture == null) continue;
                        foreach (var furniture in cars[car].AllFurniture)
                        {
                            var tray = furniture == null || furniture.notAssembled ? null : furniture.GetComponent<FarmTray>();
                            var frame = tray == null ? null : Frame(car, furniture, tray);
                            if (frame != null) frames.Add(frame);
                        }
                    }
            }
            catch (Exception ex) { _log?.Invoke("Garden beds not read: " + ex.GetType().Name + ": " + ex.Message); }
            shot.Frames = frames.ToArray();
            unchecked
            {
                int state = 17, full = 17;
                foreach (var f in shot.Frames)
                {
                    state = state * 31 + f.Car; state = state * 31 + f.Identity; state = state * 31 + f.Flags; state = state * 31 + f.Water; state = state * 31 + f.Fertilize;
                    full = full * 31 + state;
                    foreach (var pt in f.Points)
                    {
                        state = state * 31 + pt.Plant; state = state * 31 + pt.Stage; state = state * 31 + pt.Flags;
                        full = full * 31 + pt.Growth; full = full * 31 + pt.Efficiency;
                    }
                }
                shot.State = state; shot.Full = full * 31 + state;
            }
            _snapshot = shot;
            return shot;
        }

        private static FarmFrame Frame(int car, Furniture furniture, FarmTray tray)
        {
            var points = tray.FramTrayPlantPoints;
            if (points == null || points.Length == 0 || points.Length > LanProtocol.MaxFarmPoints) return null;
            var frame = new FarmFrame
            {
                Car = (byte)car, Identity = furniture.GetInstanceID(),
                Flags = (byte)((_hasWater(tray) ? 1 : 0) | (_hasFertilize(tray) ? 2 : 0)),
                Water = (byte)Mathf.Clamp(tray.WaterBottleForWetRemained, 0, 255),
                Fertilize = (byte)Mathf.Clamp(_fertilizeLeft(tray), 0, 255),
                Points = new FarmPoint[points.Length]
            };
            for (int i = 0; i < points.Length; i++)
            {
                var plant = points[i] == null ? null : points[i].PlantedHere;
                int index = plant == null ? -1 : IndexOf(plant);
                if (index < 0 || index >= LanProtocol.MaxFarmPlants) { frame.Points[i] = new FarmPoint(); continue; }
                float max = plant.GrowingTimeMax, current = _growMax(plant);
                float efficiency = max > 0f ? (max - (current - max)) / max : 1f;
                frame.Points[i] = new FarmPoint
                {
                    Plant = (byte)(index + 1), Stage = (byte)Mathf.Clamp(plant.CurrentStageGrowth, 0, LanProtocol.MaxFarmStage),
                    Flags = (byte)(plant.IsGrown ? 1 : 0), Growth = (ushort)Mathf.RoundToInt(Mathf.Clamp01(plant.GrowingFactor) * 1000f),
                    Efficiency = (byte)Mathf.Clamp(Mathf.RoundToInt(efficiency * 100f), 0, 250)
                };
            }
            return frame;
        }

        // The plant's place in the game's list of plants (the save names a plant by its crop, ItemsDataBase.GetFarmPlantByName).
        private static int IndexOf(FarmPlant plant)
        {
            string name = plant.HarvestItemName ?? "";
            int index;
            if (PlantIndex.TryGetValue(name, out index)) return index;
            var list = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.FarmPlants;
            index = -1;
            if (list != null) for (int i = 0; i < list.Count; i++) if (list[i] != null && list[i].HarvestItemName == name) { index = i; break; }
            if (index >= 0) PlantIndex[name] = index;
            return index;
        }

        // Host: the guest's water, fertilizer, seed or harvest on the bed at `local` of car `carIndex` (escrow already off
        // its ledger; `given` goes onto it).
        internal static byte HostWork(int kind, Vector3 local, int carIndex, object[] escrow, Vector3? guest, out object[] given, out int detail)
        {
            given = null; detail = 0;
            var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrain;
            var scenes = GlobalSceneManager.global;
            if (train == null || scenes == null || scenes.SceneCurrentlyLoading) return LanStorage.Unavailable;
            Zompiercer.Train.TrainCar car;
            try { car = TrainLayout.GetCar(train, carIndex); }
            catch (Exception) { return LanStorage.NotFound; }
            var at = car.transform.TransformPoint(local);
            if (guest == null) return LanStorage.Lost;
            if (Vector3.Distance(at, guest.Value) > 5f) return LanStorage.TooFar;
            FarmTray tray = null; float best = 2.25f;
            if (car.AllFurniture != null)
                foreach (var furniture in car.AllFurniture)
                {
                    var candidate = furniture == null || furniture.notAssembled ? null : furniture.GetComponent<FarmTray>();
                    if (candidate == null) continue;
                    float d = (candidate.transform.position - at).sqrMagnitude;
                    foreach (var collider in candidate.GetComponentsInChildren<Collider>())
                        if (collider != null && collider.enabled && !collider.isTrigger) d = Math.Min(d, (collider.ClosestPoint(at) - at).sqrMagnitude);
                    if (candidate.FramTrayPlantPoints != null)
                        foreach (var point in candidate.FramTrayPlantPoints) if (point != null) d = Math.Min(d, (point.transform.position - at).sqrMagnitude);
                    if (d <= best) { best = d; tray = candidate; }
                }
            if (tray == null) return LanStorage.NotFound;
            int count = escrow == null ? 0 : (int)escrow[1];
            switch (kind)
            {
                case LanStorage.WorkFarmWater:
                {
                    // InteractingObjectsController.CheckTray: a bottle of dirty water at a time, the empty bottle back.
                    if ((int)escrow[0] != LanWorldWork.DirtyBottle || count < 1) return LanStorage.NotAllowed;
                    if (!tray.IsNeedWater || count > tray.WaterBottleForWetRemained) return LanStorage.Full;
                    var prefabs = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.itemPrefab;
                    if (prefabs == null || LanWorldWork.EmptyBottle >= prefabs.Length || prefabs[LanWorldWork.EmptyBottle] == null) return LanStorage.Invalid;
                    tray.AddWater(count);
                    given = new object[] { LanWorldWork.EmptyBottle, count, new object[4] };
                    break;
                }
                case LanStorage.WorkFarmFertilize:
                    if ((int)escrow[0] != Fertilizer || count < 1) return LanStorage.NotAllowed;
                    if (!tray.IsNeedFertilize || count > tray.GetNeedFertilized()) return LanStorage.Full;
                    tray.AddFertilizer(count);
                    break;
                case LanStorage.WorkFarmPlant:
                {
                    // InteractingObjectsController.CheckSeedsInHand: a seed in an empty point of a watered, fertilized bed.
                    var prefabs = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.itemPrefab;
                    int seedId = (int)escrow[0];
                    var seed = prefabs != null && seedId >= 0 && seedId < prefabs.Length ? prefabs[seedId] : null;
                    if (seed == null || (int)seed.itemType != SeedType || string.IsNullOrEmpty(seed.SeedForPlantName)) return LanStorage.NotAllowed;
                    var point = PointAt(tray, at, false);
                    if (point == null) return LanStorage.NotFound;
                    if (!tray.IsCanPlant) return LanStorage.NotAllowed;
                    var plant = seed.GetPlantByHarvestName();
                    if (plant == null) return LanStorage.NotAllowed;
                    point.Plant(plant);
                    break;
                }
                case LanStorage.WorkFarmHarvest:
                {
                    // InteractingObjectsController.Harvesting: the crop of a grown plant, which goes.
                    var point = PointAt(tray, at, true);
                    if (point == null) return LanStorage.NotFound;
                    var plant = point.PlantedHere;
                    if (!plant.IsGrown) return LanStorage.NotAllowed;
                    int crop = plant.HarvestItemID;
                    var prefabs = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.itemPrefab;
                    if (prefabs == null || crop <= 0 || crop >= prefabs.Length || prefabs[crop] == null || plant.HarvestAmount < 1) return LanStorage.Invalid;
                    given = new object[] { crop, Math.Min(plant.HarvestAmount, 9999), new object[4] };
                    point.Remove();
                    try { GlobalSoundEffects.global.DigGround(); } catch (Exception) { }
                    break;
                }
                default: return LanStorage.Invalid;
            }
            _dirty = true; // every guest sees it at once
            return LanStorage.Ok;
        }

        // The bed's point at `at` (within 35 cm), with or without a plant.
        private static FarmTrayPlantPoint PointAt(FarmTray tray, Vector3 at, bool planted)
        {
            FarmTrayPlantPoint found = null; float best = .35f * .35f;
            if (tray.FramTrayPlantPoints != null)
                foreach (var point in tray.FramTrayPlantPoints)
                {
                    if (point == null || (point.PlantedHere != null) != planted) continue;
                    float d = (point.transform.position - at).sqrMagnitude;
                    if (d <= best) { best = d; found = point; }
                }
            return found;
        }

        // ---- Guest: the host's beds on its copies ----
        // A bed's prefab, as its copy has it: its points, planting icons and soil (child index paths from the bed).
        private sealed class Layout { internal int[][] Points, Icons, Soil; internal Material Dry, Wet, Fertilized; internal int WaterPerBed; }
        private sealed class PlantCopy { internal GameObject Root; internal int Plant; internal GameObject[] Stages; internal Transform Models; internal float Min, Max; }
        private sealed class View
        {
            internal int Car, Identity;
            internal Component Shown;
            internal Layout Layout;
            internal Transform[] Points;
            internal GameObject[] Icons;
            internal Renderer[] Soil;
            internal PlantCopy[] Plants;
            internal FarmFrame Frame;
            internal uint Sequence;
            internal float At;
        }
        private static readonly Dictionary<long, View> Views = new Dictionary<long, View>();
        private static readonly Dictionary<int, Layout> Layouts = new Dictionary<int, Layout>();
        private static readonly Dictionary<int, string> PlantNames = new Dictionary<int, string>();
        private static float _checkAt, _nextAsk;
        private static long Key(int car, int identity) { return (long)car << 32 | (uint)identity; }

        // Guest: the host's beds (the packet passed LanProtocol's checks).
        internal static void Receive(Packet p)
        {
            if (p == null || p.Kind != PacketKind.FarmStates || p.Farms == null) return;
            float now = Time.unscaledTime;
            foreach (var frame in p.Farms)
            {
                View view;
                long key = Key(frame.Car, frame.Identity);
                if (Views.TryGetValue(key, out view) && view.Frame != null && unchecked((int)(p.Sequence - view.Sequence)) < 0 && now - view.At < 10f) continue;
                if (view == null) { view = new View { Car = frame.Car, Identity = frame.Identity }; Views[key] = view; }
                view.Frame = frame; view.Sequence = p.Sequence; view.At = now;
                try { Show(view); }
                catch (Exception ex) { _log?.Invoke("Garden bed not shown: " + ex.GetType().Name + ": " + ex.Message); }
            }
        }

        // Guest: the session ended; the copies of plants go with their beds' copies.
        internal static void ClearGuest()
        {
            foreach (var view in Views.Values) Drop(view);
            Views.Clear();
        }
        private static void Drop(View view)
        {
            if (view.Plants == null) return;
            foreach (var plant in view.Plants) if (plant != null && plant.Root != null) Object.Destroy(plant.Root);
            view.Plants = null;
        }

        // Its copy of the bed (found again after the host's train layout replaced it) shows the frame.
        private static void Show(View view)
        {
            int prefab;
            var shown = TrainLayout.ShownFurniture(view.Car, view.Identity, out prefab);
            if (shown == null) { view.Shown = null; return; }
            if (shown != view.Shown)
            {
                Drop(view);
                view.Shown = shown; view.Layout = LayoutOf(prefab);
                if (view.Layout == null) return;
                var root = shown.transform;
                view.Points = new Transform[view.Layout.Points.Length];
                view.Icons = new GameObject[view.Layout.Points.Length];
                for (int i = 0; i < view.Points.Length; i++)
                {
                    view.Points[i] = Follow(root, view.Layout.Points[i]);
                    var icon = Follow(root, view.Layout.Icons[i]);
                    if (icon == null) continue;
                    view.Icons[i] = icon.gameObject;
                    // The game's own billboard (plain data: it turns the icon to the camera); the copy lost it.
                    if (icon.GetComponent<Zompiercer.UI.BillboardIcon>() == null) icon.gameObject.AddComponent<Zompiercer.UI.BillboardIcon>();
                }
                view.Soil = new Renderer[view.Layout.Soil.Length];
                for (int i = 0; i < view.Soil.Length; i++) { var t = Follow(root, view.Layout.Soil[i]); view.Soil[i] = t == null ? null : t.GetComponent<Renderer>(); }
                view.Plants = new PlantCopy[view.Points.Length];
            }
            if (view.Layout == null || view.Frame == null) return;
            var f = view.Frame;
            bool water = (f.Flags & 1) != 0, fertile = (f.Flags & 2) != 0;
            // FarmTray.SetSoilMaterial.
            var material = !water ? view.Layout.Dry : !fertile ? view.Layout.Wet : view.Layout.Fertilized;
            if (material != null)
                foreach (var soil in view.Soil)
                {
                    if (soil == null) continue;
                    var materials = soil.sharedMaterials;
                    if (materials.Length > 0 && materials[0] != material) { materials[0] = material; soil.sharedMaterials = materials; }
                }
            for (int i = 0; i < view.Points.Length; i++)
            {
                var pt = i < f.Points.Length ? f.Points[i] : new FarmPoint();
                var copy = view.Plants[i];
                if (copy != null && (copy.Root == null || copy.Plant != pt.Plant)) { if (copy.Root != null) Object.Destroy(copy.Root); copy = view.Plants[i] = null; }
                if (pt.Plant != 0 && copy == null && view.Points[i] != null) copy = view.Plants[i] = CopyPlant(pt.Plant - 1, view.Points[i]);
                if (copy != null)
                {
                    // FarmPlant.ShowStage and UpdateScale.
                    int stage = Mathf.Clamp(pt.Stage, 0, Math.Max(0, copy.Stages.Length - 1));
                    for (int s = 0; s < copy.Stages.Length; s++) if (copy.Stages[s] != null && copy.Stages[s].activeSelf != (s == stage)) copy.Stages[s].SetActive(s == stage);
                    if (copy.Models != null) copy.Models.localScale = Vector3.one * Mathf.Lerp(copy.Min, copy.Max, pt.Growth / 1000f);
                }
                // FarmTrayPlantPoint.SetActivePoint: the icon shows where a seed can go.
                var icon = view.Icons[i];
                bool shownIcon = pt.Plant == 0 && water && fertile;
                if (icon != null && icon.activeSelf != shownIcon) icon.SetActive(shownIcon);
            }
        }

        private static Layout LayoutOf(int prefab)
        {
            Layout layout;
            if (Layouts.TryGetValue(prefab, out layout)) return layout;
            var all = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.AllFurniture;
            var furniture = all != null && prefab >= 0 && prefab < all.Count ? all[prefab] : null;
            var tray = furniture == null ? null : furniture.GetComponent<FarmTray>();
            var points = tray == null ? null : tray.FramTrayPlantPoints;
            if (points != null && points.Length > 0 && points.Length <= LanProtocol.MaxFarmPoints)
            {
                var root = tray.transform;
                layout = new Layout { Points = new int[points.Length][], Icons = new int[points.Length][], Dry = _dry(tray), Wet = _wet(tray), Fertilized = _fertilized(tray), WaterPerBed = _waterPerBed(tray) };
                for (int i = 0; i < points.Length; i++)
                {
                    layout.Points[i] = points[i] == null ? null : PathOf(root, points[i].transform);
                    var icon = points[i] == null ? null : points[i].GetComponentInChildren<Zompiercer.UI.BillboardIcon>(true);
                    layout.Icons[i] = icon == null ? null : PathOf(root, icon.transform);
                }
                var soil = _soil(tray) ?? new MeshRenderer[0];
                layout.Soil = new int[soil.Length][];
                for (int i = 0; i < soil.Length; i++) layout.Soil[i] = soil[i] == null ? null : PathOf(root, soil[i].transform);
            }
            else layout = null;
            Layouts[prefab] = layout;
            return layout;
        }

        // Child index path from `root` to `t` (the copy is an instance of the prefab: the same children in the same order).
        private static int[] PathOf(Transform root, Transform t)
        {
            var path = new List<int>();
            for (var x = t; x != root; x = x.parent)
            {
                if (x == null) return null;
                path.Add(x.GetSiblingIndex());
            }
            path.Reverse();
            return path.ToArray();
        }
        private static Transform Follow(Transform root, int[] path)
        {
            if (path == null) return null;
            var x = root;
            foreach (int i in path)
            {
                if (x == null || i < 0 || i >= x.childCount) return null;
                x = x.GetChild(i);
            }
            return x;
        }

        // A script-free copy of the game's plant (no growth timer, sound or collider of its own) at the point.
        private static PlantCopy CopyPlant(int index, Transform at)
        {
            var list = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.FarmPlants;
            if (list == null || index < 0 || index >= list.Count || list[index] == null) return null;
            var staging = new GameObject("LAN farm staging");
            staging.SetActive(false);
            try
            {
                var plant = Object.Instantiate(list[index], staging.transform, false);
                var copy = new PlantCopy { Root = plant.gameObject, Plant = index + 1, Models = plant.PlantModelsParent, Min = plant.MinScale, Max = plant.MaxScale, Stages = _stages(plant) ?? new GameObject[0] };
                foreach (var behaviour in copy.Root.GetComponentsInChildren<MonoBehaviour>(true)) Object.DestroyImmediate(behaviour);
                foreach (var collider in copy.Root.GetComponentsInChildren<Collider>(true)) collider.enabled = false;
                foreach (var audio in copy.Root.GetComponentsInChildren<AudioSource>(true)) { audio.playOnAwake = false; audio.enabled = false; }
                foreach (var t in copy.Root.GetComponentsInChildren<Transform>(true)) t.gameObject.layer = 2; // Ignore Raycast, as the bed's copy
                copy.Root.transform.SetParent(at, false);
                copy.Root.transform.localPosition = Vector3.zero;
                copy.Root.transform.localEulerAngles = new Vector3(0f, UnityEngine.Random.Range(0f, 360f), 0f);
                copy.Root.transform.localScale = Vector3.one;
                return copy;
            }
            finally { Object.Destroy(staging); }
        }

        // Guest, each frame: copies kept on the beds' copies, the game's tips and keys at the bed in sight.
        private static void GuestPrefix(InventoryController __instance)
        {
            if (!LanSaveIsolation.Active || Views.Count == 0) return;
            try
            {
                float now = Time.unscaledTime;
                if (now >= _checkAt)
                {
                    _checkAt = now + 1f;
                    var gone = new List<long>();
                    foreach (var pair in Views)
                    {
                        if (now - pair.Value.At > 15f) { Drop(pair.Value); gone.Add(pair.Key); continue; }
                        if (pair.Value.Shown == null || pair.Value.Shown != TrainLayout.ShownFurniture(pair.Value.Car, pair.Value.Identity, out int prefab)) Show(pair.Value);
                    }
                    foreach (long key in gone) Views.Remove(key);
                }
                var work = LanWorldWork.GuestWork;
                var input = Zompiercer.Inputs.InputController.Global;
                var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
                if (work == null || input == null || player == null || (int)input.CurrentState != 1 || __instance.consumeSomething) return;
                RaycastHit hit;
                if (!LanTrainBuild.LookHit(out hit)) return;
                var target = TrainLayout.TryIdentifyBuild(hit.collider, true);
                View view;
                if (target == null || target.Kind != LanStorage.TrainFurniture || !Views.TryGetValue(Key(target.Car, target.Identity), out view) ||
                    view.Shown != target.Shown || view.Layout == null || view.Frame == null) return;
                Look(__instance, input, view, hit.point, now);
            }
            catch (Exception ex) { _log?.Invoke("Garden bed hook failed: " + ex.Message); }
        }

        private static void Look(InventoryController controller, Zompiercer.Inputs.InputController input, View view, Vector3 at, float now)
        {
            var info = controller.simpleInfoDisplayer;
            var sounds = GlobalSoundEffects.global;
            if (info == null || sounds == null) return;
            var f = view.Frame;
            bool water = (f.Flags & 1) != 0, fertile = (f.Flags & 2) != 0;
            int free = 0;
            foreach (var pt in f.Points) if (pt.Plant == 0) free++;
            bool use = input.isKbMouseDevice ? input.isUseKeyDown : input.gp_isUseOpenTalkDown;
            bool all = input.isKbMouseDevice ? input.isAimDown : input.gp_isAimDown;
            var item = controller.GetActiveIntenvoryItem();
            int point = -1; float best = .35f * .35f;
            for (int i = 0; i < view.Points.Length && i < f.Points.Length; i++)
            {
                if (view.Points[i] == null) continue;
                float d = (view.Points[i].position - at).sqrMagnitude;
                if (d <= best) { best = d; point = i; }
            }
            // A plant: FarmPlant.ShowTip and InteractingObjectsController.Harvesting.
            if (point >= 0 && f.Points[point].Plant != 0)
            {
                var pt = f.Points[point];
                string name = PlantName(pt.Plant - 1);
                if (pt.Flags == 1)
                {
                    info.SetText(name);
                    info.SetIconText("Harvest", (Zompiercer.Inputs.Actions)1, (Zompiercer.Inputs.Actions)0, true);
                    if (use) { Consume(input); Ask(LanStorage.WorkFarmHarvest, view, view.Points[point].position, null, now); }
                    return;
                }
                info.SetText(string.Format("{0}\n {1} {2}%", name, Zompiercer.GUI.LocalizationCore.GetTextByKey("Growing").ToUpper(), pt.Growth / 10));
                float efficiency = pt.Efficiency / 100f;
                info.color = Color.LerpUnclamped(sounds.colorRed, sounds.colorGreen, efficiency);
                info.SetText(Zompiercer.GUI.LocalizationCore.GetTextByKey("Efficiency").ToUpper() + " " + (efficiency * 100f).ToString("F1") + "%");
                return;
            }
            // A seed: InteractingObjectsController.CheckSeedsInHand.
            if (point >= 0 && item != null && (int)item.itemType == SeedType && !string.IsNullOrEmpty(item.SeedForPlantName) && water && fertile)
            {
                info.SetIconText("Plant", (Zompiercer.Inputs.Actions)1, (Zompiercer.Inputs.Actions)0, true);
                if (use && item.inInventory != null)
                {
                    Consume(input);
                    var escrow = LanStorage.Normalize(new object[] { item.itemID, 1, item.Save() });
                    item.inInventory.Extract(item, 1);
                    Ask(LanStorage.WorkFarmPlant, view, view.Points[point].position, escrow, now);
                }
                return;
            }
            // The bed: FarmTray.CheckState and InteractingObjectsController.CheckTray.
            bool dirty = item != null && item.itemID == LanWorldWork.DirtyBottle, fertilizer = item != null && item.itemID == Fertilizer;
            int amount = item == null ? 0 : item.amount;
            int pourAll = 0, fertilizeAll = 0;
            if (!water)
            {
                if (!dirty)
                {
                    info.color = sounds.colorRed;
                    info.SetText(Zompiercer.GUI.LocalizationCore.GetTextByKey("Watering is required").ToUpper());
                }
                else
                {
                    info.color = sounds.colorGreen;
                    info.SetIconText(Zompiercer.GUI.LocalizationCore.GetTextByKey("Add Water").ToUpper() + string.Format("{0} ({1})", Utility.PaintText(" x1", Color.green), view.Layout.WaterPerBed),
                        (Zompiercer.Inputs.Actions)1, (Zompiercer.Inputs.Actions)0, false);
                    if (amount > 1 && f.Water > 1)
                    {
                        pourAll = Math.Min(amount, f.Water);
                        string count = amount >= f.Water ? Utility.PaintText(string.Format(" x{0}", f.Water), Color.green) : Utility.PaintText(string.Format(" x{0}", amount), Color.red);
                        info.SetIconText(Zompiercer.GUI.LocalizationCore.GetTextByKey("Add All Water").ToUpper() + string.Format("{0} ({1})", count, view.Layout.WaterPerBed),
                            (Zompiercer.Inputs.Actions)3, (Zompiercer.Inputs.Actions)0, false);
                    }
                }
            }
            if (f.Fertilize < free)
            {
                int need = free - f.Fertilize;
                if (!fertilizer)
                {
                    if (f.Fertilize == 0)
                    {
                        info.color = sounds.colorRed;
                        info.SetText(Zompiercer.GUI.LocalizationCore.GetTextByKey("Fertilization is required").ToUpper());
                    }
                }
                else
                {
                    info.color = sounds.colorGreen;
                    info.SetIconText(Zompiercer.GUI.LocalizationCore.GetTextByKey("Add Fertilizer").ToUpper() + string.Format(" x{0} ({1})", Utility.PaintText(" x1", Color.green), free),
                        (Zompiercer.Inputs.Actions)1, (Zompiercer.Inputs.Actions)0, false);
                    if (amount > 1 && need > 1)
                    {
                        fertilizeAll = Math.Min(amount, need);
                        string count = amount >= need ? Utility.PaintText(string.Format(" x{0}", need), Color.green) : Utility.PaintText(string.Format(" x{0}", amount), Color.red);
                        info.SetIconText(Zompiercer.GUI.LocalizationCore.GetTextByKey("Add All Fertilizer").ToUpper() + string.Format("{0} ({1})", count, free),
                            (Zompiercer.Inputs.Actions)3, (Zompiercer.Inputs.Actions)0, false);
                    }
                }
            }
            if (!dirty && !fertilizer || item.inInventory == null) return;
            int kind = 0, n = 0;
            if (use) { if (!water && dirty) { kind = LanStorage.WorkFarmWater; n = 1; } else if (f.Fertilize < free && fertilizer) { kind = LanStorage.WorkFarmFertilize; n = 1; } }
            else if (all) { if (pourAll > 0) { kind = LanStorage.WorkFarmWater; n = pourAll; } else if (fertilizeAll > 0) { kind = LanStorage.WorkFarmFertilize; n = fertilizeAll; } }
            if (kind == 0 || n < 1) return;
            Consume(input);
            n = Math.Min(n, LanStorage.MaxWaterBottles);
            var given = LanStorage.Normalize(new object[] { item.itemID, n, item.Save() });
            item.inInventory.Extract(item, n);
            Ask(kind, view, at, given, now);
        }

        private static void Consume(Zompiercer.Inputs.InputController input)
        {
            input.isUseKeyDown = false; input.gp_isUseOpenTalkDown = false; input.isAimDown = false; input.gp_isAimDown = false;
        }

        // The request to the host, at `at` in the bed's car; what it carries comes back when it cannot go.
        private static void Ask(int kind, View view, Vector3 at, object[] escrow, float now)
        {
            var work = LanWorldWork.GuestWork;
            var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrain;
            bool sent = false;
            if (work != null && train != null && now >= _nextAsk)
            {
                try
                {
                    var car = TrainLayout.GetCar(train, view.Car);
                    sent = work(kind, car.transform.InverseTransformPoint(at), -1, view.Car, escrow);
                }
                catch (Exception ex) { _log?.Invoke("Garden bed request not sent: " + ex.Message); }
            }
            if (sent) _nextAsk = now + .35f;
            else if (escrow != null) new LanStorageGuestWorld().Give(escrow);
        }

        // Guest: the host did it (the bed's new state follows in FarmStates); the game's sound of it.
        internal static void Worked(int kind)
        {
            try
            {
                var sounds = GlobalSoundEffects.global;
                var camera = GlobalManager.global == null ? null : GlobalManager.global.MainCameraTransform;
                if (sounds == null || camera == null) return;
                if (kind == LanStorage.WorkFarmHarvest) { sounds.DigGround(); return; }
                var clip = kind == LanStorage.WorkFarmWater ? sounds.GetWateringPlant() : kind == LanStorage.WorkFarmFertilize ? sounds.GetDiggingSoil() : sounds.GetPlantingPlant();
                if (clip != null) AudioSource.PlayClipAtPoint(clip, camera.position, sounds.EffectsVolume);
            }
            catch (Exception) { }
        }

        private static string PlantName(int index)
        {
            string name;
            if (PlantNames.TryGetValue(index, out name)) return name;
            var db = ItemsDataBase.Global;
            var list = db == null ? null : db.FarmPlants;
            name = "";
            if (list != null && index >= 0 && index < list.Count && list[index] != null)
            {
                try { name = Zompiercer.GUI.LocalizationCore.GetTextByKey(db.GetItemNameByID(db.FindItemIdByName(list[index].HarvestItemName))).ToUpper(); }
                catch (Exception) { name = list[index].HarvestItemName ?? ""; }
            }
            PlantNames[index] = name;
            return name;
        }
    }
}
