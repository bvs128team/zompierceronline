using System;
using System.Collections.Generic;

namespace ZompiercerLAN
{
    // Host-only, one snapshot per quest phase and session. Profiles, never reusable slots,
    // own claims. Retain spent entries so a repeated completion cannot refill a receipt.
    internal sealed class LanQuestReceipts
    {
        internal const int Limit = 4096;
        private sealed class Receipt
        {
            internal readonly HashSet<string> Owners = new HashSet<string>(StringComparer.Ordinal);
            internal byte[] Items;
        }
        private readonly Dictionary<string, Receipt> _entries = new Dictionary<string, Receipt>(StringComparer.Ordinal);
        private static string Id(string scene, uint key) { return scene + "|" + key; }
        internal void Clear() { _entries.Clear(); }
        internal bool Keep(string scene, uint key, IList<string> profiles, string except, byte[] items = null)
        {
            string id = Id(scene, key);
            if (_entries.ContainsKey(id)) return true;
            if (_entries.Count >= Limit) return false;
            var receipt = new Receipt { Items = items == null ? null : (byte[])items.Clone() };
            if (profiles != null) foreach (string profile in profiles)
                if (!string.IsNullOrEmpty(profile) && profile != except && receipt.Owners.Count < LanProtocol.MaxPlayers - 1) receipt.Owners.Add(profile);
            _entries.Add(id, receipt);
            return true;
        }
        internal bool Waits(string scene, uint key, string profile)
        {
            Receipt receipt;
            return profile != null && _entries.TryGetValue(Id(scene, key), out receipt) && receipt.Owners.Contains(profile);
        }
        internal bool Claim(string scene, uint key, string profile, bool room, out byte[] items)
        {
            items = null;
            Receipt receipt;
            if (!room || profile == null || !_entries.TryGetValue(Id(scene, key), out receipt) || !receipt.Owners.Remove(profile)) return false;
            items = receipt.Items == null ? null : (byte[])receipt.Items.Clone();
            if (receipt.Owners.Count == 0) receipt.Items = null;
            return true;
        }
    }
}
