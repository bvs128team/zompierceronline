using System;
using System.Collections.Generic;
using UnityEngine;
using Zompiercer.Inventory;
using Object = UnityEngine.Object;

namespace ZompiercerLAN
{
    // 2.3.0: what a player wears (its equipment slots), for its State.Outfit.
    internal static class RemoteOutfit
    {
        private static ushort[] _local = new ushort[0];
        private static float _nextCapture;

        // The worn items of the local player, looked at twice a second (a state goes 20 times a second).
        internal static ushort[] CaptureLocal(ZombieFighterController player)
        {
            if (Time.unscaledTime < _nextCapture) return _local;
            _nextCapture = Time.unscaledTime + .5f;
            var worn = new List<ushort>();
            var slots = player == null ? null : player.eqipmentInventory;
            if (slots != null)
                foreach (var slot in slots)
                {
                    if (slot == null || slot.content == null) continue;
                    foreach (var item in slot.content)
                        if (item != null && Wearable(item.itemType) && item.itemID >= 0 && item.itemID < ushort.MaxValue && worn.Count < LanProtocol.MaxOutfit)
                            worn.Add((ushort)item.itemID);
                }
            _local = worn.ToArray();
            return _local;
        }

        internal static bool Wearable(EInventoryItemType type)
        {
            return type == EInventoryItemType.Backpack || type == EInventoryItemType.Helmet || type == EInventoryItemType.Armor ||
                type == EInventoryItemType.Shoes || type == EInventoryItemType.Mask || type == EInventoryItemType.Greaves || type == EInventoryItemType.Bracers;
        }
    }

    // 2.3.0: the other player's worn items on its avatar. The game is first-person and has no worn models, so each
    // item's own world model sits where it is worn: on the head (helmets, masks) or the chest (body armour,
    // backpacks), carried by that bone. Helmets the game itself puts on its military NPCs (MilitaryHelmet1-3,
    // MotoHelmet under the head hub "Hub003") sit exactly as there; the others are placed by their size. The
    // placing is done in the avatar's prefab pose (taken in Initialize), so it does not depend on the animation.
    // 2.4.0: shoes are the NPC model's own: every NPC prefab carries several kinds of footwear (skinned to its legs,
    // all but one switched off, as the game dresses its NPCs), and the kind nearest the worn shoes is switched on
    // (work shoes and police boots are the very same models). The small extra bags hang on the right hip, upright
    // (their models lie flat). 2.4.2: the head poses are the soldiers' (RigSlim); the avatars' heads are larger and sit
    // otherwise on their head hub, so head items go through the rig's head fit (HeadFits, measured on the game's
    // meshes: the soldier's skull and eyes onto the avatar's), and a helmet hides the model's hair (as the game's
    // soldiers have none), which came through it. 2.4.3: every pose checked on z-buffered views of the game's own
    // meshes on the four avatar models (the earlier point views did not show a face or a chest through an item): the
    // gas masks were too small and sat in the face, the armour sat in a man's chest and back and the heavy vest
    // behind the body; vests and packs now have their own pose on each rig (RigFits). Display only.
    internal sealed class RemoteOutfitVisual : MonoBehaviour
    {
        private enum Place { Head, Chest, Hip }
        // A worn pose: on which bone, the model's turn and size, and where it goes: Fixed (the pose as the game's
        // NPCs wear it: Offset is the model's place), or by its bounds (FitCentre: the bounds' centre to Offset;
        // FitPack: centred across, its top at Offset.y, its back panel at Offset.z; FitMask: centred across and
        // up at Offset.x/y, its inner face at Offset.z; FitVest: centred across, top at Offset.y, middle at Offset.z;
        // FitHip: its inner face at the hip's side (Offset.x, see HipSide), centred up and along at Offset.y/z).
        private enum Rule { Fixed, FitCentre, FitPack, FitMask, FitVest, FitHip }
        private sealed class Fit
        {
            internal Place On; internal Rule How; internal bool WholePrefab; internal Vector3 Offset; internal Quaternion Turn; internal float Scale;
            internal Vector3 Stretch = Vector3.one; // 2.4.3: on the model's own axes, with Scale (a vest deeper on a woman)
        }
        // 2.4.0: declared before Known, which uses it (2.4.0-2.4.2 had it after: Known took a zero rotation).
        private static readonly Quaternion HipTurn = new Quaternion(-.5f, -.5f, -.5f, .5f); // X to +Z, Y to +X, Z to +Y
        // Head hub poses of the game's own NPC helmets (rest pose, avatar axes; RigSlim MilitaryRegularNPC_12..15).
        private static readonly Fit Military1 = new Fit { On = Place.Head, How = Rule.Fixed, Offset = new Vector3(0f, .048f, .047f), Turn = new Quaternion(-.048f, 0f, 0f, .999f), Scale = 1f };
        private static readonly Dictionary<int, Fit> Known = new Dictionary<int, Fit>
        {
            { 227, Military1 }, // MilitaryHelmet1
            { 228, new Fit { On = Place.Head, How = Rule.Fixed, Offset = new Vector3(0f, .059f, .042f), Turn = new Quaternion(-.100f, 0f, 0f, .995f), Scale = 1.07f } },
            { 229, new Fit { On = Place.Head, How = Rule.Fixed, Offset = new Vector3(0f, .017f, .011f), Turn = new Quaternion(.167f, 0f, 0f, .986f), Scale = 1.08f } },
            { 9, new Fit { On = Place.Head, How = Rule.Fixed, Offset = new Vector3(0f, .004f, -.004f), Turn = new Quaternion(.132f, 0f, 0f, .991f), Scale = .71f } },  // MotoHelmet
            { 69, new Fit { On = Place.Head, How = Rule.Fixed, Offset = new Vector3(0f, .004f, -.004f), Turn = new Quaternion(.132f, 0f, 0f, .991f), Scale = .71f } }, // reinforced
            // PoliceHelmet: the military helmet's pose (the same size), 1.2 cm lower (it comes down to the ears; 2.4.3: 2 cm
            // let the top of a woman's head through).
            { 226, new Fit { On = Place.Head, How = Rule.Fixed, Offset = new Vector3(0f, .036f, .047f), Turn = new Quaternion(-.048f, 0f, 0f, .999f), Scale = 1f } },
            // 2.4.3: the gas masks larger and further ahead, so the face stays inside: the facepiece round the face, the
            // straps round the head (before, the nose, cheeks and eyes came through them).
            { 225, new Fit { On = Place.Head, How = Rule.FitCentre, Offset = new Vector3(0f, .078f, .066f), Turn = Quaternion.identity, Scale = 1.12f } }, // GasMask (with its strap ring round the head)
            { 224, new Fit { On = Place.Head, How = Rule.FitCentre, Offset = new Vector3(0f, .10f, .06f), Turn = Quaternion.identity, Scale = .84f } }, // WornGasMask (whole head)
            // FaceMask: modelled lying, outside up (+Y), its wide upper edge at +Z: turned so +Y faces ahead and +Z up.
            // 2.4.3: a flat cloth, so it hangs from the bridge of the nose, its lower edge 20 degrees further out (as a scarf tied
            // over the nose), its upper edge just ahead of the nose.
            { 223, new Fit { On = Place.Head, How = Rule.FitMask, Offset = new Vector3(0f, .005f, .156f), Turn = new Quaternion(0f, .8191520f, .5735764f, 0f), Scale = .55f } },
            // AdditionalBags (2.4.0): modelled lying (outer face +Y, along X): turned so +Y faces out of the right hip,
            // +Z up and X ahead; sized to about 25 cm.
            { 233, new Fit { On = Place.Hip, How = Rule.FitHip, Offset = new Vector3(0f, -.02f, 0f), Turn = HipTurn, Scale = .6f } },
            { 234, new Fit { On = Place.Hip, How = Rule.FitHip, Offset = new Vector3(0f, -.02f, 0f), Turn = HipTurn, Scale = .45f } },
            { 235, new Fit { On = Place.Hip, How = Rule.FitHip, Offset = new Vector3(0f, -.02f, 0f), Turn = HipTurn, Scale = .42f } },
        };
        // 2.4.0: the footwear of the game's NPC models (skinned meshes beside each other on a prefab), and which of
        // them stands for each pair of shoes, nearest first: work shoes, police boots and the work shoes the game's
        // own; military boots as the soldiers'; tall work boots as the farmers'; running shoes as basketball shoes.
        private static readonly HashSet<string> Footwear = new HashSet<string>(StringComparer.Ordinal)
            { "Boots_1", "Boots_2", "Boots_3", "Boots_4", "WorkShoesZB", "FarmerBoots", "PoliceBoots", "Basketball_Shoes" };
        private static readonly Dictionary<int, string[]> Shoes = new Dictionary<int, string[]>
        {
            { 22, new[] { "WorkShoesZB" } },                                          // WorkShoesZB
            { 231, new[] { "PoliceBoots", "Boots_1", "FarmerBoots" } },                // PoliceBoots
            { 232, new[] { "Boots_1", "Boots_2", "PoliceBoots", "FarmerBoots" } },     // MilitaryBoots
            { 21, new[] { "FarmerBoots", "PoliceBoots", "Boots_3" } },                 // WorkBootsZB
            { 230, new[] { "Basketball_Shoes", "WorkShoesZB" } },                      // RunningShoes
        };
        private static readonly Fit Pack = new Fit { On = Place.Chest, How = Rule.FitPack, WholePrefab = true, Offset = new Vector3(0f, .10f, -.10f), Turn = Quaternion.Euler(0f, 180f, 0f), Scale = 1f };
        private static readonly Fit Vest = new Fit { On = Place.Chest, How = Rule.FitVest, WholePrefab = true, Offset = new Vector3(0f, .12f, .05f), Turn = Quaternion.identity, Scale = .85f };
        private static readonly Fit Mask = new Fit { On = Place.Head, How = Rule.FitCentre, Offset = new Vector3(0f, .078f, .066f), Turn = Quaternion.identity, Scale = 1.12f };
        // 2.4.3: vests, armour and packs on each avatar rig's own torso (RigSkuf: the men, broad and deep; RigW: the women,
        // narrow, deep at the chest), and the face cloth ahead of a woman's nose. Vests: top (y) and middle (z) on the
        // chest hub, size, depth; the heavy vest is the military vest with a collar and shoulder guards, so it stands
        // where that one does. Packs: top and back panel.
        private static Fit VestFit(float y, float z, float scale, float depth)
        {
            return new Fit { On = Place.Chest, How = Rule.FitVest, WholePrefab = true, Offset = new Vector3(0f, y, z), Turn = Quaternion.identity, Scale = scale, Stretch = new Vector3(1f, 1f, depth) };
        }
        private static Fit PackFit(float y, float z, float scale)
        {
            return new Fit { On = Place.Chest, How = Rule.FitPack, WholePrefab = true, Offset = new Vector3(0f, y, z), Turn = Quaternion.Euler(0f, 180f, 0f), Scale = scale };
        }
        private static readonly KeyValuePair<string, Dictionary<int, Fit>>[] RigFits =
        {
            new KeyValuePair<string, Dictionary<int, Fit>>("RigSkuf", new Dictionary<int, Fit>
            {
                { 20, VestFit(.15f, .08f, 1.15f, 1.2f) },      // Tire Armor
                { 211, VestFit(.14f, .05f, 1.05f, 1f) },       // PoliceVest
                { 212, VestFit(.14f, .04f, 1.05f, .95f) },     // MilitaryVest
                { 213, VestFit(.188f, .204f, 1.05f, .95f) },   // MilitaryHeavyVest
                { 7, PackFit(.11f, -.11f, 1.1f) }, { 214, PackFit(.11f, -.11f, 1.1f) }, { 215, PackFit(.11f, -.11f, 1.1f) }, { 216, PackFit(.11f, -.11f, 1.1f) },
            }),
            new KeyValuePair<string, Dictionary<int, Fit>>("RigW", new Dictionary<int, Fit>
            {
                { 20, VestFit(.15f, .07f, 1f, 1.25f) },
                { 211, VestFit(.16f, .07f, .75f, 1.25f) },
                { 212, VestFit(.15f, .06f, .82f, 1.2f) },
                { 213, VestFit(.187f, .221f, .82f, 1.2f) },
                { 7, PackFit(.10f, -.075f, .95f) }, { 214, PackFit(.10f, -.075f, .95f) }, { 215, PackFit(.10f, -.075f, .95f) }, { 216, PackFit(.10f, -.075f, .95f) },
                { 223, new Fit { On = Place.Head, How = Rule.FitMask, Offset = new Vector3(0f, .005f, .172f), Turn = new Quaternion(0f, .8191520f, .5735764f, 0f), Scale = .55f } },
            }),
        };
        // 2.4.2: the soldier's head (RigSlim, where the poses above come from) onto the avatar's, by rig: the size of
        // the skull (width and depth, from the head meshes) and the place of the eyes on the head hub. Men (RigSkuf):
        // skull 24.4 x 27.0 cm against 21.9 x 25.2, eyes 3 cm lower and 2 cm further ahead; women (RigW): 22.6 x 27.2 cm,
        // eyes 1 cm lower.
        private static readonly KeyValuePair<string, Vector4>[] HeadFits =
        {
            new KeyValuePair<string, Vector4>("RigSkuf", new Vector4(0f, -.040f, .007f, 1.09f)),
            // 2.4.3: 1.2 cm further back and 2% larger than the eyes alone gave: the back of a woman's longer head came out
            // behind the helmets.
            new KeyValuePair<string, Vector4>("RigW", new Vector4(0f, -.009f, -.009f, 1.075f)),
        };

        private Transform _head, _chest, _hip;
        private string _rig; // 2.4.3: the rig's bone prefix (RigFits)
        // 2.4.2: the model's hair and whether each was on (off under a helmet).
        private readonly List<KeyValuePair<GameObject, bool>> _hair = new List<KeyValuePair<GameObject, bool>>();
        private float _hipSide = .225f;
        private readonly List<GameObject> _baked = new List<GameObject>();
        // 2.4.0: the model's footwear and whether each was on.
        private readonly List<KeyValuePair<GameObject, bool>> _feet = new List<KeyValuePair<GameObject, bool>>();
        private readonly List<GameObject> _models = new List<GameObject>();
        private ushort[] _shown = new ushort[0];
        private float _nextBuild;
        private bool _failed;

        // Called when the avatar is made, in its prefab pose (as RemoteAvatarMotion.Initialize); null: ready.
        internal string Initialize()
        {
            string rig;
            var head = RemoteAvatarMotion.FindBone(transform, "Hub003", out rig);
            _rig = rig;
            var chest = RemoteAvatarMotion.FindBone(transform, "Hub002", out rig);
            if (head == null || chest == null) return "no head or chest bone";
            _head = Anchor("LAN worn on head", head);
            _chest = Anchor("LAN worn on chest", chest);
            // 2.4.2: head items are placed on the soldier's head as the game has it; this frame puts that head on the model's.
            foreach (var fit in HeadFits)
                if (rig != null && rig.StartsWith(fit.Key, StringComparison.Ordinal))
                {
                    var frame = new GameObject("LAN head fit").transform;
                    frame.SetParent(_head, false);
                    frame.localPosition = new Vector3(fit.Value.x, fit.Value.y, fit.Value.z);
                    frame.localScale = Vector3.one * fit.Value.w;
                    _head = frame;
                    break;
                }
            // What the NPC model itself has on its head (a military NPC's helmet): hidden while a worn item is there.
            foreach (Transform child in head)
                if (!child.name.StartsWith("Rig", StringComparison.Ordinal) && child != _head && child.GetComponentInChildren<Renderer>(true) != null) _baked.Add(child.gameObject);
            // 2.4.0: the pelvis hub for the bags on the hip (the woman's hips are narrower); the model's footwear.
            var hip = RemoteAvatarMotion.FindBone(transform, "Hub001", out rig);
            if (hip != null) _hip = Anchor("LAN worn on hip", hip);
            if (rig != null && rig.StartsWith("RigW", StringComparison.Ordinal)) _hipSide = .195f;
            foreach (var skin in GetComponentsInChildren<SkinnedMeshRenderer>(true))
            {
                if (Footwear.Contains(skin.gameObject.name)) _feet.Add(new KeyValuePair<GameObject, bool>(skin.gameObject, skin.gameObject.activeSelf));
                else if (skin.gameObject.name.StartsWith("Hair", StringComparison.Ordinal)) _hair.Add(new KeyValuePair<GameObject, bool>(skin.gameObject, skin.gameObject.activeSelf));
            }
            return null;
        }

        // A holder on the bone in the avatar's axes and scale (as the bone stands in the prefab pose).
        private Transform Anchor(string name, Transform bone)
        {
            var anchor = new GameObject(name).transform;
            anchor.SetParent(bone, false);
            anchor.SetPositionAndRotation(bone.position, transform.rotation);
            var root = transform.lossyScale; var own = bone.lossyScale;
            anchor.localScale = new Vector3(root.x / Mathf.Max(1e-4f, Mathf.Abs(own.x)), root.y / Mathf.Max(1e-4f, Mathf.Abs(own.y)), root.z / Mathf.Max(1e-4f, Mathf.Abs(own.z)));
            return anchor;
        }

        // Every frame with the partner's state: the models again when what it wears changed (at most twice a second).
        internal void Apply(ushort[] outfit)
        {
            outfit = outfit ?? new ushort[0];
            if (Same(outfit, _shown) || Time.unscaledTime < _nextBuild || _head == null) return;
            _nextBuild = Time.unscaledTime + .5f;
            _shown = (ushort[])outfit.Clone();
            foreach (var model in _models) if (model != null) Object.Destroy(model);
            _models.Clear();
            bool onHead = false, helmet = false, gasMask = false;
            // 2.4.3: a gas mask (a mask round the whole face, FitCentre) under a helmet: the helmet goes over it (OverMask).
            foreach (var id in _shown)
            {
                var worn = FitOf(id);
                if (worn != null && worn.On == Place.Head && worn.How == Rule.FitCentre) gasMask = true;
            }
            try { PutOnShoes(); }
            catch (Exception ex)
            {
                if (!_failed) { _failed = true; Debug.LogWarning("[ZompiercerLAN] Partner's shoes not shown: " + ex.GetType().Name + ": " + ex.Message); }
            }
            foreach (var id in _shown)
            {
                try
                {
                    var model = Build(id, gasMask);
                    if (model == null) continue;
                    _models.Add(model);
                    if (model.transform.parent == _head)
                    {
                        onHead = true;
                        var database = ItemsDataBase.Global;
                        if (database != null && database.itemPrefab[id] != null && database.itemPrefab[id].itemType == EInventoryItemType.Helmet) helmet = true;
                    }
                }
                catch (Exception ex)
                {
                    if (!_failed) { _failed = true; Debug.LogWarning("[ZompiercerLAN] Partner's worn item " + id + " not shown: " + ex.GetType().Name + ": " + ex.Message); }
                }
            }
            foreach (var baked in _baked) if (baked != null) baked.SetActive(!onHead);
            foreach (var hair in _hair) if (hair.Key != null) hair.Key.SetActive(hair.Value && !helmet);
        }

        // 2.4.0: the model's footwear nearest the worn shoes on, the rest off; without shoes (or with none near) as it was.
        private void PutOnShoes()
        {
            string[] wanted = null;
            foreach (var id in _shown) if (Shoes.TryGetValue(id, out wanted)) break;
            GameObject chosen = null;
            if (wanted != null)
                foreach (var name in wanted)
                {
                    foreach (var foot in _feet) if (foot.Key != null && foot.Key.name == name) { chosen = foot.Key; break; }
                    if (chosen != null) break;
                }
            foreach (var foot in _feet)
                if (foot.Key != null) foot.Key.SetActive(chosen == null ? foot.Value : foot.Key == chosen);
        }

        private static bool Same(ushort[] a, ushort[] b)
        {
            if (a.Length != b.Length) return false;
            for (int i = 0; i < a.Length; i++) if (a[i] != b[i]) return false;
            return true;
        }

        // The pose of a worn item on this avatar (2.4.3: the rig's own first); null: not shown.
        private Fit FitOf(int id)
        {
            var database = ItemsDataBase.Global;
            if (database == null || database.itemPrefab == null || id >= database.itemPrefab.Length) return null;
            var prefab = database.itemPrefab[id];
            if (prefab == null) return null;
            Fit fit = null;
            foreach (var rigFits in RigFits)
                if (_rig != null && _rig.StartsWith(rigFits.Key, StringComparison.Ordinal)) { rigFits.Value.TryGetValue(id, out fit); break; }
            if (fit == null && !Known.TryGetValue(id, out fit))
            {
                var type = prefab.itemType;
                fit = type == EInventoryItemType.Helmet ? Military1 : type == EInventoryItemType.Mask ? Mask :
                    type == EInventoryItemType.Backpack ? Pack : type == EInventoryItemType.Armor ? Vest : null;
            }
            return fit;
        }

        // 2.4.3: a helmet over a gas mask, 22% larger, 1.8 cm higher and 2.5 cm further back: the mask's top and the
        // straps over the head stay under it (with the helmet's own pose they came through its front and back).
        private const float OverMaskScale = 1.22f;
        private static readonly Vector3 OverMaskShift = new Vector3(0f, .018f, -.025f);

        private GameObject Build(int id, bool gasMask)
        {
            var fit = FitOf(id);
            if (fit == null) return null;
            var prefab = ItemsDataBase.Global.itemPrefab[id];
            bool over = gasMask && fit.On == Place.Head && prefab.itemType == EInventoryItemType.Helmet;
            var anchor = fit.On == Place.Head ? _head : fit.On == Place.Hip ? _hip : _chest;
            if (anchor == null) return null;
            var holder = new GameObject("LAN worn " + prefab.name);
            holder.transform.SetParent(anchor, false);
            holder.transform.localRotation = fit.Turn;
            holder.transform.localScale = fit.Stretch * (fit.Scale * (over ? OverMaskScale : 1f)); // Stretch (2.4.3): (1,1,1) unless set
            // The model: the whole prefab in its own axes (packs, armour), or its LOD group's meshes in theirs
            // (helmets and masks: the axes the game's NPCs wear them in).
            var source = fit.WholePrefab ? prefab.transform : LodNode(prefab.transform);
            var model = new GameObject("Model");
            model.transform.SetParent(holder.transform, false);
            if (fit.WholePrefab) model.transform.localScale = prefab.transform.localScale;
            RemoteEquipmentVisual.CopyGeometry(source, model.transform, true, RemoteEquipmentVisual.ExcludedLowerLods(prefab));
            foreach (var renderer in holder.GetComponentsInChildren<MeshRenderer>(true)) renderer.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On;
            if (fit.How == Rule.Fixed) { holder.transform.localPosition = fit.Offset + (over ? OverMaskShift : Vector3.zero); return holder; }
            Vector3 min, max;
            if (!Bounds(anchor, holder.transform, out min, out max)) { Object.Destroy(holder); return null; }
            var centre = (min + max) / 2f; var shift = Vector3.zero;
            switch (fit.How)
            {
                case Rule.FitCentre: shift = fit.Offset - centre; break;
                case Rule.FitPack: shift = new Vector3(fit.Offset.x - centre.x, fit.Offset.y - max.y, fit.Offset.z - (max.z - .4f * (max.z - min.z))); break;
                case Rule.FitMask: shift = new Vector3(fit.Offset.x - centre.x, fit.Offset.y - centre.y, fit.Offset.z - min.z); break;
                case Rule.FitVest: shift = new Vector3(fit.Offset.x - centre.x, fit.Offset.y - max.y, fit.Offset.z - centre.z); break;
                case Rule.FitHip: shift = new Vector3(_hipSide + fit.Offset.x - min.x, fit.Offset.y - centre.y, fit.Offset.z - centre.z); break;
            }
            holder.transform.localPosition = shift;
            return holder;
        }

        // The child with the item's LOD group (its meshes in their own axes), else the prefab itself.
        private static Transform LodNode(Transform prefab)
        {
            foreach (Transform child in prefab)
                if (child.gameObject.activeSelf && child.GetComponent<LODGroup>() != null) return child;
            return prefab;
        }

        // The meshes' bounds below holder, in the anchor's space (the avatar's axes at the bone).
        private static bool Bounds(Transform anchor, Transform holder, out Vector3 min, out Vector3 max)
        {
            min = Vector3.one * float.MaxValue; max = -min; bool any = false;
            foreach (var filter in holder.GetComponentsInChildren<MeshFilter>(true))
            {
                var mesh = filter.sharedMesh; if (mesh == null) continue;
                var b = mesh.bounds;
                for (int i = 0; i < 8; i++)
                {
                    var corner = b.center + Vector3.Scale(b.extents, new Vector3((i & 1) == 0 ? -1f : 1f, (i & 2) == 0 ? -1f : 1f, (i & 4) == 0 ? -1f : 1f));
                    var at = anchor.InverseTransformPoint(filter.transform.TransformPoint(corner));
                    min = Vector3.Min(min, at); max = Vector3.Max(max, at); any = true;
                }
            }
            return any;
        }

        private void OnDestroy()
        {
            foreach (var model in _models) if (model != null) Object.Destroy(model);
        }
    }
}
