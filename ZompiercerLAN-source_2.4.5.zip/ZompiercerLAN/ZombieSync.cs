using System;
using System.Collections.Generic;
using System.Collections;
using System.Diagnostics;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
using Zompiercer.Inventory;
using Object = UnityEngine.Object;

namespace ZompiercerLAN
{
    // Main-thread only. Wire messages contain primitive state, never serialized Unity objects.
    internal sealed class ZombieSync : IDisposable
    {
        private static ZombieSync Active;
        private static Harmony Guard;
        private static bool ClientWorld; // Deliberately survives disconnect, Dispose and scene loads.
        private static bool IsClientWorld { get { if (LanSaveIsolation.Active) ClientWorld = true; return ClientWorld; } }
        private readonly bool _host;
        private readonly Action<Packet> _send;
        private readonly Action<string> _report;
        internal readonly LanCombatSync Combat;
        private readonly Dictionary<int, HostZombie> _hostIds = new Dictionary<int, HostZombie>();
        private readonly List<HostZombie> _catalog = new List<HostZombie>();
        private readonly Dictionary<uint, Replica> _replicas = new Dictionary<uint, Replica>();
        private readonly Dictionary<string, ZombieAIController> _prefabs = new Dictionary<string, ZombieAIController>(StringComparer.Ordinal);
        private readonly HashSet<string> _failedPrefabs = new HashSet<string>(StringComparer.Ordinal);
        private readonly HashSet<string> _unknownPrefabs = new HashSet<string>(StringComparer.Ordinal);
        private readonly uint[] _seen = new uint[LanProtocol.MaxZombieIds + 1];
        private readonly bool[] _dead = new bool[LanProtocol.MaxZombieIds + 1];
        private readonly uint[] _corpseSeen = new uint[LanProtocol.MaxZombieIds + 1];
        private readonly ZombieFrame[] _pendingFrames = new ZombieFrame[LanProtocol.MaxZombieIds + 1];
        private readonly uint[] _pendingSequences = new uint[LanProtocol.MaxZombieIds + 1];
        private readonly float[] _pendingTimes = new float[LanProtocol.MaxZombieIds + 1];
        // Client (1.0.7): local time minus host time, from the fastest recent batches, and the
        // average extra delay of the others; replicas are shown that far in the host's past.
        private float _clockOffset, _jitter;
        private bool _haveClock;
        private int _pendingCount, _applyCursor = 1;
        private string _scene;
        private uint _epoch, _actionSequence, _lastHurt;
        // 1.1.6: zombie effects (spits, burst stomachs) sent by the host / last shown by the guest.
        private uint _lastEffect;
        private bool _effectFailed;
        // 1.4.14, host: spawners and territories woken around the guests (WakeAroundRemotes); notices logged.
        private float _wakeAt, _territoriesAt, _noticeLogAt;
        private ZombieSpawnerTerritoryActivator[] _territories;
        private bool _wakeFailed;
        internal const float EffectRange=150f;
        private bool _ready, _playerReady, _disposed;
        private float _diagnosticAt;
        private int _sentFrames, _receivedFrames, _createdReplicas;
        private float _scanAt, _sendAt;
        // 2.0.0, host: each guest the host's zombies know of (by slot): where it is and what it holds,
        // whether it can be a target (placed, fresh, up), the stand-in transform zombies chase, its
        // pending damage and hurts (one outstanding, in order, until acknowledged), its own numbering
        // of batches, corpses and effects, its combat (ammunition, rate, ledger).
        private sealed class Remote
        {
            internal int Slot; internal Action<Packet> Send; internal LanCombatSync Combat;
            internal Vector3 Position; internal float Yaw=float.NaN; internal int Item=-1; internal bool Ready, Down;
            // 1.4.13: how it moves (crouching, running, in the air, its ground speed) and its stealth
            // (ZFLevelController.stealthFactor): the host's zombies notice it by the game's own rules.
            internal bool Crouch, Run, Air; internal float Speed, Stealth=1f;
            internal GameObject Target;
            internal readonly Queue<Packet> Hurts=new Queue<Packet>(); internal readonly float[] PendingDamage=new float[5];
            internal uint Sequence, CorpseSequence, EffectSequence, HurtSequence, LastAction;
            internal int Cursor; internal float HurtAt, DamageAt, NextAction;
            internal bool Usable { get { return Ready && !Down; } }
        }
        private readonly Dictionary<int,Remote> _remotes=new Dictionary<int,Remote>();
        // Chased: the guest a zombie hunts now (null: the native AI's own target, the host's player).
        private sealed class HostZombie { internal ZombieAIController AI; internal uint Id; internal int AttackGeneration; internal string Prefab; internal Remote Chased; internal bool Explosion, ChargeHit; internal float LastAlive, NextAttack, DeadAt=-1f, NextCorpse; internal ZombieFrame Last; internal Transform[] Bones; internal NetPose[] SentBones; internal LimbDetector[] Limbs; internal float KeepRemoteUntil; internal bool Fleeing; internal float FleeAt; }
        private sealed class Replica
        {
            internal GameObject Root; internal Animator Animator; internal Vector3 Position; internal Quaternion Rotation; internal float Seen; internal string Prefab; internal Transform[] Bones; internal int[] BoneOrder; internal bool Dead;
            // 1.4.11: this client saw it alive (a body first seen dead gives no experience).
            internal bool SeenAlive;
            // Host frames by host time, oldest first (1.0.7): the copy moves between them at an even pace
            // instead of lurching toward each new one, and its animation follows the same timeline.
            internal readonly Snap[] Snaps=new Snap[8]; internal int SnapCount;
            internal FlameVisual Flame; // 1.1.8: a firefighter's flamethrower and burning hands
            internal LimbShape[] Limbs; // 1.5.0: the prefab's limb hitboxes on the copy's bones
            internal float Interval=.05f, AnimAt=-1f, MismatchSince=-1f; internal bool ForcePlay=true;
            // 2.4.0: a corpse glides from the pose it showed to the host's newest ragdoll pose, over about the time
            // between the host's poses (CorpseAt: when the newest came; CorpseFor: the glide; -1: none).
            internal Vector3[] CorpseFromP, CorpseToP; internal Quaternion[] CorpseFromR, CorpseToR;
            internal float CorpseAt, CorpseFor=-1f, CorpseLast=-1f;
        }
        private struct Snap { internal float T, Yaw, AnimationTime; internal Vector3 P; internal int Animation; internal uint Flags; internal byte Fx; }
        // 1.1.8: the copy's flames: particles and lights of the prefab's own flamethrower effect and
        // burning hands (no scripts), the flamethrower's sounds; switched by the host's frame bits.
        private sealed class FlameVisual
        {
            internal Transform Holder; internal Quaternion Turn; internal Transform[] Hands;
            internal ParticleSystem[] Jet; internal Light[] JetLights; internal ParticleSystem[][] HandFire; internal GameObject[] HandLights;
            internal AudioSource Audio; internal AudioClip Start, End; internal byte Shown=255;
        }
        private static string _flameFailure;

        // Host: send and inventory are unused (each guest has its own, AddRemote); Combat is null.
        internal ZombieSync(bool host, Action<Packet> send, Action<string> report, HostCombatInventory inventory)
        {
            if(host && IsClientWorld) throw new InvalidOperationException("Client zombie isolation requires restart before hosting.");
            _host=host; _send=send; _report=report;
            if(host && OptimizerFailure!=null) report("Zombies far from the host stay asleep: "+OptimizerFailure);
            Combat=host?null:new LanCombatSync(false,inventory,send);
            InstallGuard();
            Active=this;
            // Capture trusted local assets before the menu/scene that owns the
            // library is unloaded. Assets remain valid across world epochs.
            BuildPrefabCatalog();
        }

        // ---- Host (2.0.0): the guests ----

        internal LanCombatSync AddRemote(int slot,Action<Packet> send,HostCombatInventory inventory)
        {
            RemoveRemote(slot);
            var target=new GameObject("LAN remote zombie target "+slot); Object.DontDestroyOnLoad(target);
            var r=new Remote {Slot=slot,Send=send,Combat=new LanCombatSync(true,inventory,send),Target=target};
            r.Combat.Rebind(_scene,_epoch);
            _remotes[slot]=r;
            return r.Combat;
        }
        internal void RemoveRemote(int slot)
        {
            Remote r;
            if(!_remotes.TryGetValue(slot,out r)) return;
            ReleaseTargets(r); r.Combat.Freeze(); _remotes.Remove(slot);
            if(r.Target!=null) Object.Destroy(r.Target);
        }
        internal LanCombatSync CombatOf(int slot) { Remote r; return _remotes.TryGetValue(slot,out r)?r.Combat:null; }
        // Every frame, before Tick: where a guest is, whether it can be a target (placed, its state fresh,
        // in this scene), what it holds and where it faces, whether it lies downed or dead.
        internal void UpdateRemote(int slot,Vector3 position,bool ready,int item,float yaw,bool down,bool crouch=false,bool run=false,bool air=false,float speed=0f,float stealth=1f,ushort[] mods=null)
        {
            Remote r;
            if(!_remotes.TryGetValue(slot,out r)) return;
            r.Position=position; r.Ready=ready; r.Item=item; r.Yaw=yaw; r.Down=down;
            r.Crouch=crouch; r.Run=run; r.Air=air; r.Speed=speed; r.Stealth=stealth;
            r.Combat.Holds(item,mods); // 2.4.0: the unit in its hands, by its mods
        }

        internal void Tick(string scene,uint epoch,bool ready,bool playerReady=true)
        {
            if(_disposed) return;
            if(_epoch!=epoch || _scene!=scene) ResetWorld(scene,epoch);
            _ready=ready && epoch!=0; _playerReady=playerReady && _ready;
            if(_host) foreach(var r in _remotes.Values) { r.Combat.Tick(_playerReady && r.Ready); if(r.Target!=null) r.Target.transform.position=r.Position; }
            // 2.4.2: the host has no Combat of its own (each guest's is in its Remote); 2.2.0-2.4.1 called it while the
            // host's world was not ready (menu, loading) and threw every frame, cutting the rest of LanPlugin.Update.
            if(_host) { if(_ready) WakeAroundRemotes(); }
            else Combat.Tick(_playerReady);
            if(!_host && !IsClientWorld) return; // Failed/cancelled pairing must not alter a solo/menu world.
            BuildPrefabCatalog();
            float now=Time.unscaledTime;
            if (now >= _diagnosticAt) {
                _diagnosticAt=now+15f;
                int ready2=0; foreach(var r in _remotes.Values) if(r.Ready) ready2++;
                _report("sync " + (_host?"host":"client") + " epoch=" + _epoch + " ready=" + _ready +
                    " playerReady=" + _playerReady + " guests=" + _remotes.Count + "/" + ready2 + " prefabs=" + _prefabs.Count +
                    " catalog=" + _catalog.Count + " sent=" + _sentFrames + " received=" + _receivedFrames +
                    " created=" + _createdReplicas + " replicas=" + _replicas.Count + " pending=" + _pendingCount + (_host ? "" : " xp=" + Mathf.RoundToInt(_experience)));
            }
            if(now>=_scanAt) {
                _scanAt=now+.5f;
                foreach(var ai in Object.FindObjectsOfType<ZombieAIController>()) {
                    if(!_host) { ai.StopAllCoroutines(); ai.gameObject.SetActive(false); continue; }
                    if(!_ready || _catalog.Count>=LanProtocol.MaxZombieIds || _hostIds.ContainsKey(ai.GetInstanceID())) continue;
                    ZombieAIController prefab;
                    if(string.IsNullOrEmpty(ai.ID) || !_prefabs.TryGetValue(ai.ID,out prefab)) continue;
                    var h=new HostZombie {AI=ai,Id=(uint)_catalog.Count+1,Prefab=ai.ID,LastAlive=now,Limbs=ai.GetComponentsInChildren<LimbDetector>(true)};
                    _catalog.Add(h); _hostIds.Add(ai.GetInstanceID(),h);
                }
            }
            if(!_host) {
                if (_ready) ApplyPending();
                TickSwing(); // 1.5.0
                TickDeviceFlames(now); // 2.2.0
                var remove=new List<uint>();
                float hostNow=now-_clockOffset, smooth=1-Mathf.Exp(-Time.unscaledDeltaTime*20);
                foreach(var pair in _replicas) {
                    var r=pair.Value;
                    if(r.Root==null || now-r.Seen>12) { if(r.Root!=null) Object.Destroy(r.Root); remove.Add(pair.Key); continue; }
                    if(r.Dead) { GlideCorpse(r,now); continue; } // 2.4.0: toward the host's newest ragdoll pose
                    if(r.SnapCount==0) continue;
                    float at=hostNow-Mathf.Clamp(r.Interval+_jitter*2+.03f,.08f,.6f);
                    Vector3 position; float yaw; Sample(r,at,out position,out yaw);
                    var t=r.Root.transform;
                    if((t.position-position).sqrMagnitude>25) t.SetPositionAndRotation(position,Quaternion.Euler(0,yaw,0)); // a jump: no glide
                    else { t.position=Vector3.Lerp(t.position,position,smooth); t.rotation=Quaternion.Slerp(t.rotation,Quaternion.Euler(0,yaw,0),smooth); }
                    // The newest frame the shown moment has reached sets the animation.
                    for(int i=r.SnapCount-1;i>=0;i--) if(r.Snaps[i].T<=at) { if(r.Snaps[i].T>r.AnimAt) { r.AnimAt=r.Snaps[i].T; ApplyAnimation(r,r.Snaps[i]); } break; }
                    if(r.ForcePlay && r.AnimAt<0) ApplyAnimation(r,r.Snaps[0]); // just created: pose it at once
                    if(r.Flame!=null && r.Flame.Holder!=null) r.Flame.Holder.rotation=t.rotation*r.Flame.Turn; // the jet points ahead
                }
                foreach(uint id in remove) _replicas.Remove(id);
                return;
            }
            // World visuals do not require an accepted guest pose. Combat still does: an
            // unplaced/stale guest cannot redirect AI or cause damage.
            if(_ready && now>=_sendAt) {
                _sendAt=now+.05f;
                var seen=new HashSet<HostZombie>();
                foreach(var r in _remotes.Values) SendBatch(r,now,seen);
                SendCorpse(seen,now);
            }
            foreach(var r in _remotes.Values) {
                if(!_ready || !r.Usable) { ReleaseTargets(r); if(!_ready || !r.Ready) continue; }
                if(now>=r.DamageAt && r.Hurts.Count<64) {
                    r.DamageAt=now+.1f;
                    for(byte kind=1;kind<5 && r.Hurts.Count<64;kind++) if(r.PendingDamage[kind]>0) {
                        var hurt=Message(PacketKind.ZombieHurt,++r.HurtSequence);hurt.Action=kind;
                        hurt.Damage=Mathf.Min(1000,r.PendingDamage[kind]);r.PendingDamage[kind]-=hurt.Damage;r.Hurts.Enqueue(hurt);
                    }
                }
                if(r.Hurts.Count>0 && now>=r.HurtAt) { r.HurtAt=now+.2f; r.Send(r.Hurts.Peek()); }
            }
        }

        private void BuildPrefabCatalog()
        {
            var library=GlobalZombieLibrary.global;
            if(library==null || library.zombie==null) return;
            foreach(var prefab in library.zombie) {
                if(prefab==null || string.IsNullOrEmpty(prefab.ID) || System.Text.Encoding.UTF8.GetByteCount(prefab.ID)>64 || _prefabs.ContainsKey(prefab.ID)) continue;
                if(_prefabs.Count>=256) break;
                _prefabs.Add(prefab.ID,prefab);
            }
        }

        // The zombies nearest to this guest (or to the host's player), a slice per batch; seen: every
        // zombie some guest's batch covers (its corpse may be sent).
        private void SendBatch(Remote to,float now,HashSet<HostZombie> seen)
        {
            var batch=new List<ZombieFrame>();
            var relevant=new List<HostZombie>();
            foreach(var h in _catalog) if(h.AI!=null && h.AI.gameObject.activeInHierarchy || h.Last!=null && now-h.LastAlive<12) relevant.Add(h);
            relevant.Sort((a,b)=>Distance(a,to).CompareTo(Distance(b,to)));
            if(relevant.Count>LanProtocol.MaxZombieReplicas) relevant.RemoveRange(LanProtocol.MaxZombieReplicas,relevant.Count-LanProtocol.MaxZombieReplicas);
            seen.UnionWith(relevant);
            int visited=0;
            while(visited++<relevant.Count && batch.Count<LanProtocol.MaxZombieBatch) {
                if(to.Cursor>=relevant.Count) to.Cursor=0;
                var h=relevant[to.Cursor++]; var ai=h.AI;
                if(ai!=null && ai.gameObject.activeInHierarchy) {
                    var pos=ai.transform.position; var anim=VisualAnimator(ai);
                    var z=new ZombieFrame {Id=h.Id,Prefab=h.Prefab,X=pos.x,Y=pos.y,Z=pos.z,Yaw=ai.transform.eulerAngles.y,
                        Health=ai.zombieHP==null?0:Mathf.Clamp(ai.zombieHP.currentHealth,0,99999),Flags=ai.dead?(byte)1:FlameFlags(ai)};
                    if(anim!=null && anim.runtimeAnimatorController!=null) { var state=anim.GetCurrentAnimatorStateInfo(0); z.Animation=state.fullPathHash; z.AnimationTime=Mathf.Repeat(state.normalizedTime,1); z.AnimationFlags=BoolFlags(anim); }
                    h.Last=z; h.LastAlive=now; batch.Add(z);
                } else if(h.Last!=null && now-h.LastAlive<12) {
                    h.Last.Flags=(byte)(ai==null?3:2); h.Last.Health=0; batch.Add(h.Last);
                }
            }
            var packet=Message(PacketKind.ZombieState,++to.Sequence); packet.Zombies=batch.ToArray(); packet.HostTime=Time.unscaledTime; to.Send(packet);_sentFrames+=batch.Count;
        }

        // Ragdoll poses to every guest, the longest-waiting bodies first. 2.4.0: up to CorpsesPerBatch bodies per batch
        // (20 batches a second); a body ten times a second while it falls (its first 2 s), then every 0.3 s up to 6 s,
        // then every 4 s; one lying still (no bone moved 5 mm since its last pose) at once every 4 s. The guest
        // glides between the poses (GlideCorpse). A blast that kills a crowd sends at most 60 poses a second.
        private const int CorpsesPerBatch=3;
        private const float CorpseStill=.005f;
        private void SendCorpse(HashSet<HostZombie> relevant,float now)
        {
            if(_remotes.Count==0) return;
            List<HostZombie> due=null;
            foreach(var h in relevant) {
                var ai=h.AI;
                if(ai==null || !ai.dead || !ai.gameObject.activeInHierarchy) continue;
                if(h.DeadAt<0) { h.DeadAt=now; h.NextCorpse=now; }
                if(now>=h.NextCorpse) (due??(due=new List<HostZombie>())).Add(h);
            }
            if(due==null) return;
            due.Sort((a,b)=>a.NextCorpse.CompareTo(b.NextCorpse));
            for(int i=0;i<due.Count && i<CorpsesPerBatch;i++) SendCorpse(due[i],now);
        }
        private void SendCorpse(HostZombie pick,float now)
        {
            if(pick.Bones==null) {
                var detector=pick.AI.GetComponentInChildren<ZombieDamagDetector>(true);
                pick.Bones=detector==null || detector.rigidElements==null || detector.rigidElements.Length>LanProtocol.MaxCorpseBones ? new Transform[0] : detector.rigidElements;
            }
            var bones=new NetPose[pick.Bones.Length];
            for(int i=0;i<bones.Length;i++) {
                if(pick.Bones[i]==null) { bones=new NetPose[0]; break; }
                bones[i]=Pose(pick.Bones[i]);
            }
            float age=now-pick.DeadAt;
            bool still=age>=1f && Still(pick.SentBones,bones);
            pick.NextCorpse=now+(still?4f:age<2f?.1f:age<6f?.3f:4f);
            pick.SentBones=bones;
            var root=pick.AI.transform.position;
            var corpse=new CorpseFrame {Id=pick.Id,Prefab=pick.Prefab,X=root.x,Y=root.y,Z=root.z,Yaw=Mathf.Repeat(pick.AI.transform.eulerAngles.y,360f)%360f,Bones=bones};
            foreach(var r in _remotes.Values) { var packet=Message(PacketKind.ZombieCorpse,++r.CorpseSequence); packet.Corpse=corpse; r.Send(packet); }
        }
        // 2.4.0, host: the zombies awake in the host's world now (for its load figures, LanHostTiming).
        internal int AwakeZombies()
        {
            int awake=0;
            foreach(var h in _catalog) if(h.AI!=null && !h.AI.dead && h.AI.gameObject.activeInHierarchy) awake++;
            return awake;
        }
        // 2.4.0: no bone moved more than CorpseStill since the last pose sent.
        private static bool Still(NetPose[] last,NetPose[] now)
        {
            if(last==null || now==null || last.Length!=now.Length || now.Length==0) return false;
            for(int i=0;i<now.Length;i++) {
                float dx=now[i].X-last[i].X, dy=now[i].Y-last[i].Y, dz=now[i].Z-last[i].Z;
                if(dx*dx+dy*dy+dz*dz>CorpseStill*CorpseStill) return false;
            }
            return true;
        }
        private static NetPose Pose(Transform t)
        {
            var p=t.position; var q=t.rotation;
            return new NetPose {X=p.x,Y=p.y,Z=p.z,QX=q.x,QY=q.y,QZ=q.z,QW=q.w};
        }
        private float Distance(HostZombie h,Remote to)
        {
            var position=h.AI!=null?h.AI.transform.position:new Vector3(h.Last.X,h.Last.Y,h.Last.Z);
            var player=LocalPlayer();
            float local=player==null?float.PositiveInfinity:(position-player.transform.position).sqrMagnitude;
            return to.Ready?Mathf.Min(local,(position-to.Position).sqrMagnitude):local;
        }

        private static Animator VisualAnimator(Component source)
        {
            foreach(var animator in source.GetComponentsInChildren<Animator>(true))
                if(animator.runtimeAnimatorController!=null) return animator;
            return null;
        }

        // Guest: the host's zombies, hurts, corpses and effects, and its combat state.
        internal void Receive(Packet p)
        {
            if(_disposed || _host || !_ready || p.WorldEpoch!=_epoch || p.Scene!=_scene) return;
            if(p.Kind==PacketKind.CombatProposal || p.Kind==PacketKind.CombatState) { Combat.Receive(p);return; }
            if(p.Kind==PacketKind.ZombieState) {
                BuildPrefabCatalog();
                _receivedFrames+=p.Zombies.Length;
                // The fastest batches set the offset; it creeps up slowly if the path gets slower,
                // and follows at once after a host restart or a long stall.
                float sample=Time.unscaledTime-p.HostTime;
                if(!_haveClock || sample<_clockOffset || sample-_clockOffset>1.5f) { _clockOffset=sample;_haveClock=true; }
                else _clockOffset+=(sample-_clockOffset)*.01f;
                _jitter+=(Mathf.Clamp(sample-_clockOffset,0,.5f)-_jitter)*.05f;
                foreach(var z in p.Zombies) QueueFrame(z,p.Sequence,p.HostTime);
            } else if(p.Kind==PacketKind.ZombieCorpse) {
                ApplyCorpse(p.Corpse,p.Sequence);
            } else if(p.Kind==PacketKind.ZombieEffect) {
                if(!Newer(p.Sequence,_lastEffect)) return;
                _lastEffect=p.Sequence; ShowEffect(p);
            } else if(p.Kind==PacketKind.ZombieHurt) {
                if(!_playerReady) return;
                if(p.Sequence==_lastHurt) { _send(Message(PacketKind.ZombieHurtAck,p.Sequence)); return; }
                if(p.Sequence!=_lastHurt+1) return; // Host sends one outstanding result, in order, until acknowledged.
                var player=LocalPlayer(); var health=player==null?null:player.zombieFighterIndicatorsBar;
                if(health==null) return;
                if(p.Action==LanProtocol.HurtMelee) MeleeEffects(player,health,p.Damage,p.Text);
                else if(p.Action==LanProtocol.HurtCharge) ChargeKnock(player,health,p);
                else if(p.Action==LanProtocol.HurtSteal) TongueGrab(player,health,p);
                else health.CauseDamage(p.Damage,false,false,(DamageType)p.Action);
                _lastHurt=p.Sequence; _send(Message(PacketKind.ZombieHurtAck,p.Sequence));
            }
        }

        // Host (2.0.0): a guest's (slot) shot, swing, reload, hurt acknowledgement or combat proposal.
        internal void Receive(int slot,Packet p)
        {
            Remote r;
            if(_disposed || !_host || !_ready || p.WorldEpoch!=_epoch || p.Scene!=_scene || !_remotes.TryGetValue(slot,out r)) return;
            if(p.Kind==PacketKind.CombatProposal || p.Kind==PacketKind.CombatState) { r.Combat.Receive(p);return; }
            if(!r.Ready) return;
            if(p.Kind==PacketKind.ZombieAction) ReceiveAction(r,p);
            else if(p.Kind==PacketKind.CombatReload) {
                if(!Newer(p.Sequence,r.LastAction)) return;
                r.LastAction=p.Sequence;r.Combat.Processed(p.Sequence);
                if(p.EquippedItemId==r.Item) r.Combat.Reload(p);
            }
            else if(p.Kind==PacketKind.ZombieHurtAck && r.Hurts.Count>0 && r.Hurts.Peek().Sequence==p.Sequence) { r.Hurts.Dequeue(); r.HurtAt=0; }
        }

        // 1.1.8: what an alive firefighter shows: its flamethrower firing (and in which hand), its burning hands.
        private static byte FlameFlags(ZombieAIController ai)
        {
            var skill=ai.flamethrower; if(skill==null) return 0;
            int flags=0; var gun=skill.flamethrower;
            if(gun!=null) {
                if(gun.Firing) flags|=LanProtocol.ZombieFlameFiring;
                if(ai.FirePosition!=null && ai.FirePosition.Length>1 && ai.FirePosition[1]!=null && gun.transform.parent==ai.FirePosition[1]) flags|=LanProtocol.ZombieFlameHand1;
            }
            var fire=skill.flameParticles;
            if(fire!=null && fire.Length>0 && fire[0]!=null && fire[0].isPlaying) flags|=LanProtocol.ZombieHandFire0;
            if(fire!=null && fire.Length>1 && fire[1]!=null && fire[1].isPlaying) flags|=LanProtocol.ZombieHandFire1;
            return (byte)flags;
        }

        private void QueueFrame(ZombieFrame frame, uint sequence, float hostTime)
        {
            uint id=frame.Id;
            if(id==0 || id>LanProtocol.MaxZombieIds || (_seen[id]!=0 && !Newer(sequence,_seen[id])) ||
                (_pendingFrames[id]!=null && !Newer(sequence,_pendingSequences[id]))) return;
            if((frame.Flags&LanProtocol.ZombieStateBits)!=0) {
                if(_pendingFrames[id]!=null) { _pendingFrames[id]=null;_pendingCount--; }
                Apply(frame,sequence,hostTime); return;
            }
            // A replica takes every frame into its timeline; only frames that would create one wait here.
            if(_pendingFrames[id]==null && _replicas.ContainsKey(id)) { Apply(frame,sequence,hostTime); return; }
            if(_pendingFrames[id]==null) {
                if(_pendingCount>=LanProtocol.MaxZombieReplicas) return;
                _pendingCount++;
            }
            _pendingFrames[id]=frame;_pendingSequences[id]=sequence;_pendingTimes[id]=hostTime;
        }
        private void ApplyPending()
        {
            var budget=Stopwatch.StartNew();int created=0;
            for(int visited=0;visited<LanProtocol.MaxZombieIds && _pendingCount>0 && budget.Elapsed.TotalMilliseconds<3;visited++) {
                if(_applyCursor>LanProtocol.MaxZombieIds) _applyCursor=1;
                uint id=(uint)_applyCursor++;var frame=_pendingFrames[id];
                if(frame==null) continue;
                if(!_replicas.ContainsKey(id) && created++>=2) break;
                _pendingFrames[id]=null;_pendingCount--;Apply(frame,_pendingSequences[id],_pendingTimes[id]);
            }
        }

        private void Apply(ZombieFrame z,uint sequence,float hostTime)
        {
            if(z.Id==0 || z.Id>LanProtocol.MaxZombieIds || (_seen[z.Id]!=0 && !Newer(sequence,_seen[z.Id]))) return;
            _seen[z.Id]=sequence;
            Replica r;
            int state=z.Flags&LanProtocol.ZombieStateBits;
            if(state!=0) {
                if((state&1)!=0) _dead[z.Id]=true;
                if(!_replicas.TryGetValue(z.Id,out r)) return;
                if((state&1)!=0) Killed(r);
                // Dead and still present at the host: keep the body (its pose comes
                // with ZombieCorpse). Deactivated or destroyed there: remove it here.
                if(state==1) { MarkDead(r); r.Seen=Time.unscaledTime; return; }
                Object.Destroy(r.Root); _replicas.Remove(z.Id);
                return;
            }
            if(_dead[z.Id]) return;
            ZombieAIController prefab;
            if(!_prefabs.TryGetValue(z.Prefab,out prefab) || prefab==null) {
                if(_unknownPrefabs.Count<256 && _unknownPrefabs.Add(z.Prefab))
                    _report(LanText.T("Неизвестная локальная модель зомби; zombieId=") + z.Id + LanText.T("; каталог=") + _prefabs.Count);
                return;
            }
            if(_failedPrefabs.Contains(z.Prefab)) return;
            if(!_replicas.TryGetValue(z.Id,out r)) {
                if(_replicas.Count>=LanProtocol.MaxZombieReplicas) return;
                try { r=CreateVisual(prefab); }
                catch(Exception ex) { _failedPrefabs.Add(z.Prefab);_report(LanText.T("Не удалось создать модель зомби ") + z.Prefab + ": " + ex.GetType().Name + ": " + ex.Message);return; }
                r.Prefab=z.Prefab; _replicas.Add(z.Id,r);
                if(_flameFailure!=null) { _report(LanText.T("Огонь пожарного не показан: ")+_flameFailure); _flameFailure=null; }
                r.Root.transform.position=new Vector3(z.X,z.Y,z.Z);
                r.Root.transform.rotation=Quaternion.Euler(0,z.Yaw,0);
                _createdReplicas++;
            }
            if(r.Prefab!=z.Prefab || r.Dead) return;
            r.Position=new Vector3(z.X,z.Y,z.Z); r.Rotation=Quaternion.Euler(0,z.Yaw,0); r.Seen=Time.unscaledTime;
            r.Root.SetActive(true); r.SeenAlive=true;
            if(r.SnapCount!=0) {
                float gap=hostTime-r.Snaps[r.SnapCount-1].T;
                if(gap<=0) return; // same or older host moment
                if(gap<1) r.Interval+=(gap-r.Interval)*.2f;
                else r.SnapCount=0; // after a long gap the old frames are history
            }
            if(r.SnapCount==r.Snaps.Length) { Array.Copy(r.Snaps,1,r.Snaps,0,r.Snaps.Length-1); r.SnapCount--; }
            r.Snaps[r.SnapCount++]=new Snap {T=hostTime,P=r.Position,Yaw=z.Yaw,Animation=z.Animation,AnimationTime=z.AnimationTime,Flags=z.AnimationFlags,Fx=(byte)(z.Flags&~LanProtocol.ZombieStateBits)};
        }
        // Position and facing at host time `at`: between the two frames around it, a short
        // extrapolation past the newest one, or the oldest one before the timeline starts.
        private static void Sample(Replica r,float at,out Vector3 position,out float yaw)
        {
            var first=r.Snaps[0]; var last=r.Snaps[r.SnapCount-1];
            if(at<=first.T) { position=first.P;yaw=first.Yaw;return; }
            if(at>=last.T) {
                position=last.P;yaw=last.Yaw;
                if(r.SnapCount<2) return;
                var prev=r.Snaps[r.SnapCount-2]; float span=last.T-prev.T;
                if(span<.01f || span>.5f) return;
                var velocity=(last.P-prev.P)/span;
                if(velocity.sqrMagnitude<400) position+=velocity*Mathf.Min(at-last.T,.15f);
                return;
            }
            int i=r.SnapCount-2; while(i>0 && r.Snaps[i].T>at) i--;
            var a=r.Snaps[i]; var b=r.Snaps[i+1]; float f=Mathf.Clamp01((at-a.T)/Mathf.Max(.001f,b.T-a.T));
            position=Vector3.Lerp(a.P,b.P,f); yaw=Mathf.LerpAngle(a.Yaw,b.Yaw,f);
        }
        // 1.0.1: the host's bool parameters drive the copy's own state machine. 1.0.7: a different
        // state is forced only when it lasts (a missed transition), not while both are mid-change,
        // where forcing it snapped the copy back and forth.
        private static void ApplyAnimation(Replica r,Snap s)
        {
            if(r.Flame!=null) ApplyFlame(r.Flame,s.Fx);
            if(r.Animator==null || !r.Animator.isInitialized) return;
            ApplyBoolFlags(r.Animator,s.Flags);
            if(s.Animation==0 || !r.Animator.HasState(0,s.Animation) || InState(r.Animator,s.Animation)) { r.MismatchSince=-1f;r.ForcePlay=false;return; }
            float now=Time.unscaledTime;
            if(!r.ForcePlay) {
                if(r.MismatchSince<0) { r.MismatchSince=now;return; }
                if(now-r.MismatchSince<.4f) return;
            }
            r.Animator.Play(s.Animation,0,s.AnimationTime); r.MismatchSince=-1f;r.ForcePlay=false;
        }
        private static bool InState(Animator animator,int state)
        {
            return animator.GetCurrentAnimatorStateInfo(0).fullPathHash==state ||
                animator.IsInTransition(0) && animator.GetNextAnimatorStateInfo(0).fullPathHash==state;
        }
        // Bool parameters (name hashes) of each zombie controller, in controller order; at most 32.
        private static readonly Dictionary<RuntimeAnimatorController,int[]> _boolParameters=new Dictionary<RuntimeAnimatorController,int[]>();
        private static int[] BoolParameters(Animator animator)
        {
            int[] hashes; var controller=animator.runtimeAnimatorController;
            if(controller==null || !animator.isInitialized) return new int[0];
            if(_boolParameters.TryGetValue(controller,out hashes)) return hashes;
            var list=new List<int>();
            foreach(var parameter in animator.parameters) if(parameter.type==AnimatorControllerParameterType.Bool && list.Count<32) list.Add(parameter.nameHash);
            hashes=list.ToArray(); if(_boolParameters.Count<64) _boolParameters[controller]=hashes;
            return hashes;
        }
        private static uint BoolFlags(Animator animator)
        {
            var hashes=BoolParameters(animator); uint flags=0;
            for(int i=0;i<hashes.Length;i++) if(animator.GetBool(hashes[i])) flags|=1u<<i;
            return flags;
        }
        private static void ApplyBoolFlags(Animator animator,uint flags)
        {
            var hashes=BoolParameters(animator);
            for(int i=0;i<hashes.Length;i++) animator.SetBool(hashes[i],(flags&(1u<<i))!=0);
        }

        // Client: a host ragdoll pose. Creates the body if this client never saw the
        // zombie alive (joined later, or it died far away).
        private void ApplyCorpse(CorpseFrame c,uint sequence)
        {
            if(!_ready || c==null || c.Id==0 || c.Id>LanProtocol.MaxZombieIds || (_corpseSeen[c.Id]!=0 && !Newer(sequence,_corpseSeen[c.Id]))) return;
            _corpseSeen[c.Id]=sequence; _dead[c.Id]=true;
            Replica r;
            bool created=false;
            if(!_replicas.TryGetValue(c.Id,out r)) {
                ZombieAIController prefab;
                if(_replicas.Count>=LanProtocol.MaxZombieReplicas || _failedPrefabs.Contains(c.Prefab) || !_prefabs.TryGetValue(c.Prefab,out prefab) || prefab==null) return;
                try { r=CreateVisual(prefab); }
                catch(Exception ex) { _failedPrefabs.Add(c.Prefab);_report(LanText.T("Не удалось создать модель зомби ") + c.Prefab + ": " + ex.GetType().Name + ": " + ex.Message);return; }
                r.Prefab=c.Prefab; _replicas.Add(c.Id,r); _createdReplicas++; created=true;
            }
            if(r.Prefab!=c.Prefab) return;
            Killed(r);
            MarkDead(r);
            float now=Time.unscaledTime;
            r.Position=new Vector3(c.X,c.Y,c.Z); r.Rotation=Quaternion.Euler(0,c.Yaw,0); r.Seen=now;
            bool valid=c.Bones.Length==r.Bones.Length;
            if(valid) foreach(var bone in c.Bones)
                if((new Vector3(bone.X,bone.Y,bone.Z)-r.Position).sqrMagnitude>100f) { valid=false; break; } // a body is not 10 m long
            // 2.4.0: the glide starts from the pose shown now (the last moment of its life, frozen when its death was
            // reported, or the previous ragdoll pose), taken before the root moves; a body made just now takes it at once.
            int n=r.Bones.Length;
            if(valid && (r.CorpseToP==null || r.CorpseToP.Length!=n)) { r.CorpseFromP=new Vector3[n]; r.CorpseToP=new Vector3[n]; r.CorpseFromR=new Quaternion[n]; r.CorpseToR=new Quaternion[n]; }
            if(valid) for(int i=0;i<n;i++) if(r.Bones[i]!=null) { r.CorpseFromP[i]=r.Bones[i].position; r.CorpseFromR[i]=r.Bones[i].rotation; }
            r.Root.transform.SetPositionAndRotation(r.Position,r.Rotation);
            r.Root.SetActive(true);
            if(!valid) return;
            for(int i=0;i<n;i++) { var b=c.Bones[i]; r.CorpseToP[i]=new Vector3(b.X,b.Y,b.Z); r.CorpseToR[i]=new Quaternion(b.QX,b.QY,b.QZ,b.QW); }
            bool first=r.CorpseLast<0;
            r.CorpseFor=created ? 0f : first ? .15f : Mathf.Clamp(now-r.CorpseLast,.05f,.4f);
            r.CorpseAt=now; r.CorpseLast=now;
            GlideCorpse(r,now);
        }
        // 2.4.0, client: a corpse's bones on the way from the pose they showed to the host's newest ragdoll pose,
        // parents first (each bone in world space), ending exactly on it.
        private static void GlideCorpse(Replica r,float now)
        {
            if(r.CorpseFor<0 || r.CorpseToP==null || r.BoneOrder==null) return;
            float t=r.CorpseFor<=0?1f:Mathf.Clamp01((now-r.CorpseAt)/r.CorpseFor);
            t=t*t*(3f-2f*t);
            foreach(int i in r.BoneOrder) {
                if(i<0 || i>=r.Bones.Length || r.Bones[i]==null) continue;
                if(t>=1f) r.Bones[i].SetPositionAndRotation(r.CorpseToP[i],r.CorpseToR[i]);
                else r.Bones[i].SetPositionAndRotation(Vector3.Lerp(r.CorpseFromP[i],r.CorpseToP[i],t),Quaternion.Slerp(r.CorpseFromR[i],r.CorpseToR[i],t));
            }
            if(t>=1f) r.CorpseFor=-1f;
        }
        // 1.4.11: the game gives every player a zombie's experience when it dies (ZombieDamagDetector.Dead,
        // which the client's copies never run): the client takes it, as the game would, when a zombie it saw
        // alive dies at the host while it plays in the host's world. The host credits the same experience
        // to the guest's checked stats (LanGuestCredits), so the guest's levels are kept.
        private void Killed(Replica r)
        {
            if(_host || r.Dead || !r.SeenAlive || !_playerReady) return;
            ZombieAIController prefab;
            var player=LocalPlayer();
            if(!_prefabs.TryGetValue(r.Prefab,out prefab) || prefab==null || player==null || player.zFLevelController==null) return;
            try {
                var detector=prefab.GetComponentInChildren<ZombieDamagDetector>(true);
                if(detector==null || !(detector.XPReward>0) || float.IsInfinity(detector.XPReward)) return;
                player.zFLevelController.AddExperience(detector.XPReward); _experience+=detector.XPReward;
            }
            catch(Exception ex) { if(!_experienceFailed) { _experienceFailed=true; _report("Zombie experience not given: "+ex.GetType().Name+": "+ex.Message); } }
        }
        private float _experience;
        private bool _experienceFailed;
        private static void MarkDead(Replica r)
        {
            if(r.Dead) return;
            r.Dead=true;
            if(r.Flame!=null) ApplyFlame(r.Flame,0);
            if(r.Animator!=null) r.Animator.enabled=false;
            foreach(var collider in r.Root.GetComponents<Collider>()) collider.enabled=false;
        }

        // Copy only transforms, meshes and a locally trusted animator. No prefab Awake, native AI,
        // native HP, loot, dismemberment, save registration or animation-event receivers are cloned.
        private static Replica CreateVisual(ZombieAIController prefab)
        {
            var root=new GameObject("LAN zombie visual"); root.SetActive(false);
            try {
            var map=new Dictionary<Transform,Transform>();
            CopyHierarchy(prefab.transform,root.transform,map,0);
            foreach(var source in prefab.GetComponentsInChildren<SkinnedMeshRenderer>(true)) {
                Transform t; if(!map.TryGetValue(source.transform,out t)) continue;
                var dest=t.gameObject.AddComponent<SkinnedMeshRenderer>(); dest.sharedMesh=source.sharedMesh; dest.sharedMaterials=source.sharedMaterials;
                var bones=source.bones; var copied=new Transform[bones.Length];
                for(int i=0;i<bones.Length;i++) if(bones[i]!=null) map.TryGetValue(bones[i],out copied[i]);
                dest.bones=copied; Transform bone;
                if(source.rootBone!=null && map.TryGetValue(source.rootBone,out bone)) dest.rootBone=bone;
                dest.localBounds=source.localBounds; dest.enabled=source.enabled; dest.updateWhenOffscreen=true;
            }
            // The prefab's own Start() picks a random material; do the same for the copy (1.0.1).
            foreach(var random in prefab.GetComponentsInChildren<RandomMaterial>(true)) {
                Transform t; if(random.targetRenderer==null || random.materials==null || random.materials.Length==0 || !map.TryGetValue(random.targetRenderer.transform,out t)) continue;
                var copy=t.GetComponent<Renderer>(); if(copy!=null) copy.sharedMaterial=random.materials[UnityEngine.Random.Range(0,random.materials.Length)];
            }
            Animator animator=null; var sourceAnimator=VisualAnimator(prefab);
            Transform animatorTransform;
            if(sourceAnimator!=null && map.TryGetValue(sourceAnimator.transform,out animatorTransform)) {
                animator=animatorTransform.gameObject.AddComponent<Animator>(); animator.avatar=sourceAnimator.avatar;
                animator.runtimeAnimatorController=sourceAnimator.runtimeAnimatorController; animator.applyRootMotion=false;
                animator.cullingMode=AnimatorCullingMode.AlwaysAnimate;
            }
            // The ragdoll bones of this prefab, parents first, for corpse poses.
            var ragdoll=new List<Transform>(); var depths=new List<int>();
            var detector=prefab.GetComponentInChildren<ZombieDamagDetector>(true);
            if(detector!=null && detector.rigidElements!=null && detector.rigidElements.Length<=LanProtocol.MaxCorpseBones)
                foreach(var element in detector.rigidElements) {
                    Transform copy;
                    if(element==null || !map.TryGetValue(element,out copy)) { ragdoll.Clear(); depths.Clear(); break; }
                    ragdoll.Add(copy); int depth=0; for(var node=copy;node!=null && node!=root.transform;node=node.parent) depth++; depths.Add(depth);
                }
            var order=new int[ragdoll.Count]; for(int i=0;i<order.Length;i++) order[i]=i;
            Array.Sort(order,(a,b)=>depths[a].CompareTo(depths[b]));
            // A passive capsule provides body collision without native AI/damage scripts.
            var controller=prefab.GetComponent<CharacterController>();
            if(controller!=null) {
                var capsule=root.AddComponent<CapsuleCollider>();capsule.radius=Mathf.Clamp(controller.radius,.1f,1);
                capsule.height=Mathf.Clamp(controller.height,capsule.radius*2,3);capsule.center=controller.center;
                root.layer=2;
            }
            return new Replica {Root=root,Animator=animator,Bones=ragdoll.ToArray(),BoneOrder=order,Flame=CreateFlame(prefab,root,map),Limbs=LimbShapes(prefab,map)};
            } catch { Object.Destroy(root);throw; }
        }
        // 1.1.8: the firefighter's flamethrower effect and burning hands for the copy. A failure leaves
        // the copy without flames (reported once), never without the zombie.
        private static FlameVisual CreateFlame(ZombieAIController prefab,GameObject root,Dictionary<Transform,Transform> map)
        {
            var skill=prefab.flamethrower!=null?prefab.flamethrower:prefab.GetComponentInChildren<SkillFlamethrower>(true);
            if(skill==null) return null;
            try {
                var f=new FlameVisual();
                var gun=skill.flamethrower;
                if(gun!=null && gun.Effect!=null) {
                    var holder=new GameObject("LAN flamethrower"); holder.transform.SetParent(root.transform,false); f.Holder=holder.transform;
                    f.Turn=Quaternion.Inverse(prefab.transform.rotation)*gun.transform.rotation;
                    var effect=VisualPart(gun.Effect.gameObject,f.Holder);
                    effect.transform.localPosition=gun.transform.InverseTransformPoint(gun.Effect.transform.position);
                    effect.transform.localRotation=Quaternion.Inverse(gun.transform.rotation)*gun.Effect.transform.rotation;
                    effect.SetActive(true);
                    f.Jet=effect.GetComponentsInChildren<ParticleSystem>(true); f.JetLights=effect.GetComponentsInChildren<Light>(true);
                    var source=gun.GetComponent<AudioSource>(); var audio=holder.AddComponent<AudioSource>();
                    audio.playOnAwake=false; audio.loop=true; audio.clip=gun.AudioLoop; audio.spatialBlend=1f;
                    if(source!=null) {
                        audio.outputAudioMixerGroup=source.outputAudioMixerGroup; audio.volume=source.volume; audio.spatialBlend=source.spatialBlend;
                        audio.minDistance=source.minDistance; audio.maxDistance=source.maxDistance; audio.rolloffMode=source.rolloffMode;
                        audio.dopplerLevel=source.dopplerLevel; audio.spread=source.spread; audio.priority=source.priority;
                    }
                    f.Audio=audio; f.Start=gun.AudioStart; f.End=gun.AudioEnd;
                } else { f.Jet=new ParticleSystem[0]; f.JetLights=new Light[0]; }
                f.Hands=new Transform[prefab.FirePosition==null?0:prefab.FirePosition.Length];
                for(int i=0;i<f.Hands.Length;i++) { Transform hand; if(prefab.FirePosition[i]!=null && map.TryGetValue(prefab.FirePosition[i],out hand)) f.Hands[i]=hand; }
                var fire=skill.flameParticles; int count=fire==null?0:Math.Min(2,fire.Length);
                f.HandFire=new ParticleSystem[count][]; f.HandLights=new GameObject[count];
                for(int i=0;i<count;i++) {
                    Transform parent;
                    if(fire[i]==null || fire[i].transform.parent==null || !map.TryGetValue(fire[i].transform.parent,out parent)) continue;
                    var copy=VisualPart(fire[i].gameObject,parent); copy.SetActive(true);
                    f.HandFire[i]=copy.GetComponentsInChildren<ParticleSystem>(true);
                    var light=skill.flameLight!=null && i<skill.flameLight.Length?skill.flameLight[i]:null;
                    if(light==null || light.transform==fire[i].transform) continue;
                    if(light.transform.IsChildOf(fire[i].transform)) { var found=copy.transform.Find(PathBelow(fire[i].transform,light.transform)); if(found!=null) f.HandLights[i]=found.gameObject; }
                    else { Transform lightParent; if(light.transform.parent!=null && map.TryGetValue(light.transform.parent,out lightParent)) f.HandLights[i]=VisualPart(light,lightParent); }
                }
                foreach(var system in AllParticles(f)) { var main=system.main; main.playOnAwake=false; }
                ApplyFlame(f,0);
                return f;
            } catch(Exception ex) { _flameFailure=prefab.ID+": "+ex.GetType().Name+": "+ex.Message; return null; }
        }
        private static IEnumerable<ParticleSystem> AllParticles(FlameVisual f)
        {
            foreach(var system in f.Jet) if(system!=null) yield return system;
            foreach(var hand in f.HandFire) if(hand!=null) foreach(var system in hand) if(system!=null) yield return system;
        }
        // A prefab part's own particles, lights and renderers only: its scripts, colliders, bodies
        // and sounds are removed while the copy is still inactive (nothing of it ever woke up).
        private static GameObject VisualPart(GameObject source,Transform parent)
        {
            var staging=new GameObject("LAN staging"); staging.SetActive(false);
            try {
                var copy=Object.Instantiate(source,staging.transform,false);
                foreach(var script in copy.GetComponentsInChildren<MonoBehaviour>(true)) Object.DestroyImmediate(script);
                foreach(var collider in copy.GetComponentsInChildren<Collider>(true)) Object.DestroyImmediate(collider);
                foreach(var body in copy.GetComponentsInChildren<Rigidbody>(true)) Object.DestroyImmediate(body);
                foreach(var audio in copy.GetComponentsInChildren<AudioSource>(true)) Object.DestroyImmediate(audio);
                copy.transform.SetParent(parent,false);
                return copy;
            } finally { Object.Destroy(staging); }
        }
        private static string PathBelow(Transform top,Transform node)
        {
            var names=new List<string>();
            for(var t=node;t!=null && t!=top;t=t.parent) names.Add(t.name);
            names.Reverse(); return string.Join("/",names.ToArray());
        }
        // Switches the copy's flames to the host's bits (only what changed).
        private static void ApplyFlame(FlameVisual f,byte fx)
        {
            if(f.Shown==fx) return;
            bool fresh=f.Shown==255, firing=(fx&LanProtocol.ZombieFlameFiring)!=0, wasFiring=!fresh && (f.Shown&LanProtocol.ZombieFlameFiring)!=0;
            if(f.Holder!=null && firing) {
                int hand=(fx&LanProtocol.ZombieFlameHand1)!=0?1:0;
                var at=hand<f.Hands.Length?f.Hands[hand]:null;
                if(at!=null && f.Holder.parent!=at) { f.Holder.SetParent(at,true); f.Holder.localPosition=Vector3.zero; } // keeps the world scale
            }
            if(fresh || firing!=wasFiring) {
                foreach(var system in f.Jet) if(system!=null) { if(firing) system.Play(true); else system.Stop(true,fresh?ParticleSystemStopBehavior.StopEmittingAndClear:ParticleSystemStopBehavior.StopEmitting); }
                foreach(var light in f.JetLights) if(light!=null) light.enabled=firing;
                if(f.Audio!=null && !fresh) {
                    float volume=GlobalSoundEffects.global==null?1f:Mathf.Clamp01(GlobalSoundEffects.global.EffectsVolume);
                    if(firing) { if(f.Start!=null) f.Audio.PlayOneShot(f.Start,volume); if(f.Audio.clip!=null) f.Audio.Play(); }
                    else { f.Audio.Stop(); if(f.End!=null) f.Audio.PlayOneShot(f.End,volume); }
                }
            }
            for(int i=0;i<f.HandFire.Length;i++) {
                int bit=i==0?LanProtocol.ZombieHandFire0:LanProtocol.ZombieHandFire1;
                bool on=(fx&bit)!=0;
                if(!fresh && on==((f.Shown&bit)!=0)) continue;
                if(f.HandFire[i]!=null) foreach(var system in f.HandFire[i]) if(system!=null) { if(on) system.Play(true); else system.Stop(true,fresh?ParticleSystemStopBehavior.StopEmittingAndClear:ParticleSystemStopBehavior.StopEmitting); }
                if(f.HandLights[i]!=null) f.HandLights[i].SetActive(on);
            }
            f.Shown=fx;
        }
        private static void CopyHierarchy(Transform source,Transform target,Dictionary<Transform,Transform> map,int depth)
        {
            if(depth>32 || map.Count>=512) return;
            map.Add(source,target); target.localPosition=source.localPosition; target.localRotation=source.localRotation; target.localScale=source.localScale;
            var filter=source.GetComponent<MeshFilter>(); var renderer=source.GetComponent<MeshRenderer>();
            if(filter!=null && renderer!=null) { target.gameObject.AddComponent<MeshFilter>().sharedMesh=filter.sharedMesh; var copy=target.gameObject.AddComponent<MeshRenderer>(); copy.sharedMaterials=renderer.sharedMaterials; copy.enabled=renderer.enabled; }
            for(int i=0;i<source.childCount && depth<32 && map.Count<512;i++) { var child=source.GetChild(i); var obj=new GameObject(child.name); obj.transform.SetParent(target,false); CopyHierarchy(child,obj.transform,map,depth+1); obj.SetActive(child.gameObject.activeSelf && NativeVisible(child)); }
        }
        // What the prefab's own Start() would hide (1.0.1): decorations of a season other than the
        // current one (SeasonalEventObject) and accessories that lose their roll (RandomActivator).
        private static bool NativeVisible(Transform source)
        {
            var seasonal=source.GetComponent<SeasonalEventObject>();
            if(seasonal!=null && !SeasonActive((int)seasonal.Event)) return false;
            var random=source.GetComponent<RandomActivator>();
            return random==null || UnityEngine.Random.Range(0,100)<random.activationChanceMAX;
        }
        private static bool SeasonActive(int season)
        {
            switch(season) {
                case 0: return SeasonalEvents.IsCurrentlyNewYear();
                case 1: return SeasonalEvents.IsCurrentlyHalloween();
                case 2: return SeasonalEvents.IsCurrentlyAprilFoolsDay();
                default: return true;
            }
        }

        private void ReceiveAction(Remote r,Packet p)
        {
            if(!Newer(p.Sequence,r.LastAction)) return;
            r.LastAction=p.Sequence;r.Combat.Processed(p.Sequence);
            float now=Time.unscaledTime;
            if(now<r.NextAction-(float)HostCombatInventory.Jitter || p.EquippedItemId!=r.Item) return;
            var origin=new Vector3(p.X,p.Y,p.Z); var aim=new Vector3(p.AimX,p.AimY,p.AimZ);
            if(Vector3.Distance(origin,r.Position+Vector3.up*1.5f)>1.75f || Mathf.Abs(aim.sqrMagnitude-1)>.01f) return;
            if(float.IsNaN(r.Yaw) || float.IsInfinity(r.Yaw)) return;
            var flat=new Vector3(aim.x,0,aim.z);
            if(flat.sqrMagnitude>.01f && Vector3.Angle(flat,Quaternion.Euler(0,r.Yaw,0)*Vector3.forward)>95) return;
            if(Physics.Linecast(r.Position+Vector3.up*1.5f,origin,~0,QueryTriggerInteraction.Ignore)) return;
            WeaponData weapon=null; Gun gun=null;
            if(p.EquippedItemId==-1) gun=LanCombatSync.FistGun(); // 1.1.6: a swing of the bare fists
            else {
                var db=ItemsDataBase.Global; var items=db==null?null:db.itemPrefab;
                if(items==null || p.EquippedItemId<0 || p.EquippedItemId>=items.Length || items[p.EquippedItemId]==null) return;
                weapon=items[p.EquippedItemId].GetComponent<WeaponData>();
                var player=LocalPlayer(); var guns=player==null || player.zombieFighterFireArmWeapon==null?null:player.zombieFighterFireArmWeapon.gunList;
                if(weapon==null || guns==null) return;
                foreach(var candidate in guns) if(candidate!=null && candidate.ID==weapon.ID) { gun=candidate; break; }
            }
            if(gun==null) return;
            float damage,range,interval; BulletScript bullet=null; int mask;
            if(p.Action==0) {
                var round=Round(gun); // 1.5.0: a bow's arrow
                if(weapon==null || gun.weaponType!=0 || round==null) return;
                bullet=round.GetComponent<BulletScript>(); if(bullet==null) return;
                damage=Mathf.Clamp(bullet.bulletDamage,0,200); range=100; mask=bullet.targetRaycastMask.value;
                if(gun.bow!=null) {
                    // 1.5.0: as the game's Bow.TryShot: 5% more a strength level of the archer, and the bow's own bonus.
                    var archer=r.Combat.Ledger==null?null:r.Combat.Ledger();
                    int strength=archer==null?1:archer.StrengthLevel;
                    damage=Mathf.Clamp(bullet.bulletDamage*(1f+.05f*(strength-1))*(1f+Mathf.Clamp(gun.bow.DamageMultiplier,0f,10f)),0,400);
                }
                interval=Mathf.Max(.05f,gun.currentBetweenShotsTime);
            } else {
                if(gun.weaponType!=2 || gun.Hands!=(weapon==null)) return;
                // The fists' own strength (the game never replaces it with an item's). 1.4.20: a weapon's too, as the game's
                // swing (Gun.GetMeleeDamage: the gun's melee strength, 5% more a strength level) with the guest's own
                // strength level; it took the lesser of the item's listed damage and the gun's strength, with no level, so
                // the guest's blows were weaker than the host's with the same weapon.
                var book=r.Combat.Ledger==null?null:r.Combat.Ledger();
                int strength=book==null?1:book.StrengthLevel;
                damage=Mathf.Clamp(gun.meleeAttackStrength*(1f+.05f*(strength-1)),0,200);
                range=Mathf.Clamp(gun.meleeAttacRange,0,3); interval=Mathf.Max(.5f,gun.meleeStrikeTimeForAttackEnd); mask=gun.targetRaycastMask.value;
            }
            if(damage<=0) return;
            if(!r.Combat.Spend(p)) return;
            r.NextAction=Mathf.Max(r.NextAction,now)+interval; // jitter-tolerant average rate (1.0.1)
            // Resolve the silencer from the reconciled guest weapon and host prefab;
            // the packet's numeric noise claim is not authoritative.
            if(p.Action==0) Gun.AttractByNoise(origin,Mathf.Clamp(gun.shotHearingRadius,0,500)*r.Combat.NoiseMultiplier(p.EquippedItemId,gun));
            // 1.0.7: a firearm round is the host gun's own native bullet from the guest's eye, so hits,
            // head and limb damage, armour, blood and deaths are the game's. Arrows stay a ray here:
            // a native arrow would leave a new pickup in the host world.
            // 1.5.0: a round the guest saw hit a zombie on its screen (where the zombie was a moment ago there) goes in as the
            // game's own round of this gun from just before that limb, as the guest's went in: head x2, armour, blood and
            // the rest stay the game's. The zombie here has moved on meanwhile, and a round from the guest's eye met its
            // head or anything at all only by luck. Rounds that hit no zombie there still leave the guest's eye.
            if(p.Action==0 && !bullet.arrow) {
                int rounds=Mathf.Clamp(gun.ProjectilesInShot,1,16), claimed=0;
                if(p.Hits!=null)
                    foreach(var c in p.Hits) {
                        Vector3 from,toward; RaycastHit struck;
                        if(claimed<rounds && Claimed(c,origin,range,mask,out from,out toward,out struck)) { FireRound(gun,from,toward); claimed++; _claimTaken++; }
                    }
                else _claimNone++;
                ClaimReport();
                if(claimed<rounds) FireNative(gun,origin,aim,rounds-claimed);
                return;
            }
            // The native layer mask: with every layer the zombie's own body capsule (CharacterController)
            // was nearer than its limb hitboxes, and the ray dealt no damage.
            RaycastHit hit;
            // 1.5.0: a swing at the limb the guest saw it meet, when this world can stand by it; else along its aim here.
            if(!((p.Action!=0 || bullet.arrow) && ClaimedHit(p.Hits,origin,range,mask,out hit)) && (!Physics.Raycast(origin,aim,out hit,range,mask) || hit.collider==null)) return;
            var zombie=hit.collider.GetComponentInParent<ZombieAIController>(); HostZombie h;
            if(zombie==null || zombie.dead || zombie.zombieHP==null || !_hostIds.TryGetValue(zombie.GetInstanceID(),out h)) return;
            var limb=hit.collider.GetComponent<LimbDetector>();
            if(limb==null || limb.deadVersionZombie || limb.zombieHP!=zombie.zombieHP) return; // Shields/armor props cannot be treated as exposed flesh.
            if(p.Action==0 && limb.armored>bullet.armorPenetration) return;
            // 1.4.13: as the game's: a swing counts the difficulty's share; the weapon's stealth bonus counts for a
            // swing at a zombie that noticed no player, for an arrow at one that does not hunt (waits or walks).
            if(p.Action!=0 && DifficultyManager.Global!=null) damage*=Mathf.Clamp(DifficultyManager.Global.ZombieHP,.1f,10f);
            if(weapon!=null && (p.Action!=0 ? h.Chased==null && Time.time>=h.KeepRemoteUntil && !zombie.playerIsInSight && !zombie.aiHeardPlayer : zombie.state=="Wait" || zombie.state=="Walk"))
                damage*=Mathf.Clamp(weapon.stealthModifier,0,10);
            if(p.Action!=0) MeleeHitEffects(zombie,limb,hit,gun); // 1.4.11: before the damage, as natively
            zombie.zombieHP.CauseDamage(limb.limbID==0 ? damage*2 : damage); // a head hit counts double, as natively
        }
        // 1.4.11, host: what the game's own swing does to a zombie besides the damage (Gun.MeleeHitTarget): a
        // wound and blood where it landed, the body-hit and pain sounds and the stun that plays its hit
        // animation (the guest sees it in the zombie's frames), the push its body falls with.
        private void MeleeHitEffects(ZombieAIController zombie,LimbDetector limb,RaycastHit hit,Gun gun)
        {
            try {
                var effects=GlobalEffects.Global;
                if(effects!=null && effects.bloodHole!=null && effects.bloodHole.Length!=0) {
                    var hole=effects.bloodHole[UnityEngine.Random.Range(0,effects.bloodHole.Length)];
                    if(hole!=null) Object.Instantiate(hole,hit.point+hit.normal*.1f,Quaternion.LookRotation(-hit.normal)).parent=hit.transform;
                }
                var detector=zombie.zombieDamagDetector;
                if(detector!=null) {
                    detector.DetectionBulletHits(); detector.SetLastHittedBodyPart(limb);
                    if(gun.meleeAttacPushForceRatio>0f) detector.pushingVector=-hit.normal*gun.meleeAttacPushForce/gun.meleeAttacPushForceRatio;
                }
                if(effects!=null) effects.SpawnBloodDecal(hit.point,hit.normal,zombie.transform.position);
                if(gun.meleeHitBodySound!=null) AudioSource.PlayClipAtPoint(gun.meleeHitBodySound,hit.point);
            }
            catch(Exception ex) { if(!_swingFailed) { _swingFailed=true; _report("Swing effects failed: "+ex.GetType().Name+": "+ex.Message); } }
        }
        private bool _swingFailed;

        // 1.4.11, guest: its swing at a zombie copy, which has no colliders (the game's own hit met what was
        // behind it): the game's wound, blood and body-hit sound where it lands, at once. The host deals the
        // damage; the zombie's flinch comes with its frames.
        private static bool BeforeMeleeHit(Gun __instance)
        {
            var a=Active;
            if(!IsClientWorld || a==null || a._host || !a._playerReady || __instance==null) return true;
            a.SwingLands(__instance); // 1.5.0
            try {
                var camera=Camera.main; if(camera==null) return true;
                var origin=camera.transform.TransformPoint(new Vector3(0,0,-.2f)); var aim=camera.transform.forward;
                float range=Mathf.Clamp(__instance.meleeAttacRange,0,3)-.2f;
                if(range<=0f) return true;
                RaycastHit wall;
                if(Physics.Raycast(origin,aim,out wall,range,__instance.targetRaycastMask.value)) range=wall.distance;
                Replica r; Transform bone; Vector3 point;
                if(!a.SwingHits(origin,aim,range,out r,out bone,out point)) return true;
                var effects=GlobalEffects.Global;
                if(effects!=null && effects.bloodHole!=null && effects.bloodHole.Length!=0) {
                    var hole=effects.bloodHole[UnityEngine.Random.Range(0,effects.bloodHole.Length)];
                    if(hole!=null) Object.Instantiate(hole,point-aim*.1f,camera.transform.rotation).parent=bone;
                }
                if(effects!=null) effects.SpawnBloodDecal(point,-aim,r.Root.transform.position);
                if(__instance.meleeHitBodySound!=null) AudioSource.PlayClipAtPoint(__instance.meleeHitBodySound,point);
                return false;
            }
            catch(Exception ex) { if(!a._swingFailed) { a._swingFailed=true; a._report("Swing effects failed: "+ex.GetType().Name+": "+ex.Message); } return true; }
        }
        // 2.4.3, guest: a live zombie copy within `radius` of `at` (its own world's zombies are switched off here), for
        // a host sleeping bag (LanSleep), which the game refuses with a zombie that near.
        internal static bool LiveZombieNear(Vector3 at,float radius)
        {
            var a=Active;
            if(a==null || a._host) return false;
            float limit=radius*radius;
            foreach(var r in a._replicas.Values)
                if(r.Root!=null && r.Root.activeInHierarchy && !r.Dead && (r.Root.transform.position-at).sqrMagnitude<=limit) return true;
            return false;
        }
        // The nearest live zombie copy the swing meets before `range`: its ragdoll bones and the middle of
        // each bone's reach to its parent, or a column from its feet to its head when it has none.
        private bool SwingHits(Vector3 origin,Vector3 aim,float range,out Replica hit,out Transform bone,out Vector3 point)
        {
            hit=null; bone=null; point=Vector3.zero; float best=range;
            const float Radius=.22f;
            foreach(var r in _replicas.Values) {
                if(r.Root==null || !r.Root.activeInHierarchy || r.Dead || (r.Root.transform.position-origin).sqrMagnitude>(range+3f)*(range+3f)) continue;
                var samples=new List<KeyValuePair<Vector3,Transform>>();
                if(r.Bones!=null && r.Bones.Length!=0)
                    foreach(var b in r.Bones) {
                        if(b==null) continue;
                        samples.Add(new KeyValuePair<Vector3,Transform>(b.position,b));
                        if(b.parent!=null && (b.parent.position-b.position).sqrMagnitude<.64f) samples.Add(new KeyValuePair<Vector3,Transform>((b.position+b.parent.position)*.5f,b));
                    }
                else for(int i=0;i<7;i++) samples.Add(new KeyValuePair<Vector3,Transform>(r.Root.transform.position+Vector3.up*(.2f+i*.25f),r.Root.transform));
                foreach(var s in samples) {
                    float along=Vector3.Dot(s.Key-origin,aim);
                    if(along<0f || along>best) continue;
                    var near=origin+aim*along;
                    if((s.Key-near).sqrMagnitude>Radius*Radius) continue;
                    best=along; hit=r; bone=s.Value; point=near;
                }
            }
            return hit!=null;
        }

        private static void FireNative(Gun gun,Vector3 origin,Vector3 aim,int rounds)
        {
            var look=Quaternion.LookRotation(aim); var right=look*Vector3.right; var up=look*Vector3.up;
            float spread=Mathf.Clamp(gun.spreadOfFractions,0,.5f);
            for(int i=Mathf.Clamp(rounds,0,16);i>0;i--) {
                var circle=UnityEngine.Random.insideUnitCircle*spread;
                FireRound(gun,origin,(aim+right*circle.x+up*circle.y).normalized);
            }
        }
        private static void FireRound(Gun gun,Vector3 from,Vector3 direction)
        {
            var round=Object.Instantiate(gun.bulletPrefab,from,Quaternion.LookRotation(direction));
            round.AddRelativeForce(Vector3.forward*Mathf.Clamp(gun.bulletSpeed,1,2000),ForceMode.VelocityChange);
            var script=round.GetComponent<BulletScript>(); if(script!=null) script.MakeInvisible();
        }

        // ---- 1.5.0: hits as the guest saw them ----
        // The guest sees the host's zombies a moment late (the network and the smoothing of their frames, 0.1-0.4 s), so
        // the guest's aim at a zombie's head met, in the host's world, where that head had gone since. Now the guest says
        // which limb of which zombie its round or blade met on its own screen, and the host takes it when it can stand by
        // it. Limbs are the prefab's LimbDetectors in their order (the host's zombie and the guest's copy come from the
        // same prefab); their hitboxes are the colliders the game's rounds meet.

        // Guest: a limb hitbox of the prefab on the copy's bone.
        private sealed class LimbShape { internal Transform T; internal byte Index, Kind; internal Vector3 Center, Size; internal float Radius, Height; internal int Axis; }
        private static LimbShape[] LimbShapes(ZombieAIController prefab,Dictionary<Transform,Transform> map)
        {
            var shapes=new List<LimbShape>(); var limbs=prefab.GetComponentsInChildren<LimbDetector>(true);
            for(int i=0;i<limbs.Length && i<LanProtocol.MaxClaimLimbs;i++) {
                var limb=limbs[i]; Transform copy;
                if(limb==null || limb.deadVersionZombie || !map.TryGetValue(limb.transform,out copy)) continue;
                var collider=limb.GetComponent<Collider>(); LimbShape s=null;
                var box=collider as BoxCollider; var sphere=collider as SphereCollider; var capsule=collider as CapsuleCollider; var mesh=collider as MeshCollider;
                if(box!=null) s=new LimbShape {Kind=0,Center=box.center,Size=box.size};
                else if(sphere!=null) s=new LimbShape {Kind=1,Center=sphere.center,Radius=sphere.radius};
                else if(capsule!=null) s=new LimbShape {Kind=2,Center=capsule.center,Radius=capsule.radius,Height=capsule.height,Axis=Mathf.Clamp(capsule.direction,0,2)};
                else if(mesh!=null && mesh.sharedMesh!=null) s=new LimbShape {Kind=0,Center=mesh.sharedMesh.bounds.center,Size=mesh.sharedMesh.bounds.size};
                if(s==null) continue;
                s.T=copy; s.Index=(byte)i; shapes.Add(s);
            }
            return shapes.ToArray();
        }
        // Guest: the hits of this shot's rounds (as the game spreads them) or of this swing on the zombie copies here.
        private HitClaim[] Claims(Gun gun,byte action,Vector3 origin,Vector3 aim)
        {
            try {
                var claims=new List<HitClaim>(); HitClaim claim;
                if(action==0) {
                    var round=Round(gun); var bullet=round==null?null:round.GetComponent<BulletScript>();
                    if(bullet==null) return null;
                    // 1.5.0: an arrow is one, along the aim (it flies its own arc: the host's ray follows the same line).
                    if(bullet.arrow) return Aimed(origin,aim,60f,bullet.targetRaycastMask.value,out claim) ? new[] {claim} : null;
                    int rounds=Mathf.Clamp(gun.ProjectilesInShot,1,16);
                    var look=Quaternion.LookRotation(aim); var right=look*Vector3.right; var up=look*Vector3.up;
                    float spread=Mathf.Clamp(gun.spreadOfFractions,0,.5f);
                    for(int i=0;i<rounds && claims.Count<LanProtocol.MaxHitClaims;i++) {
                        var circle=rounds>1?UnityEngine.Random.insideUnitCircle*spread:Vector2.zero;
                        if(Aimed(origin,(aim+right*circle.x+up*circle.y).normalized,100f,bullet.targetRaycastMask.value,out claim)) claims.Add(claim);
                    }
                }
                else if(Aimed(origin,aim,Mathf.Clamp(gun.meleeAttacRange,0,3),gun.targetRaycastMask.value,out claim)) claims.Add(claim);
                return claims.Count==0?null:claims.ToArray();
            }
            catch(Exception ex) { if(!_claimFailed) { _claimFailed=true; _report("Hit claims failed: "+ex.GetType().Name+": "+ex.Message); } return null; }
        }
        private bool _claimFailed;
        // Guest: the nearest limb of a live zombie copy along the ray before `range` and the first wall here.
        private bool Aimed(Vector3 origin,Vector3 direction,float range,int mask,out HitClaim claim)
        {
            claim=null; float best=range; RaycastHit wall;
            // Not the copies' own body capsules (layer 2).
            if(Physics.Raycast(origin,direction,out wall,range,mask&~(1<<2),QueryTriggerInteraction.Ignore)) best=wall.distance;
            foreach(var pair in _replicas) {
                var r=pair.Value;
                if(pair.Key==0 || pair.Key>LanProtocol.MaxZombieIds || r.Root==null || !r.Root.activeInHierarchy || r.Dead || r.Limbs==null) continue;
                if((r.Root.transform.position-origin).sqrMagnitude>(best+3f)*(best+3f)) continue;
                foreach(var s in r.Limbs) {
                    float t;
                    if(s.T==null || !Intersect(s,origin,direction,best,out t)) continue;
                    best=t; var point=origin+direction*t;
                    var local=s.T.InverseTransformPoint(point); var into=s.T.InverseTransformVector(direction).normalized;
                    claim=new HitClaim {Zombie=pair.Key,Limb=s.Index,LX=local.x,LY=local.y,LZ=local.z,DX=into.x,DY=into.y,DZ=into.z,WX=point.x,WY=point.y,WZ=point.z};
                }
            }
            if(claim!=null && (Mathf.Abs(claim.LX)>LanProtocol.MaxClaimLocal || Mathf.Abs(claim.LY)>LanProtocol.MaxClaimLocal || Mathf.Abs(claim.LZ)>LanProtocol.MaxClaimLocal)) claim=null;
            return claim!=null;
        }
        // Where a world ray first meets the hitbox (in world distance), within `max`; 0 when it starts inside.
        private static bool Intersect(LimbShape s,Vector3 origin,Vector3 direction,float max,out float t)
        {
            t=0f;
            var o=s.T.InverseTransformPoint(origin); var v=s.T.InverseTransformVector(direction); float scale=v.magnitude;
            if(scale<1e-6f) return false;
            var d=v/scale; float local;
            if(s.Kind==0) { if(!RayBox(o-s.Center,d,s.Size*.5f,out local)) return false; }
            else if(s.Kind==1) { if(!RaySphere(o-s.Center,d,s.Radius,out local)) return false; }
            else {
                var axis=s.Axis==0?Vector3.right:s.Axis==1?Vector3.up:Vector3.forward; float half=Mathf.Max(0f,s.Height*.5f-s.Radius);
                if(!RayCapsule(o,d,s.Center-axis*half,s.Center+axis*half,s.Radius,out local)) return false;
            }
            t=local/scale;
            return t<=max;
        }
        private static bool RaySphere(Vector3 o,Vector3 d,float r,out float t)
        {
            t=0f; float b=Vector3.Dot(o,d), c=o.sqrMagnitude-r*r;
            if(c<=0f) return true;
            float h=b*b-c;
            if(h<0f || b>0f) return false;
            t=-b-Mathf.Sqrt(h); return t>=0f;
        }
        private static bool RayBox(Vector3 o,Vector3 d,Vector3 half,out float t)
        {
            t=0f; float near=float.NegativeInfinity, far=float.PositiveInfinity;
            for(int i=0;i<3;i++) {
                if(Mathf.Abs(d[i])<1e-8f) { if(Mathf.Abs(o[i])>half[i]) return false; continue; }
                float a=(-half[i]-o[i])/d[i], b=(half[i]-o[i])/d[i];
                if(a>b) { float x=a; a=b; b=x; }
                near=Mathf.Max(near,a); far=Mathf.Min(far,b);
                if(near>far) return false;
            }
            if(far<0f) return false;
            t=Mathf.Max(0f,near); return true;
        }
        private static bool RayCapsule(Vector3 o,Vector3 d,Vector3 a,Vector3 b,float r,out float t)
        {
            t=0f; var ba=b-a; var oa=o-a; float baba=Vector3.Dot(ba,ba);
            if(baba<1e-10f) return RaySphere(oa,d,r,out t);
            float along=Mathf.Clamp01(Vector3.Dot(oa,ba)/baba);
            if((oa-ba*along).sqrMagnitude<=r*r) return true;
            float bard=Vector3.Dot(ba,d), baoa=Vector3.Dot(ba,oa), rdoa=Vector3.Dot(d,oa), oaoa=Vector3.Dot(oa,oa);
            float A=baba-bard*bard, B=baba*rdoa-baoa*bard, C=baba*oaoa-baoa*baoa-r*r*baba, h=B*B-A*C;
            if(h>=0f && A>1e-10f) {
                float side=(-B-Mathf.Sqrt(h))/A, y=baoa+side*bard;
                if(y>0f && y<baba && side>=0f) { t=side; return true; }
            }
            float first,second; bool hitA=RaySphere(oa,d,r,out first), hitB=RaySphere(o-b,d,r,out second);
            if(!hitA && !hitB) return false;
            t=!hitA?second:!hitB?first:Mathf.Min(first,second); return true;
        }

        // Host: a hit the guest claims, when this world can stand by it: a live zombie the guest was shown, a limb of its
        // own, the guest's eye within the weapon's reach of where it saw the hit, no wall between, and that place no
        // farther from the limb now than a zombie moves in the guest's view delay. Then the limb's own point the round or
        // blade met there and the way it went in, in this world (from: a little before that point).
        private const float ClaimSlack=3.5f;
        // 1.5.0: what became of the guest's hit claims (taken; refused: zombie or limb gone, out of reach, moved on, behind a
        // wall, the limb not met here), and its shots that claimed nothing; logged once a minute when any.
        private int _claimTaken, _claimAimed, _claimNone; private readonly int[] _claimRefused=new int[5]; private float _claimLogAt;
        private void ClaimReport()
        {
            float now=Time.unscaledTime;
            if(now<_claimLogAt) return;
            _claimLogAt=now+60f;
            int refused=0; foreach(int n in _claimRefused) refused+=n;
            if(_claimTaken+refused+_claimNone==0) return;
            _report("Guest hits: "+_claimTaken+" taken ("+_claimAimed+" aimed anew at the limb here), "+refused+" refused (gone "+_claimRefused[0]+", reach "+_claimRefused[1]+", moved "+_claimRefused[2]+
                ", wall "+_claimRefused[3]+", limb missed "+_claimRefused[4]+"); shots that hit no zombie on the guest's screen: "+_claimNone);
            _claimTaken=_claimAimed=_claimNone=0; Array.Clear(_claimRefused,0,_claimRefused.Length);
        }
        private bool Claimed(HitClaim c,Vector3 origin,float range,int mask,out Vector3 from,out Vector3 toward,out RaycastHit hit)
        {
            from=toward=Vector3.zero; hit=default(RaycastHit);
            if(c==null || c.Zombie==0 || c.Zombie>_catalog.Count) { _claimRefused[0]++; return false; }
            var h=_catalog[(int)c.Zombie-1]; var ai=h.AI;
            if(ai==null || ai.dead || ai.zombieHP==null || h.Limbs==null || c.Limb>=h.Limbs.Length) { _claimRefused[0]++; return false; }
            var limb=h.Limbs[c.Limb];
            if(limb==null || limb.deadVersionZombie || limb.zombieHP!=ai.zombieHP || !limb.gameObject.activeInHierarchy) { _claimRefused[0]++; return false; }
            var collider=limb.GetComponent<Collider>();
            if(collider==null || !collider.enabled) { _claimRefused[0]++; return false; }
            var seen=new Vector3(c.WX,c.WY,c.WZ);
            if(Vector3.Distance(origin,seen)>range+.5f) { _claimRefused[1]++; return false; }
            if(Vector3.Distance(collider.bounds.center,seen)>ClaimSlack) { _claimRefused[2]++; return false; }
            if(Walled(origin,seen,mask)) { _claimRefused[3]++; return false; }
            var t=limb.transform;
            toward=t.TransformVector(new Vector3(c.DX,c.DY,c.DZ));
            if(toward.sqrMagnitude<1e-8f || float.IsNaN(toward.x)) return false;
            toward.Normalize();
            bool aimed;
            if(!Entry(collider,t.TransformPoint(new Vector3(c.LX,c.LY,c.LZ)),ref toward,origin,out hit,out aimed)) { _claimRefused[4]++; return false; }
            if(aimed) _claimAimed++;
            from=hit.point-toward*.1f;
            return true;
        }
        // Host, 1.5.0: where a claimed round or blade goes into that limb's own hitbox here: along the guest's line, laid in
        // the limb's frame as on the guest's screen, when it meets the hitbox; else (the zombie here stands a little otherwise,
        // or the guest's copy of the hitbox is a rough box) straight from the guest's eye at the limb. Only this hitbox is
        // asked, so an arm or another zombie standing before it here does not take what the guest saw land on it. The point
        // the guest saw must lie at the hitbox (within a metre of its bounds), as the guest's copy is that very limb.
        private static bool Entry(Collider collider,Vector3 point,ref Vector3 toward,Vector3 origin,out RaycastHit hit,out bool aimed)
        {
            aimed=false;
            if(collider.Raycast(new Ray(point-toward*2f,toward),out hit,4f)) return true;
            if((collider.ClosestPointOnBounds(point)-point).sqrMagnitude>1f) return false;
            aimed=true;
            var center=collider.bounds.center; var mesh=collider as MeshCollider;
            var inner=mesh!=null && !mesh.convex ? center : Vector3.Lerp(collider.ClosestPoint(point),center,.5f);
            for(int i=0;i<2;i++) {
                var target=i==0 ? inner : center; var way=target-origin;
                if(way.sqrMagnitude<1e-6f) continue;
                way.Normalize();
                if(collider.Raycast(new Ray(target-way*2f,way),out hit,4f)) { toward=way; return true; }
            }
            return false;
        }
        // Host: a wall (not a zombie) between the guest's eye and the place it saw the hit.
        private static bool Walled(Vector3 origin,Vector3 seen,int mask)
        {
            var delta=seen-origin; float distance=delta.magnitude;
            if(distance<.4f) return false;
            foreach(var hit in Physics.RaycastAll(origin,delta/distance,distance-.3f,mask&~(1<<2),QueryTriggerInteraction.Ignore))
                if(hit.collider!=null && hit.collider.GetComponentInParent<ZombieAIController>()==null && hit.collider.GetComponent<LimbDetector>()==null) return true;
            return false;
        }
        // Host: the claimed swing's or arrow's hit, where it goes into that very limb's hitbox here.
        private bool ClaimedHit(HitClaim[] hits,Vector3 origin,float range,int mask,out RaycastHit hit)
        {
            hit=default(RaycastHit);
            if(hits==null || hits.Length==0) return false;
            Vector3 from,toward;
            bool found=Claimed(hits[0],origin,range,mask,out from,out toward,out hit);
            if(found) _claimTaken++;
            ClaimReport();
            return found;
        }

        private void CaptureAction(Gun gun,byte action,float startedAt=-1f)
        {
            if(_host || !_playerReady || gun==null || LocalPlayer()==null || LocalPlayer().GetSelectedGun()!=gun) return;
            int item=RemoteEquipment.CaptureLocalItemId(); if(item<0 && !(gun.Hands && action==1)) return;
            if(gun.Hands) item=-1; // 1.1.6: the bare fists
            var rays=LocalPlayer().zombieFighterRays; if(rays==null || rays.cameraPoint==null) return;
            var origin=rays.cameraPoint.position; var aim=rays.cameraPoint.forward;
            var p=Message(PacketKind.ZombieAction,++_actionSequence); p.Action=action;p.EquippedItemId=item;
            var silencer=gun.GetInstalledSilencer(); float loudness=silencer==null?1f:silencer.Value;
            p.Noise=(byte)Mathf.RoundToInt(float.IsNaN(loudness)?100f:Mathf.Clamp01(loudness)*100f);
            p.Hits=Claims(gun,action,origin,aim); // 1.5.0: what it meets on this screen
            // 1.0.7: on a train car, in that car's own space (as the player states are), so a moving
            // train does not shift the shot on the host.
            var car=LocalPlayer().OnTrainCar; var train=GlobalManager.global.controlledTrain;
            if(car!=null && train!=null && car.transform.IsChildOf(train.transform)) {
                int index=car.GetCarIndex();
                var local=car.transform.InverseTransformPoint(origin);
                if(index>=0 && index<LanProtocol.MaxCars && Mathf.Abs(local.x)<=100 && Mathf.Abs(local.y)<=100 && Mathf.Abs(local.z)<=100) {
                    p.CarIndex=index; origin=local; aim=car.transform.InverseTransformDirection(aim);
                }
            }
            p.X=origin.x;p.Y=origin.y;p.Z=origin.z;p.AimX=aim.x;p.AimY=aim.y;p.AimZ=aim.z;Combat.Submit(p,startedAt);
        }

        private void CaptureReload(Gun gun)
        {
            if(_host || !_playerReady || gun==null || LocalPlayer()==null || LocalPlayer().GetSelectedGun()!=gun) return;
            int item=RemoteEquipment.CaptureLocalItemId();if(item<0)return;
            var p=Message(PacketKind.CombatReload,++_actionSequence);p.EquippedItemId=item;Combat.Submit(p);
        }

        private static ZombieFighterController LocalPlayer() { return GlobalManager.global==null?null:GlobalManager.global.controlledChar; }
        private Packet Message(PacketKind kind,uint seq) { return new Packet {Kind=kind,WorldEpoch=_epoch,Scene=_scene,Sequence=seq}; }
        private static bool Newer(uint a,uint b) { return a!=0 && unchecked((int)(a-b))>0; }
        private void Hurt(Remote r,float damage,byte kind=1)
        {
            if(!_ready || r==null || !r.Ready || r.Hurts.Count>=64 || damage<=0 || float.IsNaN(damage) || float.IsInfinity(damage)) return;
            if(kind<1 || kind>4) return;
            r.PendingDamage[kind]=Mathf.Min(3000,r.PendingDamage[kind]+Mathf.Clamp(damage,0,1000));
        }
        // 1.5.0, host: the bodybuilder's blow (the game's RepulsiveArea.OnTriggerEnter, for a guest): its damage and the
        // push that throws the player, from the guest's place in the area, as the game reckons it for its own player.
        // 2.2.0, host: a frog's tongue grabbed a guest: its damage and where the item lands (the tongue's root, by the frog).
        private void Grab(Remote r,float damage,Vector3 point)
        {
            damage=Mathf.Clamp(damage,0,1000);
            if(!_ready || r==null || !r.Ready || !(damage>0)) return;
            if(r.Hurts.Count>=64 || !LanProtocol.ValidPoint(point.x,point.y,point.z)) { Hurt(r,damage); return; }
            var hurt=Message(PacketKind.ZombieHurt,++r.HurtSequence);
            hurt.Action=LanProtocol.HurtSteal; hurt.Damage=damage; hurt.Text=""; hurt.AimX=point.x; hurt.AimY=point.y; hurt.AimZ=point.z;
            r.Hurts.Enqueue(hurt);
            LanWorldItems.RecordGrab(r.Position,point);
        }
        private void Knock(RepulsiveArea area,Remote r)
        {
            float damage=Mathf.Clamp(area.Damage,0,1000);
            if(!_ready || r==null || !r.Ready || !(damage>0)) return;
            if(r.Hurts.Count>=64) { Hurt(r,damage); return; }
            var hurt=Message(PacketKind.ZombieHurt,++r.HurtSequence);
            hurt.Action=LanProtocol.HurtCharge; hurt.Damage=damage; hurt.Text="";
            var push=Push(area,r.Position); hurt.AimX=push.x; hurt.AimY=push.y; hurt.AimZ=push.z;
            r.Hurts.Enqueue(hurt);
        }
        // 1.4.3: a melee hit is its own hurt, so the guest gets what the game's own hit brings
        // (ZombieAIController.ZombieAttackRays): a zombie with its hand on also passes its prefab,
        // whose buffs (bleeding) the guest takes as the game would.
        private void MeleeHit(ZombieAIController ai,Remote r)
        {
            float damage=ai.GetMeleeDamage();
            if(!_ready || r==null || !r.Ready || damage<=0 || float.IsNaN(damage) || float.IsInfinity(damage)) return;
            if(r.Hurts.Count>=64) { Hurt(r,damage); return; }
            var hurt=Message(PacketKind.ZombieHurt,++r.HurtSequence);
            hurt.Action=LanProtocol.HurtMelee; hurt.Damage=Mathf.Min(1000,damage);
            string prefab=ai.ID;
            hurt.Text=ai.IsHaveHandForMelee() && LanProtocol.ValidHurt(hurt.Damage,LanProtocol.HurtMelee,prefab) ? prefab : "";
            r.Hurts.Enqueue(hurt);
        }
        private static AccessTools.FieldRef<RepulsiveArea,bool> _repulse;
        private static AccessTools.FieldRef<RepulsiveArea,float> _repulseForce, _repulseSide;
        private static bool _repulseFailed;
        private static bool RepulseFields()
        {
            if(_repulseFailed) return false;
            if(_repulse!=null) return true;
            try {
                _repulse=AccessTools.FieldRefAccess<RepulsiveArea,bool>("Repulse");
                _repulseForce=AccessTools.FieldRefAccess<RepulsiveArea,float>("Force");
                _repulseSide=AccessTools.FieldRefAccess<RepulsiveArea,float>("MinSideOffset");
                return true;
            }
            catch(Exception) { _repulseFailed=true; _repulse=null; return false; }
        }
        // Whether the area throws a player it meets now (the game's RepulsiveArea.Repulse); when it cannot be read, it does.
        private static bool Repulsing(RepulsiveArea area) { return !RepulseFields() || _repulse(area); }
        private static Vector3 Push(RepulsiveArea area,Vector3 at)
        {
            float force=.1f, side=.2f;
            if(RepulseFields()) { force=_repulseForce(area); side=_repulseSide(area); }
            var local=area.transform.InverseTransformPoint(at).normalized;
            if(local.x<side && local.x>0f) local.x=side;
            if(local.x>-side && local.x<0f) local.x=-side;
            var away=area.transform.TransformPoint(local)-area.transform.position;
            var push=away.normalized*(10f-away.magnitude)*force;
            if(float.IsNaN(push.x) || float.IsNaN(push.y) || float.IsNaN(push.z)) return Vector3.zero;
            return push.sqrMagnitude>LanProtocol.MaxChargePush*LanProtocol.MaxChargePush ? push.normalized*LanProtocol.MaxChargePush : push;
        }
        // 1.5.0, guest: the bodybuilder's blow as the game's RepulsiveArea deals it to its own player: the damage, then
        // thrown by the push and stunned for three seconds (unless the blow downed it).
        // 2.2.0, guest: a frog's tongue as the game's ItemStealer takes the player's item: the damage, consumption stops,
        // the item in hand drops where the host says the frog holds it (as the game pulls it to the tongue), marked.
        // The drop goes to the host's world like any dropped item (LanWorldItems.MarkStolen lets it land by the frog).
        internal const float MaxGrabReach=40f;
        private void TongueGrab(ZombieFighterController player,ZombieFighterIndicatorsBar health,Packet p)
        {
            health.CauseDamage(p.Damage,true,false,(DamageType)1);
            if(LanDowned.Down || health.deathRegister || health.currentHealth<=0f) return;
            try {
                if(InventoryController.global!=null) InventoryController.global.StopConsumption();
                var item=player.DropActiveItem();
                if(item==null) return;
                var point=new Vector3(p.AimX,p.AimY,p.AimZ);
                if((point-player.transform.position).sqrMagnitude<=MaxGrabReach*MaxGrabReach) { item.transform.position=point; LanWorldItems.MarkStolen(item,point); }
                item.CreateScreenMarker();
            }
            catch(Exception ex) { EffectFailed("Tongue grab",ex); }
        }
        private void ChargeKnock(ZombieFighterController player,ZombieFighterIndicatorsBar health,Packet p)
        {
            health.CauseDamage(p.Damage,true,false,(DamageType)1);
            if(LanDowned.Down || health.deathRegister || health.currentHealth<=0f) return;
            try { player.pushingVector=new Vector3(p.AimX,p.AimY,p.AimZ); player.flightAfterHit=true; player.stunDuration=3f; }
            catch(Exception ex) { EffectFailed("Charge blow",ex); }
        }
        // Guest: the game's own melee hit on the local player, its damage booked by the host.
        private void MeleeEffects(ZombieFighterController player,ZombieFighterIndicatorsBar health,float damage,string prefab)
        {
            try { var fx=player.GetComponent<ZombieFighterEffects>(); if(fx!=null) { fx.RandomBodyHitSound(); fx.RandomAttackPainSound(); } }
            catch(Exception ex) { EffectFailed("Melee hit sound",ex); }
            health.CauseDamage(damage,false,false,(DamageType)1);
            try
            {
                ZombieAIController zombie=null;
                if(!string.IsNullOrEmpty(prefab)) { BuildPrefabCatalog(); _prefabs.TryGetValue(prefab,out zombie); }
                var buffs=zombie==null?null:zombie.GetComponent<Zompiercer.UI.BuffParameters>();
                var stats=Zompiercer.GlobalStatsController.Global;
                if(buffs!=null && buffs.Buffs!=null && buffs.Buffs.Length>0 && stats!=null)
                {
                    // Armor lowers the chance to bleed and wears, as the game's hit does.
                    int lower=0;
                    for(int slot=1;slot<=2;slot++)
                    {
                        var slots=player.eqipmentInventory;
                        if(slots==null || slot>=slots.Length || slots[slot]==null || slots[slot].content==null || slots[slot].content.Count==0 || slots[slot].content[0]==null) continue;
                        var armor=slots[slot].content[0].GetComponent<Eqipment>();
                        if(armor==null || armor.ArmorDurability<=0) continue;
                        lower+=armor.decreaseChanceBleeding; armor.DamageArmor(damage);
                    }
                    foreach(var source in buffs.Buffs)
                    {
                        var buff=source;
                        if((int)buff.buffType==BleedingBuff) buff.chance-=(int)(buff.chance*(lower/100f));
                        stats.AddBuff(buff);
                    }
                }
            }
            catch(Exception ex) { EffectFailed("Melee hit buffs",ex); }
            try
            {
                var gui=Zompiercer.GUI.GUIManager.Global; if(gui!=null) gui.BloodScreen();
                var shake=player.GetComponentInChildren<CameraShake>(); if(shake!=null) shake.ShakeCamera(.1f,.1f);
            }
            catch(Exception ex) { EffectFailed("Melee hit screen",ex); }
        }
        private const int BleedingBuff=22;
        private bool _meleeFailed;
        private void EffectFailed(string what,Exception ex)
        {
            if(_meleeFailed) return;
            _meleeFailed=true; _report(what+" not shown: "+ex.GetType().Name+": "+ex.Message);
        }

        // Explicit remote branch: never replace GlobalManager.controlledChar and never construct a
        // pretend player controller that native inventory/buff scripts could dereference.
        private const float KeepRemoteSeconds=3f;
        private bool RemoteUpdate(ZombieAIController ai)
        {
            HostZombie h;
            if(!_host || !_ready || ai==null || ai.dead || !_hostIds.TryGetValue(ai.GetInstanceID(),out h)) return false;
            var local=LocalPlayer(); if(local==null) return false;
            // 1.1.7: a boss waiting behind open arena gates does not take a guest either.
            if(LanBossArena.Holds(ai)) { if(h.Chased!=null) ReleaseTarget(h); return false; }
            bool eligible=(ai.melee || ai.cannon!=null && ai.cannon.projectile!=null || ai.RunToExplode || ai.flamethrower!=null) && !ai.zombieNurse;
            bool busy=ai.Staggered || ai.attackRayActivatorHunterAnimation || ai.doingFireAnimation || ai.skillChargeAttack!=null && (int)ai.skillChargeAttack.CurrentPhase!=0 || ai.flamethrower!=null && ai.flamethrower.flamethrower!=null && ai.flamethrower.flamethrower.Firing;
            // 1.4.14: as far as it sees now (SightOf); a zombie already on the hunt sees a guest in its sight whatever
            // the guest does, as the game's chasing zombie keeps the player.
            float toLocal=Vector3.Distance(ai.transform.position,local.transform.position), sight=SightOf(ai);
            bool alerted=ai.state=="Chase" || ai.playerIsInSight || ai.aiHeardPlayer;
            // 1.0.2: a guest once seen stays the target for a few seconds (a single blocked ray, a bush
            // zombie in foliage, must not hand it back to the native AI over and over). 2.0.0: the guest
            // it hunts keeps it while busy, seen or kept; otherwise the nearest guest it sees, if nearer
            // than the host's player.
            Remote r=null; float distance=float.MaxValue; bool hostTakes=false;
            var current=h.Chased;
            if(current!=null && (!current.Usable || !_remotes.ContainsKey(current.Slot))) { ReleaseTarget(h); current=null; }
            if(current!=null) {
                float d=Vector3.Distance(ai.transform.position,current.Position);
                bool sees=d<sight && d<toLocal && ClearLine(ai,current.Position);
                if(eligible && sees) h.KeepRemoteUntil=Time.time+KeepRemoteSeconds;
                hostTakes=!busy && HostTakes(ai,local,d,toLocal,sight);
                bool keep=!hostTakes && Time.time<h.KeepRemoteUntil && d<Mathf.Min(60,Mathf.Max(3,ai.sightRadius*1.25f));
                if(eligible && (busy || sees || keep)) { r=current; distance=d; }
            }
            // 1.4.13: a guest it does not hunt yet it notices as the game's zombies notice the player (Spots,
            // Hears); before, it saw a guest anywhere within its sight, crouching or not.
            if(r==null && eligible)
                foreach(var candidate in _remotes.Values) {
                    if(!candidate.Usable) continue;
                    float d=Vector3.Distance(ai.transform.position,candidate.Position);
                    if(d>=distance || d>=toLocal) continue;
                    bool seen=d<sight && (alerted || Spots(ai,candidate,d,sight)) && ClearLine(ai,candidate.Position);
                    if(!seen && !Hears(ai,candidate,d)) continue;
                    r=candidate; distance=d;
                    if(Time.unscaledTime>=_noticeLogAt) {
                        _noticeLogAt=Time.unscaledTime+5f;
                        _report("Zombie "+h.Prefab+" noticed guest "+candidate.Slot+": "+(seen?(alerted?"seen on the hunt":"seen"):"heard")+" at "+d.ToString("0.0")+" m (sight "+sight.ToString("0")+
                            " m, noise "+ai.noiseDistance.ToString("0")+" m, field "+ai.fieldOfViewAngle.ToString("0")+"°, guest "+(candidate.Run?"running":candidate.Air?"in the air":candidate.Crouch?"crouching":candidate.Speed>.3f?"walking":"standing")+
                            ", stealth x"+Mathf.Clamp(candidate.Stealth,.1f,1f).ToString("0.0")+")");
                    }
                }
            if(r==null) { if(h.Chased!=null) { ReleaseTarget(h); if(hostTakes) HandToHost(ai); } return false; }
            if(h.Chased!=r) { if(h.Chased!=null) ReleaseTarget(h); h.KeepRemoteUntil=Time.time+KeepRemoteSeconds; }
            h.Chased=r;ai.target=r.Target.transform;ai.DistanceToPlayer=distance;ai.UpdateDistanceToTarget();
            if(!ai.Staggered && (ai.navMeshAgent==null || ai.navMeshAgent.velocity.sqrMagnitude<.1f)) {
                var facing=r.Position-ai.transform.position;facing.y=0;
                if(facing.sqrMagnitude>.001f) ai.transform.rotation=Quaternion.Slerp(ai.transform.rotation,Quaternion.LookRotation(facing),Mathf.Clamp01(Time.deltaTime*10));
            }
            ai.playerIsInSight=true;
            if(ai.sleeping) { ai.SetSleeping(false); return true; }
            if(ai.StaggeredTimer>0) { ai.StaggeredTimer-=Time.deltaTime;if(ai.StaggeredTimer<=0) ai.SetStaggered(false); }
            var charge=ai.skillChargeAttack;
            if(charge!=null) {
                var area=charge.repulsiveArea;
                if(area==null || !area.gameObject.activeInHierarchy) h.ChargeHit=false;
                // 1.5.0: as the game's RepulsiveArea does to its own player: it stops the charge, and once the area repulses
                // (the blow after the charge, or a charge into the guest after one) the guest takes the damage and is thrown.
                else if(!h.ChargeHit && OverlapsRemote(area.gameObject,r) && ClearLine(ai,r.Position)) { h.ChargeHit=true;area.HitPlayer=true; if(Repulsing(area)) Knock(area,r); }
                if((int)charge.CurrentPhase!=0) return true;
            }
            if(ai.WakesUp || ai.Staggered || (ai.zombieDamagDetector!=null && ai.zombieDamagDetector.stunAfterHittingCounter)) return true;
            var tongue=ai.skillFrogTongue;
            if(tongue!=null && tongue.cooldown!=null && tongue.cooldown.IsReady() && tongue.frogTongue!=null && distance<Mathf.Clamp(tongue.frogTongue.MaxRange,0,30) && ClearLine(ai,r.Position)) { tongue.Fire();return true; }
            var jump=ai.skillJump;
            if(jump!=null && jump.cooldown!=null && jump.cooldown.IsReady() && distance>=jump.RangeMin && distance<=jump.RangeMax && Vector3.Angle(ai.transform.forward,r.Position-ai.transform.position)<20 && ClearLine(ai,r.Position)) jump.Jump();
            if(charge!=null && charge.UltaCooldownTimer<=0 && distance<Mathf.Clamp(ai.ChargeAttackRange,0,50) && Vector3.Angle(ai.transform.forward,r.Position-ai.transform.position)<ai.ChargeAttackAngle && ClearLine(ai,r.Position)) { charge.Charge(r.Target.transform);return true; }
            var flame=ai.flamethrower;
            if(flame!=null && flame.cooldown!=null && flame.cooldown.IsReady() && distance<=Mathf.Clamp(ai.fireRange,0,30) && distance>=ai.fireRangeMin && ClearLine(ai,r.Position)) {
                int hand=ai.GetFireFromHandIndex();
                if(hand>=0 && ai.FirePosition!=null && hand<ai.FirePosition.Length && flame.animations!=null && hand<flame.animations.Length && flame.flamethrower!=null) {
                    flame.flamethrower.transform.SetParent(ai.FirePosition[hand],false);flame.flamethrower.transform.localPosition=Vector3.zero;flame.Fire();return true;
                }
            }
            if(ai.RunToExplode && ai.explodingBlob!=null && !ai.explodingBlob.Exploded && !h.Explosion && distance<=Mathf.Clamp(ai.ExplodeOnDistance,0,10)) {
                h.Explosion=true;ai.BeginStomachExplosion();return true;
            }
            if(ai.cannon!=null && ai.cannon.projectile!=null && ai.FireAnimations!=null && ai.FireAnimations.Length>0) { RangedAttack(ai,h,distance,r); return true; }
            if(ai.attackRayActivatorHunterAnimation) {
                ai.attackTimer+=Time.deltaTime;
                float delay=ai.attackRayActivator==2?ai.attackHunterHitMomentTime2:ai.OverrideAttackAnimationMode && ai.OverrideAttackAnimation!=null?ai.OverrideAttackAnimation.delay:ai.attackHunterHitMomentTime;
                if(ai.attackRayActivator>0 && ai.attackTimer>=delay) {
                    if(InMelee(ai,distance,r)) MeleeHit(ai,r);
                    ai.attackRayActivator=ai.zombieBroker && ai.attackRayActivator==1?2:0;
                }
                if(ai.attackTimer>=Mathf.Max(.5f,ai.OverrideAttackAnimationMode && ai.OverrideAttackAnimation!=null?ai.OverrideAttackAnimation.duration:ai.durationOfHunterAttack)) {
                    ai.attackRayActivatorHunterAnimation=false;ai.attackTimer=0;ai.attackRayActivator=0;h.NextAttack=Time.time+.15f;
                    if(ai.zombieAnimation!=null) ai.zombieAnimation.AttackAnimationVariants();
                }
                return true;
            }
            ai.SetState("Chase"); ai.SetNavMeshStop(false,true);ai.SetNavMeshAgentSpeed(Mathf.Max(.1f,ai.chaseSpeed),false);ai.SetNavMeshDestination(r.Position);
            if(ai.melee && InMelee(ai,distance,r) && Time.time>=h.NextAttack) {
                ai.SetNavMeshStop(true,true); ai.attackRayActivatorHunterAnimation=true;ai.attackRayActivator=1;ai.attackTimer=0;
                if(ai.zombieEffects!=null) ai.zombieEffects.ZombieAttackRoarSound();
            }
            return true;
        }
        // 1.1.8: a spitting zombie (the bush zombie) plays its own ranged game against the guest, as the
        // game's AI does against the host: it walks up while its spit is ready and spits from the hand
        // whose turn it is once it faces the guest, keeps its distance while it reloads (runs aside or
        // away, its flee thresholds), and never stops in its waiting pose. That pose is the bush zombie
        // hiding in its bush: the old stop in range made it hide and rise over and over, and it spat
        // without turning, always the first hand's animation from whichever hand held the cannon.
        private void RangedAttack(ZombieAIController ai,HostZombie h,float distance,Remote r)
        {
            bool ready=ai.cannon.IsReadyToFire() && !ai.doingFireAnimation;
            if(!ai.keepDistance) h.Fleeing=false;
            else if(distance<ai.FleeThresholdMin && !(ai.priorityOnFire && ready)) h.Fleeing=true;
            else if(distance>ai.FleeThresholdMax || ai.priorityOnFire && ready) h.Fleeing=false;
            ai.SetState("Chase"); ai.SetNavMeshStop(false,false);
            if(h.Fleeing) {
                if(Time.time>=h.FleeAt) {
                    h.FleeAt=Time.time+1f;
                    ai.SetNavMeshAgentSpeed(Mathf.Max(.1f,ai.fleeSpeed>0?ai.fleeSpeed:ai.chaseSpeed),false); ai.SetNavMeshDestination(FleePoint(ai,r));
                }
                return;
            }
            ai.SetNavMeshAgentSpeed(Mathf.Max(.1f,ai.chaseSpeed),false);
            if(!ready) return; // reloading: on toward where the guest was, as the game keeps its last destination
            ai.SetNavMeshDestination(r.Position);
            var facing=r.Position-ai.transform.position; facing.y=0;
            if(facing.sqrMagnitude<.001f || Vector3.Angle(ai.transform.forward,facing)>=20f || distance>Mathf.Clamp(ai.fireRange,0,100) || distance<ai.fireRangeMin || !ClearLine(ai,r.Position)) return;
            int hand=ai.GetFireFromHandIndex();
            if(hand<0) return;
            ai.doingFireAnimation=true; ai.Fire(ai.FireAnimations[Math.Min(hand,ai.FireAnimations.Length-1)]);
            if(ai.FirePosition!=null && hand<ai.FirePosition.Length && ai.FirePosition[hand]!=null) { ai.cannon.transform.parent=ai.FirePosition[hand]; ai.cannon.transform.localPosition=Vector3.zero; }
            ai.CycleNextFirePosition();
        }
        // Where a fleeing ranged zombie runs: aside (its flee type Side) or away from the guest.
        private Vector3 FleePoint(ZombieAIController ai,Remote r)
        {
            var self=ai.transform.position; Vector3 goal;
            if((int)ai.fleeType==1) goal=ai.transform.TransformPoint(new Vector3(UnityEngine.Random.value<.5f?-10f:10f,0,0));
            else { var away=self-r.Position; away.y=0; goal=self+(away.sqrMagnitude>.01f?away.normalized:-ai.transform.forward)*10f; }
            UnityEngine.AI.NavMeshHit hit;
            return UnityEngine.AI.NavMesh.SamplePosition(goal,out hit,8f,UnityEngine.AI.NavMesh.AllAreas)?hit.position:self;
        }
        // 1.4.13: the game's own rules for noticing the player (ZombieAIController.CheckLOS), for a guest. Seen
        // within a share of the zombie's sight (half of it sleeping) by how the guest moves: a half walking or
        // running, a third standing or sneaking, a fifth crouching still, times its stealth; and only in front
        // of the zombie (its field of view). Heard within its noise distance: all of it running or jumping,
        // otherwise the same shares and stealth.
        private static float StealthShare(Remote r,bool hearing)
        {
            if(r.Run || r.Air) return hearing?1f:2f;
            bool moving=r.Speed>.3f;
            return (r.Crouch ? moving?3f:5f : moving?2f:3f)/Mathf.Clamp(r.Stealth,.1f,1f);
        }
        private static bool Spots(ZombieAIController ai,Remote r,float distance,float sight)
        {
            if(distance>=sight/StealthShare(r,false)) return false;
            return Vector3.Angle(r.Position-ai.transform.position,ai.transform.forward)<Mathf.Clamp(ai.fieldOfViewAngle*.5f,1,180);
        }
        private static bool Hears(ZombieAIController ai,Remote r,float distance) { return distance<Mathf.Clamp(ai.noiseDistance,0,50)/StealthShare(r,true); }
        // 1.4.14: how far a zombie sees now, as the game's CheckLOS uses it (currentSightRadius: its sight radius,
        // half of it asleep at first, its catch radius once it saw, heard or was hurt).
        private static AccessTools.FieldRef<ZombieAIController,float> _currentSight;
        private static bool _currentSightFailed;
        private static float SightOf(ZombieAIController ai)
        {
            float sight=ai.sightRadius;
            if(!_currentSightFailed)
                try { if(_currentSight==null) _currentSight=AccessTools.FieldRefAccess<ZombieAIController,float>("currentSightRadius"); float current=_currentSight(ai); if(current>0) sight=current; }
                catch(Exception) { _currentSightFailed=true; }
            return Mathf.Clamp(sight,2,50);
        }

        // 1.4.14, host: the game wakes its zombies around the player only: a spawner makes its zombie once the
        // player's character comes within its reach (ZombieSpawn.Update: 60, 20, 7 or 3 m by its spawnPlace), a
        // territory (ZombieSpawnerTerritoryActivator) turns its spawners on when the player's CharacterController
        // enters it. Around a guest alone the world stayed empty until the host came; guests wake them too.
        private static readonly float[] SpawnReach={60f,20f,7f,3f};
        private void WakeAroundRemotes()
        {
            float now=Time.time;
            if(now<_wakeAt) return;
            _wakeAt=now+.5f;
            try {
                var guests=new List<Vector3>();
                foreach(var r in _remotes.Values) if(r.Usable) guests.Add(r.Position);
                var saves=Zompiercer.SaveLoad.SaveLoadCore.global;
                var local=LocalPlayer();
                if(guests.Count==0 || saves!=null && saves.LoadingNow || local==null || GlobalManager.AllZombieSpawners==null) return;
                foreach(var spawn in GlobalManager.AllZombieSpawners.ToArray()) {
                    if(spawn==null || spawn.GoingToBeDestroyed || !spawn.isActiveAndEnabled || spawn.spawnPlace<0 || spawn.spawnPlace>=SpawnReach.Length) continue;
                    float reach=SpawnReach[spawn.spawnPlace];
                    // Within the host's reach the game's own Update makes it (never twice in a frame).
                    if(Vector3.Distance(spawn.transform.position,local.transform.position)<=reach) continue;
                    foreach(var at in guests) if(Vector3.Distance(spawn.transform.position,at)<=reach) { spawn.Activator(); break; }
                }
                if(now>=_territoriesAt) { _territoriesAt=now+5f; _territories=Object.FindObjectsOfType<ZombieSpawnerTerritoryActivator>(); }
                if(_territories==null) return;
                foreach(var territory in _territories) {
                    if(territory==null || !territory.isActiveAndEnabled || territory.zombieSpawners==null) continue;
                    bool inside=false; foreach(var at in guests) if(Inside(territory,at)) { inside=true; break; }
                    if(!inside) continue;
                    foreach(var spawner in territory.zombieSpawners) if(spawner!=null && !spawner.activeSelf) spawner.SetActive(true);
                }
            }
            catch(Exception ex) { if(!_wakeFailed) { _wakeFailed=true; _report("Zombies around the guests not woken: "+ex.GetType().Name+": "+ex.Message); } }
        }
        // Whether a guest stands in a territory's trigger (its body: a point a metre above its feet).
        private static bool Inside(Component territory,Vector3 feet)
        {
            var body=feet+Vector3.up;
            foreach(var collider in territory.GetComponents<Collider>()) {
                if(collider==null || !collider.enabled || !collider.isTrigger || !collider.bounds.Contains(body)) continue;
                var mesh=collider as MeshCollider;
                if(mesh!=null && !mesh.convex || (collider.ClosestPoint(body)-body).sqrMagnitude<1e-4f) return true;
            }
            return false;
        }
        // 1.4.16: a zombie hunting a guest goes for the host at once when the host is nearer (by a metre), in its
        // sight and in a clear line, as the game's zombie goes for the player (AttackPlayer). Let go, it ran on to
        // where the guest had been and took the host only if it happened to notice it.
        private static bool HostTakes(ZombieAIController ai,ZombieFighterController local,float guestDistance,float hostDistance,float sight)
        {
            if(local==null || hostDistance+1f>=guestDistance || hostDistance>=sight) return false;
            var bar=local.zombieFighterIndicatorsBar;
            if(bar!=null && bar.deathRegister) return false;
            return ClearLine(ai,local.transform.position);
        }
        private static void HandToHost(ZombieAIController ai) { try { ai.AttackPlayer(); } catch(Exception) { } }
        private bool InMelee(ZombieAIController ai,float distance,Remote r)
        {
            float range=ai.IsHaveHandForMelee()?ai.attackDistance:ai.attackDistanceTornOff;
            return distance<=Mathf.Clamp(range,0,4) && Vector3.Angle(ai.transform.forward,r.Position-ai.transform.position)<Mathf.Clamp(ai.fieldOfAttackAngle*.5f,1,90) && ClearLine(ai,r.Position);
        }
        private static bool ClearLine(ZombieAIController ai,Vector3 target)
        {
            var start=ai.transform.position+Vector3.up;var delta=target+Vector3.up-start;
            var hits=Physics.RaycastAll(start,delta.normalized,delta.magnitude,~0,QueryTriggerInteraction.Ignore);
            foreach(var hit in hits) if(hit.collider.GetComponentInParent<ZombieAIController>()!=ai && hit.collider.GetComponentInParent<ZombieFighterController>()==null) return false;
            return true;
        }
        private static bool BeforeProjectile(Projectile __instance)
        {
            // 1.1.6: on the guest only the host's spits fly (ShowEffect): the native flight and splash,
            // without the native damage (the host books it).
            if(IsClientWorld) { VisualProjectile(__instance); return false; }
            var a=Active;if(a==null || !a._host || !a._ready) return true;
            // Same host projectile trajectory and wall occlusion, with an analytic body for each guest.
            var start=__instance.transform.TransformPoint(new Vector3(0,0,__instance.RayOffsetZ));
            float length=Mathf.Clamp(__instance.Speed*Time.fixedDeltaTime,0,30);
            if(length<=0) return true;
            var direction=__instance.transform.forward;
            foreach(var r in a._remotes.Values) {
                if(!r.Ready) continue;
                var center=r.Position+Vector3.up;
                float along=Mathf.Clamp(Vector3.Dot(center-start,direction),0,length);
                if(Vector3.Distance(start+direction*along,center)>.5f) continue;
                RaycastHit wall;
                if(Physics.Raycast(start,direction,out wall,along,~0,QueryTriggerInteraction.Ignore)) continue;
                a.Hurt(r,__instance.Damage);
                // 1.1.6: the splash where it hit the guest, as the native hit leaves it.
                if(__instance.ImpactEffect!=null) Object.Instantiate(__instance.ImpactEffect,start+direction*along,__instance.transform.rotation);
                if(__instance.Trail!=null) { __instance.Trail.parent=null; Object.Destroy(__instance.Trail.gameObject,5f); }
                __instance.enabled=false;Object.Destroy(__instance.gameObject);return false;
            }
            return true;
        }
        // 2.4.3, guest: its round reaching a live zombie copy. The copies have no colliders the round meets, so the game's
        // round flew on to what was behind: dust and a bullet hole on the wall, as a miss, and no blood. Now it stops at
        // the limb it reaches, as the game's round stops in a zombie (BulletScript.BulletContact): the blood cloud, a wound
        // on that limb, the blood decal and blood on the wall behind. The host deals the damage (the shot's hit claims).
        // An arrow keeps its own flight (it sticks where it lands).
        private static bool BeforeBulletContact(BulletScript __instance)
        {
            var a=Active;
            if(!IsClientWorld || a==null || a._host || !a._playerReady || __instance==null || __instance.arrow || a._bulletFailed) return true;
            try {
                // The game's own ray of this step (BulletRayCast): from the round, ahead, its ray distance.
                var origin=__instance.transform.position; var direction=__instance.transform.forward;
                float range=Mathf.Clamp(__instance.bulletRayDistance,0f,100f);
                if(range<=0f) return true;
                RaycastHit wall;
                if(Physics.Raycast(origin,direction,out wall,range,__instance.targetRaycastMask.value&~(1<<2),QueryTriggerInteraction.Ignore)) range=wall.distance;
                Replica r; Transform bone; float along;
                if(!a.RoundHits(origin,direction,range,out r,out bone,out along)) return true;
                BulletBlood(origin+direction*along,direction,bone,r.Root.transform.position);
                Object.Destroy(__instance.gameObject);
                return false;
            }
            catch(Exception ex) { a._bulletFailed=true; a._report("Round blood failed: "+ex.GetType().Name+": "+ex.Message); return true; }
        }
        private bool _bulletFailed;
        // The nearest limb of a live zombie copy along the ray before `range` (as Aimed meets it).
        private bool RoundHits(Vector3 origin,Vector3 direction,float range,out Replica hit,out Transform bone,out float along)
        {
            hit=null; bone=null; along=range;
            foreach(var pair in _replicas) {
                var r=pair.Value;
                if(r.Root==null || !r.Root.activeInHierarchy || r.Dead || r.Limbs==null) continue;
                if((r.Root.transform.position-origin).sqrMagnitude>(along+3f)*(along+3f)) continue;
                foreach(var s in r.Limbs) {
                    float t;
                    if(s.T==null || !Intersect(s,origin,direction,along,out t)) continue;
                    along=t; hit=r; bone=s.T;
                }
            }
            return hit!=null;
        }
        // The game's blood of a round in a zombie (BulletScript.BulletContact): its cloud, a wound on the limb, the decal
        // under the zombie and blood on a wall behind it within reach.
        private static void BulletBlood(Vector3 point,Vector3 direction,Transform bone,Vector3 floor)
        {
            var effects=GlobalEffects.Global; if(effects==null) return;
            if(effects.bulletHitCloudBlood!=null) { var cloud=Object.Instantiate(effects.bulletHitCloudBlood,point,Quaternion.identity); cloud.transform.LookAt(point-direction); }
            if(effects.bloodHole!=null && effects.bloodHole.Length!=0) {
                var hole=effects.bloodHole[UnityEngine.Random.Range(0,effects.bloodHole.Length)];
                if(hole!=null) Object.Instantiate(hole,point-direction*.1f,Quaternion.LookRotation(direction)).parent=bone;
            }
            effects.SpawnBloodDecal(point,-direction,floor);
            var manager=GlobalManager.global; RaycastHit behind;
            if(manager!=null && effects.bloodOnWallsPrefab!=null && effects.bloodOnWallsPrefab.Length!=0 &&
                Physics.Raycast(point+direction*.2f,direction,out behind,effects.bloodOnWallsCheckRange,manager.bloodOnWallsRaycastLayerMask.value)) {
                var splash=effects.bloodOnWallsPrefab[UnityEngine.Random.Range(0,effects.bloodOnWallsPrefab.Length)];
                if(splash!=null) { var copy=Object.Instantiate(splash); copy.position=behind.point; copy.LookAt(behind.point-behind.normal); }
            }
        }
        private static void VisualProjectile(Projectile round)
        {
            float step=Mathf.Clamp(round.Speed*Time.fixedDeltaTime,0,30);
            round.transform.Translate(Vector3.forward*step);
            if(step<=0) return;
            var start=round.transform.TransformPoint(new Vector3(0,0,round.RayOffsetZ));
            int mask=GlobalManager.global==null?~0:GlobalManager.global.LayerMaskEnemyProjectiles.value;
            RaycastHit hit;
            if(!Physics.Raycast(new Ray(start,round.transform.forward),out hit,step,mask) || hit.collider==null) return;
            if(round.ImpactEffect!=null) Object.Instantiate(round.ImpactEffect,hit.point,round.transform.rotation);
            if(round.Trail!=null) { round.Trail.parent=null; Object.Destroy(round.Trail.gameObject,5f); }
            round.enabled=false; Object.Destroy(round.gameObject);
        }
        private static bool OverlapsRemote(GameObject area,Remote r)
        {
            foreach(var collider in area.GetComponentsInChildren<Collider>())
                if(collider.enabled && collider.gameObject.activeInHierarchy && (collider.ClosestPoint(r.Position+Vector3.up)-(r.Position+Vector3.up)).sqrMagnitude<=.1225f) return true;
            return false;
        }
        private static void AfterFlame(Flame __instance)
        {
            var a=Active;if(a==null || !a._host || !a._ready) return;
            foreach(var r in a._remotes.Values) {
                if(!r.Ready || !OverlapsRemote(__instance.gameObject,r)) continue;
                var start=__instance.transform.position;var delta=r.Position+Vector3.up-start;
                if(!Physics.Raycast(start,delta.normalized,delta.magnitude,~0,QueryTriggerInteraction.Ignore)) a.Hurt(r,__instance.Damage*__instance.DamageFactorPlayer*Time.fixedDeltaTime,2);
            }
        }
        private static void BeforeSmooth(SmoothDirection __instance)
        {
            var a=Active;if(a==null || !a._host) return;
            var ai=__instance.GetComponentInParent<ZombieAIController>();HostZombie h;
            if(ai!=null && a._hostIds.TryGetValue(ai.GetInstanceID(),out h) && h.Chased!=null && h.Chased.Ready && h.Chased.Target!=null) __instance.Target=h.Chased.Target.transform;
        }
        private static bool BeforeAim(ZombieAIController __instance,ref Vector3 __result)
        {
            var a=Active;HostZombie h;
            if(a==null || !a._host || !a._hostIds.TryGetValue(__instance.GetInstanceID(),out h) || h.Chased==null || !h.Chased.Ready) return true;
            __result=h.Chased.Position+Vector3.up;return false;
        }
        // 2.2.0, host: the game's ZombieOptimazer turns a zombie down by its distance to the host's own player only (beyond
        // 15 m its animation partly, beyond 30 m only on screen, beyond 100 m its animator and AI off): zombies by a guest far
        // from the host stood still and never struck. With guests here it counts the nearest player, with the same steps.
        private static string OptimizerFailure;
        private static AccessTools.FieldRef<ZombieOptimazer,ZombieAnimation> _optAnimation;
        private static AccessTools.FieldRef<ZombieOptimazer,ZombieAIController> _optAI;
        private static bool BeforeOptimizer(ZombieOptimazer __instance)
        {
            var a=Active;
            if(a==null || !a._host || !a._ready || _optAnimation==null || _optAI==null || __instance==null) return true;
            var at=__instance.transform.position; var local=LocalPlayer();
            float best=local!=null?(local.transform.position-at).sqrMagnitude:float.MaxValue; bool guests=false;
            foreach(var r in a._remotes.Values) if(r.Ready) { guests=true; float d=(r.Position-at).sqrMagnitude; if(d<best) best=d; }
            if(!guests) return true;
            float distance=Mathf.Sqrt(best);
            var animation=_optAnimation(__instance); var animator=animation==null?null:animation.animator; var ai=_optAI(__instance);
            if(distance<=100f) {
                if(animator!=null) {
                    if(!animator.enabled) animator.enabled=true;
                    var mode=distance<=15f?AnimatorCullingMode.AlwaysAnimate:distance<=30f?AnimatorCullingMode.CullUpdateTransforms:AnimatorCullingMode.CullCompletely;
                    if(animator.cullingMode!=mode) animator.cullingMode=mode;
                }
                if(ai!=null && !ai.enabled) ai.enabled=true;
            }
            else {
                if(animator!=null && animator.enabled) animator.enabled=false;
                if(ai!=null && ai.enabled) ai.enabled=false;
            }
            return false;
        }
        private static bool BeforeTongueHit(ItemStealer __instance)
        {
            var a=Active;if(a==null || !a._host || !a._ready || __instance.HitSomething) return true;
            var start=__instance.transform.position;var direction=__instance.transform.forward;
            foreach(var r in a._remotes.Values) {
                if(!r.Ready) continue;
                float along=Vector3.Dot(r.Position+Vector3.up-start,direction);
                if(along<0 || along>Mathf.Clamp(__instance.RayDistance,0,10) || Vector3.Distance(start+direction*along,r.Position+Vector3.up)>.5f) continue;
                if(Physics.Raycast(start,direction,along,~0,QueryTriggerInteraction.Ignore)) continue;
                // 2.2.0: as the game's grab of its own player: the damage and the item in hand (the guest drops it by the frog).
                var tongue=__instance.GetComponentInParent<FrogTongue>();
                a.Grab(r,__instance.Damage,tongue!=null?tongue.transform.position:start);__instance.HitSomething=true;
                return false;
            }
            return true;
        }
        private static void BeforeExplosion(ExplodingBlob __instance,out bool __state) { __state=__instance.Exploded; }
        private static void AfterExplosion(ExplodingBlob __instance,bool __state)
        {
            var a=Active;if(__state || a==null || !a._host) return;
            var ai=__instance.GetComponentInParent<ZombieAIController>(); if(ai==null || !__instance.Exploded) return;
            // 1.1.6: the guest sees the stomach burst too.
            a.SendEffect(ai,LanProtocol.EffectBurst,__instance.ExplosionEffectSpawnPoint!=null?__instance.ExplosionEffectSpawnPoint.position:__instance.transform.position,Vector3.up);
            foreach(var r in a._remotes.Values)
                if(r.Ready && Vector3.Distance(__instance.transform.position,r.Position)<=Mathf.Clamp(__instance.Radius,0,30) && ClearLine(ai,r.Position)) a.Hurt(r,__instance.Damage,3);
        }
        // 1.1.8: the nurse threw its healing smoke (ShotAndReloading: the sphere and the mucus spray).
        private static void BeforeThrow(ZombieAIController __instance,out bool __state) { __state=__instance.weaponsShot; }
        private static void AfterThrow(ZombieAIController __instance,bool __state)
        {
            var a=Active; if(__state || a==null || !a._host || !__instance.weaponsShot || __instance.bulletPoint==null) return;
            try { a.SendEffect(__instance,LanProtocol.EffectThrow,__instance.bulletPoint.position,__instance.bulletPoint.forward); }
            catch(Exception ex) { if(!a._effectFailed) { a._effectFailed=true; a._report("Zombie effect not sent: "+ex.GetType().Name+": "+ex.Message); } }
        }
        // 1.1.6: a host zombie spat (Cannon.FireOneShot): the same projectile flies for the guest.
        private static void AfterCannonShot(Cannon __instance)
        {
            var a=Active; if(a==null || !a._host || __instance==null || __instance.FirePoint==null) return;
            try {
                // 2.2.0: a robot dog's turret: the guests saw the dog stand still while zombies fell around it.
                var device=__instance.GetComponentInParent<RobotDevice>();
                if(device!=null) { a.SendDeviceEffect(DeviceId(device),LanProtocol.EffectDeviceShot,__instance.FirePoint.position,__instance.FirePoint.forward); return; }
                if(__instance.projectile==null) return;
                a.SendEffect(__instance.GetComponentInParent<ZombieAIController>(),LanProtocol.EffectShot,__instance.FirePoint.position,__instance.FirePoint.forward);
            }
            catch(Exception ex) { if(!a._effectFailed) { a._effectFailed=true; a._report("Zombie effect not sent: "+ex.GetType().Name+": "+ex.Message); } }
        }
        // 2.2.0: a robot dog's flamethrower: refreshed while it burns (a lost packet only shortens the flame), stopped at once.
        private static readonly Dictionary<int,float> FlameSent=new Dictionary<int,float>();
        private const float FlameRefresh=.4f, FlameHold=1.2f;
        private static void AfterFlamethrower(Flamethrower __instance)
        {
            var a=Active; if(a==null || !a._host || !a._ready || __instance==null || !__instance.Firing || __instance.FiringPoint==null) return;
            int key=__instance.GetInstanceID(); float now=Time.unscaledTime, next;
            if(FlameSent.TryGetValue(key,out next) && now<next) return;
            if(FlameSent.Count>=64) FlameSent.Clear();
            FlameSent[key]=now+FlameRefresh;
            try {
                var device=__instance.GetComponentInParent<RobotDevice>();
                if(device!=null) a.SendDeviceEffect(DeviceId(device),LanProtocol.EffectFlameOn,__instance.FiringPoint.position,__instance.FiringPoint.forward);
            }
            catch(Exception ex) { if(!a._effectFailed) { a._effectFailed=true; a._report("Robot dog effect not sent: "+ex.GetType().Name+": "+ex.Message); } }
        }
        private static void BeforeFiring(Flamethrower __instance,out bool __state) { __state=__instance!=null && __instance.Firing; }
        private static void AfterFiring(Flamethrower __instance,bool __state)
        {
            var a=Active; if(!__state || __instance==null || __instance.Firing) return;
            FlameSent.Remove(__instance.GetInstanceID());
            if(a==null || !a._host || !a._ready || __instance.FiringPoint==null) return;
            try {
                var device=__instance.GetComponentInParent<RobotDevice>();
                if(device!=null) a.SendDeviceEffect(DeviceId(device),LanProtocol.EffectFlameOff,__instance.FiringPoint.position,__instance.FiringPoint.forward);
            }
            catch(Exception ex) { if(!a._effectFailed) { a._effectFailed=true; a._report("Robot dog effect not sent: "+ex.GetType().Name+": "+ex.Message); } }
        }
        // Host: the RobotDevice id of a dog's device (as its slot's item spawns it, the id the dog's frame sends); -1: unknown.
        private static int DeviceId(RobotDevice device)
        {
            var dog=device==null?null:device.ConnectedRobot;
            if(dog==null || dog.Devices==null) return -1;
            foreach(var slot in dog.Devices) {
                if(slot==null || slot.device!=device) continue;
                var item=slot.inventory==null?null:slot.inventory.GetFirstItem();
                return item==null?-1:item.RobotDeviceID;
            }
            return -1;
        }
        private void SendDeviceEffect(int device,byte action,Vector3 at,Vector3 facing)
        {
            if(!_host || !_ready || device<0 || device>=LanProtocol.NoDevice || !LanProtocol.ValidPoint(at.x,at.y,at.z)) return;
            if(facing.sqrMagnitude<.0001f) facing=Vector3.forward;
            facing.Normalize();
            foreach(var r in _remotes.Values) {
                if(!r.Ready || (at-r.Position).sqrMagnitude>EffectRange*EffectRange) continue;
                var p=Message(PacketKind.ZombieEffect,++r.EffectSequence); p.Revision=device+1; p.Action=action;
                p.X=at.x;p.Y=at.y;p.Z=at.z;p.AimX=facing.x;p.AimY=facing.y;p.AimZ=facing.z; r.Send(p);
            }
        }
        private void SendEffect(ZombieAIController ai,byte action,Vector3 at,Vector3 facing)
        {
            HostZombie h;
            if(!_host || !_ready || ai==null || !_hostIds.TryGetValue(ai.GetInstanceID(),out h)) return;
            if(facing.sqrMagnitude<.0001f) facing=Vector3.forward;
            facing.Normalize();
            foreach(var r in _remotes.Values) {
                if((at-r.Position).sqrMagnitude>EffectRange*EffectRange) continue;
                var p=Message(PacketKind.ZombieEffect,++r.EffectSequence); p.Revision=(int)h.Id; p.Action=action;
                p.X=at.x;p.Y=at.y;p.Z=at.z;p.AimX=facing.x;p.AimY=facing.y;p.AimZ=facing.z; r.Send(p);
            }
        }
        // Guest: the host zombie's spit or burst, from the local prefab of the zombie the copy shows.
        // A spit flies as a visual only (BeforeProjectile): the host books its hits on the guest.
        private void ShowEffect(Packet p)
        {
            if(p.Action>=LanProtocol.EffectDeviceShot) { ShowDeviceEffect(p); return; }
            Replica r; ZombieAIController prefab;
            var player=LocalPlayer();
            // A burst may come after the frame that killed the zombie: its copy may already be a corpse.
            if(player==null || !_replicas.TryGetValue((uint)p.Revision,out r) || r.Root==null || r.Dead && p.Action!=LanProtocol.EffectBurst || !_prefabs.TryGetValue(r.Prefab,out prefab) || prefab==null) return;
            var at=new Vector3(p.X,p.Y,p.Z);
            if((at-player.transform.position).sqrMagnitude>EffectRange*EffectRange) return;
            float volume=GlobalSoundEffects.global==null?1f:Mathf.Clamp01(GlobalSoundEffects.global.EffectsVolume);
            try {
                // 1.1.8: the nurse's healing smoke: the same sphere flies and bursts into the yellow cloud here
                // (whose debuff reaches this player when it stands in it, as the game does to the host).
                if(p.Action==LanProtocol.EffectThrow) {
                    if(prefab.bullet==null) return;
                    var rotation=Quaternion.LookRotation(new Vector3(p.AimX,p.AimY,p.AimZ));
                    Object.Instantiate(prefab.bullet,at,rotation).AddRelativeForce(Vector3.forward*prefab.bulletSpeed,ForceMode.VelocityChange);
                    var effects=prefab.zombieEffects!=null?prefab.zombieEffects:prefab.GetComponentInChildren<ZombieEffects>(true);
                    if(effects!=null && effects.zombieNurseMucusSprays!=null) Object.Instantiate(effects.zombieNurseMucusSprays,at,rotation);
                    return;
                }
                if(p.Action==LanProtocol.EffectShot) {
                    var cannon=prefab.cannon!=null?prefab.cannon:prefab.GetComponentInChildren<Cannon>(true);
                    if(cannon==null || cannon.projectile==null) return;
                    var round=Object.Instantiate(cannon.projectile,at,Quaternion.LookRotation(new Vector3(p.AimX,p.AimY,p.AimZ)));
                    if(cannon.ApplyForce>0) { var body=round.GetComponent<Rigidbody>(); if(body!=null) body.velocity=round.transform.forward*cannon.ApplyForce; }
                    var source=cannon.GetComponent<AudioSource>();
                    if(cannon.AudioShot!=null) AudioSource.PlayClipAtPoint(cannon.AudioShot,at,(source==null?1f:source.volume)*volume);
                    return;
                }
                var blob=prefab.explodingBlob!=null?prefab.explodingBlob:prefab.GetComponent<ExplodingBlob>();
                if(blob==null) return;
                if(blob.ExplosionEffect!=null) Object.Instantiate(blob.ExplosionEffect,at,Quaternion.identity);
                if(prefab.ExplosionAudio!=null) AudioSource.PlayClipAtPoint(prefab.ExplosionAudio,at,volume);
                if(blob.ExplodedPart!=null)
                    foreach(var t in r.Root.GetComponentsInChildren<Transform>(true)) if(t.name==blob.ExplodedPart.name) t.gameObject.SetActive(false);
                // The game's own splash on a player close by: dirt on the screen and a short slowdown.
                if(Vector3.Distance(r.Root.transform.position,player.transform.position)<blob.Radius) {
                    var gui=GlobalManager.global==null?null:GlobalManager.global.canvas;
                    if(gui!=null && gui.ScreenEffectZombieDirt!=null) gui.ScreenEffectZombieDirt.Show(blob.DirtDuration);
                    if(player.statusEffectsController!=null) {
                        var slow=player.gameObject.AddComponent<StatusEffect>();
                        slow.Name="Slow down"; slow.ValueFloat=blob.SlowDownFactor; slow.Duration=blob.SlowDownDuration; slow.ModifyMoveSpeed=true;
                        player.statusEffectsController.Add(slow);
                    }
                }
            }
            catch(Exception ex) { if(!_effectFailed) { _effectFailed=true; _report("Zombie effect not shown: "+ex.GetType().Name+": "+ex.Message); } }
        }
        // Guest (2.2.0): a host robot dog's turret shot or flame, from the local prefab of the device. Its rounds fly as a
        // sight only (the host booked their hits); the copy's turret turns where it fired.
        private sealed class DeviceFlame { internal GameObject Effect; internal AudioSource Loop; internal AudioClip End; internal float Until; }
        private readonly Dictionary<GameObject,DeviceFlame> _deviceFlames=new Dictionary<GameObject,DeviceFlame>();
        private void ShowDeviceEffect(Packet p)
        {
            var player=LocalPlayer();
            var list=ItemsDataBase.Global==null?null:ItemsDataBase.Global.RobotDevices;
            int id=p.Revision-1;
            if(player==null || list==null || id<0 || id>=list.Count || list[id]==null) return;
            var at=new Vector3(p.X,p.Y,p.Z); var facing=new Vector3(p.AimX,p.AimY,p.AimZ);
            if((at-player.transform.position).sqrMagnitude>EffectRange*EffectRange) return;
            float volume=GlobalSoundEffects.global==null?1f:Mathf.Clamp01(GlobalSoundEffects.global.EffectsVolume);
            try {
                var prefab=list[id];
                var copy=LanWorldItems.DeviceNear(id,at,3f);
                if(copy!=null) AimDeviceCopy(prefab,copy,facing);
                if(p.Action==LanProtocol.EffectDeviceShot) {
                    var cannon=prefab.GetComponentInChildren<Cannon>(true);
                    if(cannon==null) return;
                    var rotation=Quaternion.LookRotation(facing);
                    if(cannon.projectile!=null) {
                        // A projectile flies as a visual only here (BeforeProjectile).
                        var shell=Object.Instantiate(cannon.projectile,at,rotation);
                        if(cannon.ApplyForce>0) { var body=shell.GetComponent<Rigidbody>(); if(body!=null) body.velocity=shell.transform.forward*cannon.ApplyForce; }
                    }
                    if(cannon.bullet!=null)
                        for(int i=Mathf.Clamp(cannon.RoundsInShot,1,16);i>0;i--) {
                            float spread=Mathf.Clamp(cannon.RandomAngle,0,30);
                            VisualRound(cannon.bullet,at,rotation*Quaternion.Euler(UnityEngine.Random.Range(-spread,spread),UnityEngine.Random.Range(-spread,spread),0),cannon.ApplyForce);
                        }
                    if(cannon.fireEffect!=null) {
                        Transform point=copy==null?null:CopyPart(copy,prefab.transform,cannon.FirePoint);
                        var flash=point!=null?Object.Instantiate(cannon.fireEffect,point,false):Object.Instantiate(cannon.fireEffect,at,rotation);
                        Object.Destroy(flash.gameObject,3f);
                    }
                    var source=cannon.GetComponentInChildren<AudioSource>(true);
                    if(cannon.AudioShot!=null) AudioSource.PlayClipAtPoint(cannon.AudioShot,at,(source==null?1f:source.volume)*volume);
                    return;
                }
                var thrower=prefab.GetComponentInChildren<Flamethrower>(true);
                if(thrower==null || copy==null) return;
                DeviceFlame flame;
                if(p.Action==LanProtocol.EffectFlameOff) { if(_deviceFlames.TryGetValue(copy,out flame)) { _deviceFlames.Remove(copy); StopFlame(flame,volume); } return; }
                if(_deviceFlames.TryGetValue(copy,out flame) && flame.Effect!=null) { flame.Until=Time.unscaledTime+FlameHold; return; }
                Transform jet=thrower.Effect==null?null:CopyPart(copy,prefab.transform,thrower.Effect.transform);
                if(jet==null) return;
                jet.gameObject.SetActive(true);
                foreach(var particles in jet.GetComponentsInChildren<ParticleSystem>(true)) particles.Play(true);
                flame=new DeviceFlame {Effect=jet.gameObject,End=thrower.AudioEnd,Until=Time.unscaledTime+FlameHold};
                if(thrower.AudioStart!=null) AudioSource.PlayClipAtPoint(thrower.AudioStart,at,volume);
                if(thrower.AudioLoop!=null) {
                    flame.Loop=jet.gameObject.AddComponent<AudioSource>();
                    flame.Loop.clip=thrower.AudioLoop; flame.Loop.loop=true; flame.Loop.spatialBlend=1f; flame.Loop.volume=volume; flame.Loop.Play();
                }
                _deviceFlames[copy]=flame;
            }
            catch(Exception ex) { if(!_effectFailed) { _effectFailed=true; _report("Robot dog effect not shown: "+ex.GetType().Name+": "+ex.Message); } }
        }
        // A round of the device's own look, without its script (its contact would strike this world's copies): flies to
        // the first surface on its line and goes.
        private static void VisualRound(BulletScript prefab,Vector3 at,Quaternion rotation,float force)
        {
            var round=Object.Instantiate(prefab,at,rotation);
            round.enabled=false;
            foreach(var collider in round.GetComponentsInChildren<Collider>(true)) collider.enabled=false;
            float speed=force>0?force:300f, reach=100f;
            var body=round.GetComponent<Rigidbody>(); if(body!=null) { body.useGravity=false; body.velocity=round.transform.forward*speed; }
            RaycastHit hit;
            if(Physics.Raycast(at,round.transform.forward,out hit,reach,prefab.targetRaycastMask.value,QueryTriggerInteraction.Ignore)) reach=hit.distance;
            Object.Destroy(round.gameObject,Mathf.Clamp(reach/speed,.02f,2f));
        }
        // The copy's turret parts (found by their path in the device prefab) as the game's Turret turns them.
        private static void AimDeviceCopy(RobotDevice prefab,GameObject copy,Vector3 facing)
        {
            var turret=prefab.GetComponentInChildren<Turret>(true);
            if(turret==null) return;
            var horizontal=CopyPart(copy,prefab.transform,turret.HorizontalPart);
            if(horizontal!=null && horizontal.parent!=null) {
                var local=horizontal.parent.InverseTransformDirection(facing);
                float yaw=Mathf.Atan2(local.x,local.z)*Mathf.Rad2Deg;
                if(turret.FiringArcInDeg>0 && turret.FiringArcInDeg<180) yaw=Mathf.Clamp(yaw,-turret.FiringArcInDeg,turret.FiringArcInDeg);
                horizontal.localEulerAngles=new Vector3(0,yaw,0);
            }
            var vertical=CopyPart(copy,prefab.transform,turret.VerticalPart);
            if(vertical!=null && vertical.parent!=null) {
                var local=vertical.parent.InverseTransformDirection(facing);
                float pitch=-Mathf.Atan2(local.y,new Vector2(local.x,local.z).magnitude)*Mathf.Rad2Deg;
                if(turret.MinVerticalAngle<turret.MaxVerticalAngle) pitch=Mathf.Clamp(pitch,turret.MinVerticalAngle,turret.MaxVerticalAngle);
                vertical.localEulerAngles=new Vector3(pitch,0,0);
            }
        }
        // The copy's part at the prefab part's path below its root; null if the part is not below the root.
        private static Transform CopyPart(GameObject copy,Transform root,Transform part)
        {
            var names=new List<string>();
            for(var t=part;t!=null;t=t.parent) {
                if(t==root) return names.Count==0?copy.transform:copy.transform.Find(string.Join("/",names.ToArray()));
                names.Insert(0,t.name);
            }
            return null;
        }
        private static void StopFlame(DeviceFlame flame,float volume)
        {
            if(flame.Loop!=null) Object.Destroy(flame.Loop);
            if(flame.Effect==null) return;
            if(flame.End!=null) AudioSource.PlayClipAtPoint(flame.End,flame.Effect.transform.position,volume);
            flame.Effect.SetActive(false);
        }
        private void TickDeviceFlames(float now)
        {
            if(_deviceFlames.Count==0) return;
            List<GameObject> done=null;
            foreach(var pair in _deviceFlames)
                if(pair.Key==null || pair.Value.Effect==null || now>=pair.Value.Until) (done??(done=new List<GameObject>())).Add(pair.Key);
            if(done==null) return;
            float volume=GlobalSoundEffects.global==null?1f:Mathf.Clamp01(GlobalSoundEffects.global.EffectsVolume);
            foreach(var key in done) { var flame=_deviceFlames[key]; _deviceFlames.Remove(key); StopFlame(flame,volume); }
        }
        private void ClearDeviceFlames()
        {
            foreach(var flame in _deviceFlames.Values) { if(flame.Loop!=null) Object.Destroy(flame.Loop); if(flame.Effect!=null) flame.Effect.SetActive(false); }
            _deviceFlames.Clear();
        }
        private void ReleaseTarget(HostZombie h)
        {
            bool canceledExplosion=h.Explosion;h.AttackGeneration++;h.Explosion=false;
            var target=h.Chased==null || h.Chased.Target==null?null:h.Chased.Target.transform;
            if(h.AI!=null) {
                if(target!=null && h.AI.target==target) h.AI.target=LocalPlayer()==null?null:LocalPlayer().transform;
                foreach(var direction in h.AI.GetComponentsInChildren<SmoothDirection>(true))
                    if(target!=null && direction.Target==target) direction.Target=LocalPlayer()==null?null:LocalPlayer().transform;
                if(h.AI.skillChargeAttack!=null && (int)h.AI.skillChargeAttack.CurrentPhase!=0) h.AI.skillChargeAttack.StopCharge();
                if(h.AI.flamethrower!=null) {
                    h.AI.flamethrower.StopFire();
                    if(h.AI.zombieAnimation!=null && h.AI.flamethrower.animations!=null)
                        foreach(var animation in h.AI.flamethrower.animations)
                            if(animation!=null) h.AI.zombieAnimation.TripleAnimationOff(animation);
                }
                if(h.AI.skillFrogTongue!=null) h.AI.skillFrogTongue.StopFire();
                h.AI.doingFireAnimation=false;h.AI.WiggleOnDamage=true;
                if(canceledExplosion && h.AI.zombieAnimation!=null && h.AI.zombieAnimation.animator!=null)
                    h.AI.zombieAnimation.animator.SetBool("bellyExplosion",false);
                h.AI.attackRayActivatorHunterAnimation=false;h.AI.attackRayActivator=0;h.AI.attackTimer=0;h.AI.SetNavMeshStop(false,true);
            }
            h.Chased=null;h.Fleeing=false;
        }
        private void ReleaseTargets() { foreach(var h in _catalog) if(h.Chased!=null) ReleaseTarget(h); }
        private void ReleaseTargets(Remote r) { foreach(var h in _catalog) if(h.Chased==r) ReleaseTarget(h); }
        internal void Freeze()
        {
            _ready=false;_playerReady=false;
            if(_host) foreach(var g in _remotes.Values) { g.Ready=false; g.Combat.Freeze(); } else Combat.Freeze();
            ReleaseTargets();foreach(var r in _replicas.Values) if(r.Root!=null) r.Root.SetActive(false);
        }
        private void ResetWorld(string scene,uint epoch)
        {
            ReleaseTargets(); foreach(var r in _replicas.Values) if(r.Root!=null) Object.Destroy(r.Root);
            ClearDeviceFlames(); FlameSent.Clear(); // 2.2.0
            _replicas.Clear();_hostIds.Clear();_catalog.Clear();_failedPrefabs.Clear();_unknownPrefabs.Clear();Array.Clear(_seen,0,_seen.Length);Array.Clear(_dead,0,_dead.Length);Array.Clear(_corpseSeen,0,_corpseSeen.Length);
            _sentFrames=0;_receivedFrames=0;_createdReplicas=0;_diagnosticAt=0;
            Array.Clear(_pendingFrames,0,_pendingFrames.Length);Array.Clear(_pendingSequences,0,_pendingSequences.Length);
            Array.Clear(_pendingTimes,0,_pendingTimes.Length);_haveClock=false;_clockOffset=0;_jitter=0;
            _pendingCount=0;_applyCursor=1;
            _scene=scene;_epoch=epoch;_actionSequence=0;_lastHurt=0;_scanAt=0;_sendAt=0;_lastEffect=0;
            foreach(var r in _remotes.Values) {
                r.Hurts.Clear(); Array.Clear(r.PendingDamage,0,r.PendingDamage.Length);
                r.Cursor=0; r.Sequence=0; r.CorpseSequence=0; r.EffectSequence=0; r.HurtSequence=0; r.LastAction=0; r.NextAction=0; r.HurtAt=0; r.DamageAt=0;
                r.Combat.Rebind(scene,epoch);
            }
            if(Combat!=null) Combat.Rebind(scene,epoch);
        }
        public void Dispose()
        {
            if(_disposed)return;Freeze();ResetWorld(null,0);_disposed=true;
            foreach(var r in _remotes.Values) if(r.Target!=null) Object.Destroy(r.Target);
            _remotes.Clear();
            if(Active==this)Active=null;
        }

        private static void InstallGuard()
        {
            if(Guard!=null) return;
            var harmony=new Harmony("local.zompiercer.lan.zombies");
            try {
                Patch(harmony,typeof(ZombieAIController),"Update",nameof(AIUpdate));
                Patch(harmony,typeof(ZombieAIController),"FixedUpdate",nameof(AIFixed));
                foreach(var type in new[]{typeof(ZombieSpawn),typeof(ZombieDeadSpawn)}) Patch(harmony,type,"Activator",nameof(AllowNative));
                foreach(var method in new[]{"Awake","Start"}) Patch(harmony,typeof(ZombieAIController),method,nameof(ClientZombie));
                foreach(var type in new[]{typeof(ZombieHP),typeof(ZombieDamagDetector),typeof(ZombieTrainDetector)})
                    foreach(var method in new[]{"Update","CauseDamage","OnTriggerEnter","Dead"}) if(HasMethod(type,method)) Patch(harmony,type,method,nameof(AllowNative));
                harmony.Patch(AccessTools.Method(typeof(Gun),"Shot"),new HarmonyMethod(typeof(ZombieSync),nameof(BeforeShot)),new HarmonyMethod(typeof(ZombieSync),nameof(AfterShot)));
                // 1.5.0: a bow shoots on its own (Bow.SetPhase draws, Bow.TryShot looses), not through Gun.Shot.
                harmony.Patch(AccessTools.Method(typeof(Bow),"SetPhase"),new HarmonyMethod(typeof(ZombieSync),nameof(BeforeBowPhase)));
                harmony.Patch(AccessTools.Method(typeof(Bow),"TryShot"),postfix:new HarmonyMethod(typeof(ZombieSync),nameof(AfterBowShot)));
                harmony.Patch(AccessTools.Method(typeof(Gun),"MeleeStrike"),new HarmonyMethod(typeof(ZombieSync),nameof(BeforeMelee)),new HarmonyMethod(typeof(ZombieSync),nameof(AfterMelee)));
                harmony.Patch(AccessTools.Method(typeof(Gun),"MeleeHitTarget"),new HarmonyMethod(typeof(ZombieSync),nameof(BeforeMeleeHit)));
                harmony.Patch(AccessTools.Method(typeof(Gun),"ReloadingActivate"),new HarmonyMethod(typeof(ZombieSync),nameof(BeforeReload)));
                Patch(harmony,typeof(Gun),"RechargeSuitableRounds",nameof(BeforeRecharge));
                harmony.Patch(AccessTools.Method(typeof(Gun),"MagazineInserted"),prefix:new HarmonyMethod(typeof(ZombieSync),nameof(BeforeInserted)),
                    postfix:new HarmonyMethod(typeof(ZombieSync),nameof(AfterInserted)),finalizer:new HarmonyMethod(typeof(ZombieSync),nameof(InsertedDone)));
                harmony.Patch(AccessTools.Method(typeof(Inventory),"Extract",new[]{typeof(InventoryItem),typeof(int)}),new HarmonyMethod(typeof(ZombieSync),nameof(BeforeExtract)));
                Patch(harmony,typeof(Projectile),"FixedUpdate",nameof(BeforeProjectile));
                Patch(harmony,typeof(BulletScript),"BulletContact",nameof(BeforeBulletContact)); // 2.4.3
                harmony.Patch(AccessTools.Method(typeof(Flame),"FixedUpdate"),null,new HarmonyMethod(typeof(ZombieSync),nameof(AfterFlame)));
                Patch(harmony,typeof(SmoothDirection),"Update",nameof(BeforeSmooth));
                Patch(harmony,typeof(ZombieAIController),"GetPlayerPositionAim",nameof(BeforeAim));
                Patch(harmony,typeof(ItemStealer),"FixedUpdate",nameof(BeforeTongueHit));
                try {
                    _optAnimation=AccessTools.FieldRefAccess<ZombieOptimazer,ZombieAnimation>("zombieAnimation");
                    _optAI=AccessTools.FieldRefAccess<ZombieOptimazer,ZombieAIController>("zombieAIController");
                    Patch(harmony,typeof(ZombieOptimazer),"Update",nameof(BeforeOptimizer));
                }
                catch(Exception ex) { _optAnimation=null; _optAI=null; OptimizerFailure=ex.GetType().Name+": "+ex.Message; }
                harmony.Patch(AccessTools.Method(typeof(ExplodingBlob),"Explode"),new HarmonyMethod(typeof(ZombieSync),nameof(BeforeExplosion)),new HarmonyMethod(typeof(ZombieSync),nameof(AfterExplosion)));
                harmony.Patch(AccessTools.Method(typeof(Cannon),"FireOneShot"),null,new HarmonyMethod(typeof(ZombieSync),nameof(AfterCannonShot)));
                // 2.2.0: a robot dog's flamethrower (its turret's cannon goes through FireOneShot above).
                harmony.Patch(AccessTools.Method(typeof(Flamethrower),"Update"),null,new HarmonyMethod(typeof(ZombieSync),nameof(AfterFlamethrower)));
                harmony.Patch(AccessTools.Method(typeof(Flamethrower),"SetFiring"),new HarmonyMethod(typeof(ZombieSync),nameof(BeforeFiring)),new HarmonyMethod(typeof(ZombieSync),nameof(AfterFiring)));
                harmony.Patch(AccessTools.Method(typeof(ZombieAIController),"ShotAndReloading"),new HarmonyMethod(typeof(ZombieSync),nameof(BeforeThrow)),new HarmonyMethod(typeof(ZombieSync),nameof(AfterThrow)));
                foreach(var type in new[]{typeof(ZombieAIController),typeof(SkillFrogTongue),typeof(SkillFlamethrower),typeof(SkillChargeAttack)})
                    foreach(var method in AccessTools.GetDeclaredMethods(type))
                        if(method.ReturnType==typeof(IEnumerator) && (method.Name=="FireIE" || method.Name=="ChargeIE" ||
                            method.Name=="DoEndHitIE" || method.Name=="ActivateRepulserIE" || method.Name=="BeginStomachExplosionIE"))
                            harmony.Patch(method,null,new HarmonyMethod(typeof(ZombieSync),nameof(OwnAttackRoutine)));
                Guard=harmony;
            } catch { harmony.UnpatchSelf();throw; }
        }
        // Optional native methods: a quiet lookup (AccessTools.Method logs a warning for each absent one).
        private static bool HasMethod(Type type,string name)
        {
            for(var t=type;t!=null;t=t.BaseType)
                foreach(var m in t.GetMethods(BindingFlags.Instance|BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.DeclaredOnly)) if(m.Name==name) return true;
            return false;
        }
        private static void Patch(Harmony h,Type type,string method,string prefix) { h.Patch(AccessTools.Method(type,method),new HarmonyMethod(typeof(ZombieSync),prefix)); }
        private static bool AllowNative() { return !IsClientWorld; }
        private static bool ClientZombie(ZombieAIController __instance) { if(!IsClientWorld)return true;__instance.gameObject.SetActive(false);return false; }
        private static bool AIUpdate(ZombieAIController __instance) { if(IsClientWorld) { __instance.gameObject.SetActive(false);return false; } return Active==null || !Active.RemoteUpdate(__instance); }
        private static bool AIFixed(ZombieAIController __instance) { if(IsClientWorld)return false;HostZombie h;return Active==null || !Active._hostIds.TryGetValue(__instance.GetInstanceID(),out h) || h.Chased==null; }
        private static void OwnAttackRoutine(Component __instance,ref IEnumerator __result)
        {
            var owner=Active;HostZombie zombie;
            var ai=__instance.GetComponentInParent<ZombieAIController>();
            if(owner!=null && owner._host && ai!=null && owner._hostIds.TryGetValue(ai.GetInstanceID(),out zombie) && zombie.Chased!=null)
                __result=GuardAttack(__result,owner,zombie,zombie.AttackGeneration);
        }
        private static IEnumerator GuardAttack(IEnumerator routine,ZombieSync owner,HostZombie zombie,int generation)
        {
            try {
                while(!owner._disposed && owner._ready && zombie.Chased!=null && zombie.Chased.Ready && zombie.AttackGeneration==generation && routine.MoveNext()) {
                    var nested=routine.Current as IEnumerator;
                    yield return nested==null?routine.Current:GuardAttack(nested,owner,zombie,generation);
                }
            }
            finally { (routine as IDisposable)?.Dispose(); }
        }
        private static bool CanClientUse(Gun gun,bool reload=false) { return !IsClientWorld || Active!=null && !Active._host && Active._playerReady && Active.Combat.CanUse(gun,reload); }
        // 1.5.0: what a gun fires: its round, or a bow's arrow.
        internal static Rigidbody Round(Gun gun)
        {
            if(gun==null) return null;
            if(gun.bulletPrefab!=null) return gun.bulletPrefab;
            return gun.bow!=null ? gun.bow.arrowPrefab : null;
        }
        // 1.5.0, guest: a bow is drawn (SetPhase 1) only when the host would book its shot, as a gun's Shot is gated.
        private static bool BeforeBowPhase(Bow __instance,int value)
        {
            if(value!=1 || !IsClientWorld || __instance==null) return true;
            var gun=__instance.GetComponent<Gun>();
            if(gun==null || CanClientUse(gun)) return true;
            Refused("Shot",gun,false); return false;
        }
        // 1.5.0, guest: the bow's own shot goes to the host as a shot, and its reload after it (the game reloads a bow by
        // the animation after the shot, and that animation's transfer of an arrow is the host's here, as a gun's reload).
        // Before, the host never heard of a bow's shot (no damage) and the bow stayed empty.
        private static void AfterBowShot(Bow __instance)
        {
            var a=Active;
            if(!IsClientWorld || a==null || a._host || __instance==null) return;
            var gun=__instance.GetComponent<Gun>(); if(gun==null) return;
            a.CaptureAction(gun,0);
            if(gun.HowMuchAmmoInInventory()>=1) a.CaptureReload(gun);
        }
        private static bool BeforeShot(Gun __instance,out int __state) { __state=__instance.magazine; if(CanClientUse(__instance)) return true; Refused("Shot",__instance,false); return false; }
        private static void AfterShot(Gun __instance,int __state) { if(Active!=null && __instance.magazine<__state) Active.CaptureAction(__instance,0); }
        private static bool BeforeMelee(Gun __instance,out bool __state) { __state=__instance.meleeAttack; if(CanClientUse(__instance)) return true; Refused("Blow",__instance,false); return false; }
        private static void AfterMelee(Gun __instance,bool __state) { if(Active!=null && !__state && __instance.meleeAttack) Active.SwingStarted(__instance); }
        // 1.5.0, guest: a swing goes to the host when the game's blow lands (Gun.MeleeHitTarget, mid-swing), with what it meets
        // there; it went at the swing's start, and a zombie that was not yet within reach then was missed. A swing that never
        // lands (cut short) still goes after a while, as before (the host books its stamina).
        private Gun _swing; private float _swingAt;
        private void SwingStarted(Gun gun)
        {
            if(_host) { CaptureAction(gun,1); return; }
            if(_swing!=null) CaptureAction(_swing,1,_swingAt);
            _swing=gun; _swingAt=Time.unscaledTime;
        }
        private void SwingLands(Gun gun)
        {
            if(_swing==null || _swing!=gun) return;
            _swing=null; CaptureAction(gun,1,_swingAt);
        }
        private void TickSwing()
        {
            if(_swing!=null && Time.unscaledTime-_swingAt>1.2f) { var gun=_swing; _swing=null; CaptureAction(gun,1,_swingAt); }
        }
        private static bool BeforeReload(Gun __instance)
        {
            if(!IsClientWorld) return true;
            if(__instance.reloading) return false;
            if(!CanClientUse(__instance,true)) { Refused("Reload",__instance,true); return false; }
            // 1.0.6: the host books the reload; the native one still runs for the first-person
            // animation, with its rounds transfer suppressed below (no reserve spent twice).
            Active.CaptureReload(__instance);
            return true;
        }
        // 1.4.16, guest: why a blow, a shot or a reload is refused, at most every 10 seconds (it was refused
        // without a word: no blows at all, not even with the fists, and a rifle that would not reload).
        private static float _refusedLogAt;
        private static void Refused(string what,Gun gun,bool reload)
        {
            if(!IsClientWorld || Active==null || Time.unscaledTime<_refusedLogAt) return;
            _refusedLogAt=Time.unscaledTime+10f;
            Active._report(what+" refused: "+(!Active._playerReady?"the player is not placed in the host's world yet":Active.Combat.Refusal(gun,reload)));
        }
        // Guest: animation events must not move rounds; the magazine and reserve come from the host.
        private static bool _suppressExtract;
        private static bool BeforeRecharge() { return !IsClientWorld; }
        private static bool BeforeExtract() { return !_suppressExtract; }
        private static void BeforeInserted(Gun __instance,out int __state) { __state=__instance.magazine; _suppressExtract=IsClientWorld; }
        private static void AfterInserted(Gun __instance,int __state)
        {
            if(!IsClientWorld || !__instance.IncrementalReloading) return;
            __instance.magazine=__state;
            // One cartridge per event loops until the native magazine fills, which it no longer
            // does here: end the loop once the host has finished (or refused) the reload.
            if(Active==null || !Active.Combat.ReloadPending) __instance.weaponAnimation.SetBool("reload",false);
        }
        private static Exception InsertedDone(Exception __exception) { _suppressExtract=false; return __exception; }
    }
}
