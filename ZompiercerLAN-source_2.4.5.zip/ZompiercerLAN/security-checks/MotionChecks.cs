using System;

namespace ZompiercerLAN
{
    // 1.4.6: the player's State carries the sender's clock and its dash (packet schema 36), and
    // goes 20 times a second. 1.4.7: how it moves and its throws (schema 37). 1.4.8: its presses of the
    // use key (schema 38).
    internal static partial class Program
    {
        private static void MotionChecks()
        {
            Packet decoded;
            var state = State(77);
            state.SentAt = 0xFEDCBA98u; state.Dash = (byte)(LanProtocol.MaxDashCount << 3 | 7);
            state.Motion = (byte)(LanProtocol.MotionRun | LanProtocol.MotionAir | LanProtocol.MotionSwim | LanProtocol.MotionCock | LanProtocol.MaxUse << LanProtocol.UseShift);
            state.Throws = 255; state.Interacts = 254;
            var bytes = LanProtocol.Encode(state);
            Require(LanProtocol.TryDecode(bytes, out decoded) && decoded.SentAt == 0xFEDCBA98u && decoded.Dash == state.Dash && decoded.Sequence == 77 &&
                decoded.Motion == state.Motion && decoded.Throws == 255 && decoded.Interacts == 254, "State clock, dash, motion, throws or presses lost");
            for (int size = 0; size < bytes.Length; size++) { var t = new byte[size]; Array.Copy(bytes, t, size); Require(!LanProtocol.TryDecode(t, out decoded), "Truncated state accepted"); }
            var tail = new byte[bytes.Length + 1]; Array.Copy(bytes, tail, bytes.Length);
            Require(!LanProtocol.TryDecode(tail, out decoded), "State trailing bytes accepted");
            // The dash, the motion, the throws and the presses are the four bytes before the outfit (2.3.0: here
            // its count, 0) and the mods in hand (2.4.0: their count, 0): a direction without any dash yet is
            // malformed, every other value is a dash.
            const int Outfit = 2;
            for (int dash = 0; dash < 256; dash++)
            {
                var t = (byte[])bytes.Clone(); t[t.Length - 4 - Outfit] = (byte)dash;
                bool valid = dash >> 3 != 0 || (dash & 7) == 0;
                Require(LanProtocol.TryDecode(t, out decoded) == valid && LanProtocol.ValidDash((byte)dash) == valid && (!valid || decoded.Dash == dash), "Dash " + dash + " decoded wrongly");
            }
            // Motion: the top bit unused, the use kind at most MaxUse; every count of throws is one.
            for (int motion = 0; motion < 256; motion++)
            {
                var t = (byte[])bytes.Clone(); t[t.Length - 3 - Outfit] = (byte)motion;
                bool valid = (motion & 0x80) == 0 && motion >> LanProtocol.UseShift <= LanProtocol.MaxUse;
                Require(LanProtocol.TryDecode(t, out decoded) == valid && LanProtocol.ValidMotion((byte)motion) == valid && (!valid || decoded.Motion == motion), "Motion " + motion + " decoded wrongly");
                t = (byte[])bytes.Clone(); t[t.Length - 2 - Outfit] = (byte)motion;
                Require(LanProtocol.TryDecode(t, out decoded) && decoded.Throws == motion, "Throws " + motion + " rejected");
                t = (byte[])bytes.Clone(); t[t.Length - 1 - Outfit] = (byte)motion;
                Require(LanProtocol.TryDecode(t, out decoded) && decoded.Interacts == motion, "Presses " + motion + " rejected");
            }
            // 2.3.0 (schema 46): what the player wears, at most MaxOutfit item ids, each as it was.
            var dressed = State(78);
            dressed.Outfit = new ushort[LanProtocol.MaxOutfit];
            for (int i = 0; i < dressed.Outfit.Length; i++) dressed.Outfit[i] = (ushort)(i == 0 ? 65535 : 220 + i);
            var worn = LanProtocol.Encode(dressed);
            Require(LanProtocol.TryDecode(worn, out decoded) && decoded.Outfit.Length == LanProtocol.MaxOutfit && decoded.Outfit[0] == 65535 && decoded.Outfit[7] == 227,
                "Outfit lost");
            for (int size = 0; size < worn.Length; size++) { var t = new byte[size]; Array.Copy(worn, t, size); Require(!LanProtocol.TryDecode(t, out decoded), "Truncated outfit accepted"); }
            var wornTail = new byte[worn.Length + 1]; Array.Copy(worn, wornTail, worn.Length);
            Require(!LanProtocol.TryDecode(wornTail, out decoded), "Outfit with trailing bytes accepted");
            // The count forged past the bound (with the bytes such a count would need) is refused.
            var forged = new byte[worn.Length + 2]; Array.Copy(worn, forged, worn.Length);
            forged[worn.Length - 2 - 2 * LanProtocol.MaxOutfit] = (byte)(LanProtocol.MaxOutfit + 1);
            Require(!LanProtocol.TryDecode(forged, out decoded), "Outfit beyond its bound accepted");
            dressed.Outfit = new ushort[LanProtocol.MaxOutfit + 1];
            try { LanProtocol.Encode(dressed); Require(false, "An outfit beyond its bound was encoded"); }
            catch (System.IO.InvalidDataException) { }
            dressed.Outfit = null;
            Require(LanProtocol.TryDecode(LanProtocol.Encode(dressed), out decoded) && decoded.Outfit != null && decoded.Outfit.Length == 0, "No outfit not empty");
            // 2.4.0 (schema 47): the mods on the weapon in hand, at most MaxHandMods slots, empty ones as NoMod.
            var armed = State(79);
            armed.Outfit = new ushort[] { 227 };
            armed.HandMods = new ushort[LanProtocol.MaxHandMods];
            for (int i = 0; i < armed.HandMods.Length; i++) armed.HandMods[i] = i == 1 ? LanProtocol.NoMod : (ushort)(40 + i);
            var modded = LanProtocol.Encode(armed);
            Require(LanProtocol.TryDecode(modded, out decoded) && decoded.HandMods.Length == LanProtocol.MaxHandMods && decoded.HandMods[0] == 40 &&
                decoded.HandMods[1] == LanProtocol.NoMod && decoded.HandMods[5] == 45 && decoded.Outfit.Length == 1 && decoded.Outfit[0] == 227, "Mods in hand lost");
            for (int size = 0; size < modded.Length; size++) { var t = new byte[size]; Array.Copy(modded, t, size); Require(!LanProtocol.TryDecode(t, out decoded), "Truncated mods in hand accepted"); }
            var moddedTail = new byte[modded.Length + 1]; Array.Copy(modded, moddedTail, modded.Length);
            Require(!LanProtocol.TryDecode(moddedTail, out decoded), "Mods in hand with trailing bytes accepted");
            var forgedMods = new byte[modded.Length + 2]; Array.Copy(modded, forgedMods, modded.Length);
            forgedMods[modded.Length - 1 - 2 * LanProtocol.MaxHandMods] = (byte)(LanProtocol.MaxHandMods + 1);
            Require(!LanProtocol.TryDecode(forgedMods, out decoded), "Mods in hand beyond their bound accepted");
            armed.HandMods = new ushort[LanProtocol.MaxHandMods + 1];
            try { LanProtocol.Encode(armed); Require(false, "Mods in hand beyond their bound were encoded"); }
            catch (System.IO.InvalidDataException) { }
            armed.HandMods = null;
            Require(LanProtocol.TryDecode(LanProtocol.Encode(armed), out decoded) && decoded.HandMods != null && decoded.HandMods.Length == 0, "No mods in hand not empty");
            state.Dash = 3;
            try { LanProtocol.Encode(state); Require(false, "A direction without a dash was encoded"); }
            catch (System.IO.InvalidDataException) { }
            state.Dash = 0; state.Motion = (byte)((LanProtocol.MaxUse + 1) << LanProtocol.UseShift);
            try { LanProtocol.Encode(state); Require(false, "An unknown use was encoded"); }
            catch (System.IO.InvalidDataException) { }
            // Twenty states a second, with room for a delivery burst; a flood stays bounded.
            var limits = new LanMessageLimits(); int states = 0;
            for (int i = 0; i < 1000; i++) if (limits.Take(PacketKind.State, 0)) states++;
            Require(states == 48, "State bursts not bounded");
            for (int i = 0; i < 1000; i++) if (limits.Take(PacketKind.State, 1)) states++;
            Require(states == 88, "State rate not 40 a second");
            Console.WriteLine("PASS: player state (sender clock, dash, motion, throws and use-key presses roundtrip, truncation and trailing bytes, every dash, motion, throws and presses byte, 2.3.0 outfit of up to 8 items: roundtrip, truncation, forged count, encoder bound; 20 a second within a bounded budget)");
        }
    }
}
