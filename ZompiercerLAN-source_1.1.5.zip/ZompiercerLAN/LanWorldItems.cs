using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
using Zompiercer.Inventory;
using Object = UnityEngine.Object;

namespace ZompiercerLAN
{
    // Loose items and zombie loot bags of the host's world (0.7.0). The host sends
    // what lies around the guest (changes first, the rest in turn); the guest shows
    // script-free copies and hides the loose items its own copy of the world
    // generated. Picking up and dropping go through the host (LanStorage requests),
    // so the guest's ledger only ever grows by what the host hands out.
    // Items placed on the train travel with the train layout instead. Main thread only.
    internal sealed class LanWorldItems
    {
        internal const float Radius = 40f, Reach = 3.5f, Look = 3f;
        private const float ScanEvery = 1f, SendEvery = .2f, Stale = 6f, HideEvery = 1f;
        private const int MaxShown = 160;
        internal const byte ItemKind = 0, BagKind = 1, GoneKind = 2;

        private sealed class HostEntry { internal Component Source; internal WorldItemFrame Frame; }
        private sealed class Shown { internal GameObject Root; internal int ItemId, Amount; internal byte Kind; internal float Seen; internal bool PickedUp; }

        private static Harmony _harmony;
        private static Action<string> _staticLog;
        // Guest: items its player just dropped, booked at LateUpdate when they are placed.
        internal static readonly List<InventoryItem> Dropped = new List<InventoryItem>();
        internal static readonly HashSet<InventoryItem> Placed = new HashSet<InventoryItem>();
        // Guest attached to the host's world: picking up and dropping go through the host.
        internal static bool GuestActive;

        private readonly bool _host;
        private readonly Action<Packet> _send;
        private readonly Action<string> _log;
        // Host: every loose item and bag by instance id (train items too, for pick-ups).
        private readonly Dictionary<int, HostEntry> _objects = new Dictionary<int, HostEntry>();
        private readonly List<HostEntry> _near = new List<HostEntry>();
        private readonly Dictionary<int, WorldItemFrame> _sent = new Dictionary<int, WorldItemFrame>();
        private readonly List<int> _gone = new List<int>();
        private readonly Dictionary<int, Shown> _shown = new Dictionary<int, Shown>();
        private string _scene;
        private uint _epoch, _sequence, _received;
        private bool _ready;
        private float _scanAt, _sendAt, _hideAt, _rescanAt;
        private int _cursor;

        internal LanWorldItems(bool host, Action<Packet> send, Action<string> log) { _host = host; _send = send; _log = log; }

        internal static void Initialize(Action<string> log)
        {
            _staticLog = log;
            if (_harmony != null) return;
            _harmony = new Harmony("local.zompiercer.lan.world-items");
            try
            {
                _harmony.Patch(AccessTools.Method(typeof(Inventory), "Remove"), postfix: new HarmonyMethod(typeof(LanWorldItems), nameof(RemovePostfix)));
                _harmony.Patch(AccessTools.Method(typeof(Inventory), "Add", new[] { typeof(InventoryItem), typeof(bool) }), prefix: new HarmonyMethod(typeof(LanWorldItems), nameof(DuplicateAddPrefix)));
                _harmony.Patch(AccessTools.Method(typeof(InventoryController), "Update"), prefix: new HarmonyMethod(typeof(LanWorldItems), nameof(PickupPrefix)));
                _harmony.Patch(AccessTools.Method(typeof(InventoryController), "Update"), prefix: new HarmonyMethod(typeof(LanWorldItems), nameof(PlacementPrefix)));
            }
            catch (Exception ex)
            {
                _harmony.UnpatchSelf();
                Failure = ex.GetType().Name + ": " + ex.Message;
                log("World item hooks unavailable: " + Failure);
            }
        }
        internal static string Failure { get; private set; }
        internal static void Shutdown() { _harmony?.UnpatchSelf(); _harmony = null; Dropped.Clear(); Placed.Clear(); GuestActive = false; }

        private static bool DuplicateAddPrefix(Inventory __instance, InventoryItem newItem, ref bool __result)
        {
            // A stale hovered object must not be appended to an inventory twice.
            if (newItem == null || newItem.inInventory != __instance || __instance.content == null || !__instance.content.Contains(newItem)) return true;
            __result = false;
            return false;
        }

        // Guest: an item left one of the player's own inventories (dropped or placed).
        private static void RemovePostfix(Inventory __instance, InventoryItem target)
        {
            // Harmony binds by name: the game's parameter is `target`.
            if (!LanSaveIsolation.Active || !GuestActive || target == null) return;
            var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
            if (player == null || player.AllInventory == null || !player.AllInventory.Contains(__instance)) return;
            if (!Dropped.Contains(target)) Dropped.Add(target);
            var controller = InventoryController.global;
            if (controller != null && controller.ItemPreviewForPlacement != null && controller.AppropriatePosForPreview &&
                controller.draggedIcon != null && controller.draggedIcon.connectedInventoryItem == target) Placed.Add(target);
        }

        // Guest: E on one of its own (hidden or not yet hidden) loose items does nothing.
        private static void PickupPrefix()
        {
            if (!LanSaveIsolation.Active || !GuestActive) return;
            try
            {
                var input = Zompiercer.Inputs.InputController.Global;
                var selection = SelectionManager.Global;
                if (input == null || selection == null || selection.HoveredObject == null) return;
                var item = selection.HoveredObject.GetComponent<InventoryItem>();
                if (item == null) return;
                input.isUseKeyDown = false; input.gp_isUseOpenTalkDown = false; input.isTakeItemAccept_Down = false;
            }
            catch (Exception ex) { _staticLog?.Invoke("World item input hook failed: " + ex.Message); }
        }

        // The ordinary interaction ray skips host construction. A placement
        // preview needs its physical surface, while native furniture stays hidden
        // from selection. Only replace the hit data used by the preview.
        private static void PlacementPrefix(InventoryController __instance)
        {
            if (!LanSaveIsolation.Active || !GuestActive || __instance.ItemPreviewForPlacement == null) return;
            var selection = SelectionManager.Global;
            var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
            if (selection == null || player == null) return;
            RaycastHit best = default(RaycastHit); bool any = false;
            foreach (var hit in Physics.RaycastAll(selection.ray, Look, ~0, QueryTriggerInteraction.Ignore))
            {
                if (hit.collider == null || hit.collider.transform.IsChildOf(player.transform) ||
                    hit.collider.transform.IsChildOf(__instance.ItemPreviewForPlacement.transform)) continue;
                if (!any || hit.distance < best.distance) { best = hit; any = true; }
            }
            selection.raycastHit = best;
        }

        internal void Tick(string scene, uint epoch, bool ready, Vector3? guest)
        {
            if (scene != _scene || epoch != _epoch)
            {
                _scene = scene; _epoch = epoch; _sequence = 0; _received = 0; _cursor = 0;
                _objects.Clear(); _near.Clear(); _sent.Clear(); _gone.Clear(); ClearShown();
            }
            _ready = ready && epoch != 0 && !string.IsNullOrEmpty(scene);
            if (!_ready) return;
            float now = Time.unscaledTime;
            if (!_host) { GuestTick(now); return; }
            if (now >= _scanAt) { _scanAt = now + ScanEvery; Scan(guest); }
            if (now >= _sendAt && guest != null) { _sendAt = now + SendEvery; SendBatch(); }
        }

        // ---- Host ----
        private void Scan(Vector3? guest)
        {
            _objects.Clear();
            foreach (var item in Object.FindObjectsOfType<InventoryItem>())
                if (Loose(item)) _objects[item.GetInstanceID()] = new HostEntry { Source = item, Frame = Frame(item) };
            string bag = BagName();
            if (bag != null)
                foreach (var inventory in Object.FindObjectsOfType<Inventory>())
                    if (inventory != null && inventory.transform.root.name == bag && LanStorageGame.Shared(inventory))
                        _objects[inventory.GetInstanceID()] = new HostEntry { Source = inventory, Frame = Frame(inventory) };
            // A dead guest's bags (0.12.0), also those lying on a train car.
            foreach (var marker in Object.FindObjectsOfType<LanDeathBag>())
            {
                var inventory = marker == null ? null : marker.GetComponentInChildren<Inventory>();
                if (inventory != null && LanStorageGame.Shared(inventory))
                    _objects[inventory.GetInstanceID()] = new HostEntry { Source = inventory, Frame = Frame(inventory) };
            }
            _near.Clear();
            if (guest != null)
            {
                foreach (var entry in _objects.Values)
                {
                    var item = entry.Source as InventoryItem;
                    if (item != null && item.ParentedToTraincCar != null) continue; // shown by the train layout
                    var p = entry.Source.transform.position;
                    if ((p - guest.Value).sqrMagnitude <= Radius * Radius) _near.Add(entry);
                }
                var at = guest.Value;
                _near.Sort((a, b) => (a.Source.transform.position - at).sqrMagnitude.CompareTo((b.Source.transform.position - at).sqrMagnitude));
                if (_near.Count > MaxShown) _near.RemoveRange(MaxShown, _near.Count - MaxShown);
            }
            var kept = new HashSet<int>(); foreach (var entry in _near) kept.Add(entry.Frame.HostId);
            foreach (var id in new List<int>(_sent.Keys)) if (!kept.Contains(id)) { _sent.Remove(id); if (!_gone.Contains(id)) _gone.Add(id); }
        }

        private void SendBatch()
        {
            var batch = new List<WorldItemFrame>();
            while (_gone.Count > 0 && batch.Count < LanProtocol.MaxItemBatch)
            {
                batch.Add(new WorldItemFrame { HostId = _gone[0], ItemId = -1, Kind = GoneKind, Pose = Identity() });
                _gone.RemoveAt(0);
            }
            var included = new HashSet<int>();
            foreach (var entry in _near)
            {
                if (batch.Count >= LanProtocol.MaxItemBatch) break;
                if (entry.Source == null) continue;
                var frame = entry.Source is InventoryItem ? Frame((InventoryItem)entry.Source) : Frame((Inventory)entry.Source);
                WorldItemFrame last;
                if (_sent.TryGetValue(frame.HostId, out last) && Same(last, frame)) continue;
                batch.Add(frame); included.Add(frame.HostId); _sent[frame.HostId] = frame;
            }
            for (int visited = 0; visited < _near.Count && batch.Count < LanProtocol.MaxItemBatch; visited++)
            {
                if (_cursor >= _near.Count) _cursor = 0;
                var entry = _near[_cursor++];
                if (entry.Source == null || included.Contains(entry.Frame.HostId)) continue;
                var frame = entry.Source is InventoryItem ? Frame((InventoryItem)entry.Source) : Frame((Inventory)entry.Source);
                batch.Add(frame); included.Add(frame.HostId); _sent[frame.HostId] = frame;
            }
            if (batch.Count == 0) return;
            _send(new Packet { Kind = PacketKind.WorldItems, WorldEpoch = _epoch, Scene = _scene, Sequence = ++_sequence, Items = batch.ToArray() });
        }

        // Host lookups for pick-ups and bags, with one fresh scan on a miss.
        internal InventoryItem FindItem(int hostId)
        {
            HostEntry entry;
            if (!_objects.TryGetValue(hostId, out entry) || entry.Source == null) { Rescan(); _objects.TryGetValue(hostId, out entry); }
            var item = entry == null ? null : entry.Source as InventoryItem;
            return item != null && Loose(item) ? item : null;
        }
        internal Inventory FindBag(int hostId)
        {
            HostEntry entry;
            if (!_objects.TryGetValue(hostId, out entry) || entry.Source == null) { Rescan(); _objects.TryGetValue(hostId, out entry); }
            return entry == null ? null : entry.Source as Inventory;
        }
        internal void Removed(int hostId) { _objects.Remove(hostId); _sent.Remove(hostId); if (!_gone.Contains(hostId)) _gone.Add(hostId); _sendAt = 0; }
        private void Rescan()
        {
            float now = Time.unscaledTime;
            if (now < _rescanAt) return;
            _rescanAt = now + .5f; _scanAt = now + ScanEvery;
            Scan(null);
        }

        internal static bool Loose(InventoryItem item)
        {
            if (item == null || item.inInventory != null || !item.gameObject.activeInHierarchy) return false;
            if (item.GetComponentInParent<ZombieFighterController>() != null || item.GetComponentInParent<LanWorldReplica>() != null ||
                item.GetComponentInParent<LanTrainReplica>() != null) return false;
            if (item.transform.parent != null && item.transform.parent.GetComponentInParent<InventoryItem>() != null) return false;
            var controller = InventoryController.global;
            if (controller != null && controller.ItemPreviewForPlacement == item) return false;
            var db = ItemsDataBase.Global;
            return db != null && db.itemPrefab != null && item.itemID >= 0 && item.itemID < db.itemPrefab.Length && db.itemPrefab[item.itemID] != null && item.amount >= 1;
        }
        private static string BagName()
        {
            var loot = GlobalObjectLootController.global;
            return loot == null || loot.PrefabZombieLoot == null ? null : loot.PrefabZombieLoot.name + "(Clone)";
        }
        private static WorldItemFrame Frame(InventoryItem item)
        { return new WorldItemFrame { HostId = item.GetInstanceID(), ItemId = item.itemID, Amount = Math.Min(item.amount, LanStorage.MaxAmount), Kind = ItemKind, Pose = Pose(item.transform) }; }
        private static WorldItemFrame Frame(Inventory bag)
        { return new WorldItemFrame { HostId = bag.GetInstanceID(), ItemId = -1, Amount = 0, Kind = BagKind, Pose = Pose(LanDeathBag.RootOf(bag).transform) }; }
        private static NetPose Pose(Transform t)
        {
            var p = t.position; var q = t.rotation;
            return new NetPose { X = p.x, Y = p.y, Z = p.z, QX = q.x, QY = q.y, QZ = q.z, QW = q.w };
        }
        private static NetPose Identity() { return new NetPose { QW = 1 }; }
        private static bool Same(WorldItemFrame a, WorldItemFrame b)
        {
            return a.ItemId == b.ItemId && a.Amount == b.Amount && a.Kind == b.Kind &&
                Math.Abs(a.Pose.X - b.Pose.X) < .05f && Math.Abs(a.Pose.Y - b.Pose.Y) < .05f && Math.Abs(a.Pose.Z - b.Pose.Z) < .05f;
        }

        // ---- Guest ----
        internal void Receive(Packet p)
        {
            if (_host || !_ready || p.Kind != PacketKind.WorldItems || p.WorldEpoch != _epoch || p.Scene != _scene) return;
            if (_received != 0 && unchecked((int)(p.Sequence - _received)) <= 0) return;
            _received = p.Sequence;
            float now = Time.unscaledTime;
            int created = 0;
            foreach (var frame in p.Items)
            {
                Shown shown;
                _shown.TryGetValue(frame.HostId, out shown);
                if (frame.Kind == GoneKind) { if (shown != null) { Object.Destroy(shown.Root); _shown.Remove(frame.HostId); } continue; }
                if (shown != null && (shown.Kind != frame.Kind || shown.ItemId != frame.ItemId)) { Object.Destroy(shown.Root); _shown.Remove(frame.HostId); shown = null; }
                if (shown == null)
                {
                    if (_shown.Count >= MaxShown || created >= 6) continue; // the next refresh brings it
                    var root = CreateVisual(frame);
                    if (root == null) continue;
                    created++;
                    shown = new Shown { Root = root, ItemId = frame.ItemId, Kind = frame.Kind };
                    _shown.Add(frame.HostId, shown);
                    var marker = root.GetComponent<LanWorldReplica>();
                    marker.HostId = frame.HostId; marker.ItemId = frame.ItemId; marker.Kind = frame.Kind;
                }
                if (shown.Amount != frame.Amount) shown.PickedUp = false;
                shown.Seen = now; shown.Amount = frame.Amount;
                shown.Root.GetComponent<LanWorldReplica>().Amount = frame.Amount;
                shown.Root.transform.SetPositionAndRotation(new Vector3(frame.Pose.X, frame.Pose.Y, frame.Pose.Z), new Quaternion(frame.Pose.QX, frame.Pose.QY, frame.Pose.QZ, frame.Pose.QW));
                shown.Root.SetActive(!shown.PickedUp);
            }
        }

        private void GuestTick(float now)
        {
            var stale = new List<int>();
            foreach (var pair in _shown) if (pair.Value.Root == null || now - pair.Value.Seen > Stale) stale.Add(pair.Key);
            foreach (int id in stale) { if (_shown[id].Root != null) Object.Destroy(_shown[id].Root); _shown.Remove(id); }
            if (now < _hideAt) return;
            _hideAt = now + HideEvery;
            // The guest's own copy of the world generated these: they are not the host's.
            foreach (var item in Object.FindObjectsOfType<InventoryItem>())
                if (Loose(item) && !Dropped.Contains(item)) item.gameObject.SetActive(false);
        }

        internal void ClearShown()
        {
            foreach (var shown in _shown.Values) if (shown.Root != null) Object.Destroy(shown.Root);
            _shown.Clear();
        }
        internal void HidePickedItem(int hostId)
        {
            Shown shown;
            if (_shown.TryGetValue(hostId, out shown)) { shown.PickedUp = true; shown.Root.SetActive(false); }
        }

        // A script-free copy: transforms, meshes, materials; colliders only for the
        // guest's own look-at ray (layer 2, which the character does not collide with).
        private static GameObject CreateVisual(WorldItemFrame frame)
        {
            Component prefab = null;
            if (frame.Kind == ItemKind)
            {
                var prefabs = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.itemPrefab;
                if (prefabs != null && frame.ItemId < prefabs.Length) prefab = prefabs[frame.ItemId];
            }
            else
            {
                var loot = GlobalObjectLootController.global;
                prefab = loot == null ? null : loot.PrefabZombieLoot;
            }
            if (prefab == null) return null;
            var staging = new GameObject("LAN world item staging");
            staging.SetActive(false);
            GameObject copy = null;
            try
            {
                copy = Object.Instantiate(prefab.gameObject, staging.transform, false);
                copy.name = "LAN host item";
                foreach (var behaviour in copy.GetComponentsInChildren<MonoBehaviour>(true)) Object.DestroyImmediate(behaviour);
                foreach (var body in copy.GetComponentsInChildren<Rigidbody>(true)) { body.isKinematic = true; body.detectCollisions = true; }
                foreach (var audio in copy.GetComponentsInChildren<AudioSource>(true)) { audio.playOnAwake = false; audio.enabled = false; }
                foreach (var animator in copy.GetComponentsInChildren<Animator>(true)) animator.enabled = false;
                foreach (var t in copy.GetComponentsInChildren<Transform>(true)) t.gameObject.layer = 2;
                foreach (var collider in copy.GetComponentsInChildren<Collider>(true)) collider.enabled = !collider.isTrigger;
                copy.AddComponent<LanWorldReplica>();
                copy.transform.SetParent(null, false);
                copy.SetActive(false);
                return copy;
            }
            catch (Exception ex)
            {
                _staticLog?.Invoke("Host item copy failed: " + ex.GetType().Name + ": " + ex.Message);
                if (copy != null) Object.Destroy(copy);
                return null;
            }
            finally { Object.Destroy(staging); }
        }

        // Guest: the host item or bag in front of the camera, if any.
        internal static LanWorldReplica InView()
        {
            var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
            var camera = Camera.main;
            if (player == null || camera == null) return null;
            RaycastHit best = default(RaycastHit); bool any = false;
            foreach (var hit in Physics.RaycastAll(new Ray(camera.transform.position, camera.transform.forward), Look, ~0, QueryTriggerInteraction.Ignore))
            {
                if (hit.collider == null || hit.collider.transform.IsChildOf(player.transform)) continue;
                if (!any || hit.distance < best.distance) { best = hit; any = true; }
            }
            return any ? best.collider.GetComponentInParent<LanWorldReplica>() : null;
        }
    }

    // Marks a bag holding a dead guest's belongings (0.12.0); it may lie on a train car.
    internal sealed class LanDeathBag : MonoBehaviour
    {
        // The object that stands for a bag: this marker, or the bag prefab's root.
        internal static Component RootOf(Inventory bag)
        {
            var marker = bag.GetComponentInParent<LanDeathBag>();
            return marker != null ? (Component)marker : bag.transform.root;
        }
    }

    internal sealed class LanWorldReplica : MonoBehaviour
    {
        internal int HostId, ItemId, Amount;
        internal byte Kind;
    }
}
