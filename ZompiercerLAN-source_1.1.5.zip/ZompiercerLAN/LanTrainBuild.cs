using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using HarmonyLib;
using UnityEngine;
using Zompiercer.Inventory;
using Zompiercer.Train;

namespace ZompiercerLAN
{
    // Guest building and refuelling on the host's train (0.8.0). The guest's train shows
    // the host's construction (TrainLayout); a hit of the guest's tool on a host blueprint
    // part or unassembled furniture becomes a build request, and a full canister poured
    // into a host fuel tank a refuel request. The host does both on its own objects; the
    // next train layout shows the result. 0.8.1: the guest's own construction mode places
    // new blueprints too. It works on the guest's copy of the train, whose mount points are
    // made to match the host's (TrainLayout); confirming a placement asks the host, which
    // places the blueprint on its own train. Removing and building in that mode stay closed
    // (the host's parts are never edited from the guest's copy). Main thread only.
    internal static class LanTrainBuild
    {
        private const float Look = 3f;
        private const int BuildAction = 51, RefuelAction = 55;
        private static Harmony _harmony;
        private static Action<string> _log;
        internal static string Failure { get; private set; }
        // Guest: one build hit (car, kind, host id, tool item id, recipe spent on completion); null outside a usable session.
        internal static Func<int, int, int, int, int[][], bool> GuestBuild;
        // Guest: places one blueprint (part id, car, point type or -1, point, pose); null outside a usable session.
        internal static Func<int, int, int, float[], float[], bool> GuestPlace;
        // Guest attached to the host's world: construction works on the host's train only.
        internal static bool GuestAttached;
        private static readonly FieldInfo SelectedPoint = AccessTools.Field(typeof(TrainConstructor), "SelectedTrainMountPoint");
        private static float _menuNoticeAt = -10f;

        internal static void Initialize(Action<string> log)
        {
            _log = log;
            if (_harmony != null) return;
            _harmony = new Harmony("local.zompiercer.lan.train-build");
            try
            {
                _harmony.Patch(AccessTools.Method(typeof(Gun), "MeleeAssemblyTarget"), prefix: new HarmonyMethod(typeof(LanTrainBuild), nameof(AssemblyPrefix)));
                _harmony.Patch(AccessTools.Method(typeof(ZombieFighterFireArmWeapon), "GunShot"), prefix: new HarmonyMethod(typeof(LanTrainBuild), nameof(GunShotPrefix)));
                _harmony.Patch(AccessTools.Method(typeof(TrainConstructor), "Update"), prefix: new HarmonyMethod(typeof(LanTrainBuild), nameof(ConstructorPrefix)));
                if (SelectedPoint == null) throw new MissingMemberException("TrainConstructor.SelectedTrainMountPoint");
                _harmony.Patch(AccessTools.Method(typeof(TrainConstructor), "ConfirmPlacement"), prefix: new HarmonyMethod(typeof(LanTrainBuild), nameof(ConfirmPrefix)));
                _harmony.Patch(AccessTools.Method(typeof(TrainController), "GetMountPointsOfType"), postfix: new HarmonyMethod(typeof(LanTrainBuild), nameof(PointsPostfix)));
                _harmony.Patch(AccessTools.Method(typeof(TrainPart), "GetNearestMountPoint"), postfix: new HarmonyMethod(typeof(LanTrainBuild), nameof(NearestPostfix)));
                _harmony.Patch(AccessTools.Method(typeof(TrainMountPoint), "CreateMarker"), prefix: new HarmonyMethod(typeof(LanTrainBuild), nameof(MarkerPrefix)));
                _harmony.Patch(AccessTools.Method(typeof(Gun), "GetHoveredTrainPart"), postfix: new HarmonyMethod(typeof(LanTrainBuild), nameof(HoveredPartPostfix)));
                _harmony.Patch(AccessTools.Method(typeof(TrainPart), "Remove"), prefix: new HarmonyMethod(typeof(LanTrainBuild), nameof(RemovePrefix)));
                // Wiring and painting would change only the guest's copy of the host's train.
                _harmony.Patch(AccessTools.Method(typeof(Zompiercer.Electricity.WireEditor), "SetEditMode"), prefix: new HarmonyMethod(typeof(LanTrainBuild), nameof(ModePrefix)));
                _harmony.Patch(AccessTools.Method(typeof(Zompiercer.Paint.PaintManager), "SetPaintMode"), prefix: new HarmonyMethod(typeof(LanTrainBuild), nameof(ModePrefix)));
            }
            catch (Exception ex)
            {
                // Without the hooks a guest could build only in its own world: refused.
                _harmony.UnpatchSelf();
                Failure = ex.GetType().Name + ": " + ex.Message;
                log("Train build hooks unavailable: " + Failure);
            }
        }
        internal static void Shutdown() { _harmony?.UnpatchSelf(); _harmony = null; GuestBuild = null; GuestPlace = null; GuestAttached = false; }

        // ---- Hooks (guest only) ----
        private static bool Active { get { return LanSaveIsolation.Active && GuestAttached; } }

        // Without a usable session the guest's construction mode stays closed: what it
        // placed would exist only in its own world.
        private static bool ConstructorPrefix(TrainConstructor __instance)
        {
            if (!Active || GuestPlace != null) return true;
            try
            {
                if (__instance.PreviewObject != null) { UnityEngine.Object.Destroy(__instance.PreviewObject.gameObject); __instance.PreviewObject = null; }
                var input = Zompiercer.Inputs.InputController.Global;
                if (input != null && input.isBuildMenuPressed && Time.unscaledTime - _menuNoticeAt > 2f)
                {
                    _menuNoticeAt = Time.unscaledTime;
                    LanStorageGame.Notice("Строить на поезде хоста можно, когда хост сохраняет ваш профиль");
                }
            }
            catch (Exception ex) { _log?.Invoke("Construction hook failed: " + ex.Message); }
            return false;
        }

        // ---- Guest construction mode on the host's train (0.8.1) ----
        // Only points that exist and are free on the host's train.
        private static bool Usable(TrainMountPoint point)
        {
            if (!TrainLayout.GuestPointUsable(point)) return false;
            // A floor needs the platform block under its point (ConfirmPlacement reads it).
            var preview = TrainConstructor.Global == null ? null : TrainConstructor.Global.PreviewObject;
            return preview == null || !preview.Floor || point.ParentBlock != null;
        }
        private static void PointsPostfix(ref List<TrainMountPoint> __result)
        {
            if (!Active || __result == null) return;
            try { __result.RemoveAll(point => !Usable(point)); }
            catch (Exception ex) { _log?.Invoke("Mount point filter failed: " + ex.Message); __result.Clear(); }
        }
        private static void NearestPostfix(ref TrainMountPoint __result)
        {
            if (!Active || __result == null) return;
            try { if (!Usable(__result)) __result = null; }
            catch (Exception) { __result = null; }
        }
        private static bool MarkerPrefix(TrainMountPoint __instance)
        {
            if (!Active) return true;
            try { return Usable(__instance); }
            catch (Exception) { return false; }
        }
        // In construction mode the game removes or builds the hovered part; never the guest's copy.
        private static void HoveredPartPostfix(ref TrainPart __result) { if (Active) __result = null; }
        private static bool RemovePrefix() { return !Active; }
        private static bool ModePrefix(bool value)
        {
            if (!Active || !value) return true;
            LanStorageGame.Notice("Проводку и покраску на поезде хоста делает хост");
            return false;
        }

        // Confirming a placement asks the host (the preview stays for the next one).
        private static bool ConfirmPrefix(TrainConstructor __instance)
        {
            if (!Active) return true;
            try
            {
                var preview = __instance.PreviewObject;
                var place = GuestPlace;
                if (preview == null) return false;
                if (place == null) { LanStorageGame.Notice("Строить на поезде хоста можно, когда хост сохраняет ваш профиль"); return false; }
                var point = SelectedPoint.GetValue(__instance) as TrainMountPoint;
                var platform = __instance.TargetTrainPlatform;
                var checker = preview.GetComponent<CollisionChecker>();
                bool blocked = preview.Floor && point != null && point.ParentBlock != null && point.ParentBlock.BlockBelow != null;
                if (blocked || checker != null && checker.Intersects || point == null && platform == null) { Sound(__instance.SoundPreviewCantBePlaced); return false; }
                var car = point != null ? point.GetComponentInParent<TrainCar>() : platform.GetComponentInParent<TrainCar>();
                var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrain;
                int index = TrainLayout.CarIndex(train, car);
                if (index < 0) { LanStorageGame.Notice("Строить можно только на поезде хоста"); return false; }
                var t = car.transform;
                var at = t.InverseTransformPoint(preview.transform.position);
                var turn = Quaternion.Inverse(t.rotation) * preview.transform.rotation;
                var spot = point == null ? Vector3.zero : t.InverseTransformPoint(point.transform.position);
                if (place(__instance.SelectedPartID, index, point == null ? -1 : point.ID, new[] { spot.x, spot.y, spot.z }, new[] { at.x, at.y, at.z, turn.x, turn.y, turn.z, turn.w }))
                {
                    Sound(__instance.SoundPreviewPlaced);
                    LanStorageGame.Notice("Чертёж отправлен хосту");
                }
                else LanStorageGame.Notice("Хост ещё отвечает на прошлый запрос");
            }
            catch (Exception ex) { _log?.Invoke("Placement hook failed: " + ex); }
            return false;
        }
        private static void Sound(AudioClip clip)
        {
            try { if (clip != null && GlobalSoundEffects.global != null) GlobalSoundEffects.global.PlayGlobalSound(clip); }
            catch (Exception) { }
        }

        // Holding attack with the right tool on a host blueprint swings the tool natively
        // (Gun.Repairs); the hit itself arrives in MeleeAssemblyTarget.
        private static bool GunShotPrefix(ZombieFighterFireArmWeapon __instance)
        {
            if (!Active) return true;
            try
            {
                var input = Zompiercer.Inputs.InputController.Global;
                if (input == null || (int)input.CurrentState != 1) return true;
                bool attack = input.isKbMouseDevice ? input.isAttackActionPressed : input.gp_isAttackPressed;
                if (!attack) return true;
                var target = Aim();
                var tool = InventoryController.global == null ? null : InventoryController.global.GetActiveIntenvoryItem();
                if (target == null || tool == null || !Fits(target, tool)) return true;
                var gun = __instance.GetSelectedGun();
                if (gun == null || gun.weaponType != 2) return true;
                gun.Repairs();
                return false;
            }
            catch (Exception ex) { _log?.Invoke("Build swing hook failed: " + ex.Message); return true; }
        }

        // The hit: the host's blueprint is built by the host, never the guest's copy.
        private static bool AssemblyPrefix(Gun __instance)
        {
            if (!Active) return true;
            try
            {
                var build = GuestBuild;
                var target = Aim();
                var tool = InventoryController.global == null ? null : InventoryController.global.GetActiveIntenvoryItem();
                if (build == null) { LanStorageGame.Notice("Строить на поезде хоста можно, когда хост сохраняет ваш профиль"); return false; }
                if (target == null || tool == null || !Fits(target, tool)) return false;
                int[][] needs = null;
                if (target.Kind == LanStorage.TrainPart)
                {
                    var part = PartPrefab(target.Prefab);
                    needs = part == null ? new int[0][] : LanStorageGame.Needs(part.Recipe);
                    string missing = Missing(needs);
                    if (missing != null) { LanStorageGame.Notice("Не хватает: " + missing); return false; }
                }
                if (build(target.Car, target.Kind, target.Identity, tool.itemID, needs))
                    LanWorldWork.GunWear.Invoke(__instance, new object[] { -1f }); // the tool wears as natively
            }
            catch (Exception ex) { _log?.Invoke("Build hit hook failed: " + ex.Message); }
            return false;
        }

        // ---- Guest: look-at hints and pouring into a copied tank ----
        // True when the crosshair is on a host blueprint or a host fuel tank copy.
        internal static bool Tick(LanStorageClient client)
        {
            var input = Zompiercer.Inputs.InputController.Global;
            if (input == null || client == null) return false;
            RaycastHit hit;
            if (!LookHit(out hit)) return false;
            int carIndex;
            if (hit.collider.GetComponentInParent<TrainFuelTank>() == null && TrainLayout.TryIdentifyFuelTank(hit.collider, out carIndex))
            {
                var can = InventoryController.global == null ? null : InventoryController.global.GetActiveIntenvoryItem();
                if (can == null || can.itemID != LanWorldWork.FullCanister) return false;
                var info = Hint();
                if (info != null)
                {
                    info.SetText(Zompiercer.GUI.LocalizationCore.GetTextByKey("Fuel").ToUpper());
                    info.SetIconText(Zompiercer.GUI.LocalizationCore.GetTextByKey("Refuel").ToUpper(), (Zompiercer.Inputs.Actions)RefuelAction, (Zompiercer.Inputs.Actions)0, false);
                }
                bool pour = input.isKbMouseDevice ? input.isAttackActionDown : input.gp_isUseOpenTalkDown;
                if (pour && !client.Busy) PourInto(carIndex, hit.point, can);
                return true;
            }
            var target = TrainLayout.TryIdentifyBuild(hit.collider);
            if (target == null) return false;
            var hint = Hint();
            if (hint == null) return true;
            var tool = InventoryController.global == null ? null : InventoryController.global.GetActiveIntenvoryItem();
            float max = target.Kind == LanStorage.TrainPart ? (PartPrefab(target.Prefab) == null ? 0f : PartPrefab(target.Prefab).BuildPointsMaximum)
                : (FurniturePrefab(target.Prefab) == null ? 0f : FurniturePrefab(target.Prefab).completionBarMax);
            var text = new StringBuilder(Title(target).ToUpper());
            if (max > 0f) text.Append("  ").Append(Mathf.Clamp(Mathf.RoundToInt(100f * target.Progress / max), 0, 100)).Append('%');
            if (target.Kind == LanStorage.TrainPart)
            {
                var part = PartPrefab(target.Prefab);
                var needs = part == null ? new int[0][] : LanStorageGame.Needs(part.Recipe);
                if (needs.Length > 0) text.Append('\n').Append(Recipe(needs));
            }
            if (tool == null || !Fits(target, tool))
            {
                hint.color = GlobalSoundEffects.global != null ? GlobalSoundEffects.global.colorRed : hint.color;
                text.Append('\n').Append(Zompiercer.GUI.LocalizationCore.GetTextByKey("WrongTool").ToUpper());
                hint.SetText(text.ToString());
                return true;
            }
            hint.SetText(text.ToString());
            hint.SetIconText("Build", (Zompiercer.Inputs.Actions)BuildAction, (Zompiercer.Inputs.Actions)0, true);
            return true;
        }

        private static void PourInto(int carIndex, Vector3 point, InventoryItem can)
        {
            var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrain;
            TrainCar car;
            try { car = TrainLayout.GetCar(train, carIndex); }
            catch (Exception) { return; }
            var slot = can.inInventory;
            if (slot == null) return;
            var escrow = LanStorage.Normalize(new object[] { can.itemID, 1, can.Save() });
            slot.Extract(can, 1);
            if (!LanWorldWork.Pour(car, point, escrow)) new LanStorageGuestWorld().Give(escrow);
        }

        // ---- Helpers ----
        internal static bool LookHit(out RaycastHit best)
        {
            best = default(RaycastHit);
            var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
            var camera = Camera.main;
            if (player == null || camera == null) return false;
            bool any = false;
            foreach (var hit in Physics.RaycastAll(new Ray(camera.transform.position, camera.transform.forward), Look, ~0, QueryTriggerInteraction.Ignore))
            {
                if (hit.collider == null || hit.collider.transform.IsChildOf(player.transform)) continue;
                if (!any || hit.distance < best.distance) { best = hit; any = true; }
            }
            return any;
        }
        private static TrainLayout.BuildTarget Aim()
        {
            RaycastHit hit;
            return LookHit(out hit) ? TrainLayout.TryIdentifyBuild(hit.collider) : null;
        }

        private static bool Fits(TrainLayout.BuildTarget target, InventoryItem tool)
        {
            if (target.Kind == LanStorage.TrainPart)
            {
                var part = PartPrefab(target.Prefab);
                return part != null && Mathf.RoundToInt(part.RequiredTool) == tool.GetToolType();
            }
            var furniture = FurniturePrefab(target.Prefab);
            return furniture != null && furniture.GetToolType() == tool.GetToolType();
        }

        private static TrainPart PartPrefab(int id)
        {
            var parts = TrainConstructor.Global == null ? null : TrainConstructor.Global.PartsDataBase;
            return parts != null && parts.Parts != null && id >= 0 && id < parts.Parts.Count ? parts.Parts[id] : null;
        }
        private static Furniture FurniturePrefab(int id)
        {
            var db = ItemsDataBase.Global;
            return db != null && db.AllFurniture != null && id >= 0 && id < db.AllFurniture.Count ? db.AllFurniture[id] : null;
        }
        private static string Title(TrainLayout.BuildTarget target)
        {
            try
            {
                if (target.Kind == LanStorage.TrainPart)
                {
                    var part = PartPrefab(target.Prefab);
                    if (part != null && !string.IsNullOrEmpty(part.Name)) return Zompiercer.GUI.LocalizationCore.GetTextByKey(part.Name);
                }
                else
                {
                    var furniture = FurniturePrefab(target.Prefab);
                    if (furniture != null) return furniture.name.Replace("(Clone)", "");
                }
            }
            catch (Exception) { }
            return Zompiercer.GUI.LocalizationCore.GetTextByKey("Build");
        }

        private static long Have(int id)
        {
            var backpack = LanStorageGame.Backpack();
            long total = 0;
            if (backpack != null && backpack.content != null) foreach (var item in backpack.content) if (item != null && item.itemID == id) total += item.amount;
            return total;
        }
        // "Name have/need, ..." for what is short, or null when the backpack has everything.
        private static string Missing(int[][] needs)
        {
            var text = new StringBuilder();
            foreach (var need in needs)
            {
                long have = Have(need[0]);
                if (have >= need[1]) continue;
                if (text.Length > 0) text.Append(", ");
                text.Append(LanStorageGame.ItemName(need[0])).Append(' ').Append(have).Append('/').Append(need[1]);
            }
            return text.Length == 0 ? null : text.ToString();
        }
        private static string Recipe(int[][] needs)
        {
            var text = new StringBuilder();
            foreach (var need in needs)
            {
                if (text.Length > 0) text.Append("  ");
                text.Append(LanStorageGame.ItemName(need[0]).ToUpper()).Append(' ').Append(Math.Min(Have(need[0]), need[1])).Append('/').Append(need[1]);
            }
            return text.ToString();
        }

        private static Zompiercer.GUI.SimpleInfoDisplayer Hint()
        {
            var controller = InventoryController.global;
            return controller == null ? null : controller.simpleInfoDisplayer;
        }
    }
}
