using System.Collections.Generic;
using UnityEngine;

namespace ZompiercerLAN
{
    // Render a little behind reception so packet jitter does not restart each interpolation.
    internal sealed class PlayerPoseBuffer
    {
        private sealed class Sample
        {
            internal float Time, Yaw;
            internal Vector3 Position;
            internal int Car;
            internal string Scene;
        }
        private readonly List<Sample> _samples = new List<Sample>();
        internal void Clear() { _samples.Clear(); }
        internal void Push(Packet packet)
        {
            var sample = new Sample { Time = UnityEngine.Time.unscaledTime, Car = packet.CarIndex, Scene = packet.Scene,
                Position = packet.CarIndex < 0 ? new Vector3(packet.X, packet.Y, packet.Z) : new Vector3(packet.LocalX, packet.LocalY, packet.LocalZ),
                Yaw = packet.CarIndex < 0 ? packet.Yaw : packet.LocalYaw };
            if (_samples.Count > 0)
            {
                var last = _samples[_samples.Count - 1];
                if (last.Car != sample.Car || last.Scene != sample.Scene || sample.Time - last.Time > 1f ||
                    Vector3.Distance(last.Position, sample.Position) > 8f) _samples.Clear();
                else if (sample.Time <= last.Time) _samples.RemoveAt(_samples.Count - 1);
            }
            _samples.Add(sample);
            if (_samples.Count > 32) _samples.RemoveAt(0);
        }
        internal bool Get(out Vector3 position, out float yaw)
        {
            position = Vector3.zero; yaw = 0f;
            if (_samples.Count == 0) return false;
            float renderTime = UnityEngine.Time.unscaledTime - 0.15f;
            while (_samples.Count > 2 && _samples[1].Time <= renderTime) _samples.RemoveAt(0);
            var a = _samples[0];
            var b = _samples.Count > 1 ? _samples[1] : a;
            float t = b.Time > a.Time ? Mathf.Clamp01((renderTime - a.Time) / (b.Time - a.Time)) : 1f;
            position = Vector3.Lerp(a.Position, b.Position, t);
            yaw = Mathf.LerpAngle(a.Yaw, b.Yaw, t);
            var car = a.Car < 0 ? null : TrainSync.GetCar(a.Car);
            if (a.Car >= 0 && car == null) return false;
            if (car != null)
            {
                position = car.transform.TransformPoint(position);
                yaw = (car.transform.rotation * Quaternion.Euler(0f, yaw, 0f)).eulerAngles.y;
            }
            return true;
        }
    }
}
