using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;

namespace ZompiercerLAN
{
    // Shared storages (0.6.0). The host owns every container: the guest sees a
    // snapshot ("view") of the one container it opened and asks the host to move
    // items; the host applies each request natively and answers with the result.
    // No Unity APIs in this file: LanStorageGame supplies the world, the offline
    // checks a fake one.
    //
    // Items travel in the game's own Inventory.Save() entry shape, object[3] =
    // [itemID, amount, InventoryItem.Save() object[4]], validated by LanGuestSchema.
    // Slot 2 of the extras (the train car an item lies on) is cleared on the wire.
    internal static class LanStorage
    {
        internal const int ViewFormat = 2, MaxName = 64, FingerprintBytes = 32, MaxAmount = 1000000;
        internal const int SceneTarget = 1, TrainTarget = 2, BagTarget = 3;
        internal const int TrainFurniture = 1, TrainPart = 2;
        // Result and view statuses (Packet.Action of StorageResult).
        internal const byte Ok = 0, NotFound = 1, TooFar = 2, NoSpace = 3, NotAllowed = 4, Busy = 5, Gone = 6,
            Invalid = 7, Unavailable = 8, TooLarge = 9, Closed = 10, NotOwned = 11, Empty = 12, Manual = 13,
            Full = 14, Missing = 15, Occupied = 16, Lost = 17, Broken = 18, Locked = 19;

        internal static string Describe(byte status)
        {
            switch (status)
            {
                case Ok: return "Готово";
                case NotFound: return "У хоста нет такого хранилища или предмета";
                case TooFar: return "Слишком далеко от хранилища";
                case NoSpace: return "Не хватает места";
                case NotAllowed: return "Этот предмет сюда нельзя положить";
                case Busy: return "Хост занят этим хранилищем; попробуйте ещё раз";
                case Gone: return "Хранилище закрыто";
                case Invalid: return "Хост отклонил запрос";
                case Unavailable: return "Хост ещё не поставил ваши вещи на учёт (или ваш профиль не сохраняется)";
                case TooLarge: return "Слишком сложный предмет для передачи";
                case Closed: return "Хранилище закрыто";
                case NotOwned: return "По учёту хоста у вас нет такой вещи";
                case Empty: return "Здесь ничего не осталось";
                case Manual: return "Для ручного крафта откройте окно этого верстака и оставайтесь рядом";
                case Full: return "Бак поезда уже полон";
                case Missing: return "Не хватает ресурсов для постройки";
                case Occupied: return "Это место у хоста уже занято";
                case Lost: return "Хост сейчас не видит, где вы; подождите пару секунд";
                case Broken: return "Сломано: вставьте запасной рычаг";
                case Locked: return "Хост не разрешил вам управлять поездом";
                default: return "Ошибка хранилища " + status;
            }
        }

        // ---- Targets: what the guest is looking at, in terms both worlds share ----
        // Scene: [1, scene, x, y, z, inventory name]: positions are the game's own
        // identity of scene inventories in its saves. Train: [2, car, kind, host id].
        internal static byte[] ScenePayload(string scene, float x, float y, float z, string name)
        { return Payload(new object[] { SceneTarget, scene, x, y, z, name }); }
        internal static byte[] TrainPayload(int car, int kind, int identity)
        { return Payload(new object[] { TrainTarget, car, kind, identity }); }

        // Bag: [3, host id] — a loot bag that exists only in the host's world.
        internal static byte[] BagPayload(int hostId) { return Payload(new object[] { BagTarget, hostId }); }

        internal static object[] DecodeTarget(byte[] payload) { return ValidTarget(Decode(payload, "target")); }
        internal static object[] ValidTarget(object[] t)
        {
            Require(t != null && t.Length >= 1 && t[0] is int, "target type");
            if ((int)t[0] == BagTarget) Require(t.Length == 2 && t[1] is int && (int)t[1] != 0, "target bag");
            else if ((int)t[0] == SceneTarget)
            {
                Require(t.Length == 6 && t[1] is string && ((string)t[1]).Length > 0 && ((string)t[1]).Length <= 96, "target scene");
                for (int i = 2; i <= 4; i++) Require(t[i] is float && Math.Abs((float)t[i]) < 100000f, "target position");
                Require(t[5] is string && ((string)t[5]).Length > 0 && ((string)t[5]).Length <= MaxName, "target name");
            }
            else
            {
                Require((int)t[0] == TrainTarget && t.Length == 4 && t[1] is int && t[2] is int && t[3] is int, "target train");
                Require((int)t[1] >= 0 && (int)t[1] < LanProtocol.MaxCars, "target car");
                Require((int)t[2] == TrainFurniture || (int)t[2] == TrainPart, "target kind");
                Require((int)t[3] != 0, "target identity");
            }
            return t;
        }

        // ---- Items ----
        internal static object[] Normalize(object[] item)
        {
            ValidateItem(item);
            var extra = (object[])((object[])item[2]).Clone();
            extra[2] = null;
            return new object[] { item[0], item[1], extra };
        }
        internal static void ValidateItem(object[] item)
        {
            try { LanGuestSchema.Inventory(new object[] { item }, 0); }
            catch (InvalidDataException ex) { throw new InvalidDataException("Storage item: " + ex.Message); }
            Require((int)item[1] <= MaxAmount, "item amount");
        }
        internal static byte[] EncodeItem(object[] item) { return Payload(Normalize(item)); }
        internal static object[] DecodeItem(byte[] payload) { return Normalize(Decode(payload, "item")); }
        internal static bool ItemFits(object[] item)
        {
            try { EncodeItem(item); return true; } catch (InvalidDataException) { return false; }
        }
        internal static object[] WithAmount(object[] item, int amount)
        { var copy = Normalize(item); copy[1] = amount; return copy; }

        // Identity of an item regardless of stack size and train-car parent.
        internal static byte[] Fingerprint(object[] item)
        {
            var n = Normalize(item);
            using (var sha = SHA256.Create()) return sha.ComputeHash(LanValueCodec.Encode(new object[] { n[0], n[2] }));
        }
        internal static bool SameBytes(byte[] a, byte[] b)
        {
            if (a == null || b == null || a.Length != b.Length) return false;
            for (int i = 0; i < a.Length; i++) if (a[i] != b[i]) return false;
            return true;
        }
        internal static bool SameFingerprint(byte[] a, byte[] b)
        {
            if (a == null || b == null || a.Length != FingerprintBytes || b.Length != FingerprintBytes) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= a[i] ^ b[i];
            return diff == 0;
        }

        // Take: [index in the view, amount, fingerprint of that item].
        internal static byte[] TakePayload(int index, int amount, byte[] fingerprint)
        { return Payload(new object[] { index, amount, fingerprint }); }
        internal static void DecodeTake(byte[] payload, out int index, out int amount, out byte[] fingerprint)
        {
            var t = Decode(payload, "take");
            Require(t.Length == 3 && t[0] is int && t[1] is int && t[2] is byte[], "take fields");
            index = (int)t[0]; amount = (int)t[1]; fingerprint = (byte[])t[2];
            Require(index >= 0 && index < LanGuestSchema.MaxItems && amount >= 1 && amount <= MaxAmount && fingerprint.Length == FingerprintBytes, "take values");
        }

        // Pick up: [host id of the loose item, its item id, amount wanted].
        internal static byte[] PickupPayload(int hostId, int itemId, int amount) { return Payload(new object[] { hostId, itemId, amount }); }
        internal static void DecodePickup(byte[] payload, out int hostId, out int itemId, out int amount)
        {
            var t = Decode(payload, "pickup");
            Require(t.Length == 3 && t[0] is int && t[1] is int && t[2] is int, "pickup fields");
            hostId = (int)t[0]; itemId = (int)t[1]; amount = (int)t[2];
            Require(hostId != 0 && itemId >= 0 && itemId <= 65535 && amount >= 1 && amount <= MaxAmount, "pickup values");
        }
        // Drop: [item, x, y, z] — where the guest lets it fall.
        internal static byte[] DropPayload(object[] item, float x, float y, float z) { return Payload(new object[] { Normalize(item), x, y, z }); }
        internal static byte[] DropPayload(object[] item, int car, float[] pose)
        { return Payload(new object[] { Normalize(item), pose[0], pose[1], pose[2], car, pose[3], pose[4], pose[5], pose[6] }); }
        internal static object[] DecodeDrop(byte[] payload, out float x, out float y, out float z)
        { int car; float[] rotation; return DecodeDrop(payload, out x, out y, out z, out car, out rotation); }
        internal static object[] DecodeDrop(byte[] payload, out float x, out float y, out float z, out int car, out float[] rotation)
        {
            var t = Decode(payload, "drop");
            Require((t.Length == 4 || t.Length == 9) && t[0] is object[] && t[1] is float && t[2] is float && t[3] is float, "drop fields");
            x = (float)t[1]; y = (float)t[2]; z = (float)t[3];
            Require(Math.Abs(x) < 100000f && Math.Abs(y) < 100000f && Math.Abs(z) < 100000f, "drop position");
            car = -1; rotation = null;
            if (t.Length == 9)
            {
                Require(t[4] is int && (int)t[4] >= -1 && (int)t[4] < LanProtocol.MaxCars, "drop car");
                car = (int)t[4]; rotation = new float[4];
                for (int i = 0; i < 4; i++) { Require(t[5 + i] is float, "drop rotation"); rotation[i] = (float)t[5 + i]; }
                float norm = 0f; foreach (float q in rotation) norm += q * q;
                Require(norm > .96f && norm < 1.04f, "drop rotation norm");
                Require(car < 0 || Math.Abs(x) <= MaxCarLocal && Math.Abs(y) <= MaxCarLocal && Math.Abs(z) <= MaxCarLocal, "drop car position");
            }
            return Normalize((object[])t[0]);
        }

        // Work on the world through the host: [kind, x, y, z, tool item id, extra, escrowed item or null].
        // Hit: melee on a ResourceContent (what falls out lies in the host's world).
        // Gather: knife on a CollectedResource. Dig: shovel, extra = 1 sand / 2 soil.
        // Fuel: an empty canister (escrowed) filled at a gas station.
        // Refuel (0.8.0): a full canister (escrowed) poured into a fuel tank of the host's train;
        // extra = car index, x/y/z = the point on the tank in that car's local space.
        internal const int WorkHit = 1, WorkGather = 2, WorkDig = 3, WorkFuel = 4, WorkRefuel = 5;
        internal static byte[] WorkPayload(int kind, float x, float y, float z, int tool, int extra, object[] escrow)
        { return Payload(new object[] { kind, x, y, z, tool, extra, escrow == null ? null : Normalize(escrow) }); }
        internal static int DecodeWork(byte[] payload, out float x, out float y, out float z, out int tool, out int extra, out object[] escrow)
        {
            var t = Decode(payload, "work");
            Require(t.Length == 7 && t[0] is int && t[1] is float && t[2] is float && t[3] is float && t[4] is int && t[5] is int, "work fields");
            int kind = (int)t[0]; x = (float)t[1]; y = (float)t[2]; z = (float)t[3]; tool = (int)t[4]; extra = (int)t[5];
            Require(kind >= WorkHit && kind <= WorkRefuel && Math.Abs(x) < 100000f && Math.Abs(y) < 100000f && Math.Abs(z) < 100000f, "work kind or position");
            bool canister = kind == WorkFuel || kind == WorkRefuel;
            Require(canister ? tool == -1 : tool >= 0 && tool <= 65535, "work tool");
            Require(kind == WorkDig ? extra == 1 || extra == 2 : kind == WorkRefuel ? extra >= 0 && extra < LanProtocol.MaxCars : extra == 0, "work extra");
            Require(kind != WorkRefuel || Math.Abs(x) <= 256f && Math.Abs(y) <= 256f && Math.Abs(z) <= 256f, "work car-local position");
            Require(t[6] == null || t[6] is object[], "work escrow item");
            escrow = t[6] == null ? null : Normalize((object[])t[6]);
            Require(canister == (escrow != null), "work escrow");
            return kind;
        }

        // Build on the host's train (0.8.0): [car, kind (1 furniture, 2 part), host id, tool item id].
        // One hit of the guest's tool on a blueprint part or an unassembled furniture;
        // the hit that completes a part pays its recipe from the guest's ledger.
        internal static byte[] BuildPayload(int car, int kind, int identity, int tool)
        { return Payload(new object[] { car, kind, identity, tool }); }
        internal static void DecodeBuild(byte[] payload, out int car, out int kind, out int identity, out int tool)
        {
            var t = Decode(payload, "build");
            Require(t.Length == 4 && t[0] is int && t[1] is int && t[2] is int && t[3] is int, "build fields");
            car = (int)t[0]; kind = (int)t[1]; identity = (int)t[2]; tool = (int)t[3];
            Require(car >= 0 && car < LanProtocol.MaxCars && (kind == TrainFurniture || kind == TrainPart) && tool >= 0 && tool <= 65535, "build target");
        }

        // Place a blueprint on the host's train (0.8.1): [part prefab id, car, mount point type
        // (-1: on a surface), point x, y, z, x, y, z, qx, qy, qz, qw], all in that car's space.
        internal const float MaxCarLocal = 256f;
        internal static byte[] PlacePayload(int part, int car, int pointType, float[] point, float[] pose)
        { return Payload(new object[] { part, car, pointType, point[0], point[1], point[2], pose[0], pose[1], pose[2], pose[3], pose[4], pose[5], pose[6] }); }
        internal static void DecodePlace(byte[] payload, out int part, out int car, out int pointType, out float[] point, out float[] pose)
        {
            var t = Decode(payload, "place");
            Require(t.Length == 13 && t[0] is int && t[1] is int && t[2] is int, "place fields");
            for (int i = 3; i < 13; i++) Require(t[i] is float, "place numbers");
            part = (int)t[0]; car = (int)t[1]; pointType = (int)t[2];
            Require(part >= 0 && part <= 65535 && car >= 0 && car < LanProtocol.MaxCars && pointType >= -1 && pointType <= 1023, "place part");
            point = new[] { (float)t[3], (float)t[4], (float)t[5] };
            pose = new[] { (float)t[6], (float)t[7], (float)t[8], (float)t[9], (float)t[10], (float)t[11], (float)t[12] };
            for (int i = 0; i < 3; i++) Require(Math.Abs(point[i]) <= MaxCarLocal && Math.Abs(pose[i]) <= MaxCarLocal, "place position");
            float norm = pose[3] * pose[3] + pose[4] * pose[4] + pose[5] * pose[5] + pose[6] * pose[6];
            Require(norm > .96f && norm < 1.04f, "place rotation");
        }

        // A control of the host's train (0.10.0): [kind, index, check, value, escrowed item or null].
        // Button/cab light/repair: index in LanTrainControl order (< 32), value 0; repair escrows one
        // spare lever (item 66). Lever: index < MaxLevers, value = the lever's new value x1000.
        // Light of a built part: index = car, check = host id, value = 1 furniture / 2 part.
        // `check` is a hash of the control's place in the train, so different trains never match.
        internal const int ControlButton = 1, ControlLever = 2, ControlCabLight = 3, ControlRepair = 4, ControlPartLight = 5;
        internal const int LeverItem = 66, MaxControlIndex = 32;
        internal static byte[] ControlPayload(int kind, int index, int check, int value, object[] escrow)
        { return Payload(new object[] { kind, index, check, value, escrow == null ? null : Normalize(escrow) }); }
        internal static void DecodeControl(byte[] payload, out int kind, out int index, out int check, out int value, out object[] escrow)
        {
            var t = Decode(payload, "control");
            Require(t.Length == 5 && t[0] is int && t[1] is int && t[2] is int && t[3] is int && (t[4] == null || t[4] is object[]), "control fields");
            kind = (int)t[0]; index = (int)t[1]; check = (int)t[2]; value = (int)t[3];
            escrow = t[4] == null ? null : Normalize((object[])t[4]);
            switch (kind)
            {
                case ControlButton: case ControlCabLight:
                    Require(index >= 0 && index < MaxControlIndex && value == 0 && escrow == null, "control button"); break;
                case ControlRepair:
                    Require(index >= 0 && index < MaxControlIndex && value == 0 && escrow != null && (int)escrow[0] == LeverItem && (int)escrow[1] == 1, "control repair"); break;
                case ControlLever:
                    Require(index >= 0 && index < LanProtocol.MaxLevers && value >= -1000000 && value <= 1000000 && escrow == null, "control lever"); break;
                case ControlPartLight:
                    Require(index >= 0 && index < LanProtocol.MaxCars && check != 0 && (value == TrainFurniture || value == TrainPart) && escrow == null, "control part light"); break;
                default: throw new InvalidDataException("Storage: control kind");
            }
        }

        // The guest died (0.12.0): [x, y, z, car] where it fell, in that car's space when car >= 0.
        internal static byte[] DeathPayload(float x, float y, float z, int car) { return Payload(new object[] { x, y, z, car }); }
        internal static void DecodeDeath(byte[] payload, out float x, out float y, out float z, out int car)
        {
            var t = Decode(payload, "death");
            Require(t.Length == 4 && t[0] is float && t[1] is float && t[2] is float && t[3] is int, "death fields");
            x = (float)t[0]; y = (float)t[1]; z = (float)t[2]; car = (int)t[3];
            Require(car >= -1 && car < LanProtocol.MaxCars, "death car");
            float limit = car >= 0 ? MaxCarLocal : 100000f;
            Require(Math.Abs(x) < limit && Math.Abs(y) < limit && Math.Abs(z) < limit, "death position");
        }

        // Craft at a host workbench: [target, recipe item id, count, ingredients escrowed by the guest].
        internal const int MaxCraft = 20;
        internal const int MaxCraftIngredients = 16;
        internal static byte[] CraftPayload(byte[] target, int recipe, int count, object[] ingredients)
        {
            Require(ingredients != null && ingredients.Length >= 1 && ingredients.Length <= MaxCraftIngredients, "craft ingredients");
            Require(recipe >= 0 && recipe <= 65535 && count >= 1 && count <= MaxCraft, "craft recipe");
            var items = new object[ingredients.Length];
            for (int i = 0; i < items.Length; i++) items[i] = Normalize((object[])ingredients[i]);
            return Payload(new object[] { LanValueCodec.Decode(target), recipe, count, items });
        }
        // `a` and `b` as one list: equal items (same id and data) become one entry.
        internal static object[] MergeItems(object[] a, object[] b)
        {
            var merged = new List<object[]>();
            var prints = new List<byte[]>();
            foreach (var list in new[] { a, b })
                foreach (object[] raw in list)
                {
                    var item = Normalize(raw);
                    var print = Fingerprint(item);
                    int at = prints.FindIndex(x => SameFingerprint(x, print));
                    if (at < 0) { merged.Add(item); prints.Add(print); continue; }
                    long sum = (long)(int)merged[at][1] + (int)item[1];
                    Require(sum <= MaxAmount, "merged amount");
                    merged[at][1] = (int)sum;
                }
            return merged.ToArray();
        }
        internal static object[] DecodeCraft(byte[] payload, out int recipe, out int count, out object[] ingredients)
        {
            var t = Decode(payload, "craft");
            Require(t.Length == 4 && t[0] is object[] && t[1] is int && t[2] is int && t[3] is object[], "craft fields");
            var target = ValidTarget((object[])t[0]);
            recipe = (int)t[1]; count = (int)t[2];
            Require(recipe >= 0 && recipe <= 65535 && count >= 1 && count <= MaxCraft, "craft recipe");
            var raw = (object[])t[3];
            Require(raw.Length >= 1 && raw.Length <= MaxCraftIngredients, "craft ingredients");
            ingredients = new object[raw.Length];
            for (int i = 0; i < raw.Length; i++) ingredients[i] = Normalize(raw[i] as object[]);
            return target;
        }

        // Cancel one queued craft of the open workbench (1.1.5): [queue index, recipe item id].
        // The host does what the game's queue button does: the ingredients of one craft go
        // into the workbench's own inventory.
        internal static byte[] CraftCancelPayload(int index, int recipe) { return Payload(new object[] { index, recipe }); }
        internal static void DecodeCraftCancel(byte[] payload, out int index, out int recipe)
        {
            var t = Decode(payload, "craft cancel");
            Require(t.Length == 2 && t[0] is int && t[1] is int, "craft cancel fields");
            index = (int)t[0]; recipe = (int)t[1];
            Require(index >= 0 && index < MaxCraftQueue && recipe >= 0 && recipe <= 65535, "craft cancel values");
        }

        // ---- Views: [format, handle, status, name, weight, max weight, items(, craft)] ----
        // A workbench adds its craft state (1.1.5): [item being made or -1, whole seconds of
        // work done on it, 1 while the work advances, queue [[item id, amount], ...]].
        internal const int MaxCraftQueue = 32, MaxCraftSeconds = 100000000;
        internal sealed class CraftState
        {
            internal int WorkingOn = -1, Elapsed;
            internal bool Working;
            internal int[][] Queue = new int[0][];
        }
        internal sealed class View
        {
            internal int Handle;
            internal byte Status;
            internal string Name = "";
            internal float Weight, MaxWeight;
            internal object[] Items = new object[0];
            internal CraftState Craft;
        }
        internal static byte[] EncodeView(View v)
        {
            var items = new object[v.Items.Length];
            for (int i = 0; i < items.Length; i++) items[i] = Normalize(v.Items[i] as object[]);
            string name = v.Name ?? "";
            if (name.Length > MaxName) name = name.Substring(0, MaxName);
            object[] root;
            if (v.Craft == null) root = new object[] { ViewFormat, v.Handle, (int)v.Status, name, v.Weight, v.MaxWeight, items };
            else
            {
                var queue = new object[v.Craft.Queue.Length];
                for (int i = 0; i < queue.Length; i++) queue[i] = new object[] { v.Craft.Queue[i][0], v.Craft.Queue[i][1] };
                var craft = new object[] { v.Craft.WorkingOn, v.Craft.Elapsed, v.Craft.Working ? 1 : 0, queue };
                root = new object[] { ViewFormat, v.Handle, (int)v.Status, name, v.Weight, v.MaxWeight, items, craft };
            }
            CheckView(root);
            byte[] blob = LanValueCodec.Encode(root);
            Require(blob.Length <= LanProtocol.MaxGuestBytes, "view size");
            return blob;
        }
        internal static View DecodeView(byte[] blob)
        {
            object[] root;
            try { root = LanValueCodec.Decode(blob); }
            catch (ArgumentException) { throw new InvalidDataException("Storage view text"); }
            catch (EndOfStreamException) { throw new InvalidDataException("Storage view truncated"); }
            CheckView(root);
            var items = (object[])root[6];
            for (int i = 0; i < items.Length; i++) items[i] = Normalize((object[])items[i]);
            CraftState craft = null;
            if (root.Length == 8)
            {
                var c = (object[])root[7]; var queue = (object[])c[3];
                craft = new CraftState { WorkingOn = (int)c[0], Elapsed = (int)c[1], Working = (int)c[2] == 1, Queue = new int[queue.Length][] };
                for (int i = 0; i < queue.Length; i++) { var q = (object[])queue[i]; craft.Queue[i] = new[] { (int)q[0], (int)q[1] }; }
            }
            return new View { Handle = (int)root[1], Status = (byte)(int)root[2], Name = (string)root[3], Weight = (float)root[4], MaxWeight = (float)root[5], Items = items, Craft = craft };
        }
        private static void CheckView(object[] root)
        {
            Require(root != null && (root.Length == 7 || root.Length == 8) && root[0] is int && (int)root[0] == ViewFormat, "view header");
            Require(root[1] is int && (int)root[1] > 0, "view handle");
            Require(root[2] is int && (int)root[2] >= 0 && (int)root[2] <= LanProtocol.MaxStorageStatus, "view status");
            Require(root[3] is string && ((string)root[3]).Length <= MaxName, "view name");
            Require(root[4] is float && root[5] is float && Math.Abs((float)root[4]) <= 1000000f && (float)root[5] >= 0 && (float)root[5] <= 1000000f, "view weight");
            var items = root[6] as object[];
            Require(items != null && items.Length <= LanGuestSchema.MaxItems, "view items");
            foreach (var item in items) ValidateItem(item as object[]);
            Require((int)root[2] == Ok || items.Length == 0, "closed view items");
            if (root.Length == 8)
            {
                Require((int)root[2] == Ok, "closed view craft");
                var c = root[7] as object[];
                Require(c != null && c.Length == 4 && c[0] is int && c[1] is int && c[2] is int && c[3] is object[], "view craft");
                Require((int)c[0] >= -1 && (int)c[0] <= 65535 && (int)c[1] >= 0 && (int)c[1] <= MaxCraftSeconds && ((int)c[2] == 0 || (int)c[2] == 1), "view craft work");
                var queue = (object[])c[3];
                Require(queue.Length <= MaxCraftQueue, "view craft queue");
                foreach (var entry in queue)
                {
                    var q = entry as object[];
                    Require(q != null && q.Length == 2 && q[0] is int && q[1] is int && (int)q[0] >= 0 && (int)q[0] <= 65535 && (int)q[1] >= 1 && (int)q[1] <= MaxAmount, "view craft entry");
                }
            }
        }

        private static byte[] Payload(object[] value)
        {
            byte[] bytes = LanValueCodec.Encode(value);
            Require(bytes.Length <= LanProtocol.MaxStoragePayload, "payload size");
            return bytes;
        }
        private static object[] Decode(byte[] payload, string what)
        {
            Require(payload != null && payload.Length > 0 && payload.Length <= LanProtocol.MaxStoragePayload, what + " size");
            try { return LanValueCodec.Decode(payload); }
            catch (ArgumentException) { throw new InvalidDataException("Storage " + what + " text"); }
            catch (EndOfStreamException) { throw new InvalidDataException("Storage " + what + " truncated"); }
        }
        private static void Require(bool condition, string what) { if (!condition) throw new InvalidDataException("Storage: " + what); }
    }

    // The host's train controls (0.10.0): a button, lever, cab light, repair or light of a
    // built part, used for the guest as the host's own hand would (LanTrainControl).
    internal interface ILanTrainControlWorld
    {
        byte Control(int kind, int index, int check, int value, object[] escrow);
    }

    // The guest died (0.12.0): its belongings go into bags at the place it fell.
    internal interface ILanDeathWorld
    {
        // Ok when every item lies in the host's world (bags, or loose where a bag had no room).
        byte Death(object[] items, float x, float y, float z, int car);
    }

    // What the host side needs from the game. Every container is an opaque token.
    internal interface ILanStoragePlacementWorld
    {
        byte PlaceItem(object[] item, int car, float[] pose);
    }

    internal interface ILanStorageHostWorld
    {
        // A container matching a validated target that the guest may use now.
        object Resolve(object[] target, out byte status);
        // Ok while the container exists, the world is unchanged and the guest is near.
        byte Check(object container);
        // Name, weights and items (Inventory.Save() entries); null when it cannot be shown.
        LanStorage.View Snapshot(object container);
        // Removes up to `amount` of the matching item; `taken` is what the guest receives.
        byte Take(object container, int index, byte[] fingerprint, int amount, out object[] taken);
        // Adds up to the item's amount; `accepted` is how many were stored.
        byte Put(object container, object[] item, out int accepted);
        // Removes up to `amount` of a loose item of the world near the guest.
        byte Pickup(int hostId, int itemId, int amount, out object[] taken);
        // Places an item into the world at a point near the guest.
        byte Drop(object[] item, float x, float y, float z);
        // Works on the world with the guest's tool; `given` is what the guest receives (or null),
        // `detail` a non-negative number for the guest (refuel: the tank's fuel x100).
        byte Work(int kind, float x, float y, float z, int tool, int extra, object[] escrow, out object[] given, out int detail);
        // One hit of the guest's tool on a host blueprint part or unassembled furniture.
        // `pay` takes a part's recipe from the guest's ledger (false: not enough) and is
        // called only for the hit that completes it; `completed` says whether it was.
        byte Build(int car, int kind, int identity, int tool, Func<int[][], bool> pay, out bool completed);
        // Places a blueprint of part `part` on the host's train as the guest previewed it.
        byte Place(int part, int car, int pointType, float[] point, float[] pose);
        // The ingredients one craft of `recipe` at this workbench needs, or null (not offered, manual, gone, far).
        int[][] Recipe(object[] target, int recipe, out byte status);
        // Queues `count` of `recipe` at the workbench (ingredients already paid).
        byte Queue(object[] target, int recipe, int count);
        // The game's queue button on the open workbench: one craft of entry `index` (which must
        // still be `recipe`) leaves the queue and its ingredients go into the workbench.
        byte CancelCraft(object container, int index, int recipe);
    }

    // Optional game-world notification: manual work follows the one open guest view.
    internal interface ILanStorageViewWorld
    {
        void SetGuestView(object container);
    }

    // Host half for one paired guest: request deduplication, at most one open
    // container, its view pushed (chunked) whenever its contents change.
    internal sealed class LanStorageHost
    {
        private const double PollEvery = 0.25, ChunksPerSecond = 40, Retry = 1;
        private readonly ILanStorageHostWorld _world;
        private readonly Action<Packet> _send;
        private readonly Action<string> _log;
        private readonly Func<bool> _guestReady;
        private readonly LanBlobSender _view = new LanBlobSender();
        // The guest's ledger (0.7.0): takes are handed out on it, puts must come from it.
        internal Func<LanGuestLedger> Ledger;
        private object _container;
        private int _handle, _nextHandle;
        private byte[] _lastView;
        private double _nextPoll, _nextOpen, _nextWork, _nextPlace, _nextDeath;
        private uint _lastTx;
        private Packet _lastResult;
        private bool _active;
        internal bool Open { get { return _container != null; } }

        internal LanStorageHost(ILanStorageHostWorld world, Action<Packet> send, Action<string> log, Func<bool> guestReady)
        { _world = world; _send = send; _log = log; _guestReady = guestReady; }

        internal void Begin() { SetGuestView(null); _active = true; _container = null; _handle = 0; _lastView = null; _lastTx = 0; _lastResult = null; _view.Cancel(); }
        internal void End() { SetGuestView(null); _active = false; _container = null; _view.Cancel(); }

        internal void Tick(double now)
        {
            if (!_active) return;
            if (!_guestReady()) { CloseView(LanStorage.Unavailable); return; }
            if (_container != null && now >= _nextPoll)
            {
                _nextPoll = now + PollEvery;
                byte status = _world.Check(_container);
                if (status != LanStorage.Ok) CloseView(status);
                else
                {
                    var view = _world.Snapshot(_container);
                    if (view == null) CloseView(LanStorage.TooLarge);
                    else
                    {
                        view.Handle = _handle; view.Status = LanStorage.Ok;
                        byte[] blob;
                        try { blob = LanStorage.EncodeView(view); }
                        catch (InvalidDataException ex) { _log("Storage view not sent: " + ex.Message); CloseView(LanStorage.TooLarge); blob = null; }
                        if (blob != null && (_lastView == null || !Same(blob, _lastView))) { _lastView = blob; _view.Start(blob); }
                    }
                }
            }
            _view.Tick(now, ChunksPerSecond, Retry, _send, PacketKind.StorageViewChunk);
        }

        internal void Receive(Packet p, double now)
        {
            if (!_active) return;
            if (p.Kind == PacketKind.StorageViewAck) { _view.Acknowledge(p.Revision); return; }
            if (p.Kind != PacketKind.StorageRequest) return;
            if (p.Sequence < _lastTx) return;
            if (p.Sequence == _lastTx) { if (_lastResult != null) _send(_lastResult); return; } // lost answer
            var book = Ledger == null ? null : Ledger();
            if (book != null) book.BeginChange();
            Packet result;
            try { result = Process(p, now); }
            catch { if (book != null) book.EndChange(false); throw; }
            if (book != null) book.EndChange(result.Action == LanStorage.Ok);
            result.Kind = PacketKind.StorageResult; result.Sequence = p.Sequence;
            _lastTx = p.Sequence; _lastResult = result;
            _send(result);
        }

        private Packet Process(Packet p, double now)
        {
            if (!_guestReady()) return Result(LanStorage.Unavailable);
            switch (p.Action)
            {
                case LanProtocol.StorageOpen:
                    // Resolving searches the scene: at most two opens per second.
                    if (now < _nextOpen) return Result(LanStorage.Busy);
                    _nextOpen = now + 0.5;
                    object[] target;
                    try { target = LanStorage.DecodeTarget(p.Chunk); }
                    catch (InvalidDataException ex) { _log("Storage target rejected: " + ex.Message); return Result(LanStorage.Invalid); }
                    byte found;
                    var container = _world.Resolve(target, out found);
                    if (container == null) return Result(found == LanStorage.Ok ? LanStorage.NotFound : found);
                    _container = container; SetGuestView(container); _handle = ++_nextHandle; _lastView = null; _nextPoll = 0;
                    return new Packet { Action = LanStorage.Ok, Revision = _handle };
                case LanProtocol.StorageClose:
                    if (p.Revision == _handle) { SetGuestView(null); _container = null; _view.Cancel(); }
                    return Result(LanStorage.Ok);
                case LanProtocol.StoragePickup: return Pickup(p);
                case LanProtocol.StorageDrop: return Drop(p);
                case LanProtocol.StorageCraft: return Report("Craft", Craft(p));
                case LanProtocol.StorageControl: return Report("Train control", Control(p));
                case LanProtocol.StorageDeath:
                    if (now < _nextDeath) return Result(LanStorage.Busy);
                    _nextDeath = now + 5;
                    return Death(p);
                case LanProtocol.StoragePlace:
                    if (now < _nextPlace) return Result(LanStorage.Busy);
                    _nextPlace = now + 0.4;
                    return Place(p);
                case LanProtocol.StorageWork:
                case LanProtocol.StorageBuild:
                    // A melee swing is not faster than this.
                    if (now < _nextWork) return Result(LanStorage.Busy);
                    _nextWork = now + 0.3;
                    return p.Action == LanProtocol.StorageWork ? Work(p) : Build(p);
            }
            if (_container == null || p.Revision != _handle) return Result(LanStorage.Gone);
            byte status = _world.Check(_container);
            if (status != LanStorage.Ok) { CloseView(status); return Result(status); }
            _nextPoll = 0; // show the outcome at once
            if (p.Action == LanProtocol.StorageCraftCancel)
            {
                int index, recipe;
                try { LanStorage.DecodeCraftCancel(p.Chunk, out index, out recipe); }
                catch (InvalidDataException ex) { _log("Craft cancel rejected: " + ex.Message); return Result(LanStorage.Invalid); }
                return Report("Craft cancel", Result(_world.CancelCraft(_container, index, recipe)));
            }
            if (p.Action == LanProtocol.StorageTake)
            {
                int index, amount; byte[] fingerprint;
                try { LanStorage.DecodeTake(p.Chunk, out index, out amount, out fingerprint); }
                catch (InvalidDataException ex) { _log("Storage take rejected: " + ex.Message); return Result(LanStorage.Invalid); }
                object[] taken;
                var book = Ledger == null ? null : Ledger();
                if (Ledger != null && book == null) return Result(LanStorage.Unavailable);
                if (book != null && !book.CanReceive()) return Result(LanStorage.TooLarge);
                status = _world.Take(_container, index, fingerprint, amount, out taken);
                if (status != LanStorage.Ok) return Result(status);
                if (book != null) book.Give(LanGuestLedger.RequestChannel, p.Sequence, taken);
                return new Packet { Action = LanStorage.Ok, Revision = _handle, Amount = (int)taken[1], Chunk = LanStorage.EncodeItem(taken) };
            }
            object[] item;
            try { item = LanStorage.DecodeItem(p.Chunk); }
            catch (InvalidDataException ex) { _log("Storage put rejected: " + ex.Message); return Result(LanStorage.Invalid); }
            var owner = Ledger == null ? null : Ledger();
            if (Ledger != null && (owner == null || !owner.Take(item))) return Result(owner == null ? LanStorage.Unavailable : LanStorage.NotOwned);
            int accepted;
            status = _world.Put(_container, item, out accepted);
            if (status != LanStorage.Ok) accepted = 0;
            if (owner != null && accepted < (int)item[1]) owner.Refund(LanStorage.WithAmount(item, (int)item[1] - accepted));
            if (status != LanStorage.Ok) return Result(status);
            return new Packet { Action = LanStorage.Ok, Revision = _handle, Amount = accepted };
        }

        private Packet Pickup(Packet p)
        {
            int hostId, itemId, amount;
            try { LanStorage.DecodePickup(p.Chunk, out hostId, out itemId, out amount); }
            catch (InvalidDataException ex) { _log("Pickup rejected: " + ex.Message); return Result(LanStorage.Invalid); }
            var book = Ledger == null ? null : Ledger();
            if (Ledger != null && book == null) return Result(LanStorage.Unavailable);
            object[] taken;
            if (book != null && !book.CanReceive()) return Result(LanStorage.TooLarge);
            byte status = _world.Pickup(hostId, itemId, amount, out taken);
            if (status != LanStorage.Ok) return Result(status);
            if (book != null) book.Give(LanGuestLedger.RequestChannel, p.Sequence, taken);
            return new Packet { Action = LanStorage.Ok, Amount = (int)taken[1], Chunk = LanStorage.EncodeItem(taken) };
        }

        private Packet Drop(Packet p)
        {
            object[] item; float x, y, z; int car; float[] rotation;
            try { item = LanStorage.DecodeDrop(p.Chunk, out x, out y, out z, out car, out rotation); }
            catch (InvalidDataException ex) { _log("Drop rejected: " + ex.Message); return Result(LanStorage.Invalid); }
            var owner = Ledger == null ? null : Ledger();
            if (Ledger != null && (owner == null || !owner.Take(item))) return Result(owner == null ? LanStorage.Unavailable : LanStorage.NotOwned);
            var placement = _world as ILanStoragePlacementWorld;
            byte status = rotation == null ? _world.Drop(item, x, y, z) : placement == null ? LanStorage.NotAllowed :
                placement.PlaceItem(item, car, new[] { x, y, z, rotation[0], rotation[1], rotation[2], rotation[3] });
            if (status != LanStorage.Ok) { if (owner != null) owner.Refund(item); return Result(status); }
            return new Packet { Action = LanStorage.Ok, Amount = (int)item[1] };
        }

        private Packet Work(Packet p)
        {
            int kind, tool, extra; float x, y, z; object[] escrow;
            try { kind = LanStorage.DecodeWork(p.Chunk, out x, out y, out z, out tool, out extra, out escrow); }
            catch (InvalidDataException ex) { _log("Work rejected: " + ex.Message); return Result(LanStorage.Invalid); }
            var book = Ledger == null ? null : Ledger();
            if (Ledger != null && book == null) return Result(LanStorage.Unavailable);
            // The tool must be the guest's, and not broken.
            if (book != null && tool >= 0 && (book.Count(tool) < 1 || book.BestWear(tool) == 0f)) return Result(LanStorage.NotOwned);
            if (book != null && escrow != null && !book.Take(escrow)) return Result(LanStorage.NotOwned);
            object[] given; int detail;
            byte status = _world.Work(kind, x, y, z, tool, extra, escrow, out given, out detail);
            if (status != LanStorage.Ok) { if (book != null && escrow != null) book.Refund(escrow); return Result(status); }
            if (book != null && tool >= 0 && book.BestWear(tool) > 0f) book.Wear(tool, 1f);
            detail = Math.Max(0, detail);
            if (given == null) return new Packet { Action = LanStorage.Ok, Revision = detail };
            if (book != null) book.Give(LanGuestLedger.RequestChannel, p.Sequence, given);
            return new Packet { Action = LanStorage.Ok, Revision = detail, Amount = (int)given[1], Chunk = LanStorage.EncodeItem(given) };
        }

        private Packet Build(Packet p)
        {
            int car, kind, identity, tool;
            try { LanStorage.DecodeBuild(p.Chunk, out car, out kind, out identity, out tool); }
            catch (InvalidDataException ex) { _log("Build rejected: " + ex.Message); return Result(LanStorage.Invalid); }
            var book = Ledger == null ? null : Ledger();
            if (Ledger != null && book == null) return Result(LanStorage.Unavailable);
            if (book != null && (book.Count(tool) < 1 || book.BestWear(tool) == 0f)) return Result(LanStorage.NotOwned);
            bool completed;
            byte status = _world.Build(car, kind, identity, tool, needs => Pay(book, needs), out completed);
            if (status != LanStorage.Ok) return Result(status);
            if (book != null && book.BestWear(tool) > 0f) book.Wear(tool, 1f);
            return new Packet { Action = LanStorage.Ok, Amount = completed ? 1 : 0 };
        }
        private Packet Place(Packet p)
        {
            int part, car, pointType; float[] point, pose;
            try { LanStorage.DecodePlace(p.Chunk, out part, out car, out pointType, out point, out pose); }
            catch (InvalidDataException ex) { _log("Placement rejected: " + ex.Message); return Result(LanStorage.Invalid); }
            byte status = _world.Place(part, car, pointType, point, pose);
            return Result(status);
        }

        // 1.1.1: a refusal of the guest's request goes to the log (what was refused and why).
        private Packet Report(string what, Packet result)
        {
            if (result != null && result.Action != LanStorage.Ok && result.Action != LanStorage.Busy)
                _log(what + " of the guest refused: status " + result.Action + " (" + LanStorage.Describe(result.Action) + ")");
            return result;
        }

        private Packet Control(Packet p)
        {
            int kind, index, check, value; object[] escrow;
            try { LanStorage.DecodeControl(p.Chunk, out kind, out index, out check, out value, out escrow); }
            catch (InvalidDataException ex) { _log("Control rejected: " + ex.Message); return Result(LanStorage.Invalid); }
            var controls = _world as ILanTrainControlWorld;
            if (controls == null) return Result(LanStorage.NotAllowed);
            var book = Ledger == null ? null : Ledger();
            if (Ledger != null && book == null) return Result(LanStorage.Unavailable);
            // The spare lever of a repair must be the guest's.
            if (book != null && escrow != null && !book.Take(escrow)) return Result(LanStorage.NotOwned);
            byte status = controls.Control(kind, index, check, value, escrow);
            if (status != LanStorage.Ok && book != null && escrow != null) book.Refund(escrow);
            return Result(status);
        }

        private Packet Death(Packet p)
        {
            float x, y, z; int car;
            try { LanStorage.DecodeDeath(p.Chunk, out x, out y, out z, out car); }
            catch (InvalidDataException ex) { _log("Death rejected: " + ex.Message); return Result(LanStorage.Invalid); }
            var deaths = _world as ILanDeathWorld;
            if (deaths == null) return Result(LanStorage.NotAllowed);
            var book = Ledger == null ? null : Ledger();
            if (book == null) return Result(LanStorage.Unavailable);
            var items = book.TakeAll();
            byte status = items.Length == 0 ? LanStorage.Ok : deaths.Death(items, x, y, z, car);
            if (status != LanStorage.Ok) { foreach (object[] item in items) book.Refund(item); return Result(status); }
            _log("Guest died; " + items.Length + " item stack(s) left where it fell");
            return new Packet { Action = LanStorage.Ok, Amount = items.Length };
        }

        // All of a recipe or nothing.
        private static bool Pay(LanGuestLedger book, int[][] needs)
        {
            var wanted = new Dictionary<int, long>();
            foreach (var need in needs) { if (need[1] <= 0) continue; long v; wanted.TryGetValue(need[0], out v); wanted[need[0]] = v + need[1]; }
            if (book == null) return true;
            foreach (var pair in wanted) if (book.Count(pair.Key) < pair.Value) return false;
            foreach (var pair in wanted) book.Remove(pair.Key, (int)pair.Value);
            return true;
        }

        private Packet Craft(Packet p)
        {
            object[] target, ingredients; int recipe, count;
            try { target = LanStorage.DecodeCraft(p.Chunk, out recipe, out count, out ingredients); }
            catch (InvalidDataException ex) { _log("Craft rejected: " + ex.Message); return Result(LanStorage.Invalid); }
            byte status;
            var needs = _world.Recipe(target, recipe, out status);
            if (needs == null) return Result(status == LanStorage.Ok ? LanStorage.NotAllowed : status);
            // The escrow must be exactly the recipe's ingredients for `count` crafts.
            var wanted = new Dictionary<int, long>(); var given = new Dictionary<int, long>();
            foreach (var need in needs) { long v; wanted.TryGetValue(need[0], out v); wanted[need[0]] = v + (long)need[1] * count; }
            foreach (object[] item in ingredients) { long v; given.TryGetValue((int)item[0], out v); given[(int)item[0]] = v + (int)item[1]; }
            if (wanted.Count != given.Count) return Result(LanStorage.Invalid);
            foreach (var pair in wanted) { long v; if (!given.TryGetValue(pair.Key, out v) || v != pair.Value) return Result(LanStorage.Invalid); }
            var book = Ledger == null ? null : Ledger();
            if (Ledger != null && book == null) return Result(LanStorage.Unavailable);
            if (book != null)
            {
                foreach (var pair in wanted) if (book.Count(pair.Key) < pair.Value) return Result(LanStorage.NotOwned);
                foreach (var pair in wanted) book.Remove(pair.Key, (int)pair.Value);
            }
            status = _world.Queue(target, recipe, count);
            if (status != LanStorage.Ok)
            {
                if (book != null) foreach (object[] item in ingredients) book.Refund(item);
                return Result(status);
            }
            return new Packet { Action = LanStorage.Ok, Amount = count };
        }

        private void SetGuestView(object container) { (_world as ILanStorageViewWorld)?.SetGuestView(container); }

        private void CloseView(byte status)
        {
            if (_container == null) return;
            SetGuestView(null); _container = null; _lastView = null;
            _view.Start(LanStorage.EncodeView(new LanStorage.View { Handle = _handle, Status = status == LanStorage.Ok ? LanStorage.Closed : status }));
        }
        private static Packet Result(byte status) { return new Packet { Action = status }; }
        private static bool Same(byte[] a, byte[] b)
        {
            if (a.Length != b.Length) return false;
            for (int i = 0; i < a.Length; i++) if (a[i] != b[i]) return false;
            return true;
        }
    }

    // What the guest side needs from the game.
    internal interface ILanStorageGuestWorld
    {
        // How many of this item fit into the guest's backpack right now.
        int Room(object[] item);
        // Adds an item (received, or returned from escrow) to the guest's backpack.
        void Give(object[] item);
        // Removes what the host took from the guest's ledger for a construction ([id, amount]).
        void Spend(int[][] needs);
    }

    // Guest half: one request in flight (retried until answered), takes queued
    // behind it. A put is escrowed: the game removes the item before the request
    // and the client gives back whatever the host did not store.
    internal sealed class LanStorageClient
    {
        private const double RetryEvery = 1;
        private sealed class Op
        {
            internal byte Kind;
            internal uint Tx;
            internal int Handle;
            internal byte[] Payload;
            internal object[] Item; // take: the view entry; put/drop: the escrowed item; pickup: id and amount
            internal int HostId;    // pickup: the host's loose item
            internal object[] Items; // craft: the escrowed ingredients
            internal int Work;       // work: its kind
            internal int[][] Needs;  // build: what completing the target costs
            internal int Recipe, Count; // craft: recipe item id and how many
            internal byte[] Target;     // craft: the workbench
        }
        private readonly ILanStorageGuestWorld _world;
        private readonly Action<Packet> _send;
        private readonly Action<string> _log;
        private readonly Action _changed;
        private readonly LanBlobReceiver _views = new LanBlobReceiver();
        private readonly Queue<Op> _queue = new Queue<Op>();
        private Op _pending;
        private uint _tx;
        private int _handle;
        private bool _wanted;
        private LanStorage.View _early;
        private double _nextSend;
        internal LanStorage.View Current { get; private set; }
        internal string Message { get; private set; }
        // Open() was called and neither Close() nor the host ended it.
        internal bool IsOpen { get { return _wanted; } }
        internal bool Busy { get { return _pending != null || _queue.Count != 0; } }
        internal int PendingRequests { get { return (_pending != null ? 1 : 0) + _queue.Count; } }
        // The last request whose result this guest has applied.
        internal uint AppliedTx { get; private set; }
        internal Action<int, int> PickedUp;

        internal LanStorageClient(ILanStorageGuestWorld world, Action<Packet> send, Action<string> log, Action changed)
        { _world = world; _send = send; _log = log; _changed = changed; Message = ""; }

        // A new secure session: the host forgot every request; escrow comes back.
        internal void Begin() { Reset(); _tx = 0; AppliedTx = 0; _views.Reset(); }
        internal void End() { Reset(); }

        private void Reset()
        {
            if (_pending != null && Escrowed(_pending)) ReturnEscrow(_pending);
            foreach (var op in _queue) if (Escrowed(op)) ReturnEscrow(op);
            _pending = null; _queue.Clear(); _handle = 0; _wanted = false; Current = null; _early = null;
        }

        internal void Open(byte[] target)
        {
            Close();
            _wanted = true; Message = "Открытие…";
            _queue.Enqueue(new Op { Kind = LanProtocol.StorageOpen, Payload = target });
        }

        // An open still in flight is closed when its answer arrives.
        internal void Close()
        {
            if (_handle != 0) _queue.Enqueue(new Op { Kind = LanProtocol.StorageClose, Handle = _handle });
            _handle = 0; _wanted = false; Current = null; Message = "";
            Keep(op => op.Kind != LanProtocol.StorageTake && op.Kind != LanProtocol.StorageOpen && op.Kind != LanProtocol.StorageCraftCancel);
        }

        internal void Take(int index, int amount)
        {
            if (Current == null || index < 0 || index >= Current.Items.Length || amount < 1) return;
            var item = (object[])Current.Items[index];
            _queue.Enqueue(new Op { Kind = LanProtocol.StorageTake, Handle = _handle, Item = LanStorage.WithAmount(item, Math.Min(amount, (int)item[1])) });
        }

        internal void TakeAll()
        {
            if (Current == null) return;
            for (int i = 0; i < Current.Items.Length; i++) Take(i, (int)((object[])Current.Items[i])[1]);
        }

        // The caller has already removed `item` from the backpack (escrow).
        internal bool Put(object[] item)
        {
            if (_handle == 0 || Busy || !LanStorage.ItemFits(item)) return false;
            _queue.Enqueue(new Op { Kind = LanProtocol.StoragePut, Handle = _handle, Item = LanStorage.Normalize(item) });
            return true;
        }

        // Ask the host for a loose item of its world (up to what fits).
        internal void Pickup(int hostId, int itemId, int amount)
        {
            if (Busy || hostId == 0 || amount < 1) return;
            _queue.Enqueue(new Op { Kind = LanProtocol.StoragePickup, HostId = hostId, Item = new object[] { itemId, Math.Min(amount, LanStorage.MaxAmount), new object[4] } });
        }
        // The caller has already removed `item` from the backpack (escrow).
        internal bool Drop(object[] item, float x, float y, float z)
        {
            if (Busy || !LanStorage.ItemFits(item)) return false;
            byte[] payload;
            try { payload = LanStorage.DropPayload(item, x, y, z); }
            catch (InvalidDataException) { return false; }
            _queue.Enqueue(new Op { Kind = LanProtocol.StorageDrop, Item = LanStorage.Normalize(item), Payload = payload });
            return true;
        }
        internal bool Drop(object[] item, int car, float[] pose)
        {
            if (Busy || !LanStorage.ItemFits(item) || pose == null || pose.Length != 7) return false;
            byte[] payload;
            try
            {
                payload = LanStorage.DropPayload(item, car, pose);
                float x, y, z; int decodedCar; float[] rotation;
                LanStorage.DecodeDrop(payload, out x, out y, out z, out decodedCar, out rotation);
            }
            catch (InvalidDataException) { return false; }
            _queue.Enqueue(new Op { Kind = LanProtocol.StorageDrop, Item = LanStorage.Normalize(item), Payload = payload });
            return true;
        }
        // Work on the world; an escrowed item (fuel: the empty canister) is already out of the backpack.
        internal bool Work(int kind, float x, float y, float z, int tool, int extra, object[] escrow)
        {
            if (escrow != null && Busy) return false;
            if (PendingRequests >= 4) return false; // swings faster than the host answers are dropped
            byte[] payload;
            try { payload = LanStorage.WorkPayload(kind, x, y, z, tool, extra, escrow); }
            catch (InvalidDataException) { return false; }
            _queue.Enqueue(new Op { Kind = LanProtocol.StorageWork, Work = kind, Item = escrow == null ? null : LanStorage.Normalize(escrow), Payload = payload });
            return true;
        }
        // Requests a guest may line up before the host answers (crafts and cancels in the craft window).
        private const int MaxQueuedCraftRequests = 6;
        // Cancel one queued craft of the open workbench (no escrow: the ingredients stay with the host).
        internal bool CancelCraft(int index, int recipe)
        {
            if (_handle == 0 || PendingRequests >= MaxQueuedCraftRequests) return false;
            byte[] payload;
            try { payload = LanStorage.CraftCancelPayload(index, recipe); }
            catch (InvalidDataException) { return false; }
            _queue.Enqueue(new Op { Kind = LanProtocol.StorageCraftCancel, Handle = _handle, Payload = payload });
            return true;
        }
        // Craft at a host workbench; `ingredients` are already out of the backpack. Crafts of one
        // recipe made before the host answers travel as one request (the game's craft amount).
        internal bool Craft(byte[] target, int recipe, int count, object[] ingredients)
        {
            if (target == null || ingredients == null || ingredients.Length == 0 || count < 1) return false;
            Op last = null;
            foreach (var queued in _queue) last = queued;
            if (last != null && last.Kind == LanProtocol.StorageCraft && last.Recipe == recipe && last.Target != null &&
                LanStorage.SameBytes(last.Target, target) && last.Count + count <= LanStorage.MaxCraft)
            {
                try
                {
                    var merged = LanStorage.MergeItems(last.Items, ingredients);
                    last.Payload = LanStorage.CraftPayload(target, recipe, last.Count + count, merged);
                    last.Items = merged; last.Count += count;
                    return true;
                }
                catch (InvalidDataException) { } // too many different ingredients: a request of its own
            }
            if (PendingRequests >= MaxQueuedCraftRequests) return false;
            byte[] payload;
            try { payload = LanStorage.CraftPayload(target, recipe, count, ingredients); }
            catch (InvalidDataException) { return false; }
            _queue.Enqueue(new Op { Kind = LanProtocol.StorageCraft, Items = ingredients, Payload = payload, Recipe = recipe, Count = count, Target = target });
            return true;
        }
        // One hit on a host blueprint or unassembled furniture; `needs` is spent here if the host completes it.
        internal bool Build(int car, int kind, int identity, int tool, int[][] needs)
        {
            if (PendingRequests >= 2) return false; // swings faster than the host answers are dropped
            byte[] payload;
            try { payload = LanStorage.BuildPayload(car, kind, identity, tool); }
            catch (InvalidDataException) { return false; }
            _queue.Enqueue(new Op { Kind = LanProtocol.StorageBuild, Payload = payload, Needs = needs });
            return true;
        }
        // A blueprint as the guest's construction mode previewed it; the host places it.
        internal bool Place(int part, int car, int pointType, float[] point, float[] pose)
        {
            if (PendingRequests >= 2) return false;
            byte[] payload;
            try { payload = LanStorage.PlacePayload(part, car, pointType, point, pose); }
            catch (InvalidDataException) { return false; }
            _queue.Enqueue(new Op { Kind = LanProtocol.StoragePlace, Payload = payload });
            return true;
        }
        // A control of the host's train; a repair's spare lever is already out of the backpack.
        internal bool Control(int kind, int index, int check, int value, object[] escrow)
        {
            if (PendingRequests >= 3) return false; // presses faster than the host answers are dropped
            byte[] payload;
            try
            {
                payload = LanStorage.ControlPayload(kind, index, check, value, escrow);
                int k, i, c, v; object[] e;
                LanStorage.DecodeControl(payload, out k, out i, out c, out v, out e);
            }
            catch (InvalidDataException) { return false; }
            _queue.Enqueue(new Op { Kind = LanProtocol.StorageControl, Work = kind, Item = escrow == null ? null : LanStorage.Normalize(escrow), Payload = payload });
            return true;
        }
        // Successful work: its kind and the host's detail (refuel: the tank's fuel x100).
        internal Action<int, int> WorkDone;

        // The guest died where it stands (car-local when car >= 0). Pending requests stay queued.
        internal bool Death(float x, float y, float z, int car)
        {
            byte[] payload;
            try
            {
                payload = LanStorage.DeathPayload(x, y, z, car);
                float a, b, c; int d; LanStorage.DecodeDeath(payload, out a, out b, out c, out d);
            }
            catch (InvalidDataException) { return false; }
            _queue.Enqueue(new Op { Kind = LanProtocol.StorageDeath, Payload = payload });
            return true;
        }
        // The answer to Death: the host's status and how many item stacks it left there.
        internal Action<byte, int> DeathDone;

        private static bool Escrowed(Op op) { return (op.Kind == LanProtocol.StoragePut || op.Kind == LanProtocol.StorageDrop || op.Kind == LanProtocol.StorageWork || op.Kind == LanProtocol.StorageControl) && op.Item != null || op.Items != null; }

        internal void Tick(double now)
        {
            if (_pending == null && _queue.Count != 0)
            {
                var op = _queue.Dequeue();
                if (op.Kind == LanProtocol.StorageTake)
                {
                    // The view may have changed while queued: ask for what fits now.
                    int room = _world.Room(op.Item);
                    int want = Math.Min(room, (int)op.Item[1]);
                    if (want < 1) { Message = "Рюкзак полон"; DropTakes(); return; }
                    int index = IndexOf(op.Item);
                    op.Payload = LanStorage.TakePayload(index < 0 ? 0 : index, want, LanStorage.Fingerprint(op.Item));
                }
                else if (op.Kind == LanProtocol.StoragePickup)
                {
                    int want = Math.Min(_world.Room(op.Item), (int)op.Item[1]);
                    if (want < 1) { Message = "Рюкзак полон"; return; }
                    op.Payload = LanStorage.PickupPayload(op.HostId, (int)op.Item[0], want);
                }
                else if (op.Kind == LanProtocol.StoragePut)
                {
                    try { op.Payload = LanStorage.EncodeItem(op.Item); }
                    catch (InvalidDataException) { ReturnEscrow(op.Item); Message = LanStorage.Describe(LanStorage.TooLarge); return; }
                }
                op.Tx = ++_tx; _pending = op; _nextSend = 0;
            }
            if (_pending != null && now >= _nextSend)
            {
                _nextSend = now + RetryEvery;
                _send(new Packet { Kind = PacketKind.StorageRequest, Sequence = _pending.Tx, Action = _pending.Kind, Revision = _pending.Handle, Chunk = _pending.Payload });
            }
        }

        internal void Receive(Packet p)
        {
            if (p.Kind == PacketKind.StorageViewChunk)
            {
                bool ack;
                byte[] blob = _views.Accept(p, out ack);
                if (ack) _send(new Packet { Kind = PacketKind.StorageViewAck, Revision = p.Revision });
                if (blob == null) return;
                LanStorage.View view;
                try { view = LanStorage.DecodeView(blob); }
                catch (InvalidDataException ex) { _log("Storage view rejected: " + ex.Message); return; }
                // A view may overtake the answer to its own open: keep the newest one.
                if (_handle == 0 || view.Handle != _handle) { _early = view; return; }
                ApplyView(view);
                return;
            }
            if (p.Kind != PacketKind.StorageResult || _pending == null || p.Sequence != _pending.Tx) return;
            var op = _pending; _pending = null; AppliedTx = op.Tx;
            byte status = p.Action;
            switch (op.Kind)
            {
                case LanProtocol.StorageOpen:
                    bool current = _wanted && _handle == 0 && !HasQueuedOpen();
                    if (status == LanStorage.Ok && p.Revision > 0)
                    {
                        if (current)
                        {
                            _handle = p.Revision;
                            if (_early != null && _early.Handle == _handle) ApplyView(_early);
                        }
                        else _queue.Enqueue(new Op { Kind = LanProtocol.StorageClose, Handle = p.Revision });
                    }
                    else if (current) { _wanted = false; Message = LanStorage.Describe(status == LanStorage.Ok ? LanStorage.Invalid : status); }
                    break;
                case LanProtocol.StorageTake:
                    if (status != LanStorage.Ok) { Message = LanStorage.Describe(status); DropTakes(); break; }
                    object[] item;
                    try { item = LanStorage.DecodeItem(p.Chunk); }
                    catch (InvalidDataException ex) { _log("Storage item from host rejected: " + ex.Message); Message = "Хост прислал повреждённый предмет"; DropTakes(); break; }
                    try { _world.Give(item); Message = ""; }
                    catch (Exception ex) { _log("Storage item not added: " + ex.GetType().Name + ": " + ex.Message); Message = "Предмет не удалось положить в рюкзак"; }
                    _changed();
                    break;
                case LanProtocol.StoragePickup:
                    if (status != LanStorage.Ok) { Message = LanStorage.Describe(status); break; }
                    object[] picked;
                    try { picked = LanStorage.DecodeItem(p.Chunk); }
                    catch (InvalidDataException ex) { _log("Picked item from host rejected: " + ex.Message); Message = "Хост прислал повреждённый предмет"; break; }
                    try { _world.Give(picked); PickedUp?.Invoke(op.HostId, (int)picked[1]); Message = ""; }
                    catch (Exception ex) { _log("Picked item not added: " + ex.GetType().Name + ": " + ex.Message); Message = "Предмет не удалось положить в рюкзак"; }
                    _changed();
                    break;
                case LanProtocol.StorageDrop:
                    if (status != LanStorage.Ok) { ReturnEscrow(op.Item); Message = LanStorage.Describe(status); break; }
                    Message = ""; _changed();
                    break;
                case LanProtocol.StorageCraft:
                    _log(status == LanStorage.Ok ? "Craft queued at the host's workbench" : "Craft refused by the host: status " + status + " (" + LanStorage.Describe(status) + ")");
                    if (status != LanStorage.Ok) { ReturnEscrow(op); Message = LanStorage.Describe(status); break; }
                    Message = ""; _changed(); // the queue shows in the game's craft window
                    break;
                case LanProtocol.StorageCraftCancel:
                    _log(status == LanStorage.Ok ? "Craft cancelled at the host's workbench" : "Craft cancel refused by the host: status " + status + " (" + LanStorage.Describe(status) + ")");
                    Message = status == LanStorage.Ok ? "" : LanStorage.Describe(status);
                    break;
                case LanProtocol.StorageWork:
                    if (status != LanStorage.Ok) { if (op.Item != null) ReturnEscrow(op.Item); if (status != LanStorage.Busy) Message = LanStorage.Describe(status); break; }
                    if (p.Chunk != null && p.Chunk.Length > 0)
                    {
                        object[] made;
                        try { made = LanStorage.DecodeItem(p.Chunk); }
                        catch (InvalidDataException ex) { _log("Work result from host rejected: " + ex.Message); break; }
                        try { _world.Give(made); }
                        catch (Exception ex) { _log("Work result not added: " + ex.GetType().Name + ": " + ex.Message); }
                    }
                    try { WorkDone?.Invoke(op.Work, p.Revision); }
                    catch (Exception ex) { _log("Work result not shown: " + ex.Message); }
                    _changed();
                    break;
                case LanProtocol.StorageDeath:
                    try { DeathDone?.Invoke(status, p.Amount); }
                    catch (Exception ex) { _log("Death result not applied: " + ex.GetType().Name + ": " + ex.Message); }
                    break;
                case LanProtocol.StoragePlace:
                    Message = status == LanStorage.Ok ? "Чертёж поставлен у хоста" : LanStorage.Describe(status);
                    _changed();
                    break;
                case LanProtocol.StorageControl:
                    if (status != LanStorage.Ok || op.Work != LanStorage.ControlLever)
                        _log("Train control " + op.Work + (status == LanStorage.Ok ? " done by the host" : " refused by the host: status " + status + " (" + LanStorage.Describe(status) + ")"));
                    if (status != LanStorage.Ok) { if (op.Item != null) ReturnEscrow(op.Item); Message = LanStorage.Describe(status); break; }
                    Message = op.Work == LanStorage.ControlRepair ? "Починено" : "";
                    if (op.Item != null) _changed();
                    break;
                case LanProtocol.StorageBuild:
                    if (status != LanStorage.Ok) { if (status != LanStorage.Busy) Message = LanStorage.Describe(status); break; }
                    if (p.Amount == 1 && op.Needs != null)
                    {
                        try { _world.Spend(op.Needs); }
                        catch (Exception ex) { _log("Construction cost not spent: " + ex.GetType().Name + ": " + ex.Message); }
                        Message = "Построено";
                    }
                    _changed();
                    break;
                case LanProtocol.StoragePut:
                    int stored = status == LanStorage.Ok ? Math.Max(0, Math.Min(p.Amount, (int)op.Item[1])) : 0;
                    if (stored < (int)op.Item[1]) ReturnEscrow(LanStorage.WithAmount(op.Item, (int)op.Item[1] - stored));
                    Message = status == LanStorage.Ok ? (stored < (int)op.Item[1] ? "Поместилось " + stored : "") : LanStorage.Describe(status);
                    if (stored > 0) _changed();
                    break;
            }
        }

        private void ApplyView(LanStorage.View view)
        {
            _early = null;
            if (view.Status != LanStorage.Ok)
            { _handle = 0; _wanted = false; Current = null; DropTakes(); Message = LanStorage.Describe(view.Status); return; }
            Current = view;
            if (Message == "Открытие…") Message = "";
        }

        private void ReturnEscrow(Op op)
        {
            if (op.Items != null) foreach (object[] item in op.Items) ReturnEscrow(item);
            else if (op.Item != null) ReturnEscrow(op.Item);
        }
        private void ReturnEscrow(object[] item)
        {
            try { _world.Give(item); }
            catch (Exception ex) { _log("Storage escrow return failed: " + ex.GetType().Name + ": " + ex.Message); }
        }
        private int IndexOf(object[] item)
        {
            if (Current == null) return -1;
            byte[] fingerprint = LanStorage.Fingerprint(item);
            for (int i = 0; i < Current.Items.Length; i++)
                if (LanStorage.SameFingerprint(LanStorage.Fingerprint((object[])Current.Items[i]), fingerprint)) return i;
            return -1;
        }
        private void DropTakes() { Keep(op => op.Kind != LanProtocol.StorageTake); }
        private void Keep(Func<Op, bool> keep)
        {
            var all = new List<Op>(_queue); _queue.Clear();
            foreach (var op in all) if (keep(op)) _queue.Enqueue(op);
        }
        private bool HasQueuedOpen() { foreach (var op in _queue) if (op.Kind == LanProtocol.StorageOpen) return true; return false; }
    }
}
