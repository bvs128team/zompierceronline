using System;
using System.Linq;

namespace ZompiercerLAN
{
    // 0.6.1: zombie corpses and world doors (packet schema 12).
    internal static partial class Program
    {
        private static NetPose Bone(float x) { return new NetPose { X = x, Y = 1f, Z = 2f, QX = 0f, QY = 0.7071068f, QZ = 0f, QW = 0.7071068f }; }

        private static void WorldChecks()
        {
            Packet decoded;
            Func<Packet, Packet> world = p => { p.GameVersion = "checks"; p.Session = 42; p.WorldEpoch = 3; p.Sequence = 9; p.Scene = new string('S', 96); return p; };
            var corpse = world(new Packet { Kind = PacketKind.ZombieCorpse, Corpse = new CorpseFrame { Id = LanProtocol.MaxZombieIds, Prefab = new string('Z', 64), X = 1, Y = 2, Z = 3, Yaw = 359.9f,
                Bones = Enumerable.Range(0, LanProtocol.MaxCorpseBones).Select(i => Bone(i)).ToArray() } });
            var doors = world(new Packet { Kind = PacketKind.DoorStates, Doors = Enumerable.Range(0, LanProtocol.MaxDoorBatch).Select(i => new DoorFrame { X = i, Y = -i, Z = 5, Flags = (byte)(i % 4) }).ToArray() });
            var toggle = world(new Packet { Kind = PacketKind.DoorToggle, X = 10, Y = 0.5f, Z = -3, Action = 1 });
            foreach (var p in new[] { corpse, doors, toggle })
            {
                var bytes = LanProtocol.Encode(p);
                Require(bytes.Length <= 1200 && LanProtocol.TryDecode(bytes, out decoded) && decoded.Kind == p.Kind && decoded.Sequence == 9, "Valid world packet rejected: " + p.Kind);
                for (int size = 0; size < bytes.Length; size++) { var t = new byte[size]; Array.Copy(bytes, t, size); Require(!LanProtocol.TryDecode(t, out decoded), "Truncated world packet accepted"); }
                var tail = new byte[bytes.Length + 1]; Array.Copy(bytes, tail, bytes.Length); Require(!LanProtocol.TryDecode(tail, out decoded), "World packet trailing bytes accepted");
            }
            LanProtocol.TryDecode(LanProtocol.Encode(corpse), out decoded);
            Require(decoded.Corpse.Bones.Length == LanProtocol.MaxCorpseBones && decoded.Corpse.Bones[5].X == 5 && decoded.Corpse.Id == LanProtocol.MaxZombieIds, "Corpse fields");
            LanProtocol.TryDecode(LanProtocol.Encode(doors), out decoded);
            Require(decoded.Doors.Length == LanProtocol.MaxDoorBatch && decoded.Doors[7].Flags == 3 && decoded.Doors[7].Y == -7, "Door fields");
            // Malformed or out-of-range fields.
            Func<Action<Packet>, Packet, bool> rejected = (change, source) =>
            {
                Packet copy; LanProtocol.TryDecode(LanProtocol.Encode(source), out copy);
                copy.GameVersion = "checks"; change(copy);
                try { return !LanProtocol.TryDecode(LanProtocol.Encode(copy), out decoded); }
                catch (System.IO.InvalidDataException) { return true; }
            };
            var bad = new[]
            {
                rejected(p => p.Corpse.Id = 0, corpse), rejected(p => p.Corpse.Id = LanProtocol.MaxZombieIds + 1, corpse), rejected(p => p.Corpse.Prefab = "", corpse),
                rejected(p => p.Corpse.Yaw = 361, corpse), rejected(p => p.Corpse.Bones = new NetPose[LanProtocol.MaxCorpseBones + 1], corpse),
                rejected(p => p.Corpse.Bones[0].QW = 3, corpse), rejected(p => p.Corpse.X = float.NaN, corpse),
                rejected(p => p.Doors[0].Flags = 4, doors), rejected(p => p.Doors = new DoorFrame[LanProtocol.MaxDoorBatch + 1], doors), rejected(p => p.Doors[1].Z = 200000, doors),
                rejected(p => p.Action = 2, toggle), rejected(p => p.X = float.PositiveInfinity, toggle),
                rejected(p => p.WorldEpoch = 0, toggle), rejected(p => p.Sequence = 0, doors), rejected(p => p.Scene = "", corpse),
            };
            Require(bad.All(x => x), "Malformed world packet accepted: #" + Array.IndexOf(bad, false));
            Require(LanNetworkPolicy.Allowed(true, PacketKind.DoorToggle, true) && !LanNetworkPolicy.Allowed(false, PacketKind.DoorToggle, true), "Door request direction");
            foreach (var kind in new[] { PacketKind.ZombieCorpse, PacketKind.DoorStates })
                Require(!LanNetworkPolicy.Allowed(true, kind, true) && LanNetworkPolicy.Allowed(false, kind, true) && !LanNetworkPolicy.Allowed(false, kind, false), "Host-to-guest direction: " + kind);
            var limits = new LanMessageLimits(); int toggles = 0, corpses = 0;
            for (int i = 0; i < 1000; i++) { if (limits.Take(PacketKind.DoorToggle, 0)) toggles++; if (limits.Take(PacketKind.ZombieCorpse, 0)) corpses++; }
            Require(toggles == 4 && corpses == 24, "World packet bursts not bounded");
            // Loose items and bags (schema 13).
            var items = world(new Packet { Kind = PacketKind.WorldItems, Items = Enumerable.Range(0, LanProtocol.MaxItemBatch).Select(i =>
                new WorldItemFrame { HostId = i + 1, ItemId = i % 3 == 0 ? -1 : 5, Amount = i % 3 == 0 ? 0 : 3, Kind = (byte)(i % 3 == 0 ? 1 : 0), Pose = Bone(i) }).ToArray() });
            var itemBytes = LanProtocol.Encode(items);
            Require(itemBytes.Length <= 1200 && LanProtocol.TryDecode(itemBytes, out decoded) && decoded.Items.Length == LanProtocol.MaxItemBatch && decoded.Items[1].Amount == 3, "Item batch rejected");
            var badItems = new[]
            {
                rejected(p => p.Items[0].HostId = 0, items), rejected(p => p.Items[1].Kind = 3, items), rejected(p => p.Items[1].ItemId = 70000, items),
                rejected(p => p.Items[1].Amount = 0, items), rejected(p => p.Items[0].Amount = 5, items), rejected(p => p.Items[0].ItemId = 4, items),
                rejected(p => p.Items = new WorldItemFrame[LanProtocol.MaxItemBatch + 1], items), rejected(p => p.Items[2].Pose.QW = 5, items),
            };
            Require(badItems.All(x => x), "Malformed item batch accepted: #" + Array.IndexOf(badItems, false));
            Require(!LanNetworkPolicy.Allowed(true, PacketKind.WorldItems, true) && LanNetworkPolicy.Allowed(false, PacketKind.WorldItems, true), "Item batch direction");
            // Pick-up and drop requests carry no handle; bag targets name a host id.
            Require(LanProtocol.ValidStorageRequest(LanProtocol.StoragePickup, 0, 5) && !LanProtocol.ValidStorageRequest(LanProtocol.StoragePickup, 1, 5) &&
                LanProtocol.ValidStorageRequest(LanProtocol.StorageDrop, 0, 5) && !LanProtocol.ValidStorageRequest(LanProtocol.StorageDrop, 0, 0), "Pick-up/drop request shapes");
            Require((int)LanStorage.DecodeTarget(LanStorage.BagPayload(42))[1] == 42, "Bag target roundtrip");
            ExpectRejected(() => LanStorage.DecodeTarget(LanValueCodec.Encode(new object[] { 3, 0 })), "Bag target without id accepted");
            int hostId, itemId, amount; float dx, dy, dz;
            LanStorage.DecodePickup(LanStorage.PickupPayload(9, 8, 7), out hostId, out itemId, out amount);
            Require(hostId == 9 && itemId == 8 && amount == 7, "Pick-up payload roundtrip");
            ExpectRejected(() => LanStorage.DecodePickup(LanValueCodec.Encode(new object[] { 0, 8, 7 }), out hostId, out itemId, out amount), "Pick-up without host id accepted");
            ExpectRejected(() => LanStorage.DecodePickup(LanValueCodec.Encode(new object[] { 9, 8, 0 }), out hostId, out itemId, out amount), "Empty pick-up accepted");
            var dropped = LanStorage.DecodeDrop(LanStorage.DropPayload(Item(5, 2), 1f, 2f, 3f), out dx, out dy, out dz);
            Require((int)dropped[0] == 5 && dz == 3f, "Drop payload roundtrip");
            ExpectRejected(() => LanStorage.DecodeDrop(LanValueCodec.Encode(new object[] { Item(5, 2), 1f, 2f, 300000f }), out dx, out dy, out dz), "Far drop position accepted");
            ExpectRejected(() => LanStorage.DecodeDrop(LanValueCodec.Encode(new object[] { Item(70000, 2), 1f, 2f, 3f }), out dx, out dy, out dz), "Unknown dropped item accepted");
            // Work requests.
            Require(LanProtocol.ValidStorageRequest(LanProtocol.StorageWork, 0, 9) && !LanProtocol.ValidStorageRequest(LanProtocol.StorageWork, 2, 9), "Work request shape");
            int wtool, wextra; object[] wescrow;
            Require(LanStorage.DecodeWork(LanStorage.WorkPayload(LanStorage.WorkDig, 1f, 2f, 3f, 7, 2, null), out dx, out dy, out dz, out wtool, out wextra, out wescrow) == LanStorage.WorkDig && wextra == 2 && wescrow == null, "Work payload roundtrip");
            foreach (var badWork in new[] { new object[] { 9, 1f, 2f, 3f, 7, 0, null }, new object[] { LanStorage.WorkDig, 1f, 2f, 3f, 7, 3, null }, new object[] { LanStorage.WorkHit, 1f, 2f, 3f, -1, 0, null },
                new object[] { LanStorage.WorkFuel, 1f, 2f, 3f, -1, 0, null }, new object[] { LanStorage.WorkHit, 1f, 2f, 3f, 7, 0, Item(92, 1) }, new object[] { LanStorage.WorkFuel, 1f, 2f, 300000f, -1, 0, Item(92, 1) } })
                ExpectRejected(() => LanStorage.DecodeWork(LanValueCodec.Encode(badWork), out dx, out dy, out dz, out wtool, out wextra, out wescrow), "Invalid work request accepted");
            // Craft requests.
            int crecipe, ccount; object[] cingredients;
            var ctarget = LanStorage.DecodeCraft(LanStorage.CraftPayload(LanStorage.TrainPayload(1, 1, 9), 40, 2, new object[] { Item(1, 4) }), out crecipe, out ccount, out cingredients);
            Require((int)ctarget[0] == LanStorage.TrainTarget && crecipe == 40 && ccount == 2 && cingredients.Length == 1, "Craft payload roundtrip");
            foreach (var badCraft in new[] {
                new object[] { new object[] { 2, 9, 1, 5 }, 40, 1, new object[] { Item(1, 1) } }, new object[] { new object[] { 2, 0, 1, 5 }, 40, 0, new object[] { Item(1, 1) } },
                new object[] { new object[] { 2, 0, 1, 5 }, 40, 21, new object[] { Item(1, 1) } }, new object[] { new object[] { 2, 0, 1, 5 }, 40, 1, new object[0] },
                new object[] { new object[] { 2, 0, 1, 5 }, 70000, 1, new object[] { Item(1, 1) } }, new object[] { new object[] { 2, 0, 1, 5 }, 40, 1, new object[] { Item(70000, 1) } } })
                ExpectRejected(() => LanStorage.DecodeCraft(LanValueCodec.Encode(badCraft), out crecipe, out ccount, out cingredients), "Invalid craft request accepted");
            Require(LanProtocol.ValidStorageRequest(LanProtocol.StorageCraft, 0, 9) && !LanProtocol.ValidStorageRequest(LanProtocol.StorageCraft, 3, 9), "Craft request shape");
            Console.WriteLine("PASS: world packets schema 12-13 (corpse poses, door batches, door requests, item batches, pick-up/drop shapes) / bounds / truncation / directions / rate limits");
        }
    }
}
