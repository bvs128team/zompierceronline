using System;
using System.Collections.Generic;
using UnityEngine;

namespace ZompiercerLAN
{
    // Third-person animation of the other player (1.0.9). The avatar is a game NPC model (man:
    // RigSkuf* bones, woman: RigW*) whose own controller has idle and walk only. With a firearm,
    // an invisible military NPC (RigSlim*, the same 65-bone rig with the same bone axes) plays
    // the game's "NPC with AK" controller (armed idle, walk and aim); after it animates, every
    // bone's local rotation is copied by name onto the avatar, so the avatar holds the weapon
    // in both hands as the game's armed NPCs do. Display only: no gameplay scripts.
    // 1.1.0: crouching, looking up or down and melee swings, for which the game's NPCs have no
    // clips, are bone turns about the avatar's own right axis over whichever pose the animators made.
    internal sealed class RemoteAvatarMotion : MonoBehaviour
    {
        // The pace (m/s) at which the NPC walk cycles keep up with the ground (an estimate):
        // a faster partner walks the same clip faster, within PaceMin..PaceMax.
        internal const float WalkClipSpeed = 1.4f, PaceMin = .8f, PaceMax = 2.2f;
        // Crouch: knee bend and forward lean in degrees; how fast pose changes follow (per second).
        internal const float CrouchKnee = 60f, CrouchLean = 15f, Follow = 12f, MaxBodyPitch = 70f;
        // A swing: the arm rises forward over the head, strikes down past the body, comes back.
        internal const float SwingRise = .22f, SwingStrike = .12f, SwingReturn = .3f, SwingHigh = -130f, SwingLow = 15f;
        // A shot (1.1.1): the chest and arms kick back and settle.
        internal const float RecoilKick = 7f, RecoilSettle = .07f;
        private const string Palm = "RArmPalm", Hub = "Hub001";
        private Animator _own, _driver;
        private GameObject _driverObject;
        private Transform[] _from = new Transform[0], _to = new Transform[0];
        private Transform _fromHub, _toHub;
        private Vector3 _fromHubRest, _toHubRest;
        private float _hubScale = 1f;
        private bool _armed, _ownWalk, _driverWalk, _driverAim, _ownChecked, _driverChecked;

        // A bone turned by the procedural layer. Each frame starts from the animated pose; a bone
        // the animators did not write this frame (culled, or not in the clip) starts from its last
        // animated rotation instead of piling the turns up.
        private sealed class Turned
        {
            internal Transform Bone;
            internal Quaternion Base, Written;
            internal bool Seen;
        }
        private Turned _lThigh, _lShin, _lFoot, _rThigh, _rShin, _rFoot, _spine2, _spine3, _neck, _head, _arm;
        private Turned[] _turned = new Turned[0];
        private Transform _pelvis;
        private Vector3 _pelvisBase, _pelvisWritten;
        private bool _pelvisSeen;
        private float _legLength, _crouch, _crouchTarget, _pitch, _pitchTarget, _swingAt = -100f, _shotAt = -100f;

        // The avatar's right palm bone (not the driver's), for the held weapon.
        internal Transform RightPalm { get; private set; }

        // A bone whose name ends with the suffix; prefix: the rest of its name (the rig's prefix).
        internal static Transform FindBone(Transform root, string suffix, out string prefix)
        {
            foreach (var bone in root.GetComponentsInChildren<Transform>(true))
                if (bone.name.EndsWith(suffix, StringComparison.Ordinal) && bone.name.StartsWith("Rig", StringComparison.Ordinal))
                { prefix = bone.name.Substring(0, bone.name.Length - suffix.Length); return bone; }
            prefix = null;
            return null;
        }

        // own: the avatar's animator (idle and walk). driver: a display copy of a military NPC,
        // or null; it is destroyed when it cannot drive this avatar. Called before the avatar
        // is first shown, so both rigs are still in their prefab poses.
        internal string Initialize(Animator own, GameObject driver, RuntimeAnimatorController armed)
        {
            _own = own;
            string prefix, driverPrefix;
            RightPalm = FindBone(transform, Palm, out prefix);
            var avatarBones = new Dictionary<string, Transform>(StringComparer.Ordinal);
            if (RightPalm != null)
                foreach (var bone in GetComponentsInChildren<Transform>(true))
                    if (bone.name.StartsWith(prefix, StringComparison.Ordinal)) avatarBones[bone.name.Substring(prefix.Length)] = bone;
            PrepareTurns(avatarBones);
            if (driver == null) return "no military NPC model";
            if (armed == null || RightPalm == null || FindBone(driver.transform, Palm, out driverPrefix) == null)
            { Destroy(driver); return "no armed controller or no palm bone"; }
            var from = new List<Transform>(); var to = new List<Transform>();
            foreach (var bone in driver.GetComponentsInChildren<Transform>(true))
            {
                Transform match;
                if (!bone.name.StartsWith(driverPrefix, StringComparison.Ordinal) ||
                    !avatarBones.TryGetValue(bone.name.Substring(driverPrefix.Length), out match)) continue;
                from.Add(bone); to.Add(match);
                if (bone.name.EndsWith(Hub, StringComparison.Ordinal)) { _fromHub = bone; _toHub = match; }
            }
            if (from.Count < 40) { Destroy(driver); return "the rigs differ (" + from.Count + " shared bones)"; }
            _from = from.ToArray(); _to = to.ToArray();
            if (_fromHub != null)
            {
                // The pelvis moves with the clips; scaled by hip height for a shorter or taller model.
                _fromHubRest = _fromHub.localPosition; _toHubRest = _toHub.localPosition;
                _hubScale = Mathf.Abs(_fromHubRest.y) > .01f ? Mathf.Clamp(_toHubRest.y / _fromHubRest.y, .5f, 2f) : 1f;
            }
            foreach (var renderer in driver.GetComponentsInChildren<Renderer>(true)) renderer.enabled = false;
            _driver = driver.GetComponentInChildren<Animator>(true);
            if (_driver == null) { Destroy(driver); _from = _to = new Transform[0]; return "no animator on the military NPC"; }
            _driver.runtimeAnimatorController = armed;
            _driver.applyRootMotion = false;
            _driver.cullingMode = AnimatorCullingMode.AlwaysAnimate; // its renderers are off
            _driver.enabled = true;
            _driverObject = driver;
            driver.SetActive(false);
            driver.transform.SetParent(transform, false);
            driver.transform.localPosition = Vector3.zero; driver.transform.localRotation = Quaternion.identity;
            return null;
        }

        // The rig's legs ("LLeg1" thigh, "LLeg2" shin, "LLegAnkle" foot), spine, neck ("Spine1 1"),
        // head ("Hub003") and right upper arm; a missing bone only drops its part of the layer.
        private void PrepareTurns(Dictionary<string, Transform> bones)
        {
            Func<string, Turned> find = name => { Transform bone; return bones.TryGetValue(name, out bone) ? new Turned { Bone = bone } : null; };
            _lThigh = find("LLeg1"); _lShin = find("LLeg2"); _lFoot = find("LLegAnkle");
            _rThigh = find("RLeg1"); _rShin = find("RLeg2"); _rFoot = find("RLegAnkle");
            _spine2 = find("Spine2"); _spine3 = find("Spine3"); _neck = find("Spine1 1"); _head = find("Hub003");
            _arm = find("RArm1");
            Transform pelvis;
            if (bones.TryGetValue(Hub, out pelvis)) _pelvis = pelvis;
            var list = new List<Turned>();
            foreach (var turned in new[] { _lThigh, _lShin, _lFoot, _rThigh, _rShin, _rFoot, _spine2, _spine3, _neck, _head, _arm })
                if (turned != null) list.Add(turned);
            _turned = list.ToArray();
            if (_lThigh != null && _lShin != null && _lFoot != null)
                _legLength = Vector3.Distance(_lThigh.Bone.position, _lShin.Bone.position) + Vector3.Distance(_lShin.Bone.position, _lFoot.Bone.position);
        }

        // Read once each animator is active (an inactive animator lists no parameters).
        private static bool Has(Animator animator, string parameter)
        {
            try { foreach (var p in animator.parameters) if (p.name == parameter) return true; }
            catch (Exception) { }
            return false;
        }

        // Every frame: armed (a firearm in hand), walking, the partner's pace (m/s), aiming (down
        // the sights, or a recent shot), crouching, the view's pitch (degrees, up positive) and the
        // times (Time.unscaledTime; long ago when none) of the last melee swing and the last shot.
        internal void Apply(bool armed, bool walking, float speed, bool aiming, bool crouching, float pitch, float swingAt, float shotAt)
        {
            _crouchTarget = crouching ? 1f : 0f;
            _pitchTarget = Mathf.Clamp(pitch, -LanProtocol.MaxPitch, LanProtocol.MaxPitch);
            _swingAt = swingAt; _shotAt = shotAt;
            // 1.1.1: aiming shows the aiming pose even on the move (the clips have no aimed walk).
            if (armed && aiming) walking = false;
            if (_driverObject == null) armed = false;
            if (armed != _armed)
            {
                _armed = armed;
                _driverObject?.SetActive(armed);
                if (_own != null) _own.enabled = !armed;
            }
            var animator = armed ? _driver : _own;
            if (animator == null || !animator.isActiveAndEnabled) return;
            if (armed && !_driverChecked) { _driverChecked = true; _driverWalk = Has(_driver, "Walk"); _driverAim = Has(_driver, "Aim"); }
            if (!armed && !_ownChecked) { _ownChecked = true; _ownWalk = Has(_own, "Walk"); }
            if (armed ? _driverWalk : _ownWalk) animator.SetBool("Walk", walking);
            if (armed && _driverAim) animator.SetBool("Aim", aiming && !walking);
            animator.speed = walking ? Mathf.Clamp(speed / WalkClipSpeed, PaceMin, PaceMax) : 1f;
        }

        // After the animators: the driver's pose onto the avatar, then the procedural layer.
        private void LateUpdate()
        {
            if (_armed && _driverObject != null)
            {
                for (int i = 0; i < _from.Length; i++) _to[i].localRotation = _from[i].localRotation;
                if (_fromHub != null) _toHub.localPosition = _toHubRest + (_fromHub.localPosition - _fromHubRest) * _hubScale;
            }
            float follow = 1f - Mathf.Exp(-Follow * Time.unscaledDeltaTime);
            _crouch = Mathf.Lerp(_crouch, _crouchTarget, follow);
            _pitch = Mathf.Lerp(_pitch, _pitchTarget, follow);
            foreach (var turned in _turned) Restore(turned);
            RestorePelvis();
            var right = transform.right;
            if (_crouch > .001f)
            {
                // Knees forward, shins back, feet flat; the pelvis drops by what the legs lost in height.
                float knee = _crouch * CrouchKnee;
                Turn(_lThigh, -knee, right); Turn(_lShin, 2f * knee, right); Turn(_lFoot, -knee, right);
                Turn(_rThigh, -knee, right); Turn(_rShin, 2f * knee, right); Turn(_rFoot, -knee, right);
                if (_pelvis != null) _pelvis.position += Vector3.down * (_legLength * (1f - Mathf.Cos(knee * Mathf.Deg2Rad)));
            }
            // Looking up or down: the body bends with it, the more so with a rifle (the arms hang
            // from the chest, so the weapon follows the spine's share).
            float body = Mathf.Clamp(_pitch, -MaxBodyPitch, MaxBodyPitch);
            float lean = _crouch * CrouchLean;
            Turn(_spine2, (_armed ? .4f : .1f) * -body + lean * .5f, right);
            Turn(_spine3, (_armed ? .4f : .15f) * -body + lean * .5f, right);
            Turn(_neck, (_armed ? .1f : .3f) * -_pitch, right);
            Turn(_head, (_armed ? .1f : .45f) * -_pitch, right);
            if (!_armed) Turn(_arm, SwingAngle(Time.unscaledTime - _swingAt), right);
            else
            {
                float age = Time.unscaledTime - _shotAt;
                if (age >= 0f && age < 6f * RecoilSettle) Turn(_spine3, -RecoilKick * Mathf.Exp(-age / RecoilSettle), right);
            }
            foreach (var turned in _turned) turned.Written = turned.Bone.localRotation;
            if (_pelvis != null) _pelvisWritten = _pelvis.localPosition;
        }

        // The upper arm's turn (degrees about the right axis, negative raises it forward) at a
        // time after a swing began.
        internal static float SwingAngle(float age)
        {
            if (age < 0f || age > SwingRise + SwingStrike + SwingReturn) return 0f;
            if (age < SwingRise) return SwingHigh * Mathf.SmoothStep(0f, 1f, age / SwingRise);
            age -= SwingRise;
            if (age < SwingStrike) return Mathf.Lerp(SwingHigh, SwingLow, age / SwingStrike);
            age -= SwingStrike;
            return Mathf.Lerp(SwingLow, 0f, Mathf.SmoothStep(0f, 1f, age / SwingReturn));
        }

        private static void Restore(Turned turned)
        {
            if (turned.Seen && turned.Bone.localRotation == turned.Written) turned.Bone.localRotation = turned.Base;
            else turned.Base = turned.Bone.localRotation;
            turned.Seen = true;
        }

        private void RestorePelvis()
        {
            if (_pelvis == null) return;
            if (_pelvisSeen && _pelvis.localPosition == _pelvisWritten) _pelvis.localPosition = _pelvisBase;
            else _pelvisBase = _pelvis.localPosition;
            _pelvisSeen = true;
        }

        private static void Turn(Turned turned, float degrees, Vector3 axis)
        {
            if (turned == null || Mathf.Abs(degrees) < .01f) return;
            turned.Bone.rotation = Quaternion.AngleAxis(degrees, axis) * turned.Bone.rotation;
        }
    }
}
