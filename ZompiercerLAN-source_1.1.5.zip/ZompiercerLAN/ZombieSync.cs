using System;
using System.Collections.Generic;
using System.Collections;
using System.Diagnostics;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
using Zompiercer.Inventory;
using Object = UnityEngine.Object;

namespace ZompiercerLAN
{
    // Main-thread only. Wire messages contain primitive state, never serialized Unity objects.
    internal sealed class ZombieSync : IDisposable
    {
        private static ZombieSync Active;
        private static Harmony Guard;
        private static bool ClientWorld; // Deliberately survives disconnect, Dispose and scene loads.
        private static bool IsClientWorld { get { if (LanSaveIsolation.Active) ClientWorld = true; return ClientWorld; } }
        private readonly bool _host;
        private readonly Action<Packet> _send;
        private readonly Action<string> _report;
        internal readonly LanCombatSync Combat;
        private readonly Dictionary<int, HostZombie> _hostIds = new Dictionary<int, HostZombie>();
        private readonly List<HostZombie> _catalog = new List<HostZombie>();
        private readonly Dictionary<uint, Replica> _replicas = new Dictionary<uint, Replica>();
        private readonly Dictionary<string, ZombieAIController> _prefabs = new Dictionary<string, ZombieAIController>(StringComparer.Ordinal);
        private readonly HashSet<string> _failedPrefabs = new HashSet<string>(StringComparer.Ordinal);
        private readonly HashSet<string> _unknownPrefabs = new HashSet<string>(StringComparer.Ordinal);
        private readonly Queue<Packet> _hurts = new Queue<Packet>();
        private readonly uint[] _seen = new uint[LanProtocol.MaxZombieIds + 1];
        private readonly bool[] _dead = new bool[LanProtocol.MaxZombieIds + 1];
        private readonly uint[] _corpseSeen = new uint[LanProtocol.MaxZombieIds + 1];
        private uint _corpseSequence;
        private readonly ZombieFrame[] _pendingFrames = new ZombieFrame[LanProtocol.MaxZombieIds + 1];
        private readonly uint[] _pendingSequences = new uint[LanProtocol.MaxZombieIds + 1];
        private readonly float[] _pendingTimes = new float[LanProtocol.MaxZombieIds + 1];
        // Client (1.0.7): local time minus host time, from the fastest recent batches, and the
        // average extra delay of the others; replicas are shown that far in the host's past.
        private float _clockOffset, _jitter;
        private bool _haveClock;
        private readonly float[] _pendingDamage = new float[5];
        private int _pendingCount, _applyCursor = 1;
        private string _scene;
        private uint _epoch, _sequence, _actionSequence, _lastAction, _hurtSequence, _lastHurt;
        private bool _ready, _remoteReady, _playerReady, _disposed;
        private float _diagnosticAt;
        private int _sentFrames, _receivedFrames, _createdReplicas;
        private Vector3 _remote;
        private float _remoteYaw=float.NaN;
        private int _remoteItem, _cursor;
        private float _scanAt, _sendAt, _hurtAt, _nextAction, _damageAt;
        private GameObject _target;
        private sealed class HostZombie { internal ZombieAIController AI; internal uint Id; internal int AttackGeneration; internal string Prefab; internal bool Remote, Explosion, ChargeHit; internal float LastAlive, NextAttack, DeadAt=-1f, NextCorpse; internal ZombieFrame Last; internal Transform[] Bones; internal float KeepRemoteUntil; }
        private sealed class Replica
        {
            internal GameObject Root; internal Animator Animator; internal Vector3 Position; internal Quaternion Rotation; internal float Seen; internal string Prefab; internal Transform[] Bones; internal int[] BoneOrder; internal bool Dead;
            // Host frames by host time, oldest first (1.0.7): the copy moves between them at an even pace
            // instead of lurching toward each new one, and its animation follows the same timeline.
            internal readonly Snap[] Snaps=new Snap[8]; internal int SnapCount;
            internal float Interval=.05f, AnimAt=-1f, MismatchSince=-1f; internal bool ForcePlay=true;
        }
        private struct Snap { internal float T, Yaw, AnimationTime; internal Vector3 P; internal int Animation; internal uint Flags; }

        internal ZombieSync(bool host, Action<Packet> send, Action<string> report, HostCombatInventory inventory)
        {
            if(host && IsClientWorld) throw new InvalidOperationException("Client zombie isolation requires restart before hosting.");
            _host=host; _send=send; _report=report;
            Combat=new LanCombatSync(host,inventory,send);
            InstallGuard();
            Active=this;
            // Capture trusted local assets before the menu/scene that owns the
            // library is unloaded. Assets remain valid across world epochs.
            BuildPrefabCatalog();
            if(host) { _target=new GameObject("LAN remote zombie target"); Object.DontDestroyOnLoad(_target); }
        }

        internal void Tick(string scene,uint epoch,bool ready,Vector3 remotePosition,bool remoteReady,int remoteEquippedItemId,float remoteYaw=float.NaN,bool playerReady=true)
        {
            if(_disposed) return;
            if(_epoch!=epoch || _scene!=scene) ResetWorld(scene,epoch);
            _ready=ready && epoch!=0; _remoteReady=remoteReady && _ready; _playerReady=playerReady && _ready;
            _remote=remotePosition; _remoteItem=remoteEquippedItemId;_remoteYaw=remoteYaw;
            Combat.Tick(_playerReady && (!_host || _remoteReady));
            if(!_host && !IsClientWorld) return; // Failed/cancelled pairing must not alter a solo/menu world.
            if(_target!=null) _target.transform.position=_remote;
            BuildPrefabCatalog();
            float now=Time.unscaledTime;
            if (now >= _diagnosticAt) {
                _diagnosticAt=now+15f;
                _report("sync " + (_host?"host":"client") + " epoch=" + _epoch + " ready=" + _ready +
                    " playerReady=" + _playerReady + " remoteReady=" + _remoteReady + " prefabs=" + _prefabs.Count +
                    " catalog=" + _catalog.Count + " sent=" + _sentFrames + " received=" + _receivedFrames +
                    " created=" + _createdReplicas + " replicas=" + _replicas.Count + " pending=" + _pendingCount);
            }
            if(now>=_scanAt) {
                _scanAt=now+.5f;
                foreach(var ai in Object.FindObjectsOfType<ZombieAIController>()) {
                    if(!_host) { ai.StopAllCoroutines(); ai.gameObject.SetActive(false); continue; }
                    if(!_ready || _catalog.Count>=LanProtocol.MaxZombieIds || _hostIds.ContainsKey(ai.GetInstanceID())) continue;
                    ZombieAIController prefab;
                    if(string.IsNullOrEmpty(ai.ID) || !_prefabs.TryGetValue(ai.ID,out prefab)) continue;
                    var h=new HostZombie {AI=ai,Id=(uint)_catalog.Count+1,Prefab=ai.ID,LastAlive=now};
                    _catalog.Add(h); _hostIds.Add(ai.GetInstanceID(),h);
                }
            }
            if(!_host) {
                if (_ready) ApplyPending();
                var remove=new List<uint>();
                float hostNow=now-_clockOffset, smooth=1-Mathf.Exp(-Time.unscaledDeltaTime*20);
                foreach(var pair in _replicas) {
                    var r=pair.Value;
                    if(r.Root==null || now-r.Seen>12) { if(r.Root!=null) Object.Destroy(r.Root); remove.Add(pair.Key); continue; }
                    if(r.Dead || r.SnapCount==0) continue; // a corpse keeps the pose its last ragdoll frame gave it
                    float at=hostNow-Mathf.Clamp(r.Interval+_jitter*2+.03f,.08f,.6f);
                    Vector3 position; float yaw; Sample(r,at,out position,out yaw);
                    var t=r.Root.transform;
                    if((t.position-position).sqrMagnitude>25) t.SetPositionAndRotation(position,Quaternion.Euler(0,yaw,0)); // a jump: no glide
                    else { t.position=Vector3.Lerp(t.position,position,smooth); t.rotation=Quaternion.Slerp(t.rotation,Quaternion.Euler(0,yaw,0),smooth); }
                    // The newest frame the shown moment has reached sets the animation.
                    for(int i=r.SnapCount-1;i>=0;i--) if(r.Snaps[i].T<=at) { if(r.Snaps[i].T>r.AnimAt) { r.AnimAt=r.Snaps[i].T; ApplyAnimation(r,r.Snaps[i]); } break; }
                    if(r.ForcePlay && r.AnimAt<0) ApplyAnimation(r,r.Snaps[0]); // just created: pose it at once
                }
                foreach(uint id in remove) _replicas.Remove(id);
                return;
            }
            // World visuals do not require an accepted remote player pose. Combat
            // still does: an unplaced/stale client cannot redirect AI or cause damage.
            if(_ready && now>=_sendAt) { _sendAt=now+.05f; SendBatch(now); }
            if(!_ready || !_remoteReady) { ReleaseTargets(); return; }
            if(now>=_damageAt && _hurts.Count<64) {
                _damageAt=now+.1f;
                for(byte kind=1;kind<5 && _hurts.Count<64;kind++) if(_pendingDamage[kind]>0) {
                    var hurt=Message(PacketKind.ZombieHurt,++_hurtSequence);hurt.Action=kind;
                    hurt.Damage=Mathf.Min(1000,_pendingDamage[kind]);_pendingDamage[kind]-=hurt.Damage;_hurts.Enqueue(hurt);
                }
            }
            if(_hurts.Count>0 && now>=_hurtAt) { _hurtAt=now+.2f; _send(_hurts.Peek()); }
        }

        private void BuildPrefabCatalog()
        {
            var library=GlobalZombieLibrary.global;
            if(library==null || library.zombie==null) return;
            foreach(var prefab in library.zombie) {
                if(prefab==null || string.IsNullOrEmpty(prefab.ID) || System.Text.Encoding.UTF8.GetByteCount(prefab.ID)>64 || _prefabs.ContainsKey(prefab.ID)) continue;
                if(_prefabs.Count>=256) break;
                _prefabs.Add(prefab.ID,prefab);
            }
        }

        private void SendBatch(float now)
        {
            var batch=new List<ZombieFrame>();
            var relevant=new List<HostZombie>();
            foreach(var h in _catalog) if(h.AI!=null && h.AI.gameObject.activeInHierarchy || h.Last!=null && now-h.LastAlive<12) relevant.Add(h);
            relevant.Sort((a,b)=>Distance(a).CompareTo(Distance(b)));
            if(relevant.Count>LanProtocol.MaxZombieReplicas) relevant.RemoveRange(LanProtocol.MaxZombieReplicas,relevant.Count-LanProtocol.MaxZombieReplicas);
            int visited=0;
            while(visited++<relevant.Count && batch.Count<LanProtocol.MaxZombieBatch) {
                if(_cursor>=relevant.Count) _cursor=0;
                var h=relevant[_cursor++]; var ai=h.AI;
                if(ai!=null && ai.gameObject.activeInHierarchy) {
                    var pos=ai.transform.position; var anim=VisualAnimator(ai);
                    var z=new ZombieFrame {Id=h.Id,Prefab=h.Prefab,X=pos.x,Y=pos.y,Z=pos.z,Yaw=ai.transform.eulerAngles.y,
                        Health=ai.zombieHP==null?0:Mathf.Clamp(ai.zombieHP.currentHealth,0,99999),Flags=(byte)(ai.dead?1:0)};
                    if(anim!=null && anim.runtimeAnimatorController!=null) { var state=anim.GetCurrentAnimatorStateInfo(0); z.Animation=state.fullPathHash; z.AnimationTime=Mathf.Repeat(state.normalizedTime,1); z.AnimationFlags=BoolFlags(anim); }
                    h.Last=z; h.LastAlive=now; batch.Add(z);
                } else if(h.Last!=null && now-h.LastAlive<12) {
                    h.Last.Flags=(byte)(ai==null?3:2); h.Last.Health=0; batch.Add(h.Last);
                }
            }
            var packet=Message(PacketKind.ZombieState,++_sequence); packet.Zombies=batch.ToArray(); packet.HostTime=Time.unscaledTime; _send(packet);_sentFrames+=batch.Count;
            SendCorpse(relevant,now);
        }

        // One ragdoll pose per batch: often while a body is still falling, then rarely.
        private void SendCorpse(List<HostZombie> relevant,float now)
        {
            HostZombie pick=null;
            foreach(var h in relevant) {
                var ai=h.AI;
                if(ai==null || !ai.dead || !ai.gameObject.activeInHierarchy) continue;
                if(h.DeadAt<0) { h.DeadAt=now; h.NextCorpse=now; }
                if(now>=h.NextCorpse && (pick==null || h.NextCorpse<pick.NextCorpse)) pick=h;
            }
            if(pick==null) return;
            pick.NextCorpse=now+(now-pick.DeadAt<6f?.3f:4f);
            if(pick.Bones==null) {
                var detector=pick.AI.GetComponentInChildren<ZombieDamagDetector>(true);
                pick.Bones=detector==null || detector.rigidElements==null || detector.rigidElements.Length>LanProtocol.MaxCorpseBones ? new Transform[0] : detector.rigidElements;
            }
            var bones=new NetPose[pick.Bones.Length];
            for(int i=0;i<bones.Length;i++) {
                if(pick.Bones[i]==null) { bones=new NetPose[0]; break; }
                bones[i]=Pose(pick.Bones[i]);
            }
            var root=pick.AI.transform.position;
            var packet=Message(PacketKind.ZombieCorpse,++_corpseSequence);
            packet.Corpse=new CorpseFrame {Id=pick.Id,Prefab=pick.Prefab,X=root.x,Y=root.y,Z=root.z,Yaw=Mathf.Repeat(pick.AI.transform.eulerAngles.y,360f)%360f,Bones=bones};
            _send(packet);
        }
        private static NetPose Pose(Transform t)
        {
            var p=t.position; var q=t.rotation;
            return new NetPose {X=p.x,Y=p.y,Z=p.z,QX=q.x,QY=q.y,QZ=q.z,QW=q.w};
        }
        private float Distance(HostZombie h)
        {
            var position=h.AI!=null?h.AI.transform.position:new Vector3(h.Last.X,h.Last.Y,h.Last.Z);
            var player=LocalPlayer();
            float local=player==null?float.PositiveInfinity:(position-player.transform.position).sqrMagnitude;
            return _remoteReady?Mathf.Min(local,(position-_remote).sqrMagnitude):local;
        }

        private static Animator VisualAnimator(Component source)
        {
            foreach(var animator in source.GetComponentsInChildren<Animator>(true))
                if(animator.runtimeAnimatorController!=null) return animator;
            return null;
        }

        internal void Receive(Packet p)
        {
            if(_disposed || !_ready || p.WorldEpoch!=_epoch || p.Scene!=_scene) return;
            if(p.Kind==PacketKind.CombatProposal || p.Kind==PacketKind.CombatState) { Combat.Receive(p);return; }
            if(_host) {
                if(!_remoteReady) return;
                if(p.Kind==PacketKind.ZombieAction) ReceiveAction(p);
                else if(p.Kind==PacketKind.CombatReload) {
                    if(!Newer(p.Sequence,_lastAction)) return;
                    _lastAction=p.Sequence;Combat.Processed(p.Sequence);
                    if(p.EquippedItemId==_remoteItem) Combat.Reload(p);
                }
                else if(p.Kind==PacketKind.ZombieHurtAck && _hurts.Count>0 && _hurts.Peek().Sequence==p.Sequence) { _hurts.Dequeue(); _hurtAt=0; }
                return;
            }
            if(p.Kind==PacketKind.ZombieState) {
                BuildPrefabCatalog();
                _receivedFrames+=p.Zombies.Length;
                // The fastest batches set the offset; it creeps up slowly if the path gets slower,
                // and follows at once after a host restart or a long stall.
                float sample=Time.unscaledTime-p.HostTime;
                if(!_haveClock || sample<_clockOffset || sample-_clockOffset>1.5f) { _clockOffset=sample;_haveClock=true; }
                else _clockOffset+=(sample-_clockOffset)*.01f;
                _jitter+=(Mathf.Clamp(sample-_clockOffset,0,.5f)-_jitter)*.05f;
                foreach(var z in p.Zombies) QueueFrame(z,p.Sequence,p.HostTime);
            } else if(p.Kind==PacketKind.ZombieCorpse) {
                ApplyCorpse(p.Corpse,p.Sequence);
            } else if(p.Kind==PacketKind.ZombieHurt) {
                if(!_playerReady) return;
                if(p.Sequence==_lastHurt) { _send(Message(PacketKind.ZombieHurtAck,p.Sequence)); return; }
                if(p.Sequence!=_lastHurt+1) return; // Host sends one outstanding result, in order, until acknowledged.
                var player=LocalPlayer(); var health=player==null?null:player.zombieFighterIndicatorsBar;
                if(health==null) return;
                health.CauseDamage(p.Damage,false,false,(DamageType)p.Action);
                _lastHurt=p.Sequence; _send(Message(PacketKind.ZombieHurtAck,p.Sequence));
            }
        }

        private void QueueFrame(ZombieFrame frame, uint sequence, float hostTime)
        {
            uint id=frame.Id;
            if(id==0 || id>LanProtocol.MaxZombieIds || (_seen[id]!=0 && !Newer(sequence,_seen[id])) ||
                (_pendingFrames[id]!=null && !Newer(sequence,_pendingSequences[id]))) return;
            if(frame.Flags!=0) {
                if(_pendingFrames[id]!=null) { _pendingFrames[id]=null;_pendingCount--; }
                Apply(frame,sequence,hostTime); return;
            }
            // A replica takes every frame into its timeline; only frames that would create one wait here.
            if(_pendingFrames[id]==null && _replicas.ContainsKey(id)) { Apply(frame,sequence,hostTime); return; }
            if(_pendingFrames[id]==null) {
                if(_pendingCount>=LanProtocol.MaxZombieReplicas) return;
                _pendingCount++;
            }
            _pendingFrames[id]=frame;_pendingSequences[id]=sequence;_pendingTimes[id]=hostTime;
        }
        private void ApplyPending()
        {
            var budget=Stopwatch.StartNew();int created=0;
            for(int visited=0;visited<LanProtocol.MaxZombieIds && _pendingCount>0 && budget.Elapsed.TotalMilliseconds<3;visited++) {
                if(_applyCursor>LanProtocol.MaxZombieIds) _applyCursor=1;
                uint id=(uint)_applyCursor++;var frame=_pendingFrames[id];
                if(frame==null) continue;
                if(!_replicas.ContainsKey(id) && created++>=2) break;
                _pendingFrames[id]=null;_pendingCount--;Apply(frame,_pendingSequences[id],_pendingTimes[id]);
            }
        }

        private void Apply(ZombieFrame z,uint sequence,float hostTime)
        {
            if(z.Id==0 || z.Id>LanProtocol.MaxZombieIds || (_seen[z.Id]!=0 && !Newer(sequence,_seen[z.Id]))) return;
            _seen[z.Id]=sequence;
            Replica r;
            if(z.Flags!=0) {
                if((z.Flags&1)!=0) _dead[z.Id]=true;
                if(!_replicas.TryGetValue(z.Id,out r)) return;
                // Dead and still present at the host: keep the body (its pose comes
                // with ZombieCorpse). Deactivated or destroyed there: remove it here.
                if(z.Flags==1) { MarkDead(r); r.Seen=Time.unscaledTime; return; }
                Object.Destroy(r.Root); _replicas.Remove(z.Id);
                return;
            }
            if(_dead[z.Id]) return;
            ZombieAIController prefab;
            if(!_prefabs.TryGetValue(z.Prefab,out prefab) || prefab==null) {
                if(_unknownPrefabs.Count<256 && _unknownPrefabs.Add(z.Prefab))
                    _report("Неизвестная локальная модель зомби; zombieId=" + z.Id + "; каталог=" + _prefabs.Count);
                return;
            }
            if(_failedPrefabs.Contains(z.Prefab)) return;
            if(!_replicas.TryGetValue(z.Id,out r)) {
                if(_replicas.Count>=LanProtocol.MaxZombieReplicas) return;
                try { r=CreateVisual(prefab); }
                catch(Exception ex) { _failedPrefabs.Add(z.Prefab);_report("Не удалось создать модель зомби " + z.Prefab + ": " + ex.GetType().Name + ": " + ex.Message);return; }
                r.Prefab=z.Prefab; _replicas.Add(z.Id,r);
                r.Root.transform.position=new Vector3(z.X,z.Y,z.Z);
                r.Root.transform.rotation=Quaternion.Euler(0,z.Yaw,0);
                _createdReplicas++;
            }
            if(r.Prefab!=z.Prefab || r.Dead) return;
            r.Position=new Vector3(z.X,z.Y,z.Z); r.Rotation=Quaternion.Euler(0,z.Yaw,0); r.Seen=Time.unscaledTime;
            r.Root.SetActive(true);
            if(r.SnapCount!=0) {
                float gap=hostTime-r.Snaps[r.SnapCount-1].T;
                if(gap<=0) return; // same or older host moment
                if(gap<1) r.Interval+=(gap-r.Interval)*.2f;
                else r.SnapCount=0; // after a long gap the old frames are history
            }
            if(r.SnapCount==r.Snaps.Length) { Array.Copy(r.Snaps,1,r.Snaps,0,r.Snaps.Length-1); r.SnapCount--; }
            r.Snaps[r.SnapCount++]=new Snap {T=hostTime,P=r.Position,Yaw=z.Yaw,Animation=z.Animation,AnimationTime=z.AnimationTime,Flags=z.AnimationFlags};
        }
        // Position and facing at host time `at`: between the two frames around it, a short
        // extrapolation past the newest one, or the oldest one before the timeline starts.
        private static void Sample(Replica r,float at,out Vector3 position,out float yaw)
        {
            var first=r.Snaps[0]; var last=r.Snaps[r.SnapCount-1];
            if(at<=first.T) { position=first.P;yaw=first.Yaw;return; }
            if(at>=last.T) {
                position=last.P;yaw=last.Yaw;
                if(r.SnapCount<2) return;
                var prev=r.Snaps[r.SnapCount-2]; float span=last.T-prev.T;
                if(span<.01f || span>.5f) return;
                var velocity=(last.P-prev.P)/span;
                if(velocity.sqrMagnitude<400) position+=velocity*Mathf.Min(at-last.T,.15f);
                return;
            }
            int i=r.SnapCount-2; while(i>0 && r.Snaps[i].T>at) i--;
            var a=r.Snaps[i]; var b=r.Snaps[i+1]; float f=Mathf.Clamp01((at-a.T)/Mathf.Max(.001f,b.T-a.T));
            position=Vector3.Lerp(a.P,b.P,f); yaw=Mathf.LerpAngle(a.Yaw,b.Yaw,f);
        }
        // 1.0.1: the host's bool parameters drive the copy's own state machine. 1.0.7: a different
        // state is forced only when it lasts (a missed transition), not while both are mid-change,
        // where forcing it snapped the copy back and forth.
        private static void ApplyAnimation(Replica r,Snap s)
        {
            if(r.Animator==null || !r.Animator.isInitialized) return;
            ApplyBoolFlags(r.Animator,s.Flags);
            if(s.Animation==0 || !r.Animator.HasState(0,s.Animation) || InState(r.Animator,s.Animation)) { r.MismatchSince=-1f;r.ForcePlay=false;return; }
            float now=Time.unscaledTime;
            if(!r.ForcePlay) {
                if(r.MismatchSince<0) { r.MismatchSince=now;return; }
                if(now-r.MismatchSince<.4f) return;
            }
            r.Animator.Play(s.Animation,0,s.AnimationTime); r.MismatchSince=-1f;r.ForcePlay=false;
        }
        private static bool InState(Animator animator,int state)
        {
            return animator.GetCurrentAnimatorStateInfo(0).fullPathHash==state ||
                animator.IsInTransition(0) && animator.GetNextAnimatorStateInfo(0).fullPathHash==state;
        }
        // Bool parameters (name hashes) of each zombie controller, in controller order; at most 32.
        private static readonly Dictionary<RuntimeAnimatorController,int[]> _boolParameters=new Dictionary<RuntimeAnimatorController,int[]>();
        private static int[] BoolParameters(Animator animator)
        {
            int[] hashes; var controller=animator.runtimeAnimatorController;
            if(controller==null || !animator.isInitialized) return new int[0];
            if(_boolParameters.TryGetValue(controller,out hashes)) return hashes;
            var list=new List<int>();
            foreach(var parameter in animator.parameters) if(parameter.type==AnimatorControllerParameterType.Bool && list.Count<32) list.Add(parameter.nameHash);
            hashes=list.ToArray(); if(_boolParameters.Count<64) _boolParameters[controller]=hashes;
            return hashes;
        }
        private static uint BoolFlags(Animator animator)
        {
            var hashes=BoolParameters(animator); uint flags=0;
            for(int i=0;i<hashes.Length;i++) if(animator.GetBool(hashes[i])) flags|=1u<<i;
            return flags;
        }
        private static void ApplyBoolFlags(Animator animator,uint flags)
        {
            var hashes=BoolParameters(animator);
            for(int i=0;i<hashes.Length;i++) animator.SetBool(hashes[i],(flags&(1u<<i))!=0);
        }

        // Client: a host ragdoll pose. Creates the body if this client never saw the
        // zombie alive (joined later, or it died far away).
        private void ApplyCorpse(CorpseFrame c,uint sequence)
        {
            if(!_ready || c==null || c.Id==0 || c.Id>LanProtocol.MaxZombieIds || (_corpseSeen[c.Id]!=0 && !Newer(sequence,_corpseSeen[c.Id]))) return;
            _corpseSeen[c.Id]=sequence; _dead[c.Id]=true;
            Replica r;
            if(!_replicas.TryGetValue(c.Id,out r)) {
                ZombieAIController prefab;
                if(_replicas.Count>=LanProtocol.MaxZombieReplicas || _failedPrefabs.Contains(c.Prefab) || !_prefabs.TryGetValue(c.Prefab,out prefab) || prefab==null) return;
                try { r=CreateVisual(prefab); }
                catch(Exception ex) { _failedPrefabs.Add(c.Prefab);_report("Не удалось создать модель зомби " + c.Prefab + ": " + ex.GetType().Name + ": " + ex.Message);return; }
                r.Prefab=c.Prefab; _replicas.Add(c.Id,r); _createdReplicas++;
            }
            if(r.Prefab!=c.Prefab) return;
            MarkDead(r);
            r.Position=new Vector3(c.X,c.Y,c.Z); r.Rotation=Quaternion.Euler(0,c.Yaw,0); r.Seen=Time.unscaledTime;
            r.Root.transform.SetPositionAndRotation(r.Position,r.Rotation);
            r.Root.SetActive(true);
            if(c.Bones.Length!=r.Bones.Length) return;
            foreach(var bone in c.Bones)
                if((new Vector3(bone.X,bone.Y,bone.Z)-r.Position).sqrMagnitude>100f) return; // a body is not 10 m long
            foreach(int i in r.BoneOrder) {
                var b=c.Bones[i];
                if(r.Bones[i]!=null) r.Bones[i].SetPositionAndRotation(new Vector3(b.X,b.Y,b.Z),new Quaternion(b.QX,b.QY,b.QZ,b.QW));
            }
        }
        private static void MarkDead(Replica r)
        {
            if(r.Dead) return;
            r.Dead=true;
            if(r.Animator!=null) r.Animator.enabled=false;
            foreach(var collider in r.Root.GetComponents<Collider>()) collider.enabled=false;
        }

        // Copy only transforms, meshes and a locally trusted animator. No prefab Awake, native AI,
        // native HP, loot, dismemberment, save registration or animation-event receivers are cloned.
        private static Replica CreateVisual(ZombieAIController prefab)
        {
            var root=new GameObject("LAN zombie visual"); root.SetActive(false);
            try {
            var map=new Dictionary<Transform,Transform>();
            CopyHierarchy(prefab.transform,root.transform,map,0);
            foreach(var source in prefab.GetComponentsInChildren<SkinnedMeshRenderer>(true)) {
                Transform t; if(!map.TryGetValue(source.transform,out t)) continue;
                var dest=t.gameObject.AddComponent<SkinnedMeshRenderer>(); dest.sharedMesh=source.sharedMesh; dest.sharedMaterials=source.sharedMaterials;
                var bones=source.bones; var copied=new Transform[bones.Length];
                for(int i=0;i<bones.Length;i++) if(bones[i]!=null) map.TryGetValue(bones[i],out copied[i]);
                dest.bones=copied; Transform bone;
                if(source.rootBone!=null && map.TryGetValue(source.rootBone,out bone)) dest.rootBone=bone;
                dest.localBounds=source.localBounds; dest.enabled=source.enabled; dest.updateWhenOffscreen=true;
            }
            // The prefab's own Start() picks a random material; do the same for the copy (1.0.1).
            foreach(var random in prefab.GetComponentsInChildren<RandomMaterial>(true)) {
                Transform t; if(random.targetRenderer==null || random.materials==null || random.materials.Length==0 || !map.TryGetValue(random.targetRenderer.transform,out t)) continue;
                var copy=t.GetComponent<Renderer>(); if(copy!=null) copy.sharedMaterial=random.materials[UnityEngine.Random.Range(0,random.materials.Length)];
            }
            Animator animator=null; var sourceAnimator=VisualAnimator(prefab);
            Transform animatorTransform;
            if(sourceAnimator!=null && map.TryGetValue(sourceAnimator.transform,out animatorTransform)) {
                animator=animatorTransform.gameObject.AddComponent<Animator>(); animator.avatar=sourceAnimator.avatar;
                animator.runtimeAnimatorController=sourceAnimator.runtimeAnimatorController; animator.applyRootMotion=false;
                animator.cullingMode=AnimatorCullingMode.AlwaysAnimate;
            }
            // The ragdoll bones of this prefab, parents first, for corpse poses.
            var ragdoll=new List<Transform>(); var depths=new List<int>();
            var detector=prefab.GetComponentInChildren<ZombieDamagDetector>(true);
            if(detector!=null && detector.rigidElements!=null && detector.rigidElements.Length<=LanProtocol.MaxCorpseBones)
                foreach(var element in detector.rigidElements) {
                    Transform copy;
                    if(element==null || !map.TryGetValue(element,out copy)) { ragdoll.Clear(); depths.Clear(); break; }
                    ragdoll.Add(copy); int depth=0; for(var node=copy;node!=null && node!=root.transform;node=node.parent) depth++; depths.Add(depth);
                }
            var order=new int[ragdoll.Count]; for(int i=0;i<order.Length;i++) order[i]=i;
            Array.Sort(order,(a,b)=>depths[a].CompareTo(depths[b]));
            // A passive capsule provides body collision without native AI/damage scripts.
            var controller=prefab.GetComponent<CharacterController>();
            if(controller!=null) {
                var capsule=root.AddComponent<CapsuleCollider>();capsule.radius=Mathf.Clamp(controller.radius,.1f,1);
                capsule.height=Mathf.Clamp(controller.height,capsule.radius*2,3);capsule.center=controller.center;
                root.layer=2;
            }
            return new Replica {Root=root,Animator=animator,Bones=ragdoll.ToArray(),BoneOrder=order};
            } catch { Object.Destroy(root);throw; }
        }
        private static void CopyHierarchy(Transform source,Transform target,Dictionary<Transform,Transform> map,int depth)
        {
            if(depth>32 || map.Count>=512) return;
            map.Add(source,target); target.localPosition=source.localPosition; target.localRotation=source.localRotation; target.localScale=source.localScale;
            var filter=source.GetComponent<MeshFilter>(); var renderer=source.GetComponent<MeshRenderer>();
            if(filter!=null && renderer!=null) { target.gameObject.AddComponent<MeshFilter>().sharedMesh=filter.sharedMesh; var copy=target.gameObject.AddComponent<MeshRenderer>(); copy.sharedMaterials=renderer.sharedMaterials; copy.enabled=renderer.enabled; }
            for(int i=0;i<source.childCount && depth<32 && map.Count<512;i++) { var child=source.GetChild(i); var obj=new GameObject(child.name); obj.transform.SetParent(target,false); CopyHierarchy(child,obj.transform,map,depth+1); obj.SetActive(child.gameObject.activeSelf && NativeVisible(child)); }
        }
        // What the prefab's own Start() would hide (1.0.1): decorations of a season other than the
        // current one (SeasonalEventObject) and accessories that lose their roll (RandomActivator).
        private static bool NativeVisible(Transform source)
        {
            var seasonal=source.GetComponent<SeasonalEventObject>();
            if(seasonal!=null && !SeasonActive((int)seasonal.Event)) return false;
            var random=source.GetComponent<RandomActivator>();
            return random==null || UnityEngine.Random.Range(0,100)<random.activationChanceMAX;
        }
        private static bool SeasonActive(int season)
        {
            switch(season) {
                case 0: return SeasonalEvents.IsCurrentlyNewYear();
                case 1: return SeasonalEvents.IsCurrentlyHalloween();
                case 2: return SeasonalEvents.IsCurrentlyAprilFoolsDay();
                default: return true;
            }
        }

        private void ReceiveAction(Packet p)
        {
            if(!Newer(p.Sequence,_lastAction)) return;
            _lastAction=p.Sequence;Combat.Processed(p.Sequence);
            float now=Time.unscaledTime;
            if(now<_nextAction-(float)HostCombatInventory.Jitter || p.EquippedItemId!=_remoteItem) return;
            var origin=new Vector3(p.X,p.Y,p.Z); var aim=new Vector3(p.AimX,p.AimY,p.AimZ);
            if(Vector3.Distance(origin,_remote+Vector3.up*1.5f)>1.75f || Mathf.Abs(aim.sqrMagnitude-1)>.01f) return;
            if(float.IsNaN(_remoteYaw) || float.IsInfinity(_remoteYaw)) return;
            var flat=new Vector3(aim.x,0,aim.z);
            if(flat.sqrMagnitude>.01f && Vector3.Angle(flat,Quaternion.Euler(0,_remoteYaw,0)*Vector3.forward)>95) return;
            if(Physics.Linecast(_remote+Vector3.up*1.5f,origin,~0,QueryTriggerInteraction.Ignore)) return;
            var db=ItemsDataBase.Global; var items=db==null?null:db.itemPrefab;
            if(items==null || p.EquippedItemId<0 || p.EquippedItemId>=items.Length || items[p.EquippedItemId]==null) return;
            var weapon=items[p.EquippedItemId].GetComponent<WeaponData>();
            var player=LocalPlayer(); var guns=player==null || player.zombieFighterFireArmWeapon==null?null:player.zombieFighterFireArmWeapon.gunList;
            if(weapon==null || guns==null) return;
            Gun gun=null; foreach(var candidate in guns) if(candidate!=null && candidate.ID==weapon.ID) { gun=candidate; break; }
            if(gun==null) return;
            float damage,range,interval; BulletScript bullet=null; int mask;
            if(p.Action==0) {
                if(gun.weaponType!=0 || gun.bulletPrefab==null) return;
                bullet=gun.bulletPrefab.GetComponent<BulletScript>(); if(bullet==null) return;
                damage=Mathf.Clamp(bullet.bulletDamage,0,200); range=100; mask=bullet.targetRaycastMask.value;
                interval=Mathf.Max(.05f,gun.currentBetweenShotsTime);
            } else {
                if(gun.weaponType!=2 || gun.Hands) return;
                damage=Mathf.Clamp(Mathf.Min(weapon.meeleDamage,gun.meleeAttackStrength),0,100);
                range=Mathf.Clamp(gun.meleeAttacRange,0,3); interval=Mathf.Max(.5f,gun.meleeStrikeTimeForAttackEnd); mask=gun.targetRaycastMask.value;
            }
            if(damage<=0) return;
            if(!Combat.Spend(p)) return;
            _nextAction=Mathf.Max(_nextAction,now)+interval; // jitter-tolerant average rate (1.0.1)
            // 1.0.8: zombies hear the guest's shot as the game's own: the gun's hearing radius, cut
            // by the silencer on the guest's weapon (the guest reports the share, at most the full radius).
            if(p.Action==0) Gun.AttractByNoise(origin,Mathf.Clamp(gun.shotHearingRadius,0,500)*p.Noise/100f);
            // 1.0.7: a firearm round is the host gun's own native bullet from the guest's eye, so hits,
            // head and limb damage, armour, blood and deaths are the game's. Arrows stay a ray here:
            // a native arrow would leave a new pickup in the host world.
            if(p.Action==0 && !bullet.arrow) { FireNative(gun,origin,aim); return; }
            // The native layer mask: with every layer the zombie's own body capsule (CharacterController)
            // was nearer than its limb hitboxes, and the ray dealt no damage.
            RaycastHit hit;
            if(!Physics.Raycast(origin,aim,out hit,range,mask) || hit.collider==null) return;
            var zombie=hit.collider.GetComponentInParent<ZombieAIController>(); HostZombie h;
            if(zombie==null || zombie.dead || zombie.zombieHP==null || !_hostIds.TryGetValue(zombie.GetInstanceID(),out h)) return;
            var limb=hit.collider.GetComponent<LimbDetector>();
            if(limb==null || limb.deadVersionZombie || limb.zombieHP!=zombie.zombieHP) return; // Shields/armor props cannot be treated as exposed flesh.
            if(p.Action==0 && limb.armored>bullet.armorPenetration) return;
            zombie.zombieHP.CauseDamage(limb.limbID==0 ? damage*2 : damage); // a head hit counts double, as natively
        }
        private static void FireNative(Gun gun,Vector3 origin,Vector3 aim)
        {
            var look=Quaternion.LookRotation(aim); var right=look*Vector3.right; var up=look*Vector3.up;
            float spread=Mathf.Clamp(gun.spreadOfFractions,0,.5f), speed=Mathf.Clamp(gun.bulletSpeed,1,2000);
            for(int i=Mathf.Clamp(gun.ProjectilesInShot,1,16);i>0;i--) {
                var circle=UnityEngine.Random.insideUnitCircle*spread;
                var direction=(aim+right*circle.x+up*circle.y).normalized;
                var round=Object.Instantiate(gun.bulletPrefab,origin,Quaternion.LookRotation(direction));
                round.AddRelativeForce(Vector3.forward*speed,ForceMode.VelocityChange);
                var script=round.GetComponent<BulletScript>(); if(script!=null) script.MakeInvisible();
            }
        }

        private void CaptureAction(Gun gun,byte action)
        {
            if(_host || !_playerReady || gun==null || LocalPlayer()==null || LocalPlayer().GetSelectedGun()!=gun) return;
            int item=RemoteEquipment.CaptureLocalItemId(); if(item<0) return;
            var rays=LocalPlayer().zombieFighterRays; if(rays==null || rays.cameraPoint==null) return;
            var origin=rays.cameraPoint.position; var aim=rays.cameraPoint.forward;
            var p=Message(PacketKind.ZombieAction,++_actionSequence); p.Action=action;p.EquippedItemId=item;
            var silencer=gun.GetInstalledSilencer(); float loudness=silencer==null?1f:silencer.Value;
            p.Noise=(byte)Mathf.RoundToInt(float.IsNaN(loudness)?100f:Mathf.Clamp01(loudness)*100f);
            // 1.0.7: on a train car, in that car's own space (as the player states are), so a moving
            // train does not shift the shot on the host.
            var car=LocalPlayer().OnTrainCar; var train=GlobalManager.global.controlledTrain;
            if(car!=null && train!=null && car.transform.IsChildOf(train.transform)) {
                int index=car.GetCarIndex();
                var local=car.transform.InverseTransformPoint(origin);
                if(index>=0 && index<LanProtocol.MaxCars && Mathf.Abs(local.x)<=100 && Mathf.Abs(local.y)<=100 && Mathf.Abs(local.z)<=100) {
                    p.CarIndex=index; origin=local; aim=car.transform.InverseTransformDirection(aim);
                }
            }
            p.X=origin.x;p.Y=origin.y;p.Z=origin.z;p.AimX=aim.x;p.AimY=aim.y;p.AimZ=aim.z;Combat.Submit(p);
        }

        private void CaptureReload(Gun gun)
        {
            if(_host || !_playerReady || gun==null || LocalPlayer()==null || LocalPlayer().GetSelectedGun()!=gun) return;
            int item=RemoteEquipment.CaptureLocalItemId();if(item<0)return;
            var p=Message(PacketKind.CombatReload,++_actionSequence);p.EquippedItemId=item;Combat.Submit(p);
        }

        private static ZombieFighterController LocalPlayer() { return GlobalManager.global==null?null:GlobalManager.global.controlledChar; }
        private Packet Message(PacketKind kind,uint seq) { return new Packet {Kind=kind,WorldEpoch=_epoch,Scene=_scene,Sequence=seq}; }
        private static bool Newer(uint a,uint b) { return a!=0 && unchecked((int)(a-b))>0; }
        private void Hurt(float damage,byte kind=1)
        {
            if(!_ready || !_remoteReady || _hurts.Count>=64 || damage<=0 || float.IsNaN(damage) || float.IsInfinity(damage)) return;
            if(kind<1 || kind>4) return;
            _pendingDamage[kind]=Mathf.Min(3000,_pendingDamage[kind]+Mathf.Clamp(damage,0,1000));
        }

        // Explicit remote branch: never replace GlobalManager.controlledChar and never construct a
        // pretend player controller that native inventory/buff scripts could dereference.
        private const float KeepRemoteSeconds=3f;
        private bool RemoteUpdate(ZombieAIController ai)
        {
            HostZombie h;
            if(!_host || !_ready || !_remoteReady || ai==null || ai.dead || !_hostIds.TryGetValue(ai.GetInstanceID(),out h)) return false;
            var local=LocalPlayer(); if(local==null) return false;
            float distance=Vector3.Distance(ai.transform.position,_remote);
            bool eligible=(ai.melee || ai.cannon!=null && ai.cannon.projectile!=null || ai.RunToExplode || ai.flamethrower!=null) && !ai.zombieNurse;
            bool busy=ai.Staggered || ai.attackRayActivatorHunterAnimation || ai.doingFireAnimation || ai.skillChargeAttack!=null && (int)ai.skillChargeAttack.CurrentPhase!=0 || ai.flamethrower!=null && ai.flamethrower.flamethrower!=null && ai.flamethrower.flamethrower.Firing;
            bool sees=distance<Mathf.Min(50,Mathf.Max(2,ai.sightRadius)) && distance<Vector3.Distance(ai.transform.position,local.transform.position) && ClearLine(ai,_remote);
            // 1.0.2: a guest once seen stays the target for a few seconds. A single blocked ray (a bush
            // zombie in foliage) used to hand it back to the native AI, which hid it again, and the next
            // frame woke it for the guest: it hid and rose over and over while still attacking.
            if(eligible && sees) h.KeepRemoteUntil=Time.time+KeepRemoteSeconds;
            bool keep=h.Remote && Time.time<h.KeepRemoteUntil && distance<Mathf.Min(60,Mathf.Max(3,ai.sightRadius*1.25f));
            bool choose=eligible && (h.Remote && busy || sees || keep);
            if(!choose) { if(h.Remote) ReleaseTarget(h); return false; }
            h.Remote=true;ai.target=_target.transform;ai.DistanceToPlayer=distance;ai.UpdateDistanceToTarget();
            if(!ai.Staggered && (ai.navMeshAgent==null || ai.navMeshAgent.velocity.sqrMagnitude<.1f)) {
                var facing=_remote-ai.transform.position;facing.y=0;
                if(facing.sqrMagnitude>.001f) ai.transform.rotation=Quaternion.Slerp(ai.transform.rotation,Quaternion.LookRotation(facing),Mathf.Clamp01(Time.deltaTime*10));
            }
            ai.playerIsInSight=true;
            if(ai.sleeping) { ai.SetSleeping(false); return true; }
            if(ai.StaggeredTimer>0) { ai.StaggeredTimer-=Time.deltaTime;if(ai.StaggeredTimer<=0) ai.SetStaggered(false); }
            var charge=ai.skillChargeAttack;
            if(charge!=null) {
                var area=charge.repulsiveArea;
                if(area==null || !area.gameObject.activeInHierarchy) h.ChargeHit=false;
                else if(!h.ChargeHit && OverlapsRemote(area.gameObject) && ClearLine(ai,_remote)) { h.ChargeHit=true;Hurt(area.Damage);area.HitPlayer=true; }
                if((int)charge.CurrentPhase!=0) return true;
            }
            if(ai.WakesUp || ai.Staggered || (ai.zombieDamagDetector!=null && ai.zombieDamagDetector.stunAfterHittingCounter)) return true;
            var tongue=ai.skillFrogTongue;
            if(tongue!=null && tongue.cooldown!=null && tongue.cooldown.IsReady() && tongue.frogTongue!=null && distance<Mathf.Clamp(tongue.frogTongue.MaxRange,0,30) && ClearLine(ai,_remote)) { tongue.Fire();return true; }
            var jump=ai.skillJump;
            if(jump!=null && jump.cooldown!=null && jump.cooldown.IsReady() && distance>=jump.RangeMin && distance<=jump.RangeMax && Vector3.Angle(ai.transform.forward,_remote-ai.transform.position)<20 && ClearLine(ai,_remote)) jump.Jump();
            if(charge!=null && charge.UltaCooldownTimer<=0 && distance<Mathf.Clamp(ai.ChargeAttackRange,0,50) && Vector3.Angle(ai.transform.forward,_remote-ai.transform.position)<ai.ChargeAttackAngle && ClearLine(ai,_remote)) { charge.Charge(_target.transform);return true; }
            var flame=ai.flamethrower;
            if(flame!=null && flame.cooldown!=null && flame.cooldown.IsReady() && distance<=Mathf.Clamp(ai.fireRange,0,30) && distance>=ai.fireRangeMin && ClearLine(ai,_remote)) {
                int hand=ai.GetFireFromHandIndex();
                if(hand>=0 && ai.FirePosition!=null && hand<ai.FirePosition.Length && flame.animations!=null && hand<flame.animations.Length && flame.flamethrower!=null) {
                    flame.flamethrower.transform.SetParent(ai.FirePosition[hand],false);flame.flamethrower.transform.localPosition=Vector3.zero;flame.Fire();return true;
                }
            }
            if(ai.RunToExplode && ai.explodingBlob!=null && !ai.explodingBlob.Exploded && !h.Explosion && distance<=Mathf.Clamp(ai.ExplodeOnDistance,0,10)) {
                h.Explosion=true;ai.BeginStomachExplosion();return true;
            }
            if(ai.cannon!=null && ai.cannon.projectile!=null && ai.FireAnimations!=null && ai.FireAnimations.Length>0 && distance<=Mathf.Clamp(ai.fireRange,0,100) && distance>=ai.fireRangeMin && ClearLine(ai,_remote)) {
                ai.SetNavMeshStop(true,true);
                if(!ai.doingFireAnimation && ai.cannon.IsReadyToFire()) { ai.doingFireAnimation=true;ai.Fire(ai.FireAnimations[0]); }
                return true;
            }
            if(ai.attackRayActivatorHunterAnimation) {
                ai.attackTimer+=Time.deltaTime;
                float delay=ai.attackRayActivator==2?ai.attackHunterHitMomentTime2:ai.OverrideAttackAnimationMode && ai.OverrideAttackAnimation!=null?ai.OverrideAttackAnimation.delay:ai.attackHunterHitMomentTime;
                if(ai.attackRayActivator>0 && ai.attackTimer>=delay) {
                    if(InMelee(ai,distance)) Hurt(ai.GetMeleeDamage());
                    ai.attackRayActivator=ai.zombieBroker && ai.attackRayActivator==1?2:0;
                }
                if(ai.attackTimer>=Mathf.Max(.5f,ai.OverrideAttackAnimationMode && ai.OverrideAttackAnimation!=null?ai.OverrideAttackAnimation.duration:ai.durationOfHunterAttack)) {
                    ai.attackRayActivatorHunterAnimation=false;ai.attackTimer=0;ai.attackRayActivator=0;h.NextAttack=Time.time+.15f;
                    if(ai.zombieAnimation!=null) ai.zombieAnimation.AttackAnimationVariants();
                }
                return true;
            }
            ai.SetState("Chase"); ai.SetNavMeshStop(false,true);ai.SetNavMeshAgentSpeed(Mathf.Max(.1f,ai.chaseSpeed),false);ai.SetNavMeshDestination(_remote);
            if(ai.melee && InMelee(ai,distance) && Time.time>=h.NextAttack) {
                ai.SetNavMeshStop(true,true); ai.attackRayActivatorHunterAnimation=true;ai.attackRayActivator=1;ai.attackTimer=0;
                if(ai.zombieEffects!=null) ai.zombieEffects.ZombieAttackRoarSound();
            }
            return true;
        }
        private bool InMelee(ZombieAIController ai,float distance)
        {
            float range=ai.IsHaveHandForMelee()?ai.attackDistance:ai.attackDistanceTornOff;
            return distance<=Mathf.Clamp(range,0,4) && Vector3.Angle(ai.transform.forward,_remote-ai.transform.position)<Mathf.Clamp(ai.fieldOfAttackAngle*.5f,1,90) && ClearLine(ai,_remote);
        }
        private static bool ClearLine(ZombieAIController ai,Vector3 target)
        {
            var start=ai.transform.position+Vector3.up;var delta=target+Vector3.up-start;
            var hits=Physics.RaycastAll(start,delta.normalized,delta.magnitude,~0,QueryTriggerInteraction.Ignore);
            foreach(var hit in hits) if(hit.collider.GetComponentInParent<ZombieAIController>()!=ai && hit.collider.GetComponentInParent<ZombieFighterController>()==null) return false;
            return true;
        }
        private static bool BeforeProjectile(Projectile __instance)
        {
            var a=Active;if(a==null || !a._host || !a._ready || !a._remoteReady) return true;
            // Same host projectile trajectory and wall occlusion, with an analytic remote body.
            var start=__instance.transform.TransformPoint(new Vector3(0,0,__instance.RayOffsetZ));
            float length=Mathf.Clamp(__instance.Speed*Time.fixedDeltaTime,0,30);
            if(length<=0) return true;
            var direction=__instance.transform.forward; var center=a._remote+Vector3.up;
            float along=Mathf.Clamp(Vector3.Dot(center-start,direction),0,length);
            if(Vector3.Distance(start+direction*along,center)>.5f) return true;
            RaycastHit wall;
            if(Physics.Raycast(start,direction,out wall,along,~0,QueryTriggerInteraction.Ignore)) return true;
            a.Hurt(__instance.Damage);__instance.enabled=false;Object.Destroy(__instance.gameObject);return false;
        }
        private bool OverlapsRemote(GameObject area)
        {
            foreach(var collider in area.GetComponentsInChildren<Collider>())
                if(collider.enabled && collider.gameObject.activeInHierarchy && (collider.ClosestPoint(_remote+Vector3.up)-(_remote+Vector3.up)).sqrMagnitude<=.1225f) return true;
            return false;
        }
        private static void AfterFlame(Flame __instance)
        {
            var a=Active;if(a==null || !a._host || !a._ready || !a._remoteReady || !a.OverlapsRemote(__instance.gameObject)) return;
            var start=__instance.transform.position;var delta=a._remote+Vector3.up-start;
            if(!Physics.Raycast(start,delta.normalized,delta.magnitude,~0,QueryTriggerInteraction.Ignore)) a.Hurt(__instance.Damage*__instance.DamageFactorPlayer*Time.fixedDeltaTime,2);
        }
        private static void BeforeSmooth(SmoothDirection __instance)
        {
            var a=Active;if(a==null || !a._host || !a._remoteReady) return;
            var ai=__instance.GetComponentInParent<ZombieAIController>();HostZombie h;
            if(ai!=null && a._hostIds.TryGetValue(ai.GetInstanceID(),out h) && h.Remote) __instance.Target=a._target.transform;
        }
        private static bool BeforeAim(ZombieAIController __instance,ref Vector3 __result)
        {
            var a=Active;HostZombie h;
            if(a==null || !a._host || !a._remoteReady || !a._hostIds.TryGetValue(__instance.GetInstanceID(),out h) || !h.Remote) return true;
            __result=a._remote+Vector3.up;return false;
        }
        private static bool BeforeTongueHit(ItemStealer __instance)
        {
            var a=Active;if(a==null || !a._host || !a._ready || !a._remoteReady || __instance.HitSomething) return true;
            var start=__instance.transform.position;var direction=__instance.transform.forward;
            float along=Vector3.Dot(a._remote+Vector3.up-start,direction);
            if(along<0 || along>Mathf.Clamp(__instance.RayDistance,0,10) || Vector3.Distance(start+direction*along,a._remote+Vector3.up)>.5f) return true;
            if(Physics.Raycast(start,direction,along,~0,QueryTriggerInteraction.Ignore)) return true;
            a.Hurt(__instance.Damage);__instance.HitSomething=true;
            return false; // Damage only. Remote inventory theft deliberately awaits an inventory protocol.
        }
        private static void BeforeExplosion(ExplodingBlob __instance,out bool __state) { __state=__instance.Exploded; }
        private static void AfterExplosion(ExplodingBlob __instance,bool __state)
        {
            var a=Active;if(__state || a==null || !a._host || !a._remoteReady) return;
            var ai=__instance.GetComponentInParent<ZombieAIController>(); if(ai==null) return;
            if(__instance.Exploded && Vector3.Distance(__instance.transform.position,a._remote)<=Mathf.Clamp(__instance.Radius,0,30) && ClearLine(ai,a._remote)) a.Hurt(__instance.Damage,3);
        }
        private void ReleaseTarget(HostZombie h)
        {
            bool canceledExplosion=h.Explosion;h.AttackGeneration++;h.Explosion=false;
            if(h.AI!=null) {
                if(_target!=null && h.AI.target==_target.transform) h.AI.target=LocalPlayer()==null?null:LocalPlayer().transform;
                foreach(var direction in h.AI.GetComponentsInChildren<SmoothDirection>(true))
                    if(_target!=null && direction.Target==_target.transform) direction.Target=LocalPlayer()==null?null:LocalPlayer().transform;
                if(h.AI.skillChargeAttack!=null && (int)h.AI.skillChargeAttack.CurrentPhase!=0) h.AI.skillChargeAttack.StopCharge();
                if(h.AI.flamethrower!=null) {
                    h.AI.flamethrower.StopFire();
                    if(h.AI.zombieAnimation!=null && h.AI.flamethrower.animations!=null)
                        foreach(var animation in h.AI.flamethrower.animations)
                            if(animation!=null) h.AI.zombieAnimation.TripleAnimationOff(animation);
                }
                if(h.AI.skillFrogTongue!=null) h.AI.skillFrogTongue.StopFire();
                h.AI.doingFireAnimation=false;h.AI.WiggleOnDamage=true;
                if(canceledExplosion && h.AI.zombieAnimation!=null && h.AI.zombieAnimation.animator!=null)
                    h.AI.zombieAnimation.animator.SetBool("bellyExplosion",false);
                h.AI.attackRayActivatorHunterAnimation=false;h.AI.attackRayActivator=0;h.AI.attackTimer=0;h.AI.SetNavMeshStop(false,true);
            }
            h.Remote=false;
        }
        private void ReleaseTargets() { foreach(var h in _catalog) if(h.Remote) ReleaseTarget(h); }
        internal void Freeze() { _ready=false;_remoteReady=false;_playerReady=false;Combat.Freeze();ReleaseTargets();foreach(var r in _replicas.Values) if(r.Root!=null) r.Root.SetActive(false); }
        private void ResetWorld(string scene,uint epoch)
        {
            ReleaseTargets(); foreach(var r in _replicas.Values) if(r.Root!=null) Object.Destroy(r.Root);
            _replicas.Clear();_hostIds.Clear();_catalog.Clear();_failedPrefabs.Clear();_unknownPrefabs.Clear();_hurts.Clear();Array.Clear(_seen,0,_seen.Length);Array.Clear(_dead,0,_dead.Length);Array.Clear(_corpseSeen,0,_corpseSeen.Length);_corpseSequence=0;
            _sentFrames=0;_receivedFrames=0;_createdReplicas=0;_diagnosticAt=0;
            Array.Clear(_pendingFrames,0,_pendingFrames.Length);Array.Clear(_pendingSequences,0,_pendingSequences.Length);Array.Clear(_pendingDamage,0,_pendingDamage.Length);
            Array.Clear(_pendingTimes,0,_pendingTimes.Length);_haveClock=false;_clockOffset=0;_jitter=0;
            _pendingCount=0;_applyCursor=1;
            _scene=scene;_epoch=epoch;_cursor=0;_sequence=0;_lastAction=0;_actionSequence=0;_hurtSequence=0;_lastHurt=0;_scanAt=0;_sendAt=0;_nextAction=0;
            Combat.Rebind(scene,epoch);
        }
        public void Dispose() { if(_disposed)return;Freeze();ResetWorld(null,0);_disposed=true;if(_target!=null)Object.Destroy(_target);if(Active==this)Active=null; }

        private static void InstallGuard()
        {
            if(Guard!=null) return;
            var harmony=new Harmony("local.zompiercer.lan.zombies");
            try {
                Patch(harmony,typeof(ZombieAIController),"Update",nameof(AIUpdate));
                Patch(harmony,typeof(ZombieAIController),"FixedUpdate",nameof(AIFixed));
                foreach(var type in new[]{typeof(ZombieSpawn),typeof(ZombieDeadSpawn)}) Patch(harmony,type,"Activator",nameof(AllowNative));
                foreach(var method in new[]{"Awake","Start"}) Patch(harmony,typeof(ZombieAIController),method,nameof(ClientZombie));
                foreach(var type in new[]{typeof(ZombieHP),typeof(ZombieDamagDetector),typeof(ZombieTrainDetector)})
                    foreach(var method in new[]{"Update","CauseDamage","OnTriggerEnter","Dead"}) if(HasMethod(type,method)) Patch(harmony,type,method,nameof(AllowNative));
                harmony.Patch(AccessTools.Method(typeof(Gun),"Shot"),new HarmonyMethod(typeof(ZombieSync),nameof(BeforeShot)),new HarmonyMethod(typeof(ZombieSync),nameof(AfterShot)));
                harmony.Patch(AccessTools.Method(typeof(Gun),"MeleeStrike"),new HarmonyMethod(typeof(ZombieSync),nameof(BeforeMelee)),new HarmonyMethod(typeof(ZombieSync),nameof(AfterMelee)));
                harmony.Patch(AccessTools.Method(typeof(Gun),"ReloadingActivate"),new HarmonyMethod(typeof(ZombieSync),nameof(BeforeReload)));
                Patch(harmony,typeof(Gun),"RechargeSuitableRounds",nameof(BeforeRecharge));
                harmony.Patch(AccessTools.Method(typeof(Gun),"MagazineInserted"),prefix:new HarmonyMethod(typeof(ZombieSync),nameof(BeforeInserted)),
                    postfix:new HarmonyMethod(typeof(ZombieSync),nameof(AfterInserted)),finalizer:new HarmonyMethod(typeof(ZombieSync),nameof(InsertedDone)));
                harmony.Patch(AccessTools.Method(typeof(Inventory),"Extract",new[]{typeof(InventoryItem),typeof(int)}),new HarmonyMethod(typeof(ZombieSync),nameof(BeforeExtract)));
                Patch(harmony,typeof(Projectile),"FixedUpdate",nameof(BeforeProjectile));
                harmony.Patch(AccessTools.Method(typeof(Flame),"FixedUpdate"),null,new HarmonyMethod(typeof(ZombieSync),nameof(AfterFlame)));
                Patch(harmony,typeof(SmoothDirection),"Update",nameof(BeforeSmooth));
                Patch(harmony,typeof(ZombieAIController),"GetPlayerPositionAim",nameof(BeforeAim));
                Patch(harmony,typeof(ItemStealer),"FixedUpdate",nameof(BeforeTongueHit));
                harmony.Patch(AccessTools.Method(typeof(ExplodingBlob),"Explode"),new HarmonyMethod(typeof(ZombieSync),nameof(BeforeExplosion)),new HarmonyMethod(typeof(ZombieSync),nameof(AfterExplosion)));
                foreach(var type in new[]{typeof(ZombieAIController),typeof(SkillFrogTongue),typeof(SkillFlamethrower),typeof(SkillChargeAttack)})
                    foreach(var method in AccessTools.GetDeclaredMethods(type))
                        if(method.ReturnType==typeof(IEnumerator) && (method.Name=="FireIE" || method.Name=="ChargeIE" ||
                            method.Name=="DoEndHitIE" || method.Name=="ActivateRepulserIE" || method.Name=="BeginStomachExplosionIE"))
                            harmony.Patch(method,null,new HarmonyMethod(typeof(ZombieSync),nameof(OwnAttackRoutine)));
                Guard=harmony;
            } catch { harmony.UnpatchSelf();throw; }
        }
        // Optional native methods: a quiet lookup (AccessTools.Method logs a warning for each absent one).
        private static bool HasMethod(Type type,string name)
        {
            for(var t=type;t!=null;t=t.BaseType)
                foreach(var m in t.GetMethods(BindingFlags.Instance|BindingFlags.Static|BindingFlags.Public|BindingFlags.NonPublic|BindingFlags.DeclaredOnly)) if(m.Name==name) return true;
            return false;
        }
        private static void Patch(Harmony h,Type type,string method,string prefix) { h.Patch(AccessTools.Method(type,method),new HarmonyMethod(typeof(ZombieSync),prefix)); }
        private static bool AllowNative() { return !IsClientWorld; }
        private static bool ClientZombie(ZombieAIController __instance) { if(!IsClientWorld)return true;__instance.gameObject.SetActive(false);return false; }
        private static bool AIUpdate(ZombieAIController __instance) { if(IsClientWorld) { __instance.gameObject.SetActive(false);return false; } return Active==null || !Active.RemoteUpdate(__instance); }
        private static bool AIFixed(ZombieAIController __instance) { if(IsClientWorld)return false;HostZombie h;return Active==null || !Active._hostIds.TryGetValue(__instance.GetInstanceID(),out h) || !h.Remote; }
        private static void OwnAttackRoutine(Component __instance,ref IEnumerator __result)
        {
            var owner=Active;HostZombie zombie;
            var ai=__instance.GetComponentInParent<ZombieAIController>();
            if(owner!=null && owner._host && ai!=null && owner._hostIds.TryGetValue(ai.GetInstanceID(),out zombie) && zombie.Remote)
                __result=GuardAttack(__result,owner,zombie,zombie.AttackGeneration);
        }
        private static IEnumerator GuardAttack(IEnumerator routine,ZombieSync owner,HostZombie zombie,int generation)
        {
            try {
                while(!owner._disposed && owner._ready && owner._remoteReady && zombie.Remote && zombie.AttackGeneration==generation && routine.MoveNext()) {
                    var nested=routine.Current as IEnumerator;
                    yield return nested==null?routine.Current:GuardAttack(nested,owner,zombie,generation);
                }
            }
            finally { (routine as IDisposable)?.Dispose(); }
        }
        private static bool CanClientUse(Gun gun,bool reload=false) { return !IsClientWorld || Active!=null && !Active._host && Active._playerReady && Active.Combat.CanUse(gun,reload); }
        private static bool BeforeShot(Gun __instance,out int __state) { __state=__instance.magazine;return CanClientUse(__instance); }
        private static void AfterShot(Gun __instance,int __state) { if(Active!=null && __instance.magazine<__state) Active.CaptureAction(__instance,0); }
        private static bool BeforeMelee(Gun __instance,out bool __state) { __state=__instance.meleeAttack;return CanClientUse(__instance); }
        private static void AfterMelee(Gun __instance,bool __state) { if(Active!=null && !__state && __instance.meleeAttack) Active.CaptureAction(__instance,1); }
        private static bool BeforeReload(Gun __instance)
        {
            if(!IsClientWorld) return true;
            if(__instance.reloading || !CanClientUse(__instance,true)) return false;
            // 1.0.6: the host books the reload; the native one still runs for the first-person
            // animation, with its rounds transfer suppressed below (no reserve spent twice).
            Active.CaptureReload(__instance);
            return true;
        }
        // Guest: animation events must not move rounds; the magazine and reserve come from the host.
        private static bool _suppressExtract;
        private static bool BeforeRecharge() { return !IsClientWorld; }
        private static bool BeforeExtract() { return !_suppressExtract; }
        private static void BeforeInserted(Gun __instance,out int __state) { __state=__instance.magazine; _suppressExtract=IsClientWorld; }
        private static void AfterInserted(Gun __instance,int __state)
        {
            if(!IsClientWorld || !__instance.IncrementalReloading) return;
            __instance.magazine=__state;
            // One cartridge per event loops until the native magazine fills, which it no longer
            // does here: end the loop once the host has finished (or refused) the reload.
            if(Active==null || !Active.Combat.ReloadPending) __instance.weaponAnimation.SetBool("reload",false);
        }
        private static Exception InsertedDone(Exception __exception) { _suppressExtract=false; return __exception; }
    }
}
