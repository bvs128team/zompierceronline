using System;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
using Zompiercer.Inventory;
using Object = UnityEngine.Object;

namespace ZompiercerLAN
{
    // Work on the world through the host (0.7.0): melee hits on resource objects,
    // gathering with a knife, digging with a shovel, filling a canister at a gas
    // station; 0.8.0: pouring a full canister into a fuel tank of the host's train. The guest's own copy of these objects is never used; the host acts on
    // its objects with its own copy of the guest's tool and hands out the result.
    internal static class LanWorldWork
    {
        internal const int EmptyCanister = 92, FullCanister = 8, Sand = 89, Soil = 296;
        private const int Flower = 2;
        private static Harmony _harmony;
        private static Action<string> _log;
        internal static string Failure { get; private set; }
        // Guest: sends a work request; null when no usable session is attached.
        internal static Func<int, Vector3, int, int, object[], bool> GuestWork;

        private static readonly FieldInfo GunResource = AccessTools.Field(typeof(Gun), "resourceContent");
        private static readonly FieldInfo GunCollected = AccessTools.Field(typeof(Gun), "collectedResource");
        private static readonly FieldInfo GunFurniture = AccessTools.Field(typeof(Gun), "HitFurniture");
        private static readonly FieldInfo GunPart = AccessTools.Field(typeof(Gun), "HitTrainPart");
        private static readonly FieldInfo GunHit = AccessTools.Field(typeof(Gun), "raycastHit");
        internal static readonly MethodInfo GunWear = AccessTools.Method(typeof(Gun), "SubtractWeaponDurability");
        private static readonly FieldInfo SpawnedItem = AccessTools.Field(typeof(CollectedResource), "spawnedItemID");
        private static readonly FieldInfo FillingTank = AccessTools.Field(typeof(InventoryController), "CurrentlyFillingFuelTank");

        internal static void Initialize(Action<string> log)
        {
            _log = log;
            if (_harmony != null) return;
            _harmony = new Harmony("local.zompiercer.lan.world-work");
            try
            {
                if (GunResource == null || GunCollected == null || GunFurniture == null || GunPart == null || GunHit == null || GunWear == null || SpawnedItem == null || FillingTank == null)
                    throw new MissingMemberException("Gun/CollectedResource members changed");
                _harmony.Patch(AccessTools.Method(typeof(Gun), "MeleeDisassemblyTarget"), prefix: new HarmonyMethod(typeof(LanWorldWork), nameof(MeleePrefix)));
                _harmony.Patch(AccessTools.Method(typeof(InventoryController), "CheckGasStationAndFillGasoline"), prefix: new HarmonyMethod(typeof(LanWorldWork), nameof(FuelPrefix)));
                // The game's own "refuel from a canister" ends in these two calls.
                _harmony.Patch(AccessTools.Method(typeof(InventoryController), "GetResourcesFromItem"), prefix: new HarmonyMethod(typeof(LanWorldWork), nameof(PourPrefix)));
                _harmony.Patch(AccessTools.Method(typeof(TrainFuelTank), "Fill"), prefix: new HarmonyMethod(typeof(LanWorldWork), nameof(TankFillPrefix)));
            }
            catch (Exception ex)
            {
                _harmony.UnpatchSelf();
                Failure = ex.GetType().Name + ": " + ex.Message;
                log("World work hooks unavailable: " + Failure);
            }
        }
        internal static void Shutdown() { _harmony?.UnpatchSelf(); _harmony = null; GuestWork = null; _pouring = null; }

        // Guest: a melee hit on its own copy of a resource becomes a request to the host.
        private static bool MeleePrefix(Gun __instance)
        {
            if (!LanSaveIsolation.Active) return true;
            var work = GuestWork;
            if (work == null) return true; // solo or not attached: the guest's own world
            try
            {
                __instance.DoRaycast();
                var tool = InventoryController.global == null ? null : InventoryController.global.GetActiveIntenvoryItem();
                if (tool == null) return false;
                // The host's train and furniture are never taken apart from here.
                if (GunFurniture.GetValue(__instance) != null || GunPart.GetValue(__instance) != null) return false;
                var resource = GunResource.GetValue(__instance) as ResourceContent;
                var collected = GunCollected.GetValue(__instance) as CollectedResource;
                bool sent = false;
                if (resource != null) sent = work(LanStorage.WorkHit, resource.transform.position, tool.itemID, 0, null);
                else if (tool.toolShovel)
                {
                    var detector = Zompiercer.Farm.TerrainResourceDetector.Global;
                    int type = detector == null ? 0 : (int)detector.ResourceType;
                    var hit = (RaycastHit)GunHit.GetValue(__instance);
                    if ((type == 1 || type == 2) && hit.collider != null) sent = work(LanStorage.WorkDig, hit.point, tool.itemID, type, null);
                }
                else if (tool.toolKnife && collected != null) sent = work(LanStorage.WorkGather, collected.transform.position, tool.itemID, 0, null);
                // The tool wears as natively; the host wears its ledger copy alike.
                if (sent) GunWear.Invoke(__instance, new object[] { -1f });
            }
            catch (Exception ex) { _log?.Invoke("Melee work hook failed: " + ex.Message); }
            return false;
        }

        // Guest: filling a canister at a gas station is the host's fuel.
        private static bool FuelPrefix(InventoryController __instance)
        {
            if (!LanSaveIsolation.Active) return true;
            var work = GuestWork;
            if (work == null) return true;
            try
            {
                var station = SelectionManager.Global == null ? null : SelectionManager.Global.HoveredGasStation;
                var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
                if (station == null || player == null || player.beltInventory == null) return false;
                var slot = player.beltInventory[__instance.selectedBeltIcon];
                var can = slot == null || slot.content == null || slot.content.Count == 0 ? null : slot.content[0];
                if (can == null || can.itemID != EmptyCanister) return false;
                var escrow = LanStorage.Normalize(new object[] { can.itemID, 1, can.Save() });
                slot.Extract(can, 1);
                if (!work(LanStorage.WorkFuel, station.transform.position, -1, 0, escrow))
                    new LanStorageGuestWorld().Give(escrow);
            }
            catch (Exception ex) { _log?.Invoke("Fuel hook failed: " + ex.Message); }
            return false;
        }

        // ---- Guest: refuelling the host's train ----
        private static TrainFuelTank _pouring;

        // The game has taken the full canister and now wants to give back the empty one:
        // the canister goes to the host instead, which fills its own tank and hands back the empty one.
        private static bool PourPrefix(InventoryController __instance, InventoryItem fromItem)
        {
            var tank = FillingTank.GetValue(__instance) as TrainFuelTank;
            if (!LanSaveIsolation.Active || GuestWork == null || tank == null || fromItem == null || fromItem.itemID != FullCanister) return true;
            object[] escrow = null;
            try
            {
                escrow = LanStorage.Normalize(new object[] { fromItem.itemID, 1, fromItem.Save() });
                if (!Pour(tank, tank.transform.position, escrow)) new LanStorageGuestWorld().Give(escrow);
            }
            catch (Exception ex)
            {
                _log?.Invoke("Refuel hook failed: " + ex.Message);
                if (escrow != null) { try { new LanStorageGuestWorld().Give(escrow); } catch (Exception) { } }
            }
            return false;
        }
        // The guest's own copy of a tank on the host's train never fills by itself.
        private static bool TankFillPrefix(TrainFuelTank __instance, float value)
        {
            if (!LanSaveIsolation.Active || GuestWork == null || value <= 0f) return true;
            var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrain;
            return train == null || !__instance.transform.IsChildOf(train.transform);
        }

        // Sends a full canister (already out of the inventory) to the tank at `point` of the host's train.
        internal static bool Pour(TrainFuelTank shown, Vector3 point, object[] escrow)
        {
            var work = GuestWork;
            var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrain;
            var car = shown != null ? shown.GetComponentInParent<Zompiercer.Train.TrainCar>() : null;
            if (car == null && train != null)
                foreach (var hit in Physics.OverlapSphere(point, .1f, ~0, QueryTriggerInteraction.Ignore))
                    if ((car = hit.GetComponentInParent<Zompiercer.Train.TrainCar>()) != null) break;
            int index = TrainLayout.CarIndex(train, car);
            if (work == null || index < 0) { LanStorageGame.Notice("Заправлять можно только поезд хоста"); return false; }
            var local = car.transform.InverseTransformPoint(point);
            if (!work(LanStorage.WorkRefuel, local, -1, index, escrow)) return false;
            _pouring = shown;
            return true;
        }
        internal static bool Pour(Zompiercer.Train.TrainCar car, Vector3 point, object[] escrow)
        {
            var work = GuestWork;
            var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrain;
            int index = TrainLayout.CarIndex(train, car);
            if (work == null || index < 0) return false;
            _pouring = null;
            return work(LanStorage.WorkRefuel, car.transform.InverseTransformPoint(point), -1, index, escrow);
        }

        // Guest: the host's answer to a refuel, its tank's level x100; shown on the guest's own copy.
        internal static void Refuelled(int level)
        {
            var tank = _pouring; _pouring = null;
            if (tank != null) tank.currentFuelAmount = Mathf.Clamp(level / 100f, 0f, tank.maxFuelAmount);
            LanStorageGame.Notice("Бак поезда хоста: " + Mathf.RoundToInt(level / 100f));
        }

        // ---- Host ----
        internal static byte HostWork(int kind, Vector3 at, int tool, int extra, object[] escrow, Vector3? guest, out object[] given, out int detail)
        {
            given = null; detail = 0;
            if (kind == LanStorage.WorkRefuel) return HostRefuel(at, extra, escrow, guest, out given, out detail);
            if (guest == null) return LanStorage.Lost;
            if (Vector3.Distance(at, guest.Value) > 5f) return LanStorage.TooFar;
            var prefabs = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.itemPrefab;
            if (prefabs == null) return LanStorage.Unavailable;
            var toolPrefab = tool >= 0 && tool < prefabs.Length ? prefabs[tool] : null;
            var gun = tool >= 0 ? HostGun(tool) : null;
            switch (kind)
            {
                case LanStorage.WorkHit:
                {
                    if (gun == null || gun.furnitureBuildPower <= 0) return LanStorage.NotAllowed;
                    var target = Nearest<ResourceContent>(at, .3f);
                    if (target == null) return LanStorage.NotFound;
                    float power = gun.furnitureBuildPower;
                    if (target.durability <= power) target.ObjectParsed(); // what falls out lies in this world
                    target.durability -= power;
                    return LanStorage.Ok;
                }
                case LanStorage.WorkGather:
                {
                    if (toolPrefab == null || !toolPrefab.toolKnife || gun == null) return LanStorage.NotAllowed;
                    var resource = Nearest<CollectedResource>(at, .3f);
                    if (resource == null || !resource.gameObject.activeInHierarchy) return LanStorage.NotFound;
                    if ((int)resource.ResourceType != Flower) return LanStorage.NotAllowed;
                    int id = (int)SpawnedItem.GetValue(resource), amount = Math.Max(1, gun.resourceExtractionPower);
                    if (id < 0 || id >= prefabs.Length || prefabs[id] == null) return LanStorage.Invalid;
                    given = new object[] { id, amount, new object[4] };
                    resource.resourceQuantity -= amount;
                    if (resource.resourceQuantity <= 0) resource.gameObject.SetActive(false);
                    return LanStorage.Ok;
                }
                case LanStorage.WorkDig:
                {
                    if (toolPrefab == null || !toolPrefab.toolShovel || gun == null) return LanStorage.NotAllowed;
                    int id = extra == 1 ? Sand : Soil;
                    if (id >= prefabs.Length || prefabs[id] == null) return LanStorage.Invalid;
                    given = new object[] { id, Math.Max(1, gun.resourceExtractionPower), new object[4] };
                    return LanStorage.Ok;
                }
                case LanStorage.WorkFuel:
                {
                    if (escrow == null || (int)escrow[0] != EmptyCanister || (int)escrow[1] != 1) return LanStorage.NotAllowed;
                    var station = Nearest<GasStation>(at, 1f);
                    if (station == null) return LanStorage.NotFound;
                    if (station.FuelQuantityCurrent < 10) return LanStorage.Empty;
                    if (FullCanister >= prefabs.Length || prefabs[FullCanister] == null) return LanStorage.Invalid;
                    station.Fill(-10);
                    given = new object[] { FullCanister, 1, new object[4] };
                    return LanStorage.Ok;
                }
            }
            return LanStorage.Invalid;
        }

        // A full canister into the fuel tank of car `index` nearest to `local` (that car's space).
        private static byte HostRefuel(Vector3 local, int index, object[] escrow, Vector3? guest, out object[] given, out int detail)
        {
            given = null; detail = 0;
            if (escrow == null || (int)escrow[0] != FullCanister || (int)escrow[1] != 1) return LanStorage.NotAllowed;
            var train = GlobalManager.global == null ? null : GlobalManager.global.controlledTrain;
            if (train == null) return LanStorage.Unavailable;
            Zompiercer.Train.TrainCar car;
            try { car = TrainLayout.GetCar(train, index); }
            catch (Exception) { return LanStorage.NotFound; }
            var at = car.transform.TransformPoint(local);
            if (guest == null) return LanStorage.Lost;
            if (Vector3.Distance(at, guest.Value) > 5f) return LanStorage.TooFar;
            TrainFuelTank tank = null; float best = 16f; // within 4 m of the point the guest aimed at
            foreach (var candidate in car.GetComponentsInChildren<TrainFuelTank>())
            {
                if (candidate == null || !candidate.isActiveAndEnabled) continue;
                float d = (candidate.transform.position - at).sqrMagnitude;
                foreach (var collider in candidate.GetComponentsInChildren<Collider>())
                    if (collider != null && collider.enabled) d = Math.Min(d, (collider.ClosestPoint(at) - at).sqrMagnitude);
                if (d <= best) { best = d; tank = candidate; }
            }
            if (tank == null) return LanStorage.NotFound;
            if (tank.currentFuelAmount >= tank.maxFuelAmount - .01f) return LanStorage.Full;
            var prefabs = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.itemPrefab;
            var full = prefabs != null && FullCanister < prefabs.Length ? prefabs[FullCanister] : null;
            var value = full == null ? null : full.GetComponent<LootObjectValue>();
            if (value == null || value.FuelValue <= 0f || EmptyCanister >= prefabs.Length || prefabs[EmptyCanister] == null) return LanStorage.Invalid;
            tank.Fill(value.FuelValue);
            given = new object[] { EmptyCanister, 1, new object[4] };
            detail = Mathf.RoundToInt(Mathf.Clamp(tank.currentFuelAmount, 0f, 9999f) * 100f);
            return LanStorage.Ok;
        }

        // The host's own Gun for the guest's tool (same prefab, same stats).
        internal static Gun HostGun(int itemId)
        {
            var prefabs = ItemsDataBase.Global == null ? null : ItemsDataBase.Global.itemPrefab;
            var player = GlobalManager.global == null ? null : GlobalManager.global.controlledChar;
            if (prefabs == null || itemId < 0 || itemId >= prefabs.Length || prefabs[itemId] == null || player == null || player.zombieFighterFireArmWeapon == null) return null;
            var data = prefabs[itemId].GetComponent<WeaponData>();
            if (data == null || player.zombieFighterFireArmWeapon.gunList == null) return null;
            foreach (var gun in player.zombieFighterFireArmWeapon.gunList) if (gun != null && gun.ID == data.ID) return gun;
            return null;
        }

        private static T Nearest<T>(Vector3 at, float within) where T : Component
        {
            T best = null; float distance = within * within;
            foreach (var candidate in Object.FindObjectsOfType<T>())
            {
                float d = (candidate.transform.position - at).sqrMagnitude;
                if (d <= distance) { best = candidate; distance = d; }
            }
            return best;
        }
    }
}
