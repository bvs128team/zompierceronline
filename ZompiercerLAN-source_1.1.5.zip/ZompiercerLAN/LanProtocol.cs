using System;
using System.IO;
using System.Text;

namespace ZompiercerLAN
{
    internal enum PacketKind : byte { Hello=1, Welcome=2, State=3, Busy=4, VersionMismatch=5, Heartbeat=6, TrainMotion=7, TrainLayoutChunk=8, TrainLayoutAck=9, WorldState=10, ZombieState=11, ZombieAction=12, ZombieHurt=13, ZombieHurtAck=14, CombatProposal=15, CombatState=16, CombatReload=17,
        // Schema 10 (0.5.0): guest profile persistence on the host.
        IdentityRequest=18, IdentityProof=19, GuestStatus=20, GuestStateChunk=21, GuestStateAck=22, GuestRestoreChunk=23, GuestRestoreAck=24,
        // Schema 11 (0.6.0): host-authoritative shared storages.
        StorageRequest=25, StorageResult=26, StorageViewChunk=27, StorageViewAck=28,
        // Schema 12 (0.6.1): zombie corpses, world doors.
        ZombieCorpse=29, DoorStates=30, DoorToggle=31,
        // Schema 13 (0.7.0): loose items and loot bags of the host's world.
        // Schema 14 (0.8.0): no new kinds; storage request 9 (build) and work kind 5 (refuel).
        // Schema 15 (0.8.1): storage request 10 (place a blueprint), result statuses up to 20.
        WorldItems=32,
        // Schema 16 (0.10.0): marks of either player; storage request 11 (train controls);
        // the train frame carries the cab's state and whether the host lets the guest drive.
        Mark=33,
        // Schema 17 (0.11.0): text chat (LanChatChannel), not bound to a world.
        // Schema 18 (0.12.0): no new kinds; storage request 12 (the guest died), train flag 64 (the host is dead).
        // Schema 19 (1.0.1): a zombie frame also carries its animator's bool parameters, so the
        // guest's copy follows the host's state machine instead of falling back to idle.
        // Schema 20 (1.0.7): zombie batches carry the host clock; car-relative zombie actions.
        // Schema 21 (1.0.8): a player state carries its health; a zombie action its loudness.
        // Schema 22 (1.1.0): a player state carries where it looks up or down and whether it crouches;
        // its shot counter also counts melee swings.
        // Schema 23 (1.1.1): the player state's pose also says whether it aims down the sights.
        // Schema 24 (1.1.5): a workbench's storage view carries its craft queue and progress;
        // storage request 13 cancels one queued craft (the guest uses the game's craft window).
        Chat=34 }
    // A dead zombie's ragdoll: root pose and the world pose of each rigid bone,
    // in the order of the shared prefab's ZombieDamagDetector.rigidElements.
    internal sealed class CorpseFrame
    {
        internal uint Id;
        internal string Prefab;
        internal float X,Y,Z,Yaw;
        internal NetPose[] Bones;
    }
    // A scene door (DoorController) identified by its position; Flags: 1 open, 2 broken.
    internal sealed class DoorFrame { internal float X,Y,Z; internal byte Flags; }
    // A loose item (Kind 0) or loot bag (Kind 1) of the host's world near the guest,
    // or the removal of one (Kind 2). HostId is the host's instance id of the object.
    internal sealed class WorldItemFrame { internal int HostId,ItemId,Amount; internal byte Kind; internal NetPose Pose; }
    internal sealed class ZombieFrame
    {
        internal uint Id;
        internal string Prefab;
        internal float X,Y,Z,Yaw,Health,AnimationTime;
        internal int Animation;
        internal uint AnimationFlags; // bool parameters of the zombie's animator, in controller order (schema 19)
        internal byte Flags;
    }
    internal sealed class NetPose { internal float X,Y,Z,QX,QY,QZ,QW; }
    internal sealed class CarPose { internal NetPose Root,Body,Front,Back; }
    internal sealed class TrainFrame
    {
        internal uint Sequence;
        internal int Revision;
        internal string Scene;
        internal float Speed,Thrust;
        // 1 engine, 2 brake, 4 reverse, 8 horn, 16 spotlight, 32 the guest may drive (0.10.0),
        // 64 the host's player is dead (0.12.0).
        internal byte Flags;
        // The train's own controls (LanTrainControl order): button states, broken buttons,
        // cab light switches, lever values.
        internal uint Buttons,Broken;
        internal ushort Lights;
        internal float[] Levers=new float[0];
        internal CarPose[] Cars;
    }
    internal sealed class Packet
    {
        internal PacketKind Kind;
        internal string GameVersion;
        internal ulong Session;
        internal uint WorldEpoch;
        internal uint Sequence;
        internal string Scene;
        internal float X,Y,Z,Yaw,TrainPosition;
        internal int CarIndex=-1;
        internal float LocalX,LocalY,LocalZ,LocalYaw;
        internal int EquippedItemId=-1, ShotItemId=-1;
        internal uint ShotSequence;
        internal TrainFrame Train;
        internal int Revision,ChunkIndex,ChunkCount;
        internal byte[] Chunk;
        internal int Location, RailsId=-1;
        internal ClockSnapshot Clock;
        internal ZombieFrame[] Zombies;
        internal float AimX,AimY,AimZ,Damage;
        // ZombieState (schema 20): the host clock when the batch was taken, for client interpolation.
        internal float HostTime;
        // State (schema 21): the player's health in percent, or NoHealth. ZombieAction: the shot's
        // loudness in percent of the gun's hearing radius (less with a silencer).
        internal byte Health=LanProtocol.NoHealth, Noise=100;
        // State (schema 22): the view's pitch in degrees (up positive); pose flags PoseCrouch, PoseAim (23).
        internal float Pitch;
        internal byte Pose;
        internal byte Action;
        internal CombatWeapon[] CombatWeapons;
        internal CombatAmmo[] CombatAmmo;
        internal float Stamina;
        internal int Amount;
        internal CorpseFrame Corpse;
        internal DoorFrame[] Doors;
        internal WorldItemFrame[] Items;
        internal string Text;
    }
    internal static class LanProtocol
    {
        private const uint Magic=0x4C504D5A;
        private const byte Version=24;
        internal const byte NoHealth=255;
        internal const byte PoseCrouch=1, PoseAim=2, MaxPose=3;
        internal const float MaxPitch=90f;
        internal const int MaxCorpseBones=24, MaxDoorBatch=64, MaxItemBatch=24;
        internal const int MaxZombieBatch=8, MaxZombieIds=4096, MaxZombieReplicas=256;
        internal const int MaxCars=8, ChunkSize=900, MaxLayoutBytes=256*1024;
        internal const int MaxChunks=(MaxLayoutBytes+ChunkSize-1)/ChunkSize;
        internal const int MaxGuestBytes=64*1024, MaxGuestChunks=(MaxGuestBytes+ChunkSize-1)/ChunkSize;
        internal const int WorldIdBytes=16, ProfileTokenBytes=32, MaxStoragePayload=1000;
        internal const int MaxLevers=4;
        // Chat: Action 0 a message (Sequence = its number), 1 acknowledges every message up to Sequence.
        internal const int MaxChatChars=200, MaxChatBytes=MaxChatChars*3;
        // Marks: 0 removes the sender's mark Revision, 1 enemy, 2 find, 3 point / direction.
        internal const byte MarkClear=0, MarkEnemy=1, MarkFind=2, MarkPoint=3;
        private static readonly Encoding Text=new UTF8Encoding(false,true);
        internal static byte[] Encode(Packet p)
        {
            using(var s=new MemoryStream(1200))
            using(var w=new BinaryWriter(s))
            {
                w.Write(Magic); w.Write(Version); w.Write((byte)p.Kind); WriteText(w,p.GameVersion,40); w.Write(p.Session);
                w.Write(p.WorldEpoch);
                switch(p.Kind)
                {
                    case PacketKind.ZombieState:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.HostTime);
                        if(p.Zombies==null || p.Zombies.Length>MaxZombieBatch) throw new InvalidDataException("Zombie batch");
                        w.Write((byte)p.Zombies.Length);
                        foreach(var z in p.Zombies) {
                            w.Write(z.Id); WriteText(w,z.Prefab,64); w.Write(z.X);w.Write(z.Y);w.Write(z.Z);w.Write(z.Yaw);
                            w.Write(z.Health);w.Write(z.Flags);w.Write(z.Animation);w.Write(z.AnimationTime);w.Write(z.AnimationFlags);
                        }
                        break;
                    case PacketKind.ZombieAction:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.EquippedItemId); w.Write(p.Action);
                        w.Write(p.X);w.Write(p.Y);w.Write(p.Z);w.Write(p.AimX);w.Write(p.AimY);w.Write(p.AimZ); w.Write(p.Revision);
                        // Schema 20: origin and aim in car CarIndex's own space, or in the world (-1).
                        w.Write((sbyte)p.CarIndex); w.Write(p.Noise); break;
                    case PacketKind.CombatReload:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.EquippedItemId); w.Write(p.Revision); break;
                    case PacketKind.CombatProposal:
                    case PacketKind.CombatState:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.Revision); w.Write(p.Action); w.Write(p.Stamina);
                        w.Write(p.ShotSequence); w.Write(p.EquippedItemId);
                        if(!HostCombatInventory.ValidLoadout(p.CombatWeapons,p.CombatAmmo)) throw new InvalidDataException("Combat loadout");
                        w.Write((byte)p.CombatWeapons.Length);
                        foreach(var cw in p.CombatWeapons) { w.Write(cw.ItemId);w.Write(cw.Magazine);w.Write(cw.Durability); }
                        w.Write((byte)p.CombatAmmo.Length);
                        foreach(var ca in p.CombatAmmo) { w.Write(ca.ItemId);w.Write(ca.Amount); } break;
                    case PacketKind.ZombieHurt:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.Damage); w.Write(p.Action); break;
                    case PacketKind.ZombieHurtAck:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); break;
                    case PacketKind.WorldState:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.Location); w.Write(p.RailsId); w.Write(p.TrainPosition);
                        w.Write(p.Clock != null);
                        if(p.Clock != null) { w.Write(p.Clock.Year); w.Write(p.Clock.Day); w.Write(p.Clock.Hour); w.Write(p.Clock.HoursPerRealSecond); }
                        break;
                    case PacketKind.State:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96);
                        w.Write(p.X); w.Write(p.Y); w.Write(p.Z); w.Write(p.Yaw); w.Write(p.TrainPosition);
                        w.Write((sbyte)p.CarIndex); w.Write(p.LocalX); w.Write(p.LocalY); w.Write(p.LocalZ); w.Write(p.LocalYaw);
                        w.Write(p.EquippedItemId); w.Write(p.ShotSequence); w.Write(p.ShotItemId); w.Write(p.Health);
                        w.Write(p.Pitch); w.Write(p.Pose);
                        break;
                    case PacketKind.TrainMotion:
                        var f=p.Train;
                        w.Write(f.Sequence); w.Write(f.Revision); WriteText(w,f.Scene,96);
                        w.Write(f.Speed); w.Write(f.Thrust); w.Write(f.Flags);
                        w.Write(f.Buttons); w.Write(f.Broken); w.Write(f.Lights);
                        if(f.Levers==null || f.Levers.Length>MaxLevers) throw new InvalidDataException("Train levers");
                        w.Write((byte)f.Levers.Length); foreach(var lever in f.Levers) w.Write(lever);
                        if(f.Cars==null || f.Cars.Length==0 || f.Cars.Length>MaxCars) throw new InvalidDataException("Train car count");
                        w.Write((byte)f.Cars.Length);
                        foreach(var c in f.Cars) { WritePose(w,c.Root); WritePose(w,c.Body); WritePose(w,c.Front); WritePose(w,c.Back); }
                        break;
                    case PacketKind.TrainLayoutChunk:
                        w.Write(p.Revision); w.Write((ushort)p.ChunkCount); w.Write((ushort)p.ChunkIndex);
                        if(p.Chunk==null || p.Chunk.Length>ChunkSize) throw new InvalidDataException("Chunk size");
                        w.Write((ushort)p.Chunk.Length); w.Write(p.Chunk); break;
                    case PacketKind.TrainLayoutAck: w.Write(p.Revision); break;
                    case PacketKind.IdentityRequest:
                    case PacketKind.IdentityProof:
                        int fixedSize=p.Kind==PacketKind.IdentityRequest?WorldIdBytes:ProfileTokenBytes;
                        if(p.Chunk==null || p.Chunk.Length!=fixedSize) throw new InvalidDataException("Identity field size");
                        w.Write(p.Chunk); break;
                    case PacketKind.GuestStatus: w.Write(p.Action); w.Write(p.Revision); break;
                    case PacketKind.GuestStateChunk:
                    case PacketKind.GuestRestoreChunk:
                    case PacketKind.StorageViewChunk:
                        w.Write(p.Revision); w.Write((ushort)p.ChunkCount); w.Write((ushort)p.ChunkIndex);
                        if(p.Chunk==null || p.Chunk.Length>ChunkSize) throw new InvalidDataException("Chunk size");
                        w.Write((ushort)p.Chunk.Length); w.Write(p.Chunk); break;
                    case PacketKind.GuestStateAck:
                    case PacketKind.GuestRestoreAck:
                    case PacketKind.StorageViewAck: w.Write(p.Revision); break;
                    case PacketKind.StorageRequest:
                    case PacketKind.StorageResult:
                        w.Write(p.Sequence); w.Write(p.Action); w.Write(p.Revision);
                        if(p.Kind==PacketKind.StorageResult) w.Write(p.Amount);
                        int payload=p.Chunk==null?0:p.Chunk.Length;
                        if(payload>MaxStoragePayload) throw new InvalidDataException("Storage payload");
                        w.Write((ushort)payload); if(payload>0) w.Write(p.Chunk); break;
                    case PacketKind.ZombieCorpse:
                        var cf=p.Corpse;
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(cf.Id); WriteText(w,cf.Prefab,64);
                        w.Write(cf.X); w.Write(cf.Y); w.Write(cf.Z); w.Write(cf.Yaw);
                        if(cf.Bones==null || cf.Bones.Length>MaxCorpseBones) throw new InvalidDataException("Corpse bones");
                        w.Write((byte)cf.Bones.Length); foreach(var bone in cf.Bones) WritePose(w,bone); break;
                    case PacketKind.DoorStates:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96);
                        if(p.Doors==null || p.Doors.Length>MaxDoorBatch) throw new InvalidDataException("Door batch");
                        w.Write((byte)p.Doors.Length);
                        foreach(var d in p.Doors) { w.Write(d.X); w.Write(d.Y); w.Write(d.Z); w.Write(d.Flags); } break;
                    case PacketKind.DoorToggle:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.X); w.Write(p.Y); w.Write(p.Z); w.Write(p.Action); break;
                    case PacketKind.WorldItems:
                        w.Write(p.Sequence); WriteText(w,p.Scene,96);
                        if(p.Items==null || p.Items.Length>MaxItemBatch) throw new InvalidDataException("Item batch");
                        w.Write((byte)p.Items.Length);
                        foreach(var it in p.Items) { w.Write(it.HostId); w.Write(it.ItemId); w.Write(it.Amount); w.Write(it.Kind); WritePose(w,it.Pose); } break;
                    case PacketKind.Mark:
                        // A position in the world, or in car CarIndex's own space.
                        w.Write(p.Sequence); WriteText(w,p.Scene,96); w.Write(p.Action); w.Write(p.Revision);
                        w.Write((sbyte)p.CarIndex); w.Write(p.X); w.Write(p.Y); w.Write(p.Z); break;
                    case PacketKind.Chat:
                        if(!ValidChat(p.Sequence,p.Action,p.Text)) throw new InvalidDataException("Chat message");
                        var chat=Text.GetBytes(p.Text??"");
                        if(chat.Length>MaxChatBytes) throw new InvalidDataException("Chat message");
                        w.Write(p.Sequence); w.Write(p.Action); w.Write((ushort)chat.Length); w.Write(chat); break;
                }
                if(s.Length>1200) throw new InvalidDataException("LAN packet too large");
                return s.ToArray();
            }
        }
        internal static bool TryDecode(byte[] data,out Packet packet)
        {
            packet=null;
            if(data==null || data.Length<19 || data.Length>1200) return false;
            try
            {
                using(var s=new MemoryStream(data,false))
                using(var r=new BinaryReader(s))
                {
                    if(r.ReadUInt32()!=Magic || r.ReadByte()!=Version) return false;
                    var kind=(PacketKind)r.ReadByte();
                    if(kind<PacketKind.Hello || kind>PacketKind.Chat) return false;
                    var p=new Packet {Kind=kind,GameVersion=ReadText(r,40),Session=r.ReadUInt64(),WorldEpoch=r.ReadUInt32()};
                    switch(kind)
                    {
                        case PacketKind.ZombieState:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96); p.HostTime=r.ReadSingle();
                            if(float.IsNaN(p.HostTime) || float.IsInfinity(p.HostTime) || p.HostTime<0) return false;
                            int zombies=r.ReadByte(); if(zombies>MaxZombieBatch) return false;
                            p.Zombies=new ZombieFrame[zombies];
                            for(int i=0;i<zombies;i++) {
                                var z=new ZombieFrame {Id=r.ReadUInt32(),Prefab=ReadText(r,64),X=ReadFloat(r),Y=ReadFloat(r),Z=ReadFloat(r),Yaw=ReadFloat(r),Health=ReadFloat(r),Flags=r.ReadByte(),Animation=r.ReadInt32(),AnimationTime=ReadFloat(r),AnimationFlags=r.ReadUInt32()};
                                if(z.Id==0 || z.Id>MaxZombieIds || string.IsNullOrEmpty(z.Prefab) || z.Yaw<0 || z.Yaw>360 || z.Health<0 || z.Flags>3 || z.AnimationTime<0 || z.AnimationTime>1) return false;
                                for(int j=0;j<i;j++) if(p.Zombies[j].Id==z.Id) return false;
                                p.Zombies[i]=z;
                            }
                            break;
                        case PacketKind.ZombieAction:
                            p.Sequence=r.ReadUInt32();p.Scene=ReadText(r,96);p.EquippedItemId=r.ReadInt32();p.Action=r.ReadByte();
                            p.X=ReadFloat(r);p.Y=ReadFloat(r);p.Z=ReadFloat(r);p.AimX=ReadFloat(r);p.AimY=ReadFloat(r);p.AimZ=ReadFloat(r);
                            p.Revision=r.ReadInt32(); if(p.Revision<=0) return false;
                            float aim=p.AimX*p.AimX+p.AimY*p.AimY+p.AimZ*p.AimZ;
                            if(p.EquippedItemId<0 || p.EquippedItemId>65535 || p.Action>1 || aim<.99f || aim>1.01f) return false;
                            p.CarIndex=r.ReadSByte();
                            if(p.CarIndex < -1 || p.CarIndex>=MaxCars || p.CarIndex>=0 && (Math.Abs(p.X)>100 || Math.Abs(p.Y)>100 || Math.Abs(p.Z)>100)) return false;
                            p.Noise=r.ReadByte(); if(p.Noise>100) return false;
                            break;
                        case PacketKind.CombatReload:
                            p.Sequence=r.ReadUInt32();p.Scene=ReadText(r,96);p.EquippedItemId=r.ReadInt32();p.Revision=r.ReadInt32();
                            if(p.EquippedItemId<0 || p.EquippedItemId>65535 || p.Revision<=0) return false; break;
                        case PacketKind.CombatProposal:
                        case PacketKind.CombatState:
                            p.Sequence=r.ReadUInt32();p.Scene=ReadText(r,96);p.Revision=r.ReadInt32();p.Action=r.ReadByte();p.Stamina=ReadFloat(r);
                            p.ShotSequence=r.ReadUInt32();p.EquippedItemId=r.ReadInt32();
                            if(p.Revision<0 || p.Action>2 || p.Stamina<0 || p.Stamina>100 ||
                                p.EquippedItemId < -1 || p.EquippedItemId > 65535 ||
                                kind==PacketKind.CombatProposal && (p.Revision!=0 || p.Action!=0 || p.Stamina!=0 || p.ShotSequence!=0 || p.EquippedItemId!=-1) ||
                                kind==PacketKind.CombatState && ((p.Action==0)!=(p.Revision==0))) return false;
                            int wc=r.ReadByte();if(wc>16) return false;p.CombatWeapons=new CombatWeapon[wc];
                            for(int i=0;i<wc;i++) p.CombatWeapons[i]=new CombatWeapon {ItemId=r.ReadInt32(),Magazine=r.ReadInt32(),Durability=ReadFloat(r)};
                            int ac=r.ReadByte();if(ac>16) return false;p.CombatAmmo=new CombatAmmo[ac];
                            for(int i=0;i<ac;i++) p.CombatAmmo[i]=new CombatAmmo {ItemId=r.ReadInt32(),Amount=r.ReadInt32()};
                            if(!HostCombatInventory.ValidLoadout(p.CombatWeapons,p.CombatAmmo) || kind==PacketKind.CombatState && p.Action!=1 && (wc!=0 || ac!=0)) return false;
                            break;
                        case PacketKind.ZombieHurt:
                            p.Sequence=r.ReadUInt32();p.Scene=ReadText(r,96);p.Damage=ReadFloat(r);p.Action=r.ReadByte();
                            if(p.Damage<=0 || p.Damage>1000 || p.Action<1 || p.Action>4) return false; break;
                        case PacketKind.ZombieHurtAck:
                            p.Sequence=r.ReadUInt32();p.Scene=ReadText(r,96); break;
                        case PacketKind.WorldState:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96); p.Location=r.ReadInt32(); p.RailsId=r.ReadInt32(); p.TrainPosition=ReadFloat(r);
                            if(p.WorldEpoch==0 || string.IsNullOrEmpty(p.Scene) || p.Location<0 || p.Location>100000 || p.RailsId < -1 || p.TrainPosition<0) return false;
                            byte hasClock=r.ReadByte(); if(hasClock>1) return false;
                            if(hasClock!=0)
                            {
                                p.Clock=new ClockSnapshot {Year=r.ReadInt32(),Day=r.ReadInt32(),Hour=ReadFloat(r),HoursPerRealSecond=ReadFloat(r)};
                                if(p.Clock.Year<1 || p.Clock.Year>9999 || p.Clock.Day<0 || p.Clock.Day>366 || p.Clock.Hour<0 || p.Clock.Hour>24 || p.Clock.HoursPerRealSecond<0 || p.Clock.HoursPerRealSecond>24) return false;
                            }
                            break;
                        case PacketKind.State:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96);
                            p.X=ReadFloat(r); p.Y=ReadFloat(r); p.Z=ReadFloat(r); p.Yaw=ReadFloat(r); p.TrainPosition=ReadFloat(r);
                            if(string.IsNullOrEmpty(p.Scene) || p.Yaw < 0 || p.Yaw > 360 || p.TrainPosition < 0) return false;
                            p.CarIndex=r.ReadSByte();
                            if(p.CarIndex < -1 || p.CarIndex>=MaxCars) return false;
                            p.LocalX=ReadFloat(r); p.LocalY=ReadFloat(r); p.LocalZ=ReadFloat(r); p.LocalYaw=ReadFloat(r);
                            if(Math.Abs(p.LocalX)>100 || Math.Abs(p.LocalY)>100 || Math.Abs(p.LocalZ)>100) return false;
                            if(p.LocalYaw < 0 || p.LocalYaw > 360) return false;
                            p.EquippedItemId=r.ReadInt32(); p.ShotSequence=r.ReadUInt32(); p.ShotItemId=r.ReadInt32();
                            if(p.EquippedItemId < -1 || p.EquippedItemId > 65535 || p.ShotItemId < -1 || p.ShotItemId > 65535) return false;
                            p.Health=r.ReadByte(); if(p.Health>100 && p.Health!=NoHealth) return false;
                            p.Pitch=ReadFloat(r); p.Pose=r.ReadByte();
                            if(p.Pitch < -MaxPitch || p.Pitch > MaxPitch || p.Pose>MaxPose) return false;
                            break;
                        case PacketKind.TrainMotion:
                            var f=new TrainFrame {Sequence=r.ReadUInt32(),Revision=r.ReadInt32(),Scene=ReadText(r,96),Speed=ReadFloat(r),Thrust=ReadFloat(r),Flags=r.ReadByte()};
                            f.Buttons=r.ReadUInt32(); f.Broken=r.ReadUInt32(); f.Lights=r.ReadUInt16();
                            int levers=r.ReadByte(); if(levers>MaxLevers) return false;
                            f.Levers=new float[levers];
                            for(int i=0;i<levers;i++) { f.Levers[i]=ReadFloat(r); if(Math.Abs(f.Levers[i])>1000) return false; }
                            int count=r.ReadByte();
                            if(f.Revision<=0 || string.IsNullOrEmpty(f.Scene) || count==0 || count>MaxCars || Math.Abs(f.Speed)>500 || Math.Abs(f.Thrust)>100 || f.Flags>127) return false;
                            f.Cars=new CarPose[count];
                            for(int i=0;i<count;i++) f.Cars[i]=new CarPose {Root=ReadPose(r),Body=ReadPose(r),Front=ReadPose(r),Back=ReadPose(r)};
                            p.Train=f; break;
                        case PacketKind.TrainLayoutChunk:
                            p.Revision=r.ReadInt32(); p.ChunkCount=r.ReadUInt16(); p.ChunkIndex=r.ReadUInt16();
                            int size=r.ReadUInt16();
                            if(p.Revision<=0 || p.ChunkCount<1 || p.ChunkCount>MaxChunks || p.ChunkIndex>=p.ChunkCount || size<1 || size>ChunkSize) return false;
                            if(p.ChunkIndex<p.ChunkCount-1 && size!=ChunkSize) return false;
                            if((p.ChunkCount-1)*ChunkSize+(p.ChunkIndex==p.ChunkCount-1?size:1)>MaxLayoutBytes) return false;
                            p.Chunk=r.ReadBytes(size); if(p.Chunk.Length!=size) return false;
                            break;
                        case PacketKind.TrainLayoutAck:
                            p.Revision=r.ReadInt32(); if(p.Revision<=0) return false; break;
                        case PacketKind.IdentityRequest:
                        case PacketKind.IdentityProof:
                            int fixedSize=kind==PacketKind.IdentityRequest?WorldIdBytes:ProfileTokenBytes;
                            p.Chunk=r.ReadBytes(fixedSize); if(p.Chunk.Length!=fixedSize) return false;
                            if(kind==PacketKind.IdentityRequest && new Guid(p.Chunk)==Guid.Empty) return false;
                            break;
                        case PacketKind.GuestStatus:
                            p.Action=r.ReadByte(); p.Revision=r.ReadInt32();
                            if(p.Action>1 || (p.Action==0)!=(p.Revision==0) || p.Revision<0) return false; break;
                        case PacketKind.GuestStateChunk:
                        case PacketKind.GuestRestoreChunk:
                        case PacketKind.StorageViewChunk:
                            p.Revision=r.ReadInt32(); p.ChunkCount=r.ReadUInt16(); p.ChunkIndex=r.ReadUInt16();
                            int blobSize=r.ReadUInt16();
                            if(p.Revision<=0 || p.ChunkCount<1 || p.ChunkCount>MaxGuestChunks || p.ChunkIndex>=p.ChunkCount || blobSize<1 || blobSize>ChunkSize) return false;
                            if(p.ChunkIndex<p.ChunkCount-1 && blobSize!=ChunkSize) return false;
                            if((p.ChunkCount-1)*ChunkSize+(p.ChunkIndex==p.ChunkCount-1?blobSize:1)>MaxGuestBytes) return false;
                            p.Chunk=r.ReadBytes(blobSize); if(p.Chunk.Length!=blobSize) return false;
                            break;
                        case PacketKind.GuestStateAck:
                        case PacketKind.GuestRestoreAck:
                        case PacketKind.StorageViewAck:
                            p.Revision=r.ReadInt32(); if(p.Revision<=0) return false; break;
                        case PacketKind.StorageRequest:
                        case PacketKind.StorageResult:
                            p.Sequence=r.ReadUInt32(); p.Action=r.ReadByte(); p.Revision=r.ReadInt32();
                            if(kind==PacketKind.StorageResult) p.Amount=r.ReadInt32();
                            int payloadSize=r.ReadUInt16();
                            if(payloadSize>MaxStoragePayload || p.Sequence==0 || p.Revision<0) return false;
                            p.Chunk=r.ReadBytes(payloadSize); if(p.Chunk.Length!=payloadSize) return false;
                            if(kind==PacketKind.StorageRequest ? !ValidStorageRequest(p.Action,p.Revision,payloadSize) :
                                p.Action>MaxStorageStatus || p.Amount<0 || p.Amount>1000000) return false;
                            break;
                        case PacketKind.ZombieCorpse:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96);
                            var corpse=new CorpseFrame {Id=r.ReadUInt32(),Prefab=ReadText(r,64),X=ReadFloat(r),Y=ReadFloat(r),Z=ReadFloat(r),Yaw=ReadFloat(r)};
                            int bones=r.ReadByte();
                            if(corpse.Id==0 || corpse.Id>MaxZombieIds || string.IsNullOrEmpty(corpse.Prefab) || corpse.Yaw<0 || corpse.Yaw>360 || bones>MaxCorpseBones) return false;
                            corpse.Bones=new NetPose[bones];
                            for(int i=0;i<bones;i++) corpse.Bones[i]=ReadPose(r);
                            p.Corpse=corpse; break;
                        case PacketKind.DoorStates:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96);
                            int doors=r.ReadByte(); if(doors>MaxDoorBatch) return false;
                            p.Doors=new DoorFrame[doors];
                            for(int i=0;i<doors;i++) {
                                p.Doors[i]=new DoorFrame {X=ReadFloat(r),Y=ReadFloat(r),Z=ReadFloat(r),Flags=r.ReadByte()};
                                if(p.Doors[i].Flags>3) return false;
                            }
                            break;
                        case PacketKind.DoorToggle:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96); p.X=ReadFloat(r); p.Y=ReadFloat(r); p.Z=ReadFloat(r); p.Action=r.ReadByte();
                            if(p.Action>1) return false; break;
                        case PacketKind.WorldItems:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96);
                            int items=r.ReadByte(); if(items>MaxItemBatch) return false;
                            p.Items=new WorldItemFrame[items];
                            for(int i=0;i<items;i++) {
                                var it=new WorldItemFrame {HostId=r.ReadInt32(),ItemId=r.ReadInt32(),Amount=r.ReadInt32(),Kind=r.ReadByte(),Pose=ReadPose(r)};
                                if(it.HostId==0 || it.Kind>2 || it.Kind==0 && (it.ItemId<0 || it.ItemId>65535 || it.Amount<1 || it.Amount>1000000) ||
                                    it.Kind!=0 && (it.ItemId!=-1 || it.Amount!=0)) return false;
                                p.Items[i]=it;
                            }
                            break;
                        case PacketKind.Mark:
                            p.Sequence=r.ReadUInt32(); p.Scene=ReadText(r,96); p.Action=r.ReadByte(); p.Revision=r.ReadInt32();
                            p.CarIndex=r.ReadSByte(); p.X=ReadFloat(r); p.Y=ReadFloat(r); p.Z=ReadFloat(r);
                            if(p.Action>MarkPoint || p.Revision<1 || p.Revision>65535 || p.CarIndex < -1 || p.CarIndex>=MaxCars) return false;
                            if(p.CarIndex>=0 && (Math.Abs(p.X)>256 || Math.Abs(p.Y)>256 || Math.Abs(p.Z)>256)) return false;
                            break;
                        case PacketKind.Chat:
                            p.Sequence=r.ReadUInt32(); p.Action=r.ReadByte();
                            int chatBytes=r.ReadUInt16(); if(chatBytes>MaxChatBytes) return false;
                            var chat=r.ReadBytes(chatBytes); if(chat.Length!=chatBytes) return false;
                            p.Text=Text.GetString(chat);
                            if(!ValidChat(p.Sequence,p.Action,p.Text)) return false;
                            break;
                    }
                    if(WorldBound(kind) && (p.WorldEpoch==0 || p.Sequence==0 || string.IsNullOrEmpty(p.Scene))) return false;
                    if(s.Position!=s.Length) return false;
                    packet=p; return true;
                }
            }
            catch(Exception) { return false; }
        }
        // Messages about one world epoch and scene, numbered by their sender.
        internal static bool WorldBound(PacketKind kind)
        { return kind>=PacketKind.ZombieState && kind<=PacketKind.CombatReload || kind>=PacketKind.ZombieCorpse && kind<=PacketKind.Mark; }
        // The wire form of a chat packet: a message is 1..MaxChatChars UTF-16 units without
        // C0/C1 control characters (strict UTF-8 already excludes lone surrogates); an
        // acknowledgement has no text. Display always cleans again (LanChatChannel.Clean).
        internal static bool ValidChat(uint sequence,byte action,string text)
        {
            if(sequence==0 || action>1 || text==null) return false;
            if(action==1) return text.Length==0;
            if(text.Length==0 || text.Length>MaxChatChars) return false;
            foreach(char c in text) if(c<0x20 || c>=0x7F && c<=0x9F) return false;
            return true;
        }
        // Storage operations (LanStorage): 1 open (target, no handle), 2 take and 3 put
        // (handle and payload), 4 close (handle, no payload).
        // 0.7.0: 5 pick up a loose item, 6 drop an item, 7 work on the world, 8 craft at a host
        // workbench (no handle, payload). 0.8.0: 9 build on the host's train (no handle, payload).
        // 0.8.1: 10 place a blueprint on the host's train (no handle, payload).
        // 0.10.0: 11 use a control of the host's train (no handle, payload).
        // 0.12.0: 12 the guest died: everything it owns goes into a bag where it fell (no handle, payload).
        // 1.1.5: 13 cancel one queued craft of the open workbench (handle, payload).
        internal const byte StorageOpen=1, StorageTake=2, StoragePut=3, StorageClose=4, StoragePickup=5, StorageDrop=6, StorageWork=7, StorageCraft=8, StorageBuild=9, StoragePlace=10, StorageControl=11, StorageDeath=12, StorageCraftCancel=13, MaxStorageStatus=20;
        internal static bool ValidStorageRequest(byte op,int handle,int payload)
        {
            switch(op)
            {
                case StorageOpen: case StoragePickup: case StorageDrop: case StorageWork: case StorageCraft: case StorageBuild: case StoragePlace: case StorageControl: case StorageDeath: return handle==0 && payload>0;
                case StorageTake: case StoragePut: case StorageCraftCancel: return handle>0 && payload>0;
                case StorageClose: return handle>0 && payload==0;
                default: return false;
            }
        }
        private static float ReadFloat(BinaryReader r)
        {
            float v=r.ReadSingle();
            if(float.IsNaN(v)||float.IsInfinity(v)||Math.Abs(v)>=100000f) throw new InvalidDataException("Invalid coordinate");
            return v;
        }
        private static void WritePose(BinaryWriter w,NetPose p) { w.Write(p.X);w.Write(p.Y);w.Write(p.Z);w.Write(p.QX);w.Write(p.QY);w.Write(p.QZ);w.Write(p.QW); }
        private static NetPose ReadPose(BinaryReader r)
        {
            var p=new NetPose {X=ReadFloat(r),Y=ReadFloat(r),Z=ReadFloat(r),QX=ReadFloat(r),QY=ReadFloat(r),QZ=ReadFloat(r),QW=ReadFloat(r)};
            float n=p.QX*p.QX+p.QY*p.QY+p.QZ*p.QZ+p.QW*p.QW;
            if(n<0.9f || n>1.1f) throw new InvalidDataException("Invalid rotation");
            return p;
        }
        private static void WriteText(BinaryWriter w,string value,int maximum)
        {
            var b=Text.GetBytes(value??""); if(b.Length>maximum) throw new ArgumentException("LAN text field too long");
            w.Write((byte)b.Length); w.Write(b);
        }
        private static string ReadText(BinaryReader r,int maximum)
        {
            int length=r.ReadByte(); if(length>maximum) throw new InvalidDataException("LAN text field too long");
            var b=r.ReadBytes(length); if(b.Length!=length) throw new EndOfStreamException(); return Text.GetString(b);
        }
    }
}
